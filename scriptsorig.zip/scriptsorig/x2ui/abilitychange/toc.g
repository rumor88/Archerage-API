﻿## author : yoshimom
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## abilitychange

ability_change_view.lua
ability_change.lua