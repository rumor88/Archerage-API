function CreateAbilityChangeFrame(id, parent)
  local window = SetViewOfAbilityChangeFrame(id, parent)
  local MY_ABILITY_INDEX = 0
  local CHANGE_ABILITY_INDEX = 0
  local upperWindow = window.upperWindow
  local lowerWindow = window.lowerWindow
  local function EnableChangeButton(enable)
    local state = enable == nil and MY_ABILITY_INDEX ~= 0 and CHANGE_ABILITY_INDEX ~= 0 or enable
    window.buttonSet:UpdateButton("ok", {enable = state})
  end
  local function ResetMyAbilityButton()
    for i = 1, #upperWindow.abilityButton do
      local button = upperWindow.abilityButton[i]
      SetBGPushed(button, false)
    end
  end
  for i = 1, #upperWindow.abilityButton do
    local button = upperWindow.abilityButton[i]
    function button:OnClick()
      ResetMyAbilityButton()
      SetBGPushed(button, true)
      MY_ABILITY_INDEX = button.index
      EnableChangeButton()
    end
    button:SetHandler("OnClick", button.OnClick)
  end
  local function ResetAllAbilityButton()
    for i = 1, COMBAT_ABILITY_MAX - 1 do
      local button = lowerWindow.all_ability_button[i]
      SetBGPushed(button, false)
      local function OnEnter(self)
        SetTooltip(GetAbilityTooltip(i), self)
      end
      button:SetHandler("OnEnter", OnEnter)
    end
  end
  for j = 1, COMBAT_ABILITY_MAX - 1 do
    local button = lowerWindow.all_ability_button[j]
    function button:OnClick()
      ResetAllAbilityButton()
      SetBGPushed(button, true)
      CHANGE_ABILITY_INDEX = j
      EnableChangeButton()
    end
    button:SetHandler("OnClick", button.OnClick)
  end
  local function GetAbilityButtonText(isMyInfo, abilityType)
    if window.allAbilityInfos == nil then
      return
    end
    if isMyInfo then
      for i = 1, #window.allAbilityInfos do
        local info = window.allAbilityInfos[i]
        if info.level < ABILITY_ACTIVATION_LEVEL_3 then
          info.level = ABILITY_ACTIVATION_LEVEL_3
        end
        if abilityType == info.type then
          return string.format("%s(%d)", locale.common.abilityNameWithId(abilityType), info.level)
        end
      end
    else
      local info = window.allAbilityInfos[abilityType]
      if info.level < ABILITY_ACTIVATION_LEVEL_3 then
        info.level = ABILITY_ACTIVATION_LEVEL_3
      end
      return string.format("%s(%d)", locale.common.abilityNameWithId(abilityType), info.level)
    end
  end
  function window:Reset()
    MY_ABILITY_INDEX = 0
    CHANGE_ABILITY_INDEX = 0
    local myAbilityInfo = X2Ability:GetActiveAbility()
    for j = 1, COMBAT_ABILITY_MAX - 1 do
      lowerWindow.all_ability_button[j]:Enable(true)
      lowerWindow.all_ability_button[j]:SetText(GetAbilityButtonText(false, j))
    end
    for i = 1, MAX.MY_ABILITY_COUNT do
      if myAbilityInfo[i] ~= nil then
        local button = upperWindow.abilityButton[i]
        button:SetText(GetAbilityButtonText(true, myAbilityInfo[i].type))
        button.index = myAbilityInfo[i].type
        lowerWindow.all_ability_button[myAbilityInfo[i].type]:Enable(false)
      end
    end
    ResetMyAbilityButton()
    ResetAllAbilityButton()
    EnableChangeButton(false)
  end
  function window:ShowProc()
    local myAbilityInfo = X2Ability:GetActiveAbility()
    if #myAbilityInfo < 3 then
      self:Show(false)
      AddMessageToSysMsgWindow(GetUIText(ABILITY_CHANGER_TEXT, "req_activation_ability"))
      return
    end
    self.allAbilityInfos = X2Ability:GetAllCombatAbility()
    self:Reset()
  end
  window.buttonSet:UpdateButton("ok", {
    clickFunc = function()
      local abilityNames = locale.common.abilityNameWithId
      local ulcValidation, ulcType = X2LoginCharacter:CheckULCAbilityValidation(CHANGE_ABILITY_INDEX, false)
      if ulcValidation == false then
        local function DialogHandler(wnd)
          local ulcInfo = X2Player:GetULCInfo(ulcType)
          wnd:SetTitle(GetUIText(ABILITY_CHANGER_TEXT, "title"))
          local textData = {
            [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("notice_ulc_ability", abilityNames(CHANGE_ABILITY_INDEX), ulcInfo.name)
          }
          local textbox = W_MODULE:Create("textbox", wnd, W_MODULE.TYPES.TEXTBOX, textData)
          wnd:RegisterStack(textbox)
        end
        X2DialogManager:RequestDialog(DialogHandler, window:GetId(), {buttonType = DBT_OK})
      else
        local function DialogHandler(wnd)
          local changeCost = X2Ability:CanBuyAbilityChange()
          wnd:SetTitle(GetUIText(ABILITY_CHANGER_TEXT, "title"))
          local changeData = {
            titleInfo = {
              title = GetUIText(ABILITY_CHANGER_TEXT, "title")
            },
            left = {
              UpdateValueFunc = function(leftValueWidget)
                leftValueWidget:SetText(abilityNames(MY_ABILITY_INDEX))
              end
            },
            right = {
              UpdateValueFunc = function(rightValueWidget)
                rightValueWidget:SetText(abilityNames(CHANGE_ABILITY_INDEX))
              end
            }
          }
          local abilityExchange = W_MODULE:Create("abilityExchange", wnd, W_MODULE.TYPES.CHANGE_BOX_A, changeData)
          wnd:RegisterStack(abilityExchange)
          local data = {
            [W_MODULE.ATTRIBUTE.TYPE] = "cost",
            [W_MODULE.ATTRIBUTE.CURRENCY] = F_MONEY.currency.abilityChange,
            [W_MODULE.ATTRIBUTE.VALUE] = changeCost
          }
          local cost = W_MODULE:Create("cost", wnd, W_MODULE.TYPES.VALUE_BOX_DIALOG, data)
          wnd:RegisterStack(cost)
          function wnd:OkProc()
            X2Ability:SwapAbility(MY_ABILITY_INDEX, CHANGE_ABILITY_INDEX)
          end
          function wnd:GetOkSound()
            return "event_message_box_ability_change_onok"
          end
        end
        X2DialogManager:RequestDialog(DialogHandler, window:GetId())
      end
    end
  })
  window.buttonSet:UpdateButton("cancel", {
    clickFunc = function()
      window:Show(false)
    end
  })
  return window
end
local abilityChangeFrame = CreateAbilityChangeFrame("abilityChangeFrame", "UIParent")
abilityChangeFrame:AddAnchor("CENTER", "UIParent", 0, 0)
ADDON:RegisterContentWidget(UIC_ABILITY_CHANGE, abilityChangeFrame)
local abilityChangeEvents = {
  ABILITY_CHANGED = function()
    abilityChangeFrame:Reset()
  end,
  TARGET_CHANGED = function()
    abilityChangeFrame:Show(false)
  end,
  ENTERED_WORLD = function()
    abilityChangeFrame:Reset()
  end
}
abilityChangeFrame:SetHandler("OnEvent", function(this, event, ...)
  abilityChangeEvents[event](...)
end)
RegistUIEvent(abilityChangeFrame, abilityChangeEvents)
