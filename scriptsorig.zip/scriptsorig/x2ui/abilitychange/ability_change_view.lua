function SetViewOfAbilityChangeFrame(id, parent)
  local window = CreateWindow(id, parent)
  window:SetWidth(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_600))
  window:SetTitle(GetUIText(ABILITY_CHANGER_TEXT, "title"))
  window:SetSounds("ability_change")
  local contentWidth = window:GetWidth() - MARGIN.WINDOW_SIDE * 2
  local upperWindow = window:CreateChildWidget("emptywidget", "upperWindow", 0, true)
  upperWindow:Show(true)
  local line = CreateLine(upperWindow, "TYPE1")
  line:AddAnchor("TOPLEFT", upperWindow, "BOTTOMLEFT", 0, 0)
  line:AddAnchor("TOPRIGHT", upperWindow, "BOTTOMRIGHT", 0, 0)
  local MY_ABILITY_BUTTON_STYLE = {
    drawableType = "drawable",
    path = "ui/button/ability_button.dds",
    coordsKey = "btn_abillity",
    drawableColorKey = "default",
    fontColor = GetMyAbilityButtonFontColor(),
    fontSize = FONT_SIZE.LARGE
  }
  local x = 0
  local upperHeight = 0
  for i = 1, MAX.MY_ABILITY_COUNT do
    local abilityButton = upperWindow:CreateChildWidget("button", "abilityButton", i, true)
    abilityButton:AddAnchor("TOPLEFT", upperWindow, x, 0)
    ApplyButtonSkin(abilityButton, MY_ABILITY_BUTTON_STYLE)
    x = x + abilityButton:GetWidth() + 14
    if upperHeight == 0 then
      upperHeight = abilityButton:GetHeight()
    end
  end
  local width, _ = F_LAYOUT.GetExtentWidgets(upperWindow.abilityButton[1], upperWindow.abilityButton[MAX.MY_ABILITY_COUNT])
  upperWindow:SetExtent(width, upperHeight + 13)
  window:RegisterStack(upperWindow)
  local lowerWindow = window:CreateChildWidget("emptywidget", "lowerWindow", 0, true)
  lowerWindow:Show(true)
  lowerWindow:SetExtent(contentWidth, 70)
  local subTitleBg = lowerWindow:CreateDrawable(TEXTURE_PATH.DEFAULT, "type_05", "background")
  subTitleBg:SetTextureColor("brown")
  subTitleBg:SetExtent(370, 38)
  subTitleBg:AddAnchor("TOP", lowerWindow, 0, 5)
  local subTitle = lowerWindow:CreateChildWidget("label", "subTitle", 0, false)
  subTitle:SetHeight(FONT_SIZE.LARGE)
  subTitle:SetAutoResize(true)
  subTitle.style:SetColorByKey("default")
  subTitle.style:SetFontSize(FONT_SIZE.LARGE)
  subTitle:AddAnchor("CENTER", subTitleBg, 0, 0)
  subTitle:SetText(GetUIText(COMMON_TEXT, "select_ability"))
  local offset = 10
  local leftDeco = lowerWindow:CreateDrawable(TEXTURE_PATH.SKILL_ABILITY, "select_bg_deco_left", "artwork")
  leftDeco:AddAnchor("RIGHT", subTitle, "LEFT", -offset, 0)
  local rightDeco = lowerWindow:CreateDrawable(TEXTURE_PATH.SKILL_ABILITY, "select_bg_deco_right", "artwork")
  rightDeco:AddAnchor("LEFT", subTitle, "RIGHT", offset, 0)
  local x = 0
  local startOffset = subTitleBg:GetHeight() + 9
  local y = startOffset
  for j = 1, COMBAT_ABILITY_MAX - 1 do
    local all_ability_button = lowerWindow:CreateChildWidget("button", "all_ability_button", j, true)
    all_ability_button:SetText(locale.common.abilityNameWithId(j))
    ApplyButtonSkin(all_ability_button, BUTTON_CONTENTS.ALL_ABILITY)
    all_ability_button:AddAnchor("TOPLEFT", lowerWindow, x, y)
    if j % 3 == 0 then
      x = 0
      y = y + all_ability_button:GetHeight() + 7
    else
      x = x + all_ability_button:GetWidth() + 23
    end
  end
  local _, height = F_LAYOUT.GetExtentWidgets(lowerWindow.all_ability_button[1], lowerWindow.all_ability_button[#lowerWindow.all_ability_button])
  lowerWindow:SetExtent(contentWidth, height + startOffset)
  window.allAbilityInfos = X2Ability:GetAllCombatAbility()
  window:RegisterStack(lowerWindow, 5)
  local buttonSet = W_MODULE:Create("buttonSet", window, W_MODULE.TYPES.BUTTON_SET)
  buttonSet:AddButton("ok", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "ok"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER
  })
  buttonSet:AddButton("cancel", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "cancel"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER
  })
  window:RegisterStack(buttonSet)
  window:ApplyAutoHeightByStack()
  return window
end
