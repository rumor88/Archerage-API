local CraeteBlessUthstinWindow = function(id, parent)
  local window = SetViewOfBlessUthstinWindow(id, parent)
  local blessUthstinInfo
  local function GetBlessUthstinDefault(key)
    return blessUthstinInfo[string.format("default_%s", key)]
  end
  local function GetBlessUthstinApplied(key)
    return blessUthstinInfo[string.format("applied_%s", key)]
  end
  local function GetBlessUthstinTotalAppliedStats()
    return blessUthstinInfo.totalappliedStats
  end
  local function GetBlessUthstinMaxStats()
    return blessUthstinInfo.MaxStats
  end
  local function GetBlessUthstinApplyCount()
    return blessUthstinInfo.applyCount
  end
  local function GetBlessUthstinApplySpecialCount()
    return blessUthstinInfo.applySpecialCount
  end
  local function GetBlessUthstinExtendMaxStatsLimit()
    return blessUthstinInfo.extendMaxStatsLimit
  end
  local function GetBlessUthstinApplyCountLimit()
    return blessUthstinInfo.applyCountLimit
  end
  local function UpdateDailyUsageCount()
    window:UpdateDailyUsageCount(GetBlessUthstinApplyCount(), GetBlessUthstinApplyCountLimit(), GetBlessUthstinApplySpecialCount())
  end
  local function UpdateApplicableStatInfo()
    window:UpdateApplicableStatInfo(GetBlessUthstinTotalAppliedStats(), GetBlessUthstinMaxStats(), GetBlessUthstinExtendMaxStatsLimit())
  end
  local function UpdateStats()
    local infos = {}
    for i, v in ipairs(window.statsTable) do
      table.insert(infos, {
        applied = GetBlessUthstinApplied(v),
        default = GetBlessUthstinDefault(v)
      })
    end
    window:UpdateStatDetail(infos)
  end
  local function UpdateTab()
    local activatedPageNum = X2BlessUthstin:GetActivatedPageNumber()
    local selectedTab = window.tab:GetSelectedTab()
    local pageCount = X2BlessUthstin:GetPageCount()
    local maxPageCount = X2BlessUthstin:GetMaxPageCount()
    for i = 1, maxPageCount do
      if i <= pageCount then
        window.tab:ShowTab(i)
      else
        window.tab:HideTab(i)
      end
    end
    if pageCount < maxPageCount then
      window.expandBtn:Show(true)
      window.expandBtn:AddAnchor("BOTTOMLEFT", window.tab.selectedButton[pageCount], "BOTTOMRIGHT", 0, 0)
    else
      window.expandBtn:Show(false)
    end
    window:UpdateTab(selectedTab, activatedPageNum)
  end
  local function UpdateInitButton()
    window.buttonSet:UpdateButton("init", {
      enable = GetBlessUthstinTotalAppliedStats() > 0 and true or false
    })
  end
  local function UpdateBottomButtons()
    UpdateInitButton()
    local tabNum = window.tab:GetSelectedTab()
    local activatedPageNum = X2BlessUthstin:GetActivatedPageNumber()
    window.buttonSet:UpdateButton("activate", {
      enable = tabNum ~= activatedPageNum
    })
    local pageCount = X2BlessUthstin:GetPageCount()
    window.buttonSet:UpdateButton("copy", {
      enable = pageCount > 1
    })
  end
  window.buttonSet:UpdateButton("activate", {
    clickFunc = function()
      local function DialogHandler(wnd, infoTable)
        local activatedPageNum = X2BlessUthstin:GetActivatedPageNumber()
        local selectCost = X2BlessUthstin:GetSelectCost()[string.format("page%d", activatedPageNum)]
        wnd:SetTitle(GetCommonText("bless_uthstin_acitvation_popup_title"))
        local headerTable = W_MODULE:Create("headerTable", wnd, W_MODULE.TYPES.HEADER_TABLE_C, {
          title = GetUIText(COMMON_TEXT, "bless_uthstin_acitvation_table_title")
        })
        for i = 1, #window.statsTable do
          local key = window.statsTable[i]
          local value = GetBlessUthstinApplied(window.statsTable[i])
          local colorKey, valueStr
          if value < 0 then
            valueStr = tostring(value)
            colorKey = "red"
          else
            if value > 0 then
              valueStr = F_TEXT.SetSignFormat(true, value)
            else
              valueStr = tostring(value)
            end
            colorKey = "blue"
          end
          headerTable:AddRow(key, {
            title = {
              string = X2Locale:LocalizeUiText(ATTRIBUTE_TEXT, key)
            },
            value = {string = valueStr, colorKey = colorKey}
          })
        end
        wnd:RegisterStack(headerTable)
        local costValue = W_MODULE:Create("cost", wnd, W_MODULE.TYPES.VALUE_BOX_DIALOG, {
          [W_MODULE.ATTRIBUTE.TYPE] = "cost",
          [W_MODULE.ATTRIBUTE.VALUE] = tonumber(selectCost)
        })
        wnd:RegisterStack(costValue)
        function wnd:OkProc()
          local tabNum = window.tab:GetSelectedTab()
          X2BlessUthstin:SelectBlessUthstinPage(tabNum)
        end
      end
      X2DialogManager:RequestDialog(DialogHandler, window:GetId())
    end
  })
  local function SetSlot()
    if window:IsVisible() == false then
      window:Update()
      window:Show(true)
    end
    window:UpdateSlot(X2BlessUthstin:GetBlessUthstinItemInfo())
  end
  local function ClearSlot()
    window:UpdateSlot(nil)
  end
  function window.tab:OnTabChangedProc(idx)
    window:Update()
    X2BlessUthstin:SetPreviewPageNumber(idx)
    ClearSlot()
    X2BlessUthstin:ClearItemSlot()
  end
  local Events = {
    BLESS_UTHSTIN_UPDATE_STATS = function()
      window:Update()
    end,
    BLESS_UTHSTIN_ITEM_SLOT_SET = function(msgapplycountlimit)
      SetSlot()
      if msgapplycountlimit ~= nil then
        AddMessageToSysMsgWindow(GetCommonText("bless_uthstin_limit_appy_count"))
      end
    end,
    BLESS_UTHSTIN_ITEM_SLOT_CLEAR = function()
      ClearSlot()
    end,
    BLESS_UTHSTIN_WILL_APPLY_STATS = function(itemType, incStatsKind, decStatsKind, incStatsPoint, decStatsPoint)
      window.willItemType = itemType
      window.willincStatsKind = incStatsKind
      window.willdecStatsKind = decStatsKind
      window.willincStatsPoint = incStatsPoint
      window.willdecStatsPoint = decStatsPoint
      window:WillApplyStats()
    end,
    BLESS_UTHSTIN_EXTEND_MAX_STATS = function()
      window:Update()
    end
  }
  window:SetHandler("OnEvent", function(this, event, ...)
    Events[event](...)
  end)
  RegistUIEvent(window, Events)
  function window:Update()
    blessUthstinInfo = X2Unit:GetBlessUthstinInfo("player", window.tab:GetSelectedTab())
    UpdateTab()
    UpdateDailyUsageCount()
    UpdateStats()
    UpdateApplicableStatInfo()
    UpdateBottomButtons()
  end
  local function ApplyStatsButtonClickFunc()
    local itemInfo = X2BlessUthstin:GetBlessUthstinItemInfo()
    if itemInfo == nil then
      return
    end
    local errorType
    local defaultStatsTable = {
      "default_str",
      "default_dex",
      "default_sta",
      "default_int",
      "default_spi"
    }
    local appliedStatsTable = {
      "applied_str",
      "applied_dex",
      "applied_sta",
      "applied_int",
      "applied_spi"
    }
    local defaultUnderCount = 0
    local dropStatKindCount = 0
    local dropOnlyOneKind = -1
    local riseStatKindCount = 0
    local riseOnlyOneKind = -1
    for i = 1, #defaultStatsTable do
      if 0 > blessUthstinInfo[defaultStatsTable[i]] + blessUthstinInfo[appliedStatsTable[i]] - itemInfo.decpoint then
        defaultUnderCount = defaultUnderCount + 1
      elseif 0 < itemInfo.weight[i].drop then
        dropStatKindCount = dropStatKindCount + 1
        dropOnlyOneKind = i
      end
    end
    for i = 1, #defaultStatsTable do
      if 0 < itemInfo.weight[i].rise then
        riseStatKindCount = riseStatKindCount + 1
        riseOnlyOneKind = i
      end
    end
    if dropStatKindCount <= 0 then
      errorType = 1
    end
    if dropStatKindCount > 1 then
      dropOnlyOneKind = -1
    end
    if defaultUnderCount > 3 then
      errorType = 1
    end
    if riseStatKindCount > 1 then
      riseOnlyOneKind = -1
    end
    if dropOnlyOneKind >= 0 then
      if 0 > blessUthstinInfo[defaultStatsTable[dropOnlyOneKind]] + blessUthstinInfo[appliedStatsTable[dropOnlyOneKind]] - itemInfo.decpoint then
        errorType = 1
      end
      if 0 < itemInfo.weight[dropOnlyOneKind].rise then
        errorType = 2
      end
    end
    if GetBlessUthstinTotalAppliedStats() + itemInfo.incpoint > GetBlessUthstinMaxStats() then
      if dropOnlyOneKind >= 0 then
        local appliedStatsAfterChange = 0
        for i = 1, #defaultStatsTable do
          local tempStat = blessUthstinInfo[appliedStatsTable[i]]
          if i == dropOnlyOneKind then
            tempStat = tempStat - itemInfo.decpoint
          elseif i == riseOnlyOneKind then
            tempStat = tempStat + itemInfo.incpoint
          end
          if tempStat > 0 then
            appliedStatsAfterChange = appliedStatsAfterChange + tempStat
          end
        end
        if riseOnlyOneKind < 0 then
          appliedStatsAfterChange = appliedStatsAfterChange + itemInfo.incpoint
        end
        if appliedStatsAfterChange > GetBlessUthstinMaxStats() then
          errorType = 3
        end
      elseif dropOnlyOneKind < 0 or 0 > blessUthstinInfo[appliedStatsTable[dropOnlyOneKind]] - itemInfo.decpoint then
        errorType = 3
      end
    end
    if errorType ~= nil then
      local function DialogHandler(wnd)
        wnd:SetTitle(GetUIText(WINDOW_TITLE_TEXT, "bless_uthstin"))
        local content
        if errorType == 1 then
          content = GetCommonText("bless_uthstin_cannot_appy")
        elseif errorType == 2 then
          content = GetCommonText("bless_uthstin_wrong_item_data")
        elseif errorType == 3 then
          content = GetCommonText("bless_uthstin_cannot_appy_overflow")
        end
        local textData = {
          [W_MODULE.ATTRIBUTE.TEXT] = content
        }
        local textbox = W_MODULE:Create("textbox", wnd, W_MODULE.TYPES.TEXTBOX, textData)
        wnd:RegisterStack(textbox)
        if errorType == 3 then
          wnd:RegisterStack(W_MODULE:Create("titleBox", wnd, W_MODULE.TYPES.SCROLL_TITLE_BOX, {
            titleInfo = {
              title = GetUIText(COMMON_TEXT, "bless_uthstin_cannot_appy_overflow_title")
            },
            [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "bless_uthstin_cannot_appy_overflow_content")
          }))
        end
      end
      X2DialogManager:RequestDialog(DialogHandler, window:GetParent():GetId(), {buttonType = DBT_OK})
    else
      do
        local tabNum = window.tab:GetSelectedTab()
        local item = X2BlessUthstin:GetApplyStatsItemInfo(tabNum)
        if item == nil then
          return
        end
        local function DialogHandler(wnd)
          wnd:SetTitle(GetUIText(WINDOW_TITLE_TEXT, "bless_uthstin"))
          local data = {
            itemInfo = X2Item:GetItemInfoByType(item.itemType),
            stack = {
              item.has,
              item.need
            }
          }
          local itemIcon = W_MODULE:Create("itemIcon", wnd, W_MODULE.TYPES.ICON_VERTICAL, data)
          wnd:RegisterStack(itemIcon)
          function wnd:OkProc()
            X2BlessUthstin:UseApplyStatsItem(tabNum)
          end
        end
        X2DialogManager:RequestDialog(DialogHandler, window:GetParent():GetId())
      end
    end
  end
  ButtonOnClickHandler(window.applyBtn, ApplyStatsButtonClickFunc)
  function window:WillApplyStats()
    local popupwnd = CreateWindow("applyStatsWnd", "UIParent")
    popupwnd:SetWidth(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_350))
    popupwnd:AddAnchor("CENTER", "UIParent", 0, 0)
    popupwnd:SetTitle(GetUIText(WINDOW_TITLE_TEXT, "bless_uthstin"))
    popupwnd:EnableHidingIsRemove(true)
    popupwnd:SetWindowModal(true)
    local headerTable = W_MODULE:Create("headerTable", popupwnd, W_MODULE.TYPES.HEADER_TABLE_C, {
      title = GetUIText(COMMON_TEXT, "bless_uthstin_apply_table_title")
    })
    headerTable:AddRow("stats_inc", {
      title = {
        string = X2Locale:LocalizeUiText(ATTRIBUTE_TEXT, self.statsTable[self.willincStatsKind])
      },
      value = {
        string = F_TEXT.SetSignFormat(true, self.willincStatsPoint),
        colorKey = "blue"
      }
    })
    headerTable:AddRow("stats_dec", {
      title = {
        string = X2Locale:LocalizeUiText(ATTRIBUTE_TEXT, self.statsTable[self.willdecStatsKind])
      },
      value = {
        string = string.format("-%d", self.willdecStatsPoint),
        colorKey = "red"
      }
    })
    popupwnd:RegisterStack(headerTable)
    local textBox = W_MODULE:Create("textBox", popupwnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "bless_uthstin_will_apply_notice2"),
      type = "warning"
    })
    popupwnd:RegisterStack(textBox)
    local function PopupWndOkProc()
      local tabNum = window.tab:GetSelectedTab()
      X2BlessUthstin:ApplyStats(false, window.willItemType, window.willincStatsKind, window.willdecStatsKind, window.willincStatsPoint, window.willdecStatsPoint, tabNum)
      popupwnd:Show(false)
      SetSlot()
      window:Update()
    end
    local buttonSet = W_MODULE:Create("buttonSet", popupwnd, W_MODULE.TYPES.BUTTON_SET)
    buttonSet:AddButton("okButton", {
      [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "ok"),
      [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
      clickFunc = function()
        local tabNum = self.tab:GetSelectedTab()
        X2BlessUthstin:ApplyStats(true, self.willItemType, self.willincStatsKind, self.willdecStatsKind, self.willincStatsPoint, self.willdecStatsPoint, tabNum)
        popupwnd:Show(false)
        ClearSlot()
      end
    })
    buttonSet:AddButton("cancelButton", {
      [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "cancel"),
      [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
      clickFunc = function()
        local function DialogHandler(popupwnd)
          popupwnd:SetTitle(GetUIText(WINDOW_TITLE_TEXT, "bless_uthstin"))
          local textData = {
            [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "bless_uthstin_cancel_dialog_content")
          }
          local textbox = W_MODULE:Create("textbox", popupwnd, W_MODULE.TYPES.TEXTBOX, textData)
          popupwnd:RegisterStack(textbox)
          function popupwnd:OkProc()
            PopupWndOkProc()
          end
        end
        X2DialogManager:RequestDialog(DialogHandler, UIParent:GetId())
      end
    })
    popupwnd:RegisterStack(buttonSet)
    popupwnd:ApplyAutoHeightByStack()
    popupwnd:Show(true)
    self.popUp = popupwnd
    window.applyBtn:Enable(false)
    self.buttonSet:UpdateButton("init", {enable = false})
    popupwnd:SetHandler("OnCloseByEsc", PopupWndOkProc)
    local function OnHide()
      UpdateInitButton()
    end
    popupwnd:SetHandler("OnHide", OnHide)
    function popupwnd:OnDeleted()
      window.popUp = nil
    end
    popupwnd:SetDeletedHandler(popupwnd.OnDeleted)
  end
  local function OnHide()
    ClearSlot()
    if window.popUp ~= nil then
      window.popUp:Show(false)
    end
    X2BlessUthstin:ClearItemSlot()
    X2BlessUthstin:LeaveBlessUthstin()
  end
  window:SetHandler("OnHide", OnHide)
  function window:ShowProc()
    X2BlessUthstin:EnterBlessUthstin()
    self.tab:SelectTab(X2BlessUthstin:GetActivatedPageNumber())
    self:Update()
  end
  return window
end
if X2Player:GetFeatureSet().bless_uthstin then
  local blessUthstinWindow = CraeteBlessUthstinWindow("blessUthstinWindow", "UIParent")
  ADDON:RegisterContentWidget(UIC_BLESS_UTHSTIN, blessUthstinWindow)
end
