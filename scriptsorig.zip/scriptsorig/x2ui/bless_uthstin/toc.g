﻿## author : yoshimom
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## bless_uthstin

view.lua
logic.lua
dialog.lua