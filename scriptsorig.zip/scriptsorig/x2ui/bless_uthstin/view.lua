function SetViewOfBlessUthstinWindow(id, parent)
  local window = CreateWindow(id, parent, "bless_uthstin")
  window:SetExtent(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_430), 720)
  window:AddAnchor("CENTER", "UIParent", 0, 0)
  window:SetTitle(GetUIText(WINDOW_TITLE_TEXT, "bless_uthstin"))
  window.statsTable = X2BlessUthstin:GetStatInfo()
  local contentWidth = window:GetWidth() - MARGIN.WINDOW_SIDE * 2
  local uppserSection = window:CreateChildWidget("emptywidget", "upperSection", 0, true)
  uppserSection:Show(true)
  local deco = uppserSection:CreateDrawable("ui/character/slot_red.dds", "slot_red", "background")
  deco:AddAnchor("TOP", uppserSection, -1, 0)
  window:RegisterStack(uppserSection)
  local offset = 25
  local itemIcon = W_MODULE:Create("itemIcon", window, W_MODULE.TYPES.ICON_VERTICAL, nil, {
    [W_MODULE.ATTRIBUTE.ICON_SIZE] = ICON_SIZE.XLARGE,
    [W_MODULE.ATTRIBUTE.ICON_CLICK_FUNC] = function(arg, iconInfo)
      if arg == "LeftButton" then
        if X2Cursor:GetCursorPickedBagItemIndex() ~= 0 then
          X2BlessUthstin:SetBlessUthstinItemSlotFromPick()
        end
      else
        X2BlessUthstin:ClearItemSlot()
      end
    end,
    [W_MODULE.ATTRIBUTE.REGISTER_CLICK] = {
      {
        mouseButton = "RightButton"
      }
    },
    [W_MODULE.ATTRIBUTE.ICON_ON_ENTER_PROC] = function(self, info)
      if info == nil then
        SetTooltip(X2Locale:LocalizeUiText(TOOLTIP_TEXT, "uthstion_item_slot_tooltip_desc"), self)
        return
      end
    end
  })
  itemIcon:AddAnchor("TOP", uppserSection, 0, offset)
  local applyBtn = window:CreateChildWidget("button", "applyBtn", 0, true)
  applyBtn:SetText(X2Locale:LocalizeUiText(COMMON_TEXT, "apply"))
  applyBtn:SetStyle("text_default")
  applyBtn:Enable(false)
  applyBtn:AddAnchor("TOP", itemIcon, "BOTTOM", 0, 7)
  local _, height = F_LAYOUT.GetExtentWidgets(itemIcon, applyBtn)
  uppserSection:SetExtent(contentWidth, height + offset)
  local tab = W_TAB.CreateTab("tab", window, "uthstin_page_tab")
  tab:RemoveAllAnchors()
  tab:SetExtent(contentWidth, 340)
  tab:AddTabs({
    "1",
    "2",
    "3",
    "4",
    "5",
    "6"
  })
  window:RegisterStack(tab, 10)
  local expandBtn = window:CreateChildWidget("button", "expandBtn", 0, true)
  expandBtn:SetText("+")
  ApplyButtonSkin(expandBtn, BUTTON_BASIC.TAB_UNSELECT)
  expandBtn:SetExtent(27, 25)
  local OnEnterButtonExpand = function(self)
    SetTooltip(GetCommonText("expand_slot_count"), self)
  end
  expandBtn:SetHandler("OnEnter", OnEnterButtonExpand)
  local function OnClickExpandPage()
    ShowBlessUthstinExpandDialog(window:GetId())
  end
  expandBtn:SetHandler("OnClick", OnClickExpandPage)
  local uthstinPageCheck = F_TEXTURE.CreateCheckIcon(tab)
  uthstinPageCheck:AddAnchor("TOPRIGHT", tab.selectedButton[6], 0, 0)
  tab.uthstinPageCheck = uthstinPageCheck
  local previewText = window:CreateChildWidget("label", "previewText", 0, true)
  previewText:SetHeight(FONT_SIZE.MIDDLE)
  previewText:SetAutoResize(true)
  previewText:AddAnchor("TOPRIGHT", tab, 0, 10)
  previewText.style:SetColorByKey("blue")
  previewText:SetText(X2Locale:LocalizeUiText(COMMON_TEXT, "bless_uthstin_preview"))
  local dailyUsageCountHeaderTable = W_MODULE:Create("dailyUsageCountHeaderTable", tab, W_MODULE.TYPES.HEADER_TABLE_C, {
    title = GetCommonText("bless_uthstin_today_usable_item_count")
  }, {
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = contentWidth
  })
  tab:RegisterStack(0, dailyUsageCountHeaderTable)
  dailyUsageCountHeaderTable:AddRow("normal", {
    title = {
      string = GetUIText(COMMON_TEXT, "bless_uthstin_normal_item_name")
    },
    value = {string = "0/0"}
  })
  dailyUsageCountHeaderTable:AddRow("cash", {
    title = {
      string = GetUIText(COMMON_TEXT, "bless_uthstin_cash_item_name")
    },
    value = {string = "0"}
  })
  function window:UpdateDailyUsageCount(count, limit, specialCount)
    dailyUsageCountHeaderTable:UpdateRow("normal", {
      value = {
        string = F_TEXT.SetSlashFormat(count, limit)
      }
    })
    dailyUsageCountHeaderTable:UpdateRow("cash", {
      value = {
        string = tostring(specialCount)
      }
    })
  end
  local applicableStatInfoHeaderTable = W_MODULE:Create("applicableStatInfoHeaderTable", tab, W_MODULE.TYPES.HEADER_TABLE_C, {
    title = GetUIText(COMMON_TEXT, "applied_stat_info"),
    [W_MODULE.ATTRIBUTE.GUIDE_TOOLTIP] = GetCommonText("bless_uthstin_help")
  }, {
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = contentWidth
  })
  tab:RegisterStack(0, applicableStatInfoHeaderTable)
  local GetMaxString = function(cur, max)
    return F_TEXT.SetSlashFormat(cur, max)
  end
  applicableStatInfoHeaderTable:AddRow("stat", {
    title = {
      string = GetUIText(COMMON_TEXT, "bless_uthstin_inc_max_stats")
    },
    value = {
      [W_MODULE.ATTRIBUTE.CREATE_ROW_FUNC] = function(valueWidgetName, valueMaxWidth, rowFrame)
        local rowValue = rowFrame:CreateChildWidget("emptywidget", valueWidgetName, 0, true)
        local increaseButton = rowValue:CreateChildWidget("button", "increaseButton", 0, true)
        increaseButton:AddAnchor("RIGHT", rowFrame, 0, 0)
        increaseButton:SetStyle("uthstin_stat_max_expand")
        rowValue:SetExtent(valueMaxWidth, FONT_SIZE.MIDDLE)
        local OnEnter = function(self)
          SetTooltip(GetCommonText("bless_uthstin_button_tooltip_increase_max"), self)
        end
        increaseButton:SetHandler("OnEnter", OnEnter)
        local function IncMaxButtonLeftClickFunc()
          local DialogHandler = function(wnd)
            wnd:SetTitle(GetUIText(COMMON_TEXT, "bless_uthstin_inc_max_stats2"))
            local textData = {
              [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "bless_uthstin_inc_max_notice2")
            }
            local textbox = W_MODULE:Create("textbox", wnd, W_MODULE.TYPES.TEXTBOX, textData)
            wnd:RegisterStack(textbox)
            local item = X2BlessUthstin:GetBlessUthstinIncreaseMax()
            local data = {
              itemInfo = X2Item:GetItemInfoByType(item.itemType),
              stack = {
                item.has,
                item.need
              }
            }
            local itemIcon = W_MODULE:Create("itemIcon", wnd, W_MODULE.TYPES.ICON_VERTICAL, data)
            wnd:RegisterStack(itemIcon)
            function wnd:OkProc()
              X2BlessUthstin:UseBlessUthstinExtendMaxStats()
            end
          end
          X2DialogManager:RequestDialog(DialogHandler, window:GetParent():GetId())
        end
        increaseButton:SetHandler("OnClick", IncMaxButtonLeftClickFunc)
        local offset = 7
        local statString = rowValue:CreateChildWidget("textbox", "statString", 0, true)
        statString:SetExtent(valueMaxWidth - increaseButton:GetWidth() - offset, FONT_SIZE.MIDDLE)
        statString:AddAnchor("RIGHT", increaseButton, "LEFT", -offset, 0)
        statString.style:SetColorByKey("default")
        statString.style:SetAlign(ALIGN_RIGHT)
        statString:SetText(GetMaxString(0, 0))
        return rowValue
      end
    }
  })
  local GetApplicableValueString = function(incValue, decValue)
    return string.format("%s%s, %s%s", F_COLOR.GetColor("blue", true), incValue, F_COLOR.GetColor("red", true), decValue)
  end
  applicableStatInfoHeaderTable:AddRow("ableStat", {
    title = {
      string = GetUIText(COMMON_TEXT, "bless_uthstin_applicable_stats")
    },
    value = {
      string = GetApplicableValueString(0, 0)
    }
  })
  applicableStatInfoHeaderTable:AddRow("lineRow", {
    [W_MODULE.ATTRIBUTE.LINE_ROW] = true
  })
  for i, v in ipairs(window.statsTable) do
    applicableStatInfoHeaderTable:AddRow(v, {
      title = {
        string = X2Locale:LocalizeUiText(ATTRIBUTE_TEXT, v)
      },
      value = {string = "-"}
    })
  end
  function window:UpdateTab(selectedTabIdx, activateTabIdx)
    uthstinPageCheck:RemoveAllAnchors()
    uthstinPageCheck:AddAnchor("BOTTOMRIGHT", tab.selectedButton[activateTabIdx], "TOPRIGHT", 0, 13)
    previewText:Show(selectedTabIdx ~= activateTabIdx)
    dailyUsageCountHeaderTable:SetData({
      title = GetCommonText("bless_uthstin_today_usable_item_count"),
      [W_MODULE.ATTRIBUTE.GUIDE_TOOLTIP] = GetCommonText("bless_uthstin_button_tooltip_cash_item", X2BlessUthstin:GetCashItemNeedCount(selectedTabIdx))
    })
  end
  function window:UpdateApplicableStatInfo(cur, extended, max)
    applicableStatInfoHeaderTable:UpdateRow("stat", {
      value = {
        [W_MODULE.ATTRIBUTE.UPDATE_ROW_FUNC] = function(valueWidget)
          valueWidget.increaseButton:Enable(extended < max)
          valueWidget.statString:SetText(GetMaxString(cur, extended))
        end
      }
    })
  end
  function window:UpdateStatDetail(values)
    for i, v in ipairs(window.statsTable) do
      if values[i] ~= nil then
        local default = values[i].default
        local applied = values[i].applied
        local colorKey = tonumber(applied) < 0 and "red" or "blue"
        local sign = tonumber(applied) < 0 and "" or "+"
        applicableStatInfoHeaderTable:UpdateRow(v, {
          value = {
            string = string.format("%s (%s%s%s%s|r)", default + applied, default, F_COLOR.GetColor(colorKey, true), sign, applied)
          }
        })
      end
    end
  end
  function window:UpdateSlot(itemInfo)
    if itemInfo ~= nil then
      itemIcon:SetData({
        itemInfo = itemInfo,
        stack = {
          itemInfo.hasCount,
          itemInfo.needCount
        }
      })
      if itemInfo.itemfunction == 0 then
        deco:SetTexture("ui/character/slot_red.dds")
      else
        deco:SetTexture("ui/character/slot_blue.dds")
      end
      applicableStatInfoHeaderTable:UpdateRow("ableStat", {
        value = {
          string = GetApplicableValueString(itemInfo.incpoint, itemInfo.decpoint)
        }
      })
      applyBtn:Enable(true)
    else
      itemIcon:SetData({itemInfo = nil})
      deco:SetTexture("ui/character/slot_red.dds")
      applicableStatInfoHeaderTable:UpdateRow("ableStat", {
        value = {
          string = GetApplicableValueString(0, 0)
        }
      })
      applyBtn:Enable(false)
    end
  end
  tab:ApplyAutoHeightByStack()
  local buttonSet = W_MODULE:Create("buttonSet", window, W_MODULE.TYPES.BUTTON_SET)
  local GetInitButtonTooltip = function()
    local item = X2BlessUthstin:GetBlessUthstinInitItemInfo()
    if item == nil then
      return ""
    end
    local itemInfo = X2Item:GetItemInfoByType(item.itemType)
    if itemInfo == nil then
      return ""
    end
    return GetCommonText("bless_uthstin_button_tooltip_init", itemInfo.name, item.need, item.has)
  end
  buttonSet:AddButton("init", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("init"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.LEFT,
    tooltip = GetInitButtonTooltip(),
    clickFunc = function()
      ShowBlessUthstinInitDialog(window:GetId(), false, window.tab:GetSelectedTab())
    end
  })
  buttonSet:AddButton("copy", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("copy"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.LEFT,
    tooltip = GetCommonText("bless_uthstin_button_tooltip_copy"),
    clickFunc = function()
      ShowBlessUhtstinCopyDialog(window:GetId(), window.tab:GetSelectedTab())
    end
  })
  buttonSet:AddButton("activate", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("bless_uthstin_activation"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.RIGHT,
    tooltip = GetCommonText("bless_uthstin_button_tooltip_activate")
  })
  window:RegisterStack(buttonSet)
  window:ApplyAutoHeightByStack()
  return window
end
