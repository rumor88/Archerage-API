function ShowBlessUthstinInitDialog(parentId, openFromCopyDialog, initTabNumber)
  local function DialogHandler(wnd)
    wnd:SetTitle(GetCommonText("bless_uthstin_init_stats"))
    if openFromCopyDialog then
      local textData = {
        [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("bless_uthstin_init_for_copy")
      }
      local textbox = W_MODULE:Create("textbox", wnd, W_MODULE.TYPES.TEXTBOX, textData)
      wnd:RegisterStack(textbox)
    end
    local initInfo = X2BlessUthstin:GetBlessUthstinInitItemInfo()
    local itemData = {
      itemInfo = X2Item:GetItemInfoByType(initInfo.itemType),
      stack = {
        initInfo.has,
        initInfo.need
      }
    }
    local itemIcon = W_MODULE:Create("itemIcon", wnd, W_MODULE.TYPES.ICON_VERTICAL, itemData)
    wnd:RegisterStack(itemIcon)
    local textData = {
      type = "warning",
      [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("bless_uthstin_init_stats_warning")
    }
    local warning = W_MODULE:Create("warning", wnd, W_MODULE.TYPES.TEXTBOX, textData)
    wnd:RegisterStack(warning)
    function wnd:OkProc()
      X2BlessUthstin:UseBlessUthstinInitStats(initTabNumber)
    end
  end
  X2DialogManager:RequestDialog(DialogHandler, parentId)
end
function ShowBlessUhtstinCopyDialog(parentId, previewPageNum)
  local function DialogHandler(dialog)
    dialog:SetTitle(GetCommonText("bless_uthstin_copy_popup_title"))
    dialog:RegisterStack(W_MODULE:Create("textData", dialog, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("bless_uthstin_copy_popup_desc")
    }))
    local pageCount = X2BlessUthstin:GetPageCount()
    local maxPageCount = X2BlessUthstin:GetMaxPageCount()
    local radioTexts = {}
    local radioEnable = true
    for i = 1, maxPageCount do
      radioEnable = true
      if i > pageCount or i == previewPageNum then
        radioEnable = false
      end
      if X2BlessUthstin:GetTotalAppliedStats(i) > 0 then
        local item = {
          text = GetUIText(COMMON_TEXT, "bless_uthstin_copy_popup_tab_name_selected", tostring(i)),
          value = i,
          enable = radioEnable
        }
        table.insert(radioTexts, item)
      else
        local item = {
          text = GetUIText(COMMON_TEXT, "bless_uthstin_copy_popup_tab_name", tostring(i)),
          value = i,
          enable = radioEnable
        }
        table.insert(radioTexts, item)
      end
    end
    local radioTitleBox = W_MODULE:Create("radioTitleBox", dialog, W_MODULE.TYPES.RADIO_GROUP_TITLE_BOX, {
      titleInfo = {
        title = X2Locale:LocalizeUiText(COMMON_TEXT, "bless_uthstin_tab_title")
      }
    }, {
      [W_MODULE.ATTRIBUTE.SELECT_INDEX] = 0,
      [W_MODULE.ATTRIBUTE.RADIO_GROUP_DATA] = radioTexts,
      [W_MODULE.ATTRIBUTE.RADIO_CHANGED_PROC] = function(radioGroup, index, value)
        local cost = X2BlessUthstin:GetCopyCost()[string.format("page%d", previewPageNum)]
        dialog.btnOk:Enable(tonumber(cost) <= tonumber(X2Util:GetMyMoneyString()))
      end
    })
    dialog:RegisterStack(radioTitleBox)
    dialog.radio = radioTitleBox
    local cost = 0
    local costInfo = X2BlessUthstin:GetCopyCost()
    if costInfo ~= nil then
      cost = tonumber(costInfo[string.format("page%d", previewPageNum)])
    end
    dialog:RegisterStack(W_MODULE:Create("costBox", dialog, W_MODULE.TYPES.VALUE_BOX, {
      [W_MODULE.ATTRIBUTE.TYPE] = "cost",
      [W_MODULE.ATTRIBUTE.CURRENCY] = F_MONEY.currency.heirSkillsReset,
      [W_MODULE.ATTRIBUTE.VALUE] = tostring(cost)
    }))
    dialog:RegisterStack(W_MODULE:Create("warning", dialog, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = X2Locale:LocalizeUiText(COMMON_TEXT, "bless_uthstin_warning"),
      type = "warning"
    }))
    function dialog:OkProc()
      local pageNum = radioTitleBox:GetCheckedData()
      if pageNum ~= previewPageNum then
        if X2BlessUthstin:GetTotalAppliedStats(pageNum) > 0 then
          ShowBlessUthstinInitDialog(parentId, true, pageNum)
        else
          X2BlessUthstin:CopyBlessUthstinPage(previewPageNum, pageNum)
        end
      end
    end
  end
  X2DialogManager:RequestDialog(DialogHandler, parentId)
end
function ShowBlessUthstinExpandDialog(parentId)
  local DialogHandler = function(wnd)
    local maxPageCount = X2BlessUthstin:GetMaxPageCount()
    local curPageCount = X2BlessUthstin:GetPageCount()
    wnd:SetTitle(GetUIText(COMMON_TEXT, "expand_slot_count"))
    local changeData = {
      titleInfo = {
        title = GetUIText(COMMON_TEXT, "add_slot_count")
      },
      left = {
        UpdateValueFunc = function(leftValueWidget)
          leftValueWidget:SetText(GetUIText(COMMON_TEXT, "amount", tostring(curPageCount)))
        end
      },
      right = {
        UpdateValueFunc = function(rightValueWidget)
          rightValueWidget:SetText(GetUIText(COMMON_TEXT, "amount", tostring(curPageCount + 1)))
        end
      }
    }
    wnd:RegisterStack(W_MODULE:Create("changeData", wnd, W_MODULE.TYPES.CHANGE_BOX_A, changeData))
    local itemType, requireItemInfo, hasCount, needCount = X2BlessUthstin:GetExpandItemInfo()
    local itemData = {
      itemInfo = requireItemInfo,
      stack = {hasCount, needCount}
    }
    wnd:RegisterStack(W_MODULE:Create("itemIcon", wnd, W_MODULE.TYPES.ICON_VERTICAL, itemData))
    local textData = {
      type = "default",
      [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "expandable_count", tostring(curPageCount), tostring(maxPageCount))
    }
    wnd:RegisterStack(W_MODULE:Create("textData", wnd, W_MODULE.TYPES.TEXTBOX, textData))
    function wnd:OkProc()
      X2BlessUthstin:ExpandBlessUthstinPage()
    end
  end
  X2DialogManager:RequestDialog(DialogHandler, parentId)
end
