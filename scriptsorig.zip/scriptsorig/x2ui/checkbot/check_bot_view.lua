function SetViewOfCheckBotWindow(id, parent)
  local width = F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_350)
  local buttonAlpha = 4602678819172646912
  local window = CreateWindow(id, parent)
  window:SetWidth(width)
  window:SetTitle(GetCommonText("check_bot_title"))
  window:SetCloseOnEscape(false)
  window.titleBar:HideCloseButton()
  local desc = W_MODULE:Create("desc", window, W_MODULE.TYPES.TEXTBOX, {
    [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("check_bot_desc")
  })
  window:RegisterStack(desc)
  local titlebox = W_MODULE:Create("titlebox", window, W_MODULE.TYPES.TITLE_BOX, {
    title = GetUIText(COMMON_TEXT, "verification")
  })
  window:RegisterStack(titlebox)
  local height = 40
  local contentWidth = titlebox:GetWidth() - MARGIN.WINDOW_SIDE * 2
  local characterSection = titlebox:CreateChildWidget("emptywidget", "characterSection", 0, false)
  characterSection:SetExtent(contentWidth, height)
  local bg = window:CreateColorDrawableByKey("common_white_bg", "background")
  local characterImgs = {}
  local x = 10
  local offset = 5
  for i = 1, BOT_QUESTION_CHAR_SIZE do
    local chImg = characterSection:CreateDrawable(TEXTURE_PATH.SECURITY, "security_48", "overlay")
    chImg:AddAnchor("LEFT", bg, x, 0)
    x = x + chImg:GetWidth() + offset
    table.insert(characterImgs, chImg)
  end
  local scratchImg = window:CreateDrawable(TEXTURE_PATH.SECURITY, "pattern_01", "overlay")
  scratchImg:AddAnchor("CENTER", bg, 0, 0)
  local refresh = window:CreateChildWidget("button", "refresh", 0, true)
  ApplyButtonSkin(refresh, BUTTON_STYLE.RESET_BIG)
  refresh:AddAnchor("LEFT", bg, "RIGHT", 2, 0)
  refresh:SetAlpha(buttonAlpha)
  bg:AddAnchor("CENTER", characterSection, -refresh:GetWidth() / 2, 0)
  bg:SetExtent(x + offset, height)
  titlebox:AddBody(characterSection, false)
  function titlebox:UpdateQuestion(question)
    for i = 1, BOT_QUESTION_CHAR_SIZE do
      local var = string.sub(question, i, i)
      local imgKey = string.format("security_%d", string.byte(var))
      characterImgs[i]:SetTextureInfo(imgKey)
    end
    local scratchImgKey = string.format("pattern_%02d", math.random(1, 3))
    scratchImg:SetTextureInfo(scratchImgKey)
  end
  local editbox = W_MODULE:Create("editbox", window, W_MODULE.TYPES.EDITBOX, {action = "input"}, {
    width = contentWidth,
    dialog = window,
    [W_MODULE.ATTRIBUTE.SHOW_EDITBOX_RULE] = false,
    [W_MODULE.ATTRIBUTE.MIN_LETTER] = BOT_QUESTION_CHAR_SIZE,
    [W_MODULE.ATTRIBUTE.MAX_LETTER] = BOT_QUESTION_CHAR_SIZE
  })
  titlebox:AddBody(editbox)
  local GetAnswerText = function(cur)
    return GetUIText(COMMON_TEXT, "check_bot_answer_cnt", tostring(cur), tostring(BOT_CHECK_ANSWER_COUNT))
  end
  local answerCount = titlebox:AddModule("answerCount", W_MODULE.TYPES.TEXTBOX, {
    [W_MODULE.ATTRIBUTE.TEXT] = GetAnswerText(0)
  })
  function titlebox:UpdateAnswerCount(cur)
    local data = answerCount:GetData()
    answerCount:SetData({
      colorKey = data.colorKey,
      [W_MODULE.ATTRIBUTE.TEXT] = GetAnswerText(cur)
    })
  end
  titlebox:UpdateAnswerCount(0)
  local remainTimeModule = W_MODULE:Create("remainTimeModule", window, W_MODULE.TYPES.REMAIN_TIME, nil)
  window.remainTimeModule = remainTimeModule
  window:RegisterStack(remainTimeModule)
  local warning = W_MODULE:Create("warning", window, W_MODULE.TYPES.TEXTBOX, {
    [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("check_bot_restict_desc"),
    [W_MODULE.ATTRIBUTE.TYPE] = "warning"
  })
  window:RegisterStack(warning)
  local randomColorTarget = {
    desc,
    answerCount,
    warning,
    remainTimeModule.timeStr
  }
  local fontColors = {
    "default",
    "middle_title",
    "green",
    "blue",
    "black",
    "red"
  }
  function window:RandomColor()
    for i, v in ipairs(randomColorTarget) do
      local colorKey = fontColors[math.random(1, #fontColors)]
      if v:GetObjectType() == "textbox" then
        local data = v:GetData()
        data.colorKey = colorKey
        v:SetData(data)
      else
        v.style:SetColorByKey(colorKey)
      end
    end
  end
  local buttonSet = W_MODULE:Create("buttonSet", window, W_MODULE.TYPES.BUTTON_SET)
  buttonSet:AddButton("input", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "input"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    enable = false
  })
  local inputButton = buttonSet:GetButton("input")
  inputButton:SetAlpha(buttonAlpha)
  window:RegisterOkButton(inputButton)
  window:RegisterStack(buttonSet)
  window:ApplyAutoHeightByStack()
  return window
end
