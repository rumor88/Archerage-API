local CreateBotCheckWindow = function(id, parent)
  local w = SetViewOfCheckBotWindow(id, parent)
  local delay = 0
  local inputButton = w.buttonSet:GetButton("input")
  function w.buttonSet:Satisfy()
    return delay <= 0
  end
  local oldQuestion
  local function UpdateInfos(totalTime, remainTime, count, question)
    if remainTime == 0 and count == 0 and question ~= nil and string.len(question) == 0 then
      w:Show(false)
      return
    end
    w.remainTimeModule:SetData({
      [W_MODULE.ATTRIBUTE.TIME] = remainTime,
      [W_MODULE.ATTRIBUTE.LIMIT] = totalTime
    })
    w.titlebox:UpdateAnswerCount(BOT_CHECK_ANSWER_COUNT - count)
    if oldQuestion ~= question then
      w.titlebox:UpdateQuestion(question)
      oldQuestion = question
    end
  end
  local function Update(self, dt)
    if delay > 0 then
      delay = delay - dt
    else
      delay = 0
      w:SetEnableButtons(true)
      w:ReleaseHandler("OnUpdate")
    end
  end
  function w:SetEnableButtons(enable)
    if inputButton:IsEnabled() == enable then
      return
    end
    w.refresh:Enable(enable)
    if enable == false then
      delay = 1000
      w:SetHandler("OnUpdate", Update)
    end
    w:ApplyOkButtonEnablement()
  end
  local function SendAnswer()
    local answer = w.editbox:GetDataPartially(W_MODULE.ATTRIBUTE.TEXT)
    if answer ~= nil and string.len(answer) == 5 then
      X2Player:AnswerBotCheck(answer)
      w:SetEnableButtons(false)
    else
      UIParent:Warning(string.format("[Lua Error] bot check window / fail send answer. (%s) ", answer))
    end
    w.editbox:SetDataPartially(W_MODULE.ATTRIBUTE.TEXT, "")
  end
  inputButton:SetHandler("OnClick", SendAnswer)
  local function RefreshBotCheckInfo()
    X2Player:RefreshBotCheckInfo()
    w:SetEnableButtons(false)
  end
  w.refresh:SetHandler("OnClick", RefreshBotCheckInfo)
  local function OnEndAlphaAnime()
    w:SetAlpha(math.random(70, 95) / 100)
  end
  w:SetHandler("OnAlphaAnimeEnd", OnEndAlphaAnime)
  local GetRandSign = function()
    local randSign = 1
    if math.random(1, 2) % 2 == 0 then
      randSign = -1
    end
    return randSign
  end
  function w:ShowProc()
    oldQuestion = nil
    delay = 0
    w:ApplyOkButtonEnablement()
    w:RandomColor()
    local rangeWidth = (UIParent:GetScreenWidth() - w:GetWidth() * UIParent:GetUIScale()) / UIParent:GetUIScale()
    local rangeHeight = (UIParent:GetScreenHeight() - w:GetHeight() * UIParent:GetUIScale()) / UIParent:GetUIScale()
    local posX = math.random(1, rangeWidth)
    local posY = math.random(1, rangeHeight)
    w:RemoveAllAnchors()
    w:AddAnchor("TOPLEFT", parent, posX, posY)
  end
  local checkBotEvents = {
    UPDATE_BOT_CHECK_INFO = function(totalTime, remainTime, count, question)
      UpdateInfos(totalTime, remainTime, count, question)
    end
  }
  w:SetHandler("OnEvent", function(this, event, ...)
    checkBotEvents[event](...)
  end)
  RegistUIEvent(w, checkBotEvents)
  return w
end
local checkBotWnd
function ShowCheckBotWindow()
  if checkBotWnd == nil then
    checkBotWnd = CreateBotCheckWindow("checkBotWnd", "UIParent")
  end
  if checkBotWnd:IsVisible() == false then
    checkBotWnd:Show(true)
    checkBotWnd:SetEnableButtons(true)
    ADDON:RegisterContentWidget(UIC_CHECK_BOT_WND, checkBotWnd, ShowCheckBotWindow)
  end
end
ADDON:RegisterContentTriggerFunc(UIC_CHECK_BOT_WND, ShowCheckBotWindow)
