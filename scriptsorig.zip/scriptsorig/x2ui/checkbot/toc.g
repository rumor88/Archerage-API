## author : mook
## Copyright (c) 2014 XLGames, Inc. All rights reserved.
## slave

check_bot_view.lua
check_bot.lua