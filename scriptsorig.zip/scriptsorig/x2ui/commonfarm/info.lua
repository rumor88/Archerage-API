function CreateCommonFarmInfoWindow()
  function SetViewOfCommonFarmInfoWindow()
    local wnd = CreateWindow("farm_info")
    wnd:SetWidth(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_350))
    wnd:SetSounds("common_farm_info")
    local growableTitle = W_MODULE:Create("growableTitle", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = ""
    })
    wnd:RegisterStack(growableTitle)
    local protectTime = W_MODULE:Create("protectTime", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = ""
    })
    wnd:RegisterStack(protectTime, TEXTBOX_LINE_SPACE.MIDDLE)
    local titleBox = W_MODULE:Create("titleBox", wnd, W_MODULE.TYPES.TITLE_BOX, {
      title = locale.commonFarm.itemList
    }, {
      [W_MODULE.ATTRIBUTE.BODY_INSET] = {
        15,
        5,
        10,
        10
      }
    })
    local scrollList = titleBox:AddModule("scrollList", W_MODULE.TYPES.LISTCTRL, nil, {
      [W_MODULE.ATTRIBUTE.HAS_SCROLL] = true,
      [W_MODULE.ATTRIBUTE.COLUMN_HEIGHT_TYPE] = nil,
      [W_MODULE.ATTRIBUTE.ROW_COUNT] = 13,
      [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = true,
      [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = "text_small",
      [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
        {
          [W_MODULE.ATTRIBUTE.WIDTH] = titleBox:GetContentWidth() - 25,
          [W_MODULE.ATTRIBUTE.TEXT] = "",
          [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_STRING,
          [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
            subItem.style:SetColorByKey("default")
            subItem.style:SetAlign(ALIGN_LEFT)
            subItem.style:SetEllipsis(true)
            local function OnEnter(self)
              local text = self:GetText()
              if subItem:GetWidth() > self.style:GetTextWidth(text) then
                return
              end
              SetTooltip(text, self)
            end
            subItem:SetHandler("OnEnter", OnEnter)
          end,
          [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
            if data ~= nil then
              subItem:SetText(data)
            else
              subItem:SetText("")
            end
          end
        }
      }
    })
    wnd:RegisterStack(titleBox)
    wnd.scrollList = scrollList
    local growableCount = W_MODULE:Create("growableCount", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = ""
    })
    wnd:RegisterStack(growableCount)
    wnd.growableCount = growableCount
    local buttonSet = W_MODULE:Create("buttonSet", wnd, W_MODULE.TYPES.BUTTON_SET)
    buttonSet:AddButton("ok", {
      [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "ok"),
      [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
      clickFunc = function()
        wnd:Show(false)
      end
    })
    wnd:RegisterStack(buttonSet)
    wnd:ApplyAutoHeightByStack()
    return wnd
  end
  local w = SetViewOfCommonFarmInfoWindow()
  function w:Update(commonFarmType)
    local name, guardTime, farmGroupType = X2:GetCommonFarmInfo(commonFarmType)
    if name == nil then
      return
    end
    self:SetTitle(name)
    local time = MakeTimeString(guardTime / 1000)
    local farmGroupName, maxCount = X2:GetFarmGorupInfo(farmGroupType)
    if farmGroupName == nil then
      return
    end
    self.protectTime:SetText(locale.commonFarm.protectWaring(time))
    self.growableCount:SetText(locale.commonFarm.ableCount(maxCount))
    local names = X2:GetFarmGroupDoodadList(farmGroupType)
    if names == nil then
      return
    end
    self.scrollList:SetData({
      [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
      [W_MODULE.ATTRIBUTE.DATA] = names
    })
    self:ApplyAutoHeightByStack()
  end
  return w
end
local commonFarmInfoWindow = CreateCommonFarmInfoWindow()
commonFarmInfoWindow:AddAnchor("CENTER", "UIParent", 0, 0)
commonFarmInfoWindow:Show(false)
local testEvents = {
  OPEN_COMMON_FARM_INFO = function(commonFarmType)
    commonFarmInfoWindow:Update(commonFarmType)
    commonFarmInfoWindow:Show(true)
  end,
  INTERACTION_END = function()
    commonFarmInfoWindow:Show(false)
  end
}
commonFarmInfoWindow:SetHandler("OnEvent", function(this, event, ...)
  testEvents[event](...)
end)
commonFarmInfoWindow:RegisterEvent("OPEN_COMMON_FARM_INFO")
commonFarmInfoWindow:RegisterEvent("INTERACTION_END")
