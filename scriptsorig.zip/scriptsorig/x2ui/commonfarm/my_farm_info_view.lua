function SetViewOfMyFarmInfo()
  local layoutSetInfo = GetLayoutSetCommonFarmInfo()
  local w = CreateWindow("myFarminfo", "UIParent")
  w:SetExtent(layoutSetInfo.windowWidth, 400)
  w:SetTitle(locale.commonFarm.title)
  w:SetSounds("my_farm_info")
  local farmInfo = X2:GetFarmGroups()
  local tabName = {}
  local farmGroups = {}
  for i = 1, #farmInfo do
    table.insert(tabName, farmInfo[i].name)
    farmGroups[i] = farmInfo[i].type
  end
  w.farmGroups = farmGroups
  local tab = W_TAB.CreateTab("tab", w)
  tab:AddTabs(tabName)
  local listCtrl = W_MODULE:Create("listCtrl", tab, W_MODULE.TYPES.LISTCTRL, nil, {
    [W_MODULE.ATTRIBUTE.COLUMN_HEIGHT_TYPE] = "large",
    [W_MODULE.ATTRIBUTE.ROW_COUNT] = 5,
    [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = true,
    [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = "icon_middle",
    [W_MODULE.ATTRIBUTE.ROW_INSET_TYPE] = "icon_middle",
    [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = layoutSetInfo.columnWidth[1],
        [W_MODULE.ATTRIBUTE.TEXT] = locale.commonFarm.item,
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
          local iconButton = CreateIconButton("iconButton", subItem)
          iconButton:AddAnchor("LEFT", subItem, 0, 0)
          subItem.itemButton = iconButton
          local bg = subItem:CreateDrawable(TEXTURE_PATH.DEFAULT, "common_bg", "background")
          bg:AddAnchor("TOPLEFT", row, 0, 0)
          bg:AddAnchor("BOTTOMRIGHT", row, 0, 0)
          subItem.bg = bg
          local inset = 5
          local nameLabel = iconButton:CreateChildWidget("label", "nameLabel", 0, true)
          nameLabel:AddAnchor("LEFT", iconButton, "RIGHT", inset, 0)
          nameLabel:SetExtent(subItem:GetWidth() - iconButton:GetWidth() - inset, iconButton:GetHeight())
          nameLabel.style:SetEllipsis(true)
          nameLabel.style:SetAlign(ALIGN_LEFT)
          nameLabel.style:SetColorByKey("default")
        end,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data then
            local itemInfo = X2Item:GetItemInfoByType(data.itemType)
            if itemInfo == nil then
              subItem.iconButton:Show(false)
              subItem.bg:SetVisible(false)
              return
            end
            subItem.iconButton:Show(true)
            subItem.iconButton:SetInfo(itemInfo)
            subItem.iconButton.nameLabel:SetText(data.name)
            if data.leftProtectTime <= 0 then
              subItem.bg:SetTextureColor("soft_red")
              subItem.bg:SetVisible(true)
            elseif 0 >= data.leftGrowthTime or data.growUp then
              subItem.bg:SetTextureColor("blue")
              subItem.bg:SetVisible(true)
            else
              subItem.bg:SetVisible(false)
            end
          else
            subItem.iconButton:Show(false)
            subItem.bg:SetVisible(false)
          end
        end
      },
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = layoutSetInfo.columnWidth[2],
        [W_MODULE.ATTRIBUTE.TEXT] = locale.commonFarm.time,
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_TEXTBOX,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data then
            subItem:Show(true)
            local colorKey = "default"
            if data.leftGrowthTime > 0 and not data.growUp then
              leftGrowthTimeStr = MakeTimeString(data.leftGrowthTime)
            else
              leftGrowthTimeStr = locale.commonFarm.growUp
              colorKey = "blue"
            end
            if 0 < data.leftProtectTime then
              leftProtectTimeStr = MakeTimeString(data.leftProtectTime)
            else
              leftProtectTimeStr = locale.commonFarm.endanger
              colorKey = "red"
            end
            subItem:SetText(F_TEXT.SetSlashFormat(leftGrowthTimeStr, leftProtectTimeStr))
            subItem.style:SetColorByKey(colorKey)
          else
            subItem:Show(false)
          end
        end
      },
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = layoutSetInfo.columnWidth[3],
        [W_MODULE.ATTRIBUTE.TEXT] = locale.commonFarm.area,
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_STRING,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data then
            subItem:Show(true)
            subItem:SetText(data.location)
          else
            subItem:Show(false)
          end
        end
      },
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = layoutSetInfo.columnWidth[4],
        [W_MODULE.ATTRIBUTE.TEXT] = locale.commonFarm.map,
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_BUTTON,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
          subItem:SetStyle("location")
          function subItem:SetInfo(farmGroup, farmType, x, y)
            self.farmGroup = farmGroup
            self.farmType = farmType
            self.x = x
            self.y = y
          end
          local OnClick = function(self)
            worldmap:ToggleMapWithCommonFarm(self.farmGroup, self.farmType, self.x, self.y)
          end
          subItem:SetHandler("OnClick", OnClick)
        end,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data then
            subItem:Enable(true)
            subItem:Show(true)
            subItem:SetInfo(data.farmGroup, data.farmType, data.vPosX, data.vPosY)
          else
            subItem:Enable(false)
            subItem:Show(false)
          end
        end
      }
    }
  })
  listCtrl:AddAnchor("TOPLEFT", tab, 0, 35)
  w.listCtrl = listCtrl
  local commonFarmStatus = w:CreateChildWidget("label", "commonFarmStatus", 0, true)
  commonFarmStatus:Show(true)
  commonFarmStatus:SetHeight(FONT_SIZE.MIDDLE)
  commonFarmStatus:SetAutoResize(true)
  commonFarmStatus:AddAnchor("TOPRIGHT", tab, 0, 10)
  commonFarmStatus.style:SetColorByKey("blue")
  return w
end
