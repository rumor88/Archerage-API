function CreateMyFarmInfo()
  local w = SetViewOfMyFarmInfo()
  w.infos = {}
  local listCtrl = w.listCtrl
  function w:UpdateBaseInfo()
    local farmGroups = X2:GetFarmGroups()
    for i = 1, #farmGroups do
      local farmType = farmGroups[i].type
      self.infos[farmType] = X2:GetRuntimeCommonFarmDoodadsInfo(farmType)
    end
  end
  function w:RefreshCommonFarmList(farmType)
    self:UpdateBaseInfo()
    local infos = self.infos[farmType]
    if infos == nil then
      listCtrl:SetData(nil)
      return
    end
    for i = 1, #infos do
      local info = infos[i]
      info.farmGroup = farmType
    end
    listCtrl:SetData({
      [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = false,
      [W_MODULE.ATTRIBUTE.DATA] = infos
    })
  end
  function w:RefreshCommonFarmStatus()
    local selected = self.tab:GetSelectedTab()
    local farmType = self.farmGroups[selected]
    local name, limit, _ = X2:GetFarmGorupInfo(farmType)
    local count = X2:GetRuntimeCommonFarmDoodadCount(farmType)
    local perFarmStatus = F_TEXT.SetSlashFormat(count, limit)
    self.commonFarmStatus:SetText(perFarmStatus)
  end
  function w.tab:OnTabChangedProc(selected)
    w:RefreshCommonFarmStatus()
  end
  function w:ShowProc()
    X2:RequestRuntimeCommonFarmDoodadInfo()
  end
  local function Refresh()
    local selected = w.tab:GetSelectedTab()
    local farmType = w.farmGroups[selected]
    w:RefreshCommonFarmList(farmType)
  end
  Refresh()
  local time = 0
  local function OnUpdate(self, dt)
    if time < 500 then
      time = time + dt
      return
    end
    time = 0
    Refresh()
  end
  w:SetHandler("OnUpdate", OnUpdate)
  local farmEvents = {
    COMMON_FARM_UPDATED = function()
      w:RefreshCommonFarmStatus()
      w:Show(true)
    end
  }
  w:SetHandler("OnEvent", function(this, event, ...)
    farmEvents[event](...)
  end)
  RegistUIEvent(w, farmEvents)
  return w
end
local myFarmInfoWindow = CreateMyFarmInfo()
myFarmInfoWindow:AddAnchor("CENTER", "UIParent", 0, 0)
local function ToggleCommonFarm(isShow)
  if isShow == nil then
    isShow = not myFarmInfoWindow:IsVisible()
  end
  myFarmInfoWindow:Show(isShow)
end
ADDON:RegisterContentTriggerFunc(UIC_MY_FARM_INFO, ToggleCommonFarm)
