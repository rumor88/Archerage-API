﻿## author : yoseop
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## commonfarm

locale/layout_set.lua

info.lua

my_farm_info_view.lua
my_farm_info.lua