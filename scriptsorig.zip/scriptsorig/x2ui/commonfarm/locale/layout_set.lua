local layoutSet = {
  default = {
    windowWidth = F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_600),
    columnWidth = {
      165,
      220,
      100,
      75
    }
  },
  [MAILRU] = {
    windowWidth = F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_680),
    columnWidth = {
      185,
      260,
      140,
      55
    }
  }
}
layoutSet[KAKAONA] = layoutSet[MAILRU]
layoutSet[XLGAMES_TH] = layoutSet[MAILRU]
layoutSet[GAMEON] = layoutSet[MAILRU]
function GetLayoutSetCommonFarmInfo()
  return L_HELPER.Get(layoutSet)
end
