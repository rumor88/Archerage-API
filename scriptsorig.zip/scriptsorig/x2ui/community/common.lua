COMMUNITY = {
  RELATION = 1,
  FAMILY = 2,
  EXPEDITION = 3,
  NATION = 4
}
FRIEND_TAB = {
  FRIEND = 1,
  WAIT = 2,
  BLOCK = 3
}
coolTimeGroup = {
  handleWnd = nil,
  buttonGroup = nil,
  InitCoolTimeGroup = function(parentWnd)
    handleWnd = parentWnd
    buttonGroup = {}
  end,
  ResetCoolTimeGroup = function()
    handleWnd = nil
    buttonGroup = nil
  end,
  ClearCoolTimeGroupBtn = function()
    buttonGroup = nil
  end,
  RegisterCoolTimeGroupBtn = function(btn)
    if buttonGroup == nil then
      buttonGroup = {}
    end
    btn:Enable(X2Team:CheckCoolTimerByTimerType(SIEGE_RAID_TEAM_INFO_BY_FACTION))
    local obj = {button = btn}
    table.insert(buttonGroup, obj)
  end,
  SetGlobalCoolTime = function()
    if handleWnd == nil then
      buttonGroup = nil
      return
    end
    if buttonGroup == nil or #buttonGroup == 0 then
      return
    end
    for i = 1, #buttonGroup do
      buttonGroup[i].button:Enable(false)
    end
    handleWnd:SetHandler("OnUpdate", handleWnd.OnUpdate)
  end,
  UpdateGlobalCoolTime = function()
    if buttonGroup == nil then
      buttonGroup = nil
      handleWnd:ReleaseHandler("OnUpdate")
      return
    end
    if X2Team:CheckCoolTimerByTimerType(SIEGE_RAID_TEAM_INFO_BY_FACTION) then
      for i = 1, #buttonGroup do
        buttonGroup[i].button:Enable(true)
      end
      handleWnd:ReleaseHandler("OnUpdate")
    end
  end
}
COMMUNITY_MEMBER_LIST_ROW_COUNT = 17
COMMUNITY_MEMBER_PAGE_PER_COUNT = 50
local CreateNoticeEditWindow = function(id, parent, info)
  if info == nil then
    return
  end
  local window = CreateWindow(id, parent)
  window:SetExtent(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_350), 350)
  window:SetTitle(info.title or "")
  window:AddAnchor("CENTER", parent, 0, 0)
  local exped = X2Faction:GetMyExpeditionInfo()
  local editbox = W_MODULE:Create("editbox", window, W_MODULE.TYPES.EDITBOX_MULTILINE, nil, {
    [W_MODULE.ATTRIBUTE.SHOW_BG] = true,
    [W_MODULE.ATTRIBUTE.USE_WINDOW_MARGIN] = true,
    [W_MODULE.ATTRIBUTE.MAX_LETTER] = 200,
    [W_MODULE.ATTRIBUTE.WINDOW_WIDTH_PRESET] = WINDOW_WIDTH_350
  })
  window:RegisterStack(editbox)
  local function UpdateEditbox()
    local getter = info.getter
    if getter == nil or type(getter) ~= "function" then
      return
    end
    editbox:SetData({
      text = getter() or ""
    })
  end
  local buttonSet
  local function MotdEditOnOff(on)
    editbox:SetReadOnly(on)
    if on then
      buttonSet:ToggleLayer(1)
    else
      buttonSet:ToggleLayer(0)
    end
  end
  buttonSet = W_MODULE:Create("buttonSet", window, W_MODULE.TYPES.BUTTON_SET, {default = true})
  buttonSet:UpdateButton("ok", {
    clickFunc = function()
      local okFunc = info.okFunc
      if okFunc == nil or type(okFunc) ~= "function" then
        return
      end
      okFunc(editbox:GetText())
      MotdEditOnOff(true)
    end
  })
  buttonSet:UpdateButton("cancel", {
    clickFunc = function()
      UpdateEditbox()
      MotdEditOnOff(true)
    end
  })
  buttonSet:AddButton("edit", {
    skin = "write",
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.RIGHT,
    [W_MODULE.ATTRIBUTE.LAYER] = 1,
    clickFunc = function()
      MotdEditOnOff(false)
    end
  })
  window:RegisterStack(buttonSet, window:FooterStackGap())
  window:ApplyAutoHeightByStack()
  UpdateEditbox()
  MotdEditOnOff(true)
  return window
end
function CreateCommunityNoticeSection(id, tabWindow, tabIndex, info)
  if info == nil then
    return
  end
  local tab = tabWindow:GetParent()
  local section = tabWindow:CreateChildWidget("emptywidget", id, 0, true)
  section:SetExtent(tabWindow:GetWidth(), 30)
  local bg = section:CreateDrawable(TEXTURE_PATH.DEFAULT, "common_bg", "background")
  bg:SetTextureColor("bg_02")
  local guideButton = section:CreateChildWidget("button", "guideButton", 0, true)
  guideButton:SetStyle("question_mark")
  guideButton:AddAnchor("RIGHT", section, 0, 0)
  local infoGuideWindow
  local function LeftClickFuncGuideButton()
    if info.guideWindow ~= nil and infoGuideWindow == nil then
      infoGuideWindow = CreateInfomationGuideWindow("infoGuideWindow", tab, info.guideWindow.title, info.guideWindow.body)
      infoGuideWindow:AddAnchor("TOPRIGHT", tabWindow, 0, 10)
      tab:RegisterTabChangedTarget(tabIndex, infoGuideWindow)
    end
    infoGuideWindow:Show(not infoGuideWindow:IsVisible())
  end
  ButtonOnClickHandler(guideButton, LeftClickFuncGuideButton)
  local editButton = section:CreateChildWidget("button", "editButton", 0, true)
  editButton:SetStyle("plus")
  editButton:AddAnchor("RIGHT", guideButton, "LEFT", -5, 0)
  local editWindow
  local function LeftClickFuncEditButton()
    if info.editButton == nil or info.editButton.editWindow == nil then
      return
    end
    if editWindow == nil then
      editWindow = CreateNoticeEditWindow("editWindow", tab, info.editButton.editWindow)
      editWindow:AddAnchor("CENTER", "UIParent", 0, 0)
      tab:RegisterTabChangedTarget(tabIndex, editWindow)
    end
    editWindow:Show(not editWindow:IsVisible())
  end
  ButtonOnClickHandler(editButton, LeftClickFuncEditButton)
  bg:AddAnchor("LEFT", section, 0, 0)
  bg:AddAnchor("RIGHT", editButton, "LEFT", -5, 0)
  bg:SetHeight(section:GetHeight())
  local speakerIcon = section:CreateDrawable(TEXTURE_PATH.DEFAULT, "notice", "background")
  speakerIcon:AddAnchor("LEFT", section, 2, -1)
  local label = section:CreateChildWidget("label", "label", 0, false)
  label:AddAnchor("LEFT", speakerIcon, "RIGHT", 5, 0)
  label:AddAnchor("RIGHT", bg, -10, 0)
  label:SetHeight(FONT_SIZE.MIDDLE)
  label.style:SetAlign(ALIGN_LEFT)
  label.style:SetColorByKey("blue")
  F_TEXT.ApplyAutoEllipsisTooltipText(label)
  function section:FillNotice(str)
    label:SetText(str or "")
  end
  function section:UpdateEditButton()
    if info.editButton == nil or info.editButton.updateFunc == nil or type(info.editButton.updateFunc) ~= "function" then
      editButton:Enable(false)
      return
    end
    editButton:Enable(info.editButton.updateFunc())
  end
  return section
end
function CreateCommunityInfoSection(id, tabWindow, info)
  if info == nil then
    return
  end
  local width = tabWindow:GetWidth()
  local section = tabWindow:CreateChildWidget("emptywidget", id, 0, true)
  section:SetExtent(width, 95)
  local bg = section:CreateDrawable(TEXTURE_PATH.DEFAULT, "type02_new", "background")
  bg:SetTextureColor("default")
  bg:AddAnchor("TOPLEFT", section, 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", section, 0, 0)
  local leftOffset = 15
  local levelOffset = 0
  local levelWidget
  local levelCreater = info.levelCreater
  if levelCreater ~= nil and type(levelCreater) == "function" then
    levelWidget = levelCreater("levelWidget", section)
    levelWidget:AddAnchor("LEFT", section, leftOffset, 0)
    levelOffset = levelWidget:GetWidth() + 10
  end
  local nameWidget
  local nameCreater = info.nameCreater
  if nameCreater ~= nil and type(nameCreater) == "function" then
    nameWidget = nameCreater("nameWidget", section)
    if levelWidget == nil then
      nameWidget:AddAnchor("LEFT", section, leftOffset, 0)
    else
      nameWidget:AddAnchor("TOPLEFT", section, levelOffset + leftOffset, 25)
    end
  end
  local expOffset = 5
  local expBarSideButton
  if info.expBarSideButtonStyle ~= nil then
    expBarSideButton = section:CreateChildWidget("button", "expBarSiderButton", 0, false)
    expBarSideButton:SetStyle(info.expBarSideButtonStyle)
    do
      local clickFunc = info.expBarSideButtonClickFunc
      if clickFunc ~= nil and type(clickFunc) == "function" then
        local function LeftClickFuncSideButton(self)
          clickFunc(self)
        end
        ButtonOnClickHandler(expBarSideButton, LeftClickFuncSideButton)
      end
    end
  end
  local expBarWidget
  local expBarCreater = info.expBarCreater
  if expBarCreater ~= nil and type(expBarCreater) == "function" then
    expBarWidget = expBarCreater("expBarWidget", section)
    expBarWidget:SetWidth(width - leftOffset - levelOffset - expBarSideButton:GetWidth() - expOffset - 30)
    if levelWidget == nil then
      expBarWidget:AddAnchor("LEFT", section, leftOffset, 0)
    else
      expBarWidget:AddAnchor("BOTTOMLEFT", section, levelOffset + leftOffset, -25)
    end
    local OnEnterExpBarWidget = function(self)
      if self.tooltipStr == nil or self.tooltipStr == "" then
        return
      end
      SetTooltip(self.tooltipStr, self)
    end
    expBarWidget:SetHandler("OnEnter", OnEnterExpBarWidget)
  end
  if expBarSideButton ~= nil then
    expBarSideButton:AddAnchor("LEFT", expBarWidget, "RIGHT", expOffset, 0)
  end
  local levelUpdater = info.levelUpdater
  local nameUpdater = info.nameUpdater
  local expBarUpdater = info.expBarUpdater
  function section:Fill(data)
    if levelUpdater ~= nil and type(levelUpdater) == "function" then
      levelUpdater(levelWidget, data)
    end
    if nameUpdater ~= nil and type(nameUpdater) == "function" then
      nameUpdater(nameWidget, data)
    end
    if expBarUpdater ~= nil and type(expBarUpdater) == "function" then
      expBarUpdater(expBarWidget, data, expBarSideButton)
    end
  end
  return section
end
function CreatePeopleCountSection(id, tabWindow, info)
  if info == nil then
    info = {useOfflineFilter = true}
  end
  local width = tabWindow:GetWidth()
  local section = tabWindow:CreateChildWidget("emptywidget", id, 0, true)
  section:SetExtent(width, 20)
  local numOfonlineMember = section:CreateChildWidget("textbox", "numOfonlineMember", 0, true)
  numOfonlineMember:SetHeight(FONT_SIZE.MIDDLE)
  numOfonlineMember:SetAutoResize(true)
  numOfonlineMember:SetAutoWordwrap(false)
  numOfonlineMember:AddAnchor("LEFT", section, 0, 0)
  numOfonlineMember.style:SetColorByKey("title")
  function section:UpdateMemberCount(title, online, total)
    numOfonlineMember:SetText(string.format("%s %s", title, F_TEXT.SetSlashFormat(string.format("%s%d", F_COLOR.GetColor("blue", true), online), total)))
  end
  if info.useOfflineFilter then
    local refreshButton = section:CreateChildWidget("button", "refreshButton", 0, true)
    refreshButton:AddAnchor("RIGHT", section, 0, 0)
    ApplyButtonSkin(refreshButton, BUTTON_BASIC.RESET)
    local initData = {
      style = "eye_shape",
      textData = {
        text = locale.friend.showOffMember
      }
    }
    local viewOffMember = CreateCheckButton("viewOffMember", section, initData)
    viewOffMember:AddAnchor("RIGHT", refreshButton, "LEFT", -10, 0)
    section.viewOffMember = viewOffMember
  end
  return section
end
