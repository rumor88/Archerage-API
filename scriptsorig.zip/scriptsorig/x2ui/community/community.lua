local communityWnd
local tabIdx = COMMUNITY.RELATION
local function ProcVisibleFrame(idx)
  if idx == nil then
    idx = COMMUNITY.RELATION
  end
  tabIdx = idx
  local contentBtns = communityWnd.contentBtns
  local contentFrames = communityWnd.contentFrames
  for i = 1, #contentBtns do
    local isShow = i == idx
    SetBGPushed(contentBtns[i], isShow)
    contentFrames[i]:Show(isShow)
  end
end
local function AttachContentBtnsHandler()
  local contentBtns = communityWnd.contentBtns
  function contentBtns:SetBGPushedOnly(idx)
    for i = 1, #self do
      if i == idx then
        SetBGPushed(self[idx], true, GetCommunityButtonFontColor())
      else
        SetBGPushed(self[i], false, GetCommunityButtonFontColor())
      end
    end
  end
  for i = 1, #contentBtns do
    local cotentBtn = contentBtns[i]
    function cotentBtn:OnClick()
      contentBtns:SetBGPushedOnly(i)
      ProcVisibleFrame(i)
    end
    cotentBtn:SetHandler("OnClick", cotentBtn.OnClick)
  end
end
local function AttachCommunityConetents()
  local contentFrames = communityWnd.contentFrames
  local contentTabBtns = communityWnd.contentBtns
  CreateRelationshipFrame("relationshipFrame", contentFrames[COMMUNITY.RELATION], contentTabBtns[COMMUNITY.RELATION])
  CreateFamilyFrame("familyFrame", contentFrames[COMMUNITY.FAMILY])
  CreateExpeditionFrame("expedMgmt", contentFrames[COMMUNITY.EXPEDITION])
  CreateNationFrame("nationFrame", contentFrames[COMMUNITY.NATION])
end
local function CreateCommunityWnd()
  communityWnd = SetViewOfCommunity("communityWnd", "UIParent")
  coolTimeGroup.InitCoolTimeGroup(communityWnd)
  AttachContentBtnsHandler()
  communityWnd:Show(false)
  AttachCommunityConetents()
  function communityWnd:ShowProc()
    X2Team:RequestSiegeRaidRecruitInfo()
  end
  function communityWnd:OnHide()
    for i = 1, #communityWnd.contentFrames do
      if communityWnd.contentFrames[i]:IsVisible() then
        communityWnd.contentFrames[i]:Show(false)
        return
      end
    end
  end
  communityWnd:SetHandler("OnHide", communityWnd.OnHide)
  function communityWnd:OnUpdate(dt)
    coolTimeGroup.UpdateGlobalCoolTime(dt)
  end
  local function ShowNewWaitFriendAlarm(force)
    if force ~= true and communityWnd.contentFrames[COMMUNITY.RELATION]:IsActiveTab(FRIEND_TAB.WAIT) == true then
      return
    end
    if communityWnd.contentFrames[COMMUNITY.RELATION] then
      communityWnd.contentFrames[COMMUNITY.RELATION]:ShowWaitFriendAlarm(FRIEND_TAB.WAIT)
    end
  end
  local events = {
    ENTERED_WORLD = function()
      local isShow = X2Friend:IsExistWaitFriendToReceive()
      if isShow then
        ShowNewWaitFriendAlarm(true)
      end
    end,
    WAIT_FRIEND_ADD_ALARM = function()
      ShowNewWaitFriendAlarm(false)
    end
  }
  communityWnd:SetHandler("OnEvent", function(this, event, ...)
    events[event](...)
  end)
  RegistUIEvent(communityWnd, events)
  communityWnd.contentBtns:SetBGPushedOnly(1)
  return communityWnd
end
communityWnd = CreateCommunityWnd()
local tabMapping = {
  [UIC_FAMILY] = COMMUNITY.FAMILY,
  [UIC_EXPEDITION] = COMMUNITY.EXPEDITION,
  [UIC_NATION] = COMMUNITY.NATION
}
function ToggleCommunityWindow(show, data)
  if show == nil then
    show = not communityWnd:IsVisible()
  end
  local uic = UIC_COMMUNITY
  if data ~= nil then
    uic = data.uic
    tabIdx = tabMapping[uic]
  end
  if show and not UIParent:GetPermission(uic) then
    return
  end
  communityWnd:Show(show)
  if communityWnd:IsVisible() then
    ProcVisibleFrame(tabIdx)
  end
end
ADDON:RegisterContentTriggerFunc(UIC_COMMUNITY, ToggleCommunityWindow)
