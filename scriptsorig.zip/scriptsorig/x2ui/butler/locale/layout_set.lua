local layoutSet = {
  default = {
    rechargeProductionCostDialogExpandWidth = false,
    butlerBindingInfoDialogLeftPresetWidth = "small",
    upperHeaderTableBetweenRows = GetLayoutSetModule().headerTableInsetBetweenRowsDefault,
    bottomHeaderTableBetweenRows = 6,
    bottomHeaderTableBetweenRowsForTrade = 6,
    butlerTradingLocationLeftPresetRatio = 4598175219545276416
  },
  [GAMEON] = {
    butlerBindingInfoDialogLeftPresetWidth = "small",
    rechargeProductionCostDialogExpandWidth = true,
    upperHeaderTableBetweenRows = 2,
    bottomHeaderTableBetweenRows = 3,
    bottomHeaderTableBetweenRowsForTrade = -1
  },
  [KAKAONA] = {
    rechargeProductionCostDialogExpandWidth = true,
    butlerBindingInfoDialogLeftPresetWidth = "middle",
    upperHeaderTableBetweenRows = 4,
    bottomHeaderTableBetweenRows = 4,
    bottomHeaderTableBetweenRowsForTrade = 4
  },
  [MAILRU] = {
    rechargeProductionCostDialogExpandWidth = true,
    butlerBindingInfoDialogLeftPresetWidth = "middle",
    butlerTradingLocationLeftPresetRatio = 4599075939470750515,
    upperHeaderTableBetweenRows = GetLayoutSetModule().headerTableInsetBetweenRowsDefault,
    bottomHeaderTableBetweenRows = GetLayoutSetModule().headerTableInsetBetweenRowsDefault,
    bottomHeaderTableBetweenRowsForTrade = GetLayoutSetModule().headerTableInsetBetweenRowsDefault
  },
  [XLGAMES_TH] = {rechargeProductionCostDialogExpandWidth = true}
}
function GetLayoutSetButler()
  return L_HELPER.Get(layoutSet)
end
