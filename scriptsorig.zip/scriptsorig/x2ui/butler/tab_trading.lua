local CreateHowToFrame = function(id, parent)
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  wnd:SetExtent(352, 604)
  local howToInfo = W_MODULE:Create("howToInfo", wnd, W_MODULE.TYPES.TITLE_BOX, {
    title = GetCommonText("butler_traing_how_to_use")
  }, {
    [W_MODULE.ATTRIBUTE.LAYOUT_PRESET] = W_MODULE.LAYOUT_PRESET_TYPE.VARIETY_1,
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = wnd:GetWidth()
  })
  howToInfo:AddAnchor("TOP", wnd, 0, 0)
  howToInfo:SetHeight(wnd:GetHeight())
  local widgetInfo = {
    {
      name = "step1Title",
      type = "label",
      fontSize = FONT_SIZE.LARGE,
      fontColor = "middle_title",
      text = GetCommonText("butler_traing_step1_title"),
      offset = 0,
      widget = nil
    },
    {
      name = "step1Desc",
      type = "textbox",
      fontSize = FONT_SIZE.MIDDLE,
      fontColor = "default",
      text = GetCommonText("butler_traing_step1_desc"),
      offset = 5,
      widget = nil
    },
    {
      name = "step2Title",
      type = "label",
      fontSize = FONT_SIZE.LARGE,
      fontColor = "middle_title",
      text = GetCommonText("butler_traing_step2_title"),
      offset = 40,
      widget = nil
    },
    {
      name = "step2Desc",
      type = "textbox",
      fontSize = FONT_SIZE.MIDDLE,
      fontColor = "default",
      text = GetCommonText("butler_traing_step2_desc"),
      offset = 5,
      widget = nil
    },
    {
      name = "step3Title",
      type = "label",
      fontSize = FONT_SIZE.LARGE,
      fontColor = "middle_title",
      text = GetCommonText("butler_traing_step3_title"),
      offset = 40,
      widget = nil
    },
    {
      name = "step3Desc",
      type = "textbox",
      fontSize = FONT_SIZE.MIDDLE,
      fontColor = "default",
      text = GetCommonText("butler_traing_step3_desc"),
      offset = 5,
      widget = nil
    }
  }
  local infoTotalHeight = 0
  for i = 1, #widgetInfo do
    local info = widgetInfo[i]
    info.widget = wnd:CreateChildWidget(info.type, info.name, 0, true)
    info.widget:SetExtent(324, info.fontSize)
    info.widget:SetAutoResize(true)
    info.widget.style:SetFontSize(info.fontSize)
    info.widget.style:SetColorByKey(info.fontColor)
    info.widget:SetText(info.text)
    infoTotalHeight = infoTotalHeight + info.widget:GetHeight() + info.offset
  end
  widgetInfo[1].offset = (532 - infoTotalHeight) / 2
  for i = 1, #widgetInfo do
    local info = widgetInfo[i]
    howToInfo:AddBody(info.widget, false, {
      {
        myAnchor = "TOP",
        targetAnchor = "BOTTOM",
        x = 0,
        y = info.offset
      }
    })
  end
  local closeBtn = howToInfo:CreateChildWidget("button", "closeBtn", 0, true)
  closeBtn:SetText(GetCommonText("show_butler_specialty_trade"))
  closeBtn:SetStyle("text_default")
  closeBtn:AddAnchor("BOTTOM", howToInfo, 0, -10)
  function closeBtn:OnClick()
    parent:HideHowToFrame()
  end
  closeBtn:SetHandler("OnClick", closeBtn.OnClick)
  return wnd
end
local butlerLocale = GetLayoutSetButler()
local function CreateTopLeftFrame(id, parent)
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  wnd:SetExtent(352, 135)
  local myTractor = W_MODULE:Create("myTractor", wnd, W_MODULE.TYPES.TITLE_BOX, {
    title = GetCommonText("butler_tractor_config"),
    [W_MODULE.ATTRIBUTE.GUIDE_TOOLTIP] = GetCommonText("butler_tractor_config_tip")
  }, {
    [W_MODULE.ATTRIBUTE.LAYOUT_PRESET] = W_MODULE.LAYOUT_PRESET_TYPE.VARIETY_1,
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = wnd:GetWidth()
  })
  myTractor:AddAnchor("TOP", wnd, 0, 0)
  local tractorLabel = W_CTRL.CreateEdit("tractorLabel", myTractor)
  tractorLabel:SetHeight(26)
  tractorLabel.style:SetAlign(ALIGN_LEFT)
  tractorLabel.style:SetColorByKey("off_gray")
  tractorLabel:SetMaxTextLength(25)
  tractorLabel:Enable(false)
  myTractor:AddBody(tractorLabel)
  local detailInfo = myTractor:AddModule("defailtInfo", W_MODULE.TYPES.HEADER_TABLE_BASE, {
    [W_MODULE.ATTRIBUTE.WIDTH] = myTractor:GetContentWidth(),
    [W_MODULE.ATTRIBUTE.LEFT_WIDTH_RATIO] = 4604480259023595110,
    [W_MODULE.ATTRIBUTE.INSET_BETWEEN_ROWS] = butlerLocale.upperHeaderTableBetweenRows,
    valueAnchor = "RIGHT"
  }, nil, false)
  local rowInfo = {
    {
      key = "storage",
      body = {
        title = {
          string = GetCommonText("selected_tractor_storage")
        },
        value = {string = "-"}
      }
    }
  }
  for i = 1, #rowInfo do
    detailInfo:AddRow(rowInfo[i].key, rowInfo[i].body)
  end
  local buttonSet = myTractor:AddModule("buttonSet", W_MODULE.TYPES.BUTTON_SET)
  buttonSet:AddButton("register", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("register_tractor_item"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    clickFunc = function()
      if wnd.info.itemInfo == nil then
        ShowRegisterTractorDialog(parent)
      else
        ShowRemoveTractorDialog(parent, wnd.info)
      end
    end
  })
  myTractor:Refresh()
  local function UpdateTractorInfo(key, valueStr)
    detailInfo:UpdateRow(key, {
      value = {string = valueStr}
    })
  end
  function wnd:UpdateTractor()
    if wnd.info == nil then
      return
    end
    if wnd.info.itemInfo == nil then
      tractorLabel:SetText(GetCommonText("no_infomation"))
      buttonSet:UpdateButton("register", {
        [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("register_tractor_item")
      })
    else
      tractorLabel:SetText(wnd.info.name)
      buttonSet:UpdateButton("register", {
        [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("unregister_tractor_item")
      })
    end
    UpdateTractorInfo("storage", F_TEXT.SetSlashFormat(wnd.info.usedTractorStorageCount, wnd.info.totalTractorStorageCount))
  end
  function wnd:UpdateAll()
    wnd.info = X2Butler:GetMyTractorInfo()
    wnd:UpdateTractor()
  end
  function wnd:IsExistTractor()
    return wnd.info ~= nil and wnd.info.totalTractorStorageCount > 1
  end
  wnd:SetHeight(myTractor:GetHeight())
  return wnd
end
local function CreateBottomLeftFrame(id, parent)
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  wnd:SetExtent(352, 450)
  local specialtyConfig = W_MODULE:Create("specialtyConfig", wnd, W_MODULE.TYPES.TITLE_BOX, {
    title = GetCommonText("butler_trading_specialties_config"),
    [W_MODULE.ATTRIBUTE.GUIDE_TOOLTIP] = GetCommonText("butler_trading_specialties_config_tip")
  }, {
    [W_MODULE.ATTRIBUTE.LAYOUT_PRESET] = W_MODULE.LAYOUT_PRESET_TYPE.VARIETY_1,
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = wnd:GetWidth()
  })
  specialtyConfig:AddAnchor("TOP", wnd, 0, 0)
  specialtyConfig:AddAnchor("BOTTOM", wnd, 0, 0)
  local destinationList, specialties
  local locationInfoData = {
    width = specialtyConfig:GetContentWidth(),
    [W_MODULE.ATTRIBUTE.LEFT_WIDTH_RATIO] = butlerLocale.butlerTradingLocationLeftPresetRatio,
    valueAnchor = "RIGHT"
  }
  local locationInfo = W_MODULE:Create("locationInfo", specialtyConfig, W_MODULE.TYPES.HEADER_TABLE_BASE, locationInfoData)
  local CraftSort = function(targetTable)
    local Sort = function(a, b)
      return a.name < b.name and true or false
    end
    table.sort(targetTable, Sort)
    return targetTable
  end
  local rowInfo = {
    {
      key = "continent",
      body = {
        title = {
          string = GetUIText(PORTAL_TEXT, "world_name")
        },
        value = {string = "-"}
      }
    },
    {
      key = "starting_point",
      body = {
        [W_MODULE.ATTRIBUTE.SPECIAL_INSET_BETWEEN_ROW] = 10,
        title = {
          string = GetCommonText("butler_trading_starting_point")
        },
        value = {string = "-"}
      }
    },
    {
      key = "destinations",
      body = {
        title = {
          string = GetCommonText("butler_trading_destination")
        },
        value = {
          [W_MODULE.ATTRIBUTE.CREATE_ROW_FUNC] = function(valueWidgetName, valueMaxWidth, rowFrame)
            destinationList = W_CTRL.CreateComboBox(valueWidgetName, rowFrame)
            destinationList:SetWidth(locationInfoData.width * (1 - locationInfoData[W_MODULE.ATTRIBUTE.LEFT_WIDTH_RATIO]))
            function destinationList:SelectedProc()
              local destInfo = self:GetSelectedInfo()
              specialties:Clear()
              specialties:SetGuideText(GetCommonText("select_butler_trading_specialties"))
              local specialtyDatas = X2Butler:GetSpecialties(destInfo.value)
              if specialtyDatas ~= nil and #specialtyDatas ~= 0 then
                specialtyDatas = CraftSort(specialtyDatas)
                local specialtyNames = {}
                for i = 1, #specialtyDatas do
                  local data = {
                    text = specialtyDatas[i].name,
                    value = specialtyDatas[i].id
                  }
                  table.insert(specialtyNames, data)
                end
                specialties:AppendItems(specialtyNames, false)
              end
              wnd:UpdateSpecialtyConfigInfo()
            end
            return destinationList
          end
        }
      }
    },
    {
      key = "line",
      body = {
        [W_MODULE.ATTRIBUTE.LINE_ROW] = true
      }
    }
  }
  for i = 1, #rowInfo do
    locationInfo:AddRow(rowInfo[i].key, rowInfo[i].body)
  end
  specialtyConfig:AddBody(locationInfo)
  local function UpdateLocationInfo(key, valueStr)
    locationInfo:UpdateRow(key, {
      value = {string = valueStr}
    })
  end
  local specialtiesItemWnd = specialtyConfig:CreateChildWidget("emptywidget", "specialtiesItemWnd", 0, true)
  specialties = W_CTRL.CreateComboBox("specialties", specialtiesItemWnd)
  specialties:AddAnchor("TOPLEFT", specialtiesItemWnd, "TOPLEFT", 0, 0)
  specialties:SetWidth(specialtyConfig:GetContentWidth())
  function specialties:SelectedProc()
    wnd:UpdateSpecialtyConfigInfo()
  end
  local item = CreateIconButton("item", specialtiesItemWnd)
  item:AddAnchor("TOPLEFT", specialties, "BOTTOMLEFT", 0, 10)
  local itemName = specialtiesItemWnd:CreateChildWidget("label", "itemName", 0, true)
  itemName:AddAnchor("LEFT", item, "RIGHT", 5, 0)
  itemName:SetWidth(specialtyConfig:GetContentWidth() - ICON_SIZE.DEFAULT)
  itemName.style:SetEllipsis(true)
  itemName.style:SetFontSize(FONT_SIZE.MIDDLE)
  itemName.style:SetAlign(ALIGN_LEFT)
  itemName.style:SetColorByKey("default")
  specialtiesItemWnd:SetHeight(specialties:GetHeight() + 10 + ICON_SIZE.DEFAULT)
  specialtyConfig:AddBody(specialtiesItemWnd, true, {
    {
      myAnchor = "TOP",
      targetAnchor = "BOTTOM",
      x = 0,
      y = 10
    }
  })
  specialtyConfig:AddLine()
  local meterialsTitle = specialtyConfig:CreateChildWidget("label", "meterialsTitle", 0, true)
  meterialsTitle:SetAutoResize(true)
  meterialsTitle:SetHeight(FONT_SIZE.LARGE)
  meterialsTitle.style:SetFontSize(FONT_SIZE.LARGE)
  meterialsTitle.style:SetAlign(ALIGN_LEFT)
  meterialsTitle.style:SetColorByKey("middle_title")
  meterialsTitle:SetText(GetCommonText("require_resources"))
  specialtyConfig:AddBody(meterialsTitle, true, {
    {
      myAnchor = "TOPLEFT",
      targetAnchor = "BOTTOMLEFT",
      x = 0,
      y = 10
    }
  })
  local materials = W_MODULE:Create("materials", specialtyConfig, W_MODULE.TYPES.ICON_GROUP, {
    emptyIconShow = true,
    maxIconCount = 6,
    iconType = "constant",
    handlerFunc = {
      {
        handler = "OnContentUpdated",
        func = function(self_table, arg1, arg2, arg3)
          if arg1 ~= "stack_count_changed" then
            return
          end
          wnd:UpdateSpecialtyConfigInfo()
        end
      }
    }
  })
  specialtyConfig:AddBody(materials, true, {
    {
      myAnchor = "TOPLEFT",
      targetAnchor = "BOTTOMLEFT",
      x = 0,
      y = 10
    }
  })
  local specialtyInfo = W_MODULE:Create("specialtyInfo", specialtyConfig, W_MODULE.TYPES.HEADER_TABLE_BASE, {
    width = specialtyConfig:GetContentWidth(),
    [W_MODULE.ATTRIBUTE.LEFT_WIDTH_RATIO] = 4603579539098121011,
    [W_MODULE.ATTRIBUTE.INSET_BETWEEN_ROWS] = butlerLocale.bottomHeaderTableBetweenRowsForTrade,
    valueAnchor = "RIGHT"
  })
  rowInfo = {
    {
      key = "predict_time_cost",
      body = {
        title = {
          string = GetCommonText("predict_time_cost")
        },
        value = {string = "-"}
      }
    },
    {
      key = "laborpower_cost",
      body = {
        title = {
          string = GetCommonText("laborpower_cost")
        },
        value = {string = "-"}
      }
    },
    {
      key = "production_cost",
      body = {
        title = {
          string = GetCommonText("production_cost")
        },
        value = {string = "-"}
      }
    },
    {
      key = "default_production_cost",
      body = {
        title = {
          string = string.format("- %s", GetUIText(TOOLTIP_TEXT, "default"))
        },
        value = {string = "-"}
      }
    },
    {
      key = "overwork_production_cost",
      body = {
        title = {
          string = string.format("- %s", GetCommonText("addition"))
        },
        value = {string = "-"}
      }
    }
  }
  for i = 1, #rowInfo do
    specialtyInfo:AddRow(rowInfo[i].key, rowInfo[i].body)
  end
  specialtyConfig:AddBody(specialtyInfo, true, {
    {
      myAnchor = "TOP",
      targetAnchor = "BOTTOM",
      x = 0,
      y = 10
    }
  })
  local function UpdateSpecialtyInfo(key, valueStr, colorKey)
    specialtyInfo:UpdateRow(key, {
      value = {string = valueStr, colorKey = colorKey}
    })
  end
  local buttonSet = specialtyConfig:AddModule("buttonSet", W_MODULE.TYPES.BUTTON_SET)
  buttonSet:AddButton("start", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("butler_trading_start"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    clickFunc = function()
      if wnd.zoneGroupType ~= nil and wnd.zoneGroupType ~= 0 and wnd.specialtyTradeType ~= nil and wnd.specialtyTradeType ~= 0 then
        X2Butler:RegisterSpecialtyTrade(wnd.specialtyTradeType, wnd.zoneGroupType)
      end
    end
  })
  function wnd:UpdateSpecialtyConfigInfo()
    local destInfo = destinationList:GetSelectedInfo()
    local specialtyInfo = specialties:GetSelectedInfo()
    wnd.zoneGroupType = destInfo == nil and 0 or destInfo.value
    wnd.specialtyTradeType = specialtyInfo == nil and 0 or specialtyInfo.value
    wnd.info = X2Butler:GetSpecialtyDetailInfo(wnd.specialtyTradeType)
    local satisfyMaterials = wnd.info ~= nil
    local data = materials:GetData()
    data.iconInfo = {}
    if wnd.info ~= nil then
      item:SetInfo(X2Item:GetItemInfoByType(wnd.info.productInfo.itemType, wnd.info.productInfo.itemGame))
      itemName:SetText(wnd.info == nil and "" or wnd.info.productInfo.itemName)
      for i = 1, #wnd.info.materialInfo do
        data.iconInfo[i] = {
          info = wnd.info.materialInfo[i].item_info,
          stack = {
            wnd.info.materialInfo[i].count,
            wnd.info.materialInfo[i].amount
          }
        }
        satisfyMaterials = satisfyMaterials and wnd.info.materialInfo[i].count >= wnd.info.materialInfo[i].amount
      end
    else
      item:SetInfo(nil)
      itemName:SetText(GetCommonText("no_infomation"))
    end
    materials:SetData(data)
    local satisfyProductionCost = wnd.info ~= nil and wnd.info.productionCost + wnd.info.overworkProductionCost <= wnd.info.remainProductionCost
    local productionCostStr = wnd.info == nil and "-" or F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(wnd.info.productionCost + wnd.info.overworkProductionCost, true), F_TEXT.SetCommaFormat(wnd.info.remainProductionCost, true))
    local colorKey = "default"
    if not satisfyProductionCost then
      colorKey = "red"
    end
    UpdateSpecialtyInfo("production_cost", productionCostStr, colorKey)
    local defaultProductionCostStr = wnd.info == nil and "-" or F_TEXT.SetCommaFormat(wnd.info.productionCost, true)
    UpdateSpecialtyInfo("default_production_cost", defaultProductionCostStr, "default")
    local overworkProductionCostStr = wnd.info == nil and "-" or F_TEXT.SetCommaFormat(wnd.info.overworkProductionCost, true)
    UpdateSpecialtyInfo("overwork_production_cost", overworkProductionCostStr, "default")
    local satisfyLaborPower = wnd.info ~= nil and wnd.info.laborPower <= wnd.info.remainLaborPower
    local lpCostStr = wnd.info == nil and "-" or F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(wnd.info.laborPower, true), F_TEXT.SetCommaFormat(wnd.info.remainLaborPower, true))
    colorKey = "default"
    if not satisfyLaborPower then
      colorKey = "red"
    end
    UpdateSpecialtyInfo("laborpower_cost", lpCostStr, colorKey)
    local predictTimeStr = "-"
    if wnd.info ~= nil then
      local dtMin = locale.time.GetDateFormatFromSec(wnd.info.deliveryTimeMin)
      predictTimeMinStr = locale.time.GetRemainDateToDateFormat(dtMin)
      local dtMax = locale.time.GetDateFormatFromSec(wnd.info.deliveryTimeMax)
      predictTimeMaxStr = locale.time.GetRemainDateToDateFormat(dtMax)
      predictTimeStr = GetCommonText("from_to", predictTimeMinStr, predictTimeMaxStr)
    end
    UpdateSpecialtyInfo("predict_time_cost", predictTimeStr, "default")
    local tradingListInfo = parent:GetTradingListInfo()
    local satisfySlot = tradingListInfo ~= nil and 0 < tradingListInfo.emptySlotCount
    buttonSet:UpdateButton("start", {
      [W_MODULE.ATTRIBUTE.ENABLE] = satisfyMaterials and satisfyProductionCost and satisfyLaborPower and satisfySlot
    })
  end
  local DestinationSort = function(targetTable)
    local Sort = function(a, b)
      if a.continentName == b.continentName then
        return a.zoneGroupName < b.zoneGroupName and true or false
      else
        return a.continentName < b.continentName and true or false
      end
    end
    table.sort(targetTable, Sort)
    return targetTable
  end
  function wnd:UpdateAll()
    local zoneInfo = X2Butler:GetButlerZoneGroupInfo()
    if zoneInfo ~= nil then
      UpdateLocationInfo("continent", zoneInfo.continentName or "")
      UpdateLocationInfo("starting_point", zoneInfo.zoneGroupName)
    end
    destinationList:Clear()
    destinationList:SetGuideText(GetCommonText("select_butler_trading_destination"))
    local destinationZones = X2Butler:GetSellableZoneGroups()
    if destinationZones ~= nil and #destinationZones ~= 0 then
      destinationZones = DestinationSort(destinationZones)
      local destinationZoneNames = {}
      for i = 1, #destinationZones do
        local data = {
          text = destinationZones[i].zoneGroupName,
          value = destinationZones[i].id
        }
        table.insert(destinationZoneNames, data)
      end
      destinationList:AppendItems(destinationZoneNames, false)
    end
    specialties:Clear()
    specialties:SetGuideText(GetCommonText("select_butler_trading_specialties"))
    wnd:UpdateSpecialtyConfigInfo()
  end
  wnd:SetHeight(specialtyConfig:GetHeight())
  local backBtn = wnd:CreateChildWidget("button", "backBtn", 0, true)
  backBtn:AddAnchor("BOTTOMLEFT", buttonSet, -5, 0)
  backBtn:SetStyle("common_back")
  backBtn:Enable(true)
  function backBtn:OnClick()
    parent:ShowHowToFrame()
  end
  backBtn:SetHandler("OnClick", backBtn.OnClick)
  return wnd
end
local CreateRightFrame = function(id, parent)
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  wnd:SetExtent(504, 604)
  local tradingSpecialtiesInfo = W_MODULE:Create("tradingSpecialtiesInfo", wnd, W_MODULE.TYPES.TITLE_BOX, {
    title = GetCommonText("specialty_info_title")
  }, {
    [W_MODULE.ATTRIBUTE.LAYOUT_PRESET] = W_MODULE.LAYOUT_PRESET_TYPE.VARIETY_1,
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = wnd:GetWidth(),
    [W_MODULE.ATTRIBUTE.BODY_INSET] = {
      10,
      0,
      10,
      15
    }
  })
  tradingSpecialtiesInfo:AddAnchor("TOP", wnd, 0, 0)
  tradingSpecialtiesInfo:AddAnchor("BOTTOM", wnd, 0, 0)
  local function TradingSpecialtyDataSetFunc(subItem, data)
    subItem:ReleaseHandler("OnUpdate")
    if data then
      subItem.btnWnd:SetHeight(subItem.btnWnd.actionBtn:GetHeight())
      subItem.btnWnd.actionBtn:Enable(true)
      subItem.btnWnd.remainTime:Show(false)
      subItem.infoWnd:Show(false)
      subItem.msgTextBox:Show(false)
      subItem.btnWnd:Show(false)
      if data.specialtyTradeId ~= nil then
        subItem.btnWnd:SetHeight(subItem.btnWnd.remainTime:GetHeight() + subItem.btnWnd.actionBtn:GetHeight() + 10)
        subItem.btnWnd.remainTime:Show(true)
        subItem.btnWnd:Show(true)
        subItem.infoWnd:Show(true)
        subItem.btnWnd.actionBtn:SetText(GetCommonText("cancel"))
        local function OnClick()
          ShowCancelTradingSpecialtyDialog(parent, data.specialtyTradeId)
        end
        subItem.btnWnd.actionBtn:SetHandler("OnClick", OnClick)
        subItem.remainTime = data.remainTime * 1000
        function subItem:OnUpdate(dt)
          subItem.remainTime = subItem.remainTime - dt
          local dt = locale.time.GetDateFormatFromSec(math.floor(subItem.remainTime / 1000))
          subItem.btnWnd.remainTime:SetText(locale.time.GetRemainDateToDateFormat(dt))
          subItem.btnWnd.remainTime:Show(true)
        end
        subItem:SetHandler("OnUpdate", subItem.OnUpdate)
        subItem.infoWnd.item:SetInfo(data.itemInfo)
        subItem.infoWnd.itemName:SetText(data.itemInfo.name)
        subItem.infoWnd.destination:SetText(data.destination)
      elseif data.isEmpty then
        subItem.msgTextBox.style:SetColorByKey("default")
        subItem.msgTextBox:SetWidth(430)
        subItem.msgTextBox:SetText(GetCommonText("can_register_butler_trading"))
        subItem.msgTextBox:Show(true)
      elseif data.notEnoughTractorStorage then
        subItem.msgTextBox.style:SetColorByKey("red")
        subItem.msgTextBox:SetWidth(430)
        subItem.msgTextBox:SetText(GetCommonText("not_enough_tractor_storage"))
        subItem.msgTextBox:Show(true)
      else
        subItem.btnWnd.actionBtn:Enable(data.satisfy)
        subItem.btnWnd.actionBtn:SetText(GetUIText(MSG_BOX_TITLE_TEXT, "expand_harvest"))
        subItem.btnWnd:Show(true)
        local function OnClick()
          ShowExpandButlerFuncSlotDialog(parent, data.requireItemInfo, data.requireItemCount, "specialtyTradeSlot")
        end
        subItem.btnWnd.actionBtn:SetHandler("OnClick", OnClick)
        subItem.msgTextBox.style:SetColorByKey("character_slot_successor_df")
        subItem.msgTextBox:SetWidth(320)
        subItem.msgTextBox:SetText(GetCommonText("expand_harvest_req", tostring(data.requireLevel)))
        subItem.msgTextBox:Show(true)
      end
    end
    subItem:Show(data ~= nil)
  end
  local TradingSpecialtyLayoutSetFunc = function(subItem, row, listCtrl)
    local btnWnd = subItem:CreateChildWidget("emptywidget", "btnWnd", 0, true)
    btnWnd:AddAnchor("RIGHT", subItem, 0, 0)
    btnWnd:SetWidth(84)
    local remainTime = btnWnd:CreateChildWidget("label", "remainTime", 0, true)
    remainTime:AddAnchor("TOP", btnWnd, 0, 0)
    remainTime:SetAutoResize(true)
    remainTime:SetHeight(FONT_SIZE.DEFAULT)
    remainTime.style:SetColorByKey("default")
    remainTime:SetText("-")
    local actionBtn = btnWnd:CreateChildWidget("button", "actionBtn", 0, true)
    actionBtn:AddAnchor("BOTTOM", btnWnd, 0, 0)
    actionBtn:SetStyle("text_default")
    local infoWnd = subItem:CreateChildWidget("emptywidget", "infoWnd", 0, true)
    infoWnd:AddAnchor("TOPLEFT", subItem, 13, 0)
    infoWnd:SetExtent(328, 113)
    local item = CreateIconButton("item", infoWnd)
    item:AddAnchor("TOPLEFT", infoWnd, 0, 16)
    local itemName = infoWnd:CreateChildWidget("label", "itemName", 0, true)
    itemName:AddAnchor("LEFT", item, "RIGHT", 5, 0)
    itemName:SetWidth(300)
    itemName.style:SetEllipsis(true)
    itemName.style:SetFontSize(FONT_SIZE.MIDDLE)
    itemName.style:SetAlign(ALIGN_LEFT)
    itemName.style:SetColorByKey("default")
    local maxWidth = 313
    local destinationTitle = infoWnd:CreateChildWidget("label", "detinationTitle", 0, true)
    destinationTitle:SetHeight(FONT_SIZE.MIDDLE)
    destinationTitle:SetAutoResize(true)
    destinationTitle:AddAnchor("TOPLEFT", item, "BOTTOMLEFT", 0, 9)
    destinationTitle:SetText(GetCommonText("butler_trading_destination"))
    destinationTitle.style:SetColorByKey("default")
    local destination = infoWnd:CreateChildWidget("label", "destination", 0, true)
    destination:SetHeight(FONT_SIZE.MIDDLE)
    destination.style:SetEllipsis(true)
    destination:AddAnchor("LEFT", destinationTitle, "RIGHT", 25, 0)
    destination:AddAnchor("RIGHT", btnWnd, "LEFT", -35, 0)
    destination.style:SetColorByKey("default")
    destination.style:SetAlign(ALIGN_RIGHT)
    local msgTextBox = subItem:CreateChildWidget("textbox", "msgTextBox", 0, true)
    msgTextBox:AddAnchor("LEFT", subItem, 15, 0)
    msgTextBox:SetAutoWordwrap(true)
    msgTextBox:SetAutoResize(true)
    msgTextBox:SetHeight(FONT_SIZE.DEFAULT)
    msgTextBox.style:SetAlign(ALIGN_CENTER)
  end
  local scrollFrame = tradingSpecialtiesInfo:AddModule("scrollFrame", W_MODULE.TYPES.LISTCTRL, nil, {
    [W_MODULE.ATTRIBUTE.HAS_SCROLL] = true,
    [W_MODULE.ATTRIBUTE.ROW_COUNT] = 5,
    [W_MODULE.ATTRIBUTE.COLUMN_HEIGHT_TYPE] = nil,
    [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = 113,
    [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = true,
    [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = tradingSpecialtiesInfo:GetContentWidth() - 24,
        [W_MODULE.ATTRIBUTE.TEXT] = "",
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = TradingSpecialtyLayoutSetFunc,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = TradingSpecialtyDataSetFunc
      }
    }
  })
  function wnd:UpdateTradingSpecialtySlots()
    wnd.info = X2Butler:GetMySpecialtyTradeInfo()
    scrollFrame:SetData({
      [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
      data = wnd.info.slotDetailinfo
    })
  end
  return wnd
end
function CreateButlerTradingWnd(parent)
  local wnd = parent
  local howToFrame = CreateHowToFrame("howToFrame", parent)
  howToFrame:AddAnchor("TOPLEFT", parent, 0, 10)
  local topLeftFrame = CreateTopLeftFrame("topLeftFrame", parent)
  topLeftFrame:AddAnchor("TOPLEFT", parent, 0, 10)
  local bottomLeftFrame = CreateBottomLeftFrame("bottomLeftFrame", parent)
  bottomLeftFrame:AddAnchor("TOPLEFT", topLeftFrame, "BOTTOMLEFT", 0, 5)
  local rightFrame = CreateRightFrame("rightFrame", parent)
  rightFrame:AddAnchor("TOPRIGHT", parent, 0, 10)
  function wnd:HideHowToFrame()
    howToFrame:Show(false)
    topLeftFrame:Show(true)
    bottomLeftFrame:Show(true)
  end
  function wnd:ShowHowToFrame()
    howToFrame:Show(true)
    topLeftFrame:Show(false)
    bottomLeftFrame:Show(false)
  end
  function wnd:GetTradingListInfo()
    if rightFrame ~= nil then
      return rightFrame.info
    end
    return nil
  end
  function parent:Refresh()
    topLeftFrame:UpdateAll()
    rightFrame:UpdateTradingSpecialtySlots()
    bottomLeftFrame:UpdateAll()
    if topLeftFrame:IsExistTractor() then
      wnd:HideHowToFrame()
    else
      wnd:ShowHowToFrame()
    end
  end
  function parent:Clear()
    X2DialogManager:DeleteByOwnerWindow(parent:GetId())
    X2Butler:LeaveInteractionMode()
  end
  parent:SetHandler("OnHide", parent.Clear)
  function wnd:HandleEvent(event, arg1)
    if event == "tractor" then
      topLeftFrame:UpdateAll()
      rightFrame:UpdateTradingSpecialtySlots()
      bottomLeftFrame:UpdateSpecialtyConfigInfo()
    elseif event == "productionCost" then
      bottomLeftFrame:UpdateSpecialtyConfigInfo()
    elseif event == "specialtyTradeSlot" then
      topLeftFrame:UpdateAll()
      rightFrame:UpdateTradingSpecialtySlots()
      bottomLeftFrame:UpdateSpecialtyConfigInfo()
    elseif event == "harvestSlot" then
      bottomLeftFrame:UpdateSpecialtyConfigInfo()
    elseif event == "exp" and arg1 == true then
      rightFrame:UpdateTradingSpecialtySlots()
    end
  end
end
