local TAB = {
  MY_BUTLER = 1,
  FARMING = 2,
  TRADING = 3
}
local WINDOW_WIDTH = F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_900)
local WINDOW_HEIGHT = 715
local butlerTabInfo = {
  {
    validationCheckFunc = function()
      return true
    end,
    title = GetCommonText("butler_tab_my_butler"),
    subWindowConstructor = function(parent)
      CreateMyButlerWnd(parent)
    end
  },
  {
    validationCheckFunc = function()
      return true
    end,
    title = GetCommonText("butler_tab_farming"),
    subWindowConstructor = function(parent)
      CreateButlerFarmingWnd(parent)
    end
  },
  {
    validationCheckFunc = function()
      return true
    end,
    title = GetCommonText("butler_tab_trading"),
    subWindowConstructor = function(parent)
      CreateButlerTradingWnd(parent)
    end
  }
}
function CreateButlerInfoWnd(id, parent)
  local wnd = CreateWindow(id, parent, "butler", butlerTabInfo)
  wnd:SetExtent(WINDOW_WIDTH, WINDOW_HEIGHT)
  wnd:AddAnchor("CENTER", "UIParent", 0, 0)
  wnd:SetTitle(GetCommonText("butler"))
  local tab = wnd.tab
  function tab:OnTabChangedProc(idx)
    tab.window[idx]:Refresh()
  end
  function wnd:ShowProc()
    local info = X2Butler:GetMyButlerInfo()
    if info.isMine then
      tab:EnableTab(TAB.FARMING, true)
      tab:EnableTab(TAB.TRADING, X2Butler:IsEnableSpecialtyTrade())
    else
      tab:EnableTab(TAB.FARMING, false)
      tab:EnableTab(TAB.TRADING, false)
    end
    tab:SelectTab(TAB.MY_BUTLER)
  end
  function wnd:OnHide()
    local tabIdx = tab:GetSelectedTab()
    tab.window[tabIdx]:Clear()
  end
  wnd:SetHandler("OnHide", wnd.OnHide)
  function wnd:AttachButlerHarvestItem(slotIndex)
    if tab:GetSelectedTab() ~= TAB.FARMING then
      tab:SelectTab(TAB.FARMING)
    end
    X2Butler:SetReservedHarvest(slotIndex)
  end
  local butlerEvents = {
    BUTLER_INFO_UPDATED = function(event, arg1)
      if not wnd:IsVisible() then
        return
      end
      if event == "bind" or event == "unbind" then
        tab:EnableTab(TAB.FARMING, event == "bind")
        tab:EnableTab(TAB.TRADING, X2Butler:IsEnableSpecialtyTrade())
        if tab:GetSelectedTab() ~= TAB.MY_BUTLER then
          tab:SelectTab(TAB.MY_BUTLER)
        end
      elseif event == "exp" and arg1 then
        local isEnable = X2Butler:IsEnableSpecialtyTrade()
        tab:EnableTab(TAB.TRADING, isEnable)
        if not isEnable and tab:GetSelectedTab() == TAB.TRADING then
          tab:SelectTab(TAB.MY_BUTLER)
        end
      end
      tab.window[tab:GetSelectedTab()]:HandleEvent(event, arg1)
    end,
    LEVEL_CHANGED = function(_, stringId)
      if not wnd:IsVisible() then
        return
      end
      if not W_UNIT.IsMyUnitId(stringId) then
        return
      end
      local isEnable = X2Butler:IsEnableSpecialtyTrade()
      tab:EnableTab(TAB.TRADING, isEnable)
      if not isEnable and tab:GetSelectedTab() == TAB.TRADING then
        tab:SelectTab(TAB.MY_BUTLER)
      end
    end,
    BUTLER_UI_COMMAND = function(mode)
      if not wnd:IsVisible() then
        return
      end
      if mode == RECHARGE_COST_MODE then
        tab:SelectTab(TAB.MY_BUTLER)
        ShowRechargeProductionCostDialog(wnd)
      end
    end
  }
  wnd:SetHandler("OnEvent", function(this, event, ...)
    butlerEvents[event](...)
  end)
  RegistUIEvent(wnd, butlerEvents)
  return wnd
end
local butlerInfoWnd
function ToggleButlerInfo(isShow)
  local featureSet = X2Player:GetFeatureSet()
  if featureSet.butler ~= true or X2Player:IsInSeamlessZone() == false then
    return
  end
  if butlerInfoWnd == nil then
    if isShow == false then
      return
    end
    butlerInfoWnd = CreateButlerInfoWnd("butlerInfoWnd", "UIParent")
    isShow = true
  end
  if isShow == nil then
    isShow = not butlerInfoWnd:IsVisible()
  end
  butlerInfoWnd:Show(isShow)
end
ADDON:RegisterContentTriggerFunc(UIC_BUTLER_INFO, ToggleButlerInfo)
function AttachItemToButlerInfo(slotIndex)
  local featureSet = X2Player:GetFeatureSet()
  if featureSet.butler ~= true or butlerInfoWnd == nil or not butlerInfoWnd:IsVisible() then
    return false
  end
  if X2Butler:IsButlerHarvestItem(slotIndex) then
    butlerInfoWnd:AttachButlerHarvestItem(slotIndex)
    return true
  end
  return false
end
