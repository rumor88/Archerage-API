local CreateHowToFrame = function(id, parent)
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  wnd:SetExtent(352, 604)
  local howToInfo = W_MODULE:Create("howToInfo", wnd, W_MODULE.TYPES.TITLE_BOX, {
    title = GetCommonText("butler_harvest_how_to_use")
  }, {
    [W_MODULE.ATTRIBUTE.LAYOUT_PRESET] = W_MODULE.LAYOUT_PRESET_TYPE.VARIETY_1,
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = wnd:GetWidth()
  })
  howToInfo:AddAnchor("TOP", wnd, 0, 0)
  howToInfo:SetHeight(wnd:GetHeight())
  local widgetInfo = {
    {
      name = "step1Title",
      type = "label",
      fontSize = FONT_SIZE.LARGE,
      fontColor = "middle_title",
      text = GetCommonText("butler_farming_step1_title"),
      offset = 0,
      widget = nil
    },
    {
      name = "step1Desc",
      type = "textbox",
      fontSize = FONT_SIZE.MIDDLE,
      fontColor = "default",
      text = GetCommonText("butler_farming_step1_desc"),
      offset = 5,
      widget = nil
    },
    {
      name = "step2Title",
      type = "label",
      fontSize = FONT_SIZE.LARGE,
      fontColor = "middle_title",
      text = GetCommonText("butler_farming_step2_title"),
      offset = 40,
      widget = nil
    },
    {
      name = "step2Desc",
      type = "textbox",
      fontSize = FONT_SIZE.MIDDLE,
      fontColor = "default",
      text = GetCommonText("butler_farming_step2_desc"),
      offset = 5,
      widget = nil
    },
    {
      name = "step3Title",
      type = "label",
      fontSize = FONT_SIZE.LARGE,
      fontColor = "middle_title",
      text = GetCommonText("butler_farming_step3_title"),
      offset = 40,
      widget = nil
    },
    {
      name = "step3Desc",
      type = "textbox",
      fontSize = FONT_SIZE.MIDDLE,
      fontColor = "default",
      text = GetCommonText("butler_farming_step3_desc"),
      offset = 5,
      widget = nil
    }
  }
  local infoTotalHeight = 0
  for i = 1, #widgetInfo do
    local info = widgetInfo[i]
    info.widget = wnd:CreateChildWidget(info.type, info.name, 0, true)
    info.widget:SetExtent(324, info.fontSize)
    info.widget:SetAutoResize(true)
    info.widget.style:SetFontSize(info.fontSize)
    info.widget.style:SetColorByKey(info.fontColor)
    info.widget:SetText(info.text)
    infoTotalHeight = infoTotalHeight + info.widget:GetHeight() + info.offset
  end
  widgetInfo[1].offset = (532 - infoTotalHeight) / 2
  for i = 1, #widgetInfo do
    local info = widgetInfo[i]
    howToInfo:AddBody(info.widget, false, {
      {
        myAnchor = "TOP",
        targetAnchor = "BOTTOM",
        x = 0,
        y = info.offset
      }
    })
  end
  local closeBtn = howToInfo:CreateChildWidget("button", "closeBtn", 0, true)
  closeBtn:SetText(GetCommonText("show_butler_garden"))
  closeBtn:SetStyle("text_default")
  closeBtn:AddAnchor("BOTTOM", howToInfo, 0, -10)
  function closeBtn:OnClick()
    parent:HideHowToFrame()
  end
  closeBtn:SetHandler("OnClick", closeBtn.OnClick)
  return wnd
end
local butlerLocale = GetLayoutSetButler()
local function CreateTopLeftFrame(id, parent)
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  wnd:SetExtent(352, 180)
  local myGarden = W_MODULE:Create("myGarden", wnd, W_MODULE.TYPES.TITLE_BOX, {
    title = GetCommonText("select_butler_garden"),
    [W_MODULE.ATTRIBUTE.GUIDE_TOOLTIP] = GetCommonText("select_butler_garden_tip")
  }, {
    [W_MODULE.ATTRIBUTE.LAYOUT_PRESET] = W_MODULE.LAYOUT_PRESET_TYPE.VARIETY_1,
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = wnd:GetWidth()
  })
  myGarden:AddAnchor("TOP", wnd, 0, 0)
  local gardenList = W_CTRL.CreateComboBox("gardenList", myGarden)
  myGarden:AddBody(gardenList)
  local gardenInfo = myGarden:AddModule("gardenInfo", W_MODULE.TYPES.HEADER_TABLE_BASE, {
    width = 312,
    [W_MODULE.ATTRIBUTE.LEFT_WIDTH_RATIO] = 4603579539098121011,
    [W_MODULE.ATTRIBUTE.INSET_BETWEEN_ROWS] = butlerLocale.upperHeaderTableBetweenRows,
    valueAnchor = "RIGHT"
  }, nil, false)
  local rowInfo = {
    {
      key = "selectGardenSize",
      body = {
        title = {
          string = GetCommonText("selected_butler_garden_size")
        },
        value = {string = "-"}
      }
    },
    {
      key = "line",
      body = {
        [W_MODULE.ATTRIBUTE.LINE_ROW] = true
      }
    },
    {
      key = "gardenSizeInfo",
      body = {
        title = {
          string = GetCommonText("butler_garden_size_infos")
        },
        value = {string = " "}
      }
    },
    {
      key = "totalGardenSize",
      body = {
        title = {
          string = GetCommonText("butler_total_garden_size")
        },
        value = {string = "-"}
      }
    },
    {
      key = "totalUnderWaterGardenSize",
      body = {
        title = {
          string = GetCommonText("butler_total_under_water_garden_size")
        },
        value = {string = "-"}
      }
    }
  }
  for i = 1, #rowInfo do
    gardenInfo:AddRow(rowInfo[i].key, rowInfo[i].body)
  end
  local buttonSet = myGarden:AddModule("buttonSet", W_MODULE.TYPES.BUTTON_SET)
  buttonSet:AddButton("register", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(MSG_BOX_TITLE_TEXT, "add_butler_garden"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    clickFunc = function()
      ShowAddGardenDialog(parent, {
        usedGardenCount = wnd.usedGardenCount,
        maxGardenCount = wnd.maxGardenCount
      })
    end
  })
  buttonSet:AddButton("remove", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(MSG_BOX_TITLE_TEXT, "remove_butler_gargen"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    clickFunc = function()
      local info = gardenList:GetSelectedInfo()
      ShowRemoveGardenDialog(parent, info)
    end
  })
  myGarden:Refresh()
  local function UpdateGardenInfoRow(key, isValue, str, colorKey)
    if isValue then
      gardenInfo:UpdateRow(key, {
        value = {string = str, colorKey = colorKey}
      })
    else
      gardenInfo:UpdateRow(key, {
        title = {string = str, colorKey = colorKey}
      })
    end
  end
  function gardenList:SelectedProc()
    local info = gardenList:GetSelectedInfo()
    buttonSet:UpdateButton("remove", {
      [W_MODULE.ATTRIBUTE.ENABLE] = info ~= nil
    })
    UpdateGardenInfoRow("selectGardenSize", true, info == nil and "-" or F_TEXT.SetCommaFormat(info.size, true), "default")
  end
  function wnd:UpdateGarden(info)
    if info == nil then
      return
    end
    wnd.usedGardenCount = info.usedGardenCount
    wnd.maxGardenCount = info.maxGardenCount
    gardenList:Clear()
    gardenList:SetGuideText(GetCommonText("select_butler_garden_guide"))
    gardenList:AppendItems(info.gardenInfo, false)
    local registerBtnStr = ""
    if info.usedGardenCount > 0 then
      registerBtnStr = GetCommonText("additional_register")
    else
      registerBtnStr = GetUIText(MSG_BOX_TITLE_TEXT, "add_butler_garden")
    end
    buttonSet:UpdateButton("register", {
      [W_MODULE.ATTRIBUTE.TEXT] = registerBtnStr,
      [W_MODULE.ATTRIBUTE.ENABLE] = info.usedGardenCount < info.maxGardenCount
    })
    buttonSet:UpdateButton("remove", {
      [W_MODULE.ATTRIBUTE.ENABLE] = false
    })
    UpdateGardenInfoRow("selectGardenSize", true, "-", "default")
    wnd:UpdateGardenSize(info)
  end
  function wnd:UpdateGardenSize(info)
    local colorKey = "default_gray"
    local valueStr = "-"
    if info.isGardenActive then
      colorKey = "default"
      valueStr = F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(info.usedGardenSize, true), F_TEXT.SetCommaFormat(info.totalGardenSize, true))
    end
    UpdateGardenInfoRow("totalGardenSize", true, valueStr, colorKey)
    UpdateGardenInfoRow("totalGardenSize", false, GetCommonText("butler_total_garden_size"), colorKey)
    colorKey = "default_gray"
    valueStr = "-"
    if info.isUnderWaterGardenActive then
      colorKey = "default"
      valueStr = F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(info.usedUnderWaterGardenSize, true), F_TEXT.SetCommaFormat(info.totalUnderWaterGardenSize, true))
    end
    UpdateGardenInfoRow("totalUnderWaterGardenSize", true, valueStr, colorKey)
    UpdateGardenInfoRow("totalUnderWaterGardenSize", false, GetCommonText("butler_total_under_water_garden_size"), colorKey)
  end
  wnd:SetHeight(myGarden:GetHeight())
  return wnd
end
local function CreateBottomLeftFrame(id, parent)
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  wnd:SetExtent(352, 380)
  local register = W_MODULE:Create("register", wnd, W_MODULE.TYPES.TITLE_BOX, {
    title = GetCommonText("register_butler_harvest"),
    [W_MODULE.ATTRIBUTE.GUIDE_TOOLTIP] = GetCommonText("register_butler_harvest_tip")
  }, {
    [W_MODULE.ATTRIBUTE.LAYOUT_PRESET] = W_MODULE.LAYOUT_PRESET_TYPE.VARIETY_1,
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = wnd:GetWidth()
  })
  register:AddAnchor("TOP", wnd, 0, 0)
  register:AddAnchor("BOTTOM", wnd, 0, 0)
  local itemSlot = W_MODULE:Create("itemSlot", register, W_MODULE.TYPES.ICON_VERTICAL, nil, {
    [W_MODULE.ATTRIBUTE.USE_NAME_BG] = false
  })
  register:AddBody(itemSlot, false)
  itemSlot.iconButton:RegisterForClicks("RightButton")
  function itemSlot.iconButton:OnClickProc(arg)
    if arg == "LeftButton" then
      X2Butler:SetReservedHarvest()
    elseif wnd.itemCount ~= nil then
      X2Butler:ClearReservedHarvest()
    end
  end
  local harvestInfo = W_MODULE:Create("harvestInfo", register, W_MODULE.TYPES.HEADER_TABLE_BASE, {
    width = 312,
    [W_MODULE.ATTRIBUTE.LEFT_WIDTH_RATIO] = 4603579539098121011,
    [W_MODULE.ATTRIBUTE.INSET_BETWEEN_ROWS] = butlerLocale.bottomHeaderTableBetweenRows,
    valueAnchor = "RIGHT"
  })
  local function UpdateHarvestInfo(key, valueStr, colorKey)
    harvestInfo:UpdateRow(key, {
      value = {string = valueStr, colorKey = colorKey}
    })
  end
  local rowInfo = {
    {
      key = "time_cost",
      body = {
        title = {
          string = GetCommonText("time_cost")
        },
        value = {string = "-"}
      }
    },
    {
      key = "garden_size_cost",
      body = {
        title = {
          string = GetCommonText("garden_size_cost")
        },
        value = {string = "-"}
      }
    },
    {
      key = "laborpower_cost",
      body = {
        title = {
          string = GetCommonText("laborpower_cost")
        },
        value = {string = "-"}
      }
    },
    {
      key = "production_cost",
      body = {
        title = {
          string = GetCommonText("production_cost")
        },
        value = {string = "-"}
      }
    },
    {
      key = "default_production_cost",
      body = {
        title = {
          string = string.format("- %s", GetUIText(TOOLTIP_TEXT, "default"))
        },
        value = {string = "-"}
      }
    },
    {
      key = "overwork_production_cost",
      body = {
        title = {
          string = string.format("- %s", GetCommonText("addition"))
        },
        value = {string = "-"}
      }
    },
    {
      key = "row1",
      body = {
        [W_MODULE.ATTRIBUTE.LINE_ROW] = true
      }
    },
    {
      key = "butler_harvest_size",
      body = {
        title = {
          string = GetCommonText("butler_harvest_size")
        },
        value = {string = "-"}
      }
    },
    {
      key = "butler_harvest_repeat_count",
      body = {
        title = {
          string = GetCommonText("butler_harvest_repeat_count")
        },
        value = {string = "-"}
      }
    },
    {
      key = "row2",
      body = {
        [W_MODULE.ATTRIBUTE.LINE_ROW] = true
      }
    },
    {
      key = "register_count",
      body = {
        title = {
          string = GetCommonText("the_number_of")
        },
        value = {
          [W_MODULE.ATTRIBUTE.CREATE_ROW_FUNC] = function(valueWidgetName, valueMaxWidth, rowFrame)
            local spinner = W_ETC.CreateSpinner(valueWidgetName, rowFrame)
            function spinner:OnSpinnerValueChangeProc(valueStr)
              wnd:UpdateAmount(tonumber(valueStr))
            end
            wnd.spinner = spinner
            return spinner
          end
        }
      }
    }
  }
  for i = 1, #rowInfo do
    harvestInfo:AddRow(rowInfo[i].key, rowInfo[i].body)
  end
  register:AddBody(harvestInfo)
  local buttonSet = register:AddModule("buttonSet", W_MODULE.TYPES.BUTTON_SET)
  buttonSet:AddButton("register", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("request_harvest"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    clickFunc = function()
      if wnd.itemCount ~= nil then
        X2Butler:RegisterHarvest(wnd.spinner:GetCurValue())
      end
    end
  })
  function wnd:UpdateAmount(amount)
    local lpCostStr = wnd.itemCount == nil and "-" or F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(amount * wnd.laborPower, true), F_TEXT.SetCommaFormat(wnd.remainLaborPower, true))
    local colorKey = "default"
    if wnd.itemCount ~= nil and amount * wnd.laborPower > wnd.remainLaborPower then
      colorKey = "red"
    end
    UpdateHarvestInfo("laborpower_cost", lpCostStr, colorKey)
    local sizeCostStr = "-"
    colorKey = "default"
    if wnd.itemCount ~= nil then
      if wnd.isUnderWater then
        sizeCostStr = F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(amount * wnd.gardenSize, true), F_TEXT.SetCommaFormat(wnd.remainUnderWaterGardenSize, true))
        if amount * wnd.gardenSize > wnd.remainUnderWaterGardenSize then
          colorKey = "red"
        end
      else
        sizeCostStr = F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(amount * wnd.gardenSize, true), F_TEXT.SetCommaFormat(wnd.remainGardenSize, true))
        if amount * wnd.gardenSize > wnd.remainGardenSize then
          colorKey = "red"
        end
      end
    end
    UpdateHarvestInfo("garden_size_cost", sizeCostStr, colorKey)
    local defaultProductionCost = wnd.itemCount == nil and 0 or wnd.repeatCount * wnd.gardenSize * amount
    local overworkProductionCost = 0
    if wnd.isOverwork then
      overworkProductionCost = defaultProductionCost * wnd.overworkProductionCostRatio
      if overworkProductionCost % 1000 ~= 0 then
        overworkProductionCost = math.ceil(overworkProductionCost / 1000)
      else
        overworkProductionCost = overworkProductionCost / 1000
      end
    end
    local productionCostStr = wnd.itemCount == nil and "-" or F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(defaultProductionCost + overworkProductionCost, true), F_TEXT.SetCommaFormat(wnd.remainProductionCost, true))
    colorKey = "default"
    if wnd.itemCount ~= nil and defaultProductionCost + overworkProductionCost > wnd.remainProductionCost then
      colorKey = "red"
    end
    UpdateHarvestInfo("production_cost", productionCostStr, colorKey)
    local defaultProductionCostStr = wnd.itemCount == nil and "-" or F_TEXT.SetCommaFormat(defaultProductionCost, true)
    UpdateHarvestInfo("default_production_cost", defaultProductionCostStr, "default")
    local addedProductionCostStr = wnd.itemCount == nil and "-" or F_TEXT.SetCommaFormat(overworkProductionCost, true)
    UpdateHarvestInfo("overwork_production_cost", addedProductionCostStr, "default")
  end
  function wnd:UpdateSpinner(reset)
    local maxCount = 0
    if wnd.itemCount ~= nil then
      local sizeMax = 0
      if wnd.isUnderWater then
        sizeMax = math.floor(wnd.remainUnderWaterGardenSize / wnd.gardenSize)
      else
        sizeMax = math.floor(wnd.remainGardenSize / wnd.gardenSize)
      end
      local productionCost = wnd.repeatCount * wnd.gardenSize
      if wnd.isOverwork then
        local overworkProductionCost = productionCost * wnd.overworkProductionCostRatio
        if overworkProductionCost % 1000 ~= 0 then
          overworkProductionCost = math.ceil(overworkProductionCost / 1000)
        else
          overworkProductionCost = overworkProductionCost / 1000
        end
        productionCost = productionCost + overworkProductionCost
      end
      local costMax = math.floor(wnd.remainProductionCost / productionCost)
      maxCount = math.min(math.min(wnd.itemCount, sizeMax), costMax)
      if wnd.laborPower ~= 0 then
        local lpMax = math.floor(wnd.remainLaborPower / wnd.laborPower)
        maxCount = math.min(maxCount, lpMax)
      end
    end
    wnd.spinner:SetMinMaxValues(1, maxCount)
    if reset then
      wnd:UpdateAmount(1)
    end
  end
  function wnd:UpdateGardenInfo(info)
    if info == nill then
      return
    end
    wnd.remainGardenSize = info.totalGardenSize - info.usedGardenSize
    wnd.remainUnderWaterGardenSize = info.totalUnderWaterGardenSize - info.usedUnderWaterGardenSize
    wnd.remainProductionCost = info.remainProductionCost
    wnd.remainLaborPower = info.remainLaborPower
    wnd.overworkProductionCostRatio = info.overworkProductionCostRatio
    local jobCount = X2Butler:GetMyJobCount()
    if jobCount == nil then
    end
    wnd.isOverwork = jobCount.specialtyTradeCount > 0
    wnd:UpdateSpinner(false)
  end
  function wnd:UpdateReservedHarvest(info)
    local itemInfo
    if info ~= nil then
      itemInfo = info.itemInfo
      wnd.gardenSize = math.max(1, info.gardenSize)
      wnd.isUnderWater = info.isUnderWater
      wnd.repeatCount = math.max(1, info.repeatCount)
      wnd.itemCount = math.max(1, info.itemCount)
      wnd.laborPower = math.max(0, info.laborPower)
    else
      wnd.gardenSize = nil
      wnd.isUnderWater = nil
      wnd.repeatCount = nil
      wnd.itemCount = nil
      wnd.laborPower = nil
    end
    itemSlot:SetData({itemInfo = itemInfo, stack = 1})
    local growthTimeStr = "-"
    if info ~= nil then
      local dt = locale.time.GetDateFormatFromSec(info.growthTime)
      growthTimeStr = locale.time.GetRemainDateToDateFormat(dt)
    end
    UpdateHarvestInfo("time_cost", growthTimeStr, "default")
    UpdateHarvestInfo("butler_harvest_size", info == nil and "-" or F_TEXT.SetCommaFormat(info.gardenSize, true), "default")
    UpdateHarvestInfo("butler_harvest_repeat_count", info == nil and "-" or F_TEXT.SetCommaFormat(info.repeatCount, true), "default")
    wnd:UpdateSpinner(true)
    buttonSet:UpdateButton("register", {
      [W_MODULE.ATTRIBUTE.ENABLE] = wnd.spinner:IsEnabled()
    })
  end
  local backBtn = wnd:CreateChildWidget("button", "backBtn", 0, true)
  backBtn:AddAnchor("BOTTOMLEFT", buttonSet, -5, 0)
  backBtn:SetStyle("common_back")
  function backBtn:OnClick()
    parent:ShowHowToFrame()
  end
  backBtn:SetHandler("OnClick", backBtn.OnClick)
  return wnd
end
local CreateRightFrame = function(id, parent)
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  wnd:SetExtent(504, 604)
  local harvestInfo = W_MODULE:Create("harvestInfo", wnd, W_MODULE.TYPES.TITLE_BOX, {
    title = GetCommonText("butler_harvest_info"),
    [W_MODULE.ATTRIBUTE.GUIDE_TOOLTIP] = GetCommonText("current_butler_harvest_tip")
  }, {
    [W_MODULE.ATTRIBUTE.LAYOUT_PRESET] = W_MODULE.LAYOUT_PRESET_TYPE.VARIETY_1,
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = wnd:GetWidth(),
    [W_MODULE.ATTRIBUTE.BODY_INSET] = {
      10,
      0,
      10,
      15
    }
  })
  harvestInfo:AddAnchor("TOP", wnd, 0, 0)
  harvestInfo:AddAnchor("BOTTOM", wnd, 0, 0)
  local function HarvestDataSetFunc(subItem, data)
    subItem:ReleaseHandler("OnUpdate")
    if data then
      subItem.btnWnd:SetHeight(subItem.btnWnd.actionBtn:GetHeight())
      subItem.btnWnd.actionBtn:Enable(true)
      subItem.btnWnd.remainTime:Show(false)
      subItem.infoWnd:Show(false)
      subItem.msgLabel:Show(false)
      if data.harvestId ~= nil then
        subItem.btnWnd:SetHeight(subItem.btnWnd.remainTime:GetHeight() + subItem.btnWnd.actionBtn:GetHeight() + 10)
        subItem.btnWnd.remainTime:Show(true)
        subItem.infoWnd:Show(true)
        subItem.btnWnd.actionBtn:SetText(GetCommonText("cancel"))
        local function OnClick()
          ShowCancelHarvestDialog(parent, data.harvestId)
        end
        subItem.btnWnd.actionBtn:SetHandler("OnClick", OnClick)
        subItem.remainTime = data.remainTime * 1000
        function subItem:OnUpdate(dt)
          subItem.remainTime = subItem.remainTime - dt
          local dt = locale.time.GetDateFormatFromSec(math.floor(subItem.remainTime / 1000))
          subItem.btnWnd.remainTime:SetText(locale.time.GetRemainDateToDateFormat(dt))
          subItem.btnWnd.remainTime:Show(true)
        end
        subItem:SetHandler("OnUpdate", subItem.OnUpdate)
        subItem.infoWnd.item:SetInfo(data.itemInfo)
        subItem.infoWnd.item:SetStack(data.requestedAmount)
        subItem.infoWnd.itemName:SetText(data.itemInfo.name)
        F_COLOR.ApplyTextColor(subItem.infoWnd.itemName, F_COLOR.Hex2Dec(data.itemInfo.gradeColor))
        subItem:UpdateHarvestInfo("garden_size_cost", F_TEXT.SetCommaFormat(data.usedGardenSize, true))
        subItem:UpdateHarvestInfo("remain_harvest_repeat", F_TEXT.SetCommaFormat(data.repeatCount, true))
      elseif data.isEmpty then
        subItem.btnWnd.actionBtn:SetText(GetCommonText("find_harvest"))
        local function OnClick()
          parent:HideHowToFrame()
          ADDON:ShowContent(UIC_BAG, true)
          X2Butler:EnterInteractionMode(REGISTER_HARVEST_MODE)
        end
        subItem.btnWnd.actionBtn:SetHandler("OnClick", OnClick)
        subItem.msgLabel.style:SetColorByKey("default")
        subItem.msgLabel:SetText(GetCommonText("register_harvest_desc"))
        subItem.msgLabel:Show(true)
      else
        subItem.btnWnd.actionBtn:Enable(data.satisfy)
        subItem.btnWnd.actionBtn:SetText(GetUIText(MSG_BOX_TITLE_TEXT, "expand_harvest"))
        local function OnClick()
          ShowExpandButlerFuncSlotDialog(parent, data.requireItemInfo, data.requireItemCount, "harvestSlot")
        end
        subItem.btnWnd.actionBtn:SetHandler("OnClick", OnClick)
        subItem.msgLabel.style:SetColorByKey("character_slot_successor_df")
        subItem.msgLabel:SetText(GetCommonText("expand_harvest_req", tostring(data.requireLevel)))
        subItem.msgLabel:Show(true)
      end
    end
    subItem:Show(data ~= nil)
  end
  local HarvestLayoutSetFunc = function(subItem, row, listCtrl)
    local btnWnd = subItem:CreateChildWidget("emptywidget", "btnWnd", 0, true)
    btnWnd:AddAnchor("RIGHT", subItem, -5, 0)
    btnWnd:SetWidth(84)
    local remainTime = btnWnd:CreateChildWidget("label", "remainTime", 0, true)
    remainTime:AddAnchor("TOP", btnWnd, 0, 0)
    remainTime:SetAutoResize(true)
    remainTime:SetHeight(FONT_SIZE.DEFAULT)
    remainTime.style:SetColorByKey("default")
    remainTime:SetText("-")
    local actionBtn = btnWnd:CreateChildWidget("button", "actionBtn", 0, true)
    actionBtn:AddAnchor("BOTTOM", btnWnd, 0, 0)
    actionBtn:SetStyle("text_default")
    local infoWnd = subItem:CreateChildWidget("emptywidget", "infoWnd", 0, true)
    infoWnd:AddAnchor("TOPLEFT", subItem, 13, 0)
    infoWnd:SetExtent(328, 113)
    local item = CreateIconButton("item", infoWnd)
    item:AddAnchor("TOPLEFT", infoWnd, 0, 16)
    local itemName = infoWnd:CreateChildWidget("textbox", "itemName", 0, true)
    itemName:AddAnchor("LEFT", item, "RIGHT", 5, 0)
    itemName:SetWidth(300)
    itemName.style:SetFontSize(FONT_SIZE.MIDDLE)
    itemName:SetAutoResize(true)
    itemName:SetAutoWordwrap(true)
    itemName.style:SetAlign(ALIGN_LEFT)
    itemName.style:SetColorByKey("default")
    local harvest = W_MODULE:Create("harvest", infoWnd, W_MODULE.TYPES.HEADER_TABLE_BASE, {
      width = infoWnd:GetWidth(),
      [W_MODULE.ATTRIBUTE.LEFT_WIDTH_RATIO] = 4604480259023595110,
      valueAnchor = "RIGHT"
    })
    harvest:AddAnchor("TOPLEFT", item, "BOTTOMLEFT", 0, 9)
    local rowInfo = {
      {
        key = "garden_size_cost",
        body = {
          title = {
            string = GetCommonText("garden_size_cost")
          },
          value = {string = "-"}
        }
      },
      {
        key = "remain_harvest_repeat",
        body = {
          title = {
            string = GetCommonText("remain_harvest_repeat")
          },
          value = {string = "-"}
        }
      }
    }
    for i = 1, #rowInfo do
      harvest:AddRow(rowInfo[i].key, rowInfo[i].body)
    end
    function subItem:UpdateHarvestInfo(key, valueStr)
      harvest:UpdateRow(key, {
        value = {string = valueStr}
      })
    end
    local msgLabel = subItem:CreateChildWidget("label", "msgLabel", 0, true)
    msgLabel:AddAnchor("CENTER", infoWnd, 0, 0)
    msgLabel:SetAutoResize(true)
    msgLabel:SetHeight(FONT_SIZE.DEFAULT)
  end
  local scrollFrame = harvestInfo:AddModule("scrollFrame", W_MODULE.TYPES.LISTCTRL, nil, {
    [W_MODULE.ATTRIBUTE.HAS_SCROLL] = true,
    [W_MODULE.ATTRIBUTE.ROW_COUNT] = 5,
    [W_MODULE.ATTRIBUTE.COLUMN_HEIGHT_TYPE] = nil,
    [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = 113,
    [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = true,
    [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = harvestInfo:GetContentWidth() - 24,
        [W_MODULE.ATTRIBUTE.TEXT] = "",
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = HarvestLayoutSetFunc,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = HarvestDataSetFunc
      }
    }
  })
  function wnd:UpdateHarvestSlot(info)
    scrollFrame:SetData({
      [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
      data = info
    })
  end
  return wnd
end
function CreateButlerFarmingWnd(parent)
  local wnd = parent
  local howToFrame = CreateHowToFrame("howToFrame", parent)
  howToFrame:AddAnchor("TOPLEFT", parent, 0, 10)
  local topLeftFrame = CreateTopLeftFrame("topLeftFrame", parent)
  topLeftFrame:AddAnchor("TOPLEFT", parent, 0, 10)
  local bottomLeftFrame = CreateBottomLeftFrame("bottomLeftFrame", parent)
  bottomLeftFrame:AddAnchor("TOPLEFT", topLeftFrame, "BOTTOMLEFT", 0, 5)
  local rightFrame = CreateRightFrame("rightFrame", parent)
  rightFrame:AddAnchor("TOPRIGHT", parent, 0, 10)
  function wnd:HideHowToFrame()
    howToFrame:Show(false)
    topLeftFrame:Show(true)
    bottomLeftFrame:Show(true)
  end
  function wnd:ShowHowToFrame()
    howToFrame:Show(true)
    topLeftFrame:Show(false)
    bottomLeftFrame:Show(false)
  end
  function parent:Refresh()
    local gInfo = X2Butler:GetMyGardenInfo()
    topLeftFrame:UpdateGarden(gInfo)
    bottomLeftFrame:UpdateGardenInfo(gInfo)
    bottomLeftFrame:UpdateReservedHarvest(nil)
    local hInfo = X2Butler:GetMyHarvestInfo()
    rightFrame:UpdateHarvestSlot(hInfo)
    if gInfo ~= nil and gInfo.usedGardenCount > 0 then
      wnd:HideHowToFrame()
    else
      wnd:ShowHowToFrame()
    end
  end
  function parent:Clear()
    X2DialogManager:DeleteByOwnerWindow(parent:GetId())
    X2Butler:LeaveInteractionMode()
    X2Butler:ClearReservedHarvest()
  end
  parent:SetHandler("OnHide", parent.Clear)
  function wnd:HandleEvent(event, arg1)
    if event == "garden" then
      local info = X2Butler:GetMyGardenInfo()
      topLeftFrame:UpdateGarden(info)
      bottomLeftFrame:UpdateGardenInfo(info)
    elseif event == "productionCost" then
      local info = X2Butler:GetMyGardenInfo()
      bottomLeftFrame:UpdateGardenInfo(info)
    elseif event == "reservedHarvest" then
      if not bottomLeftFrame:IsVisible() then
        wnd:HideHowToFrame()
      end
      local info = X2Butler:GetReservedHarvest()
      bottomLeftFrame:UpdateReservedHarvest(info)
    elseif event == "harvestSlot" then
      local info = X2Butler:GetMyGardenInfo()
      topLeftFrame:UpdateGardenSize(info)
      bottomLeftFrame:UpdateGardenInfo(info)
      bottomLeftFrame:UpdateReservedHarvest(X2Butler:GetReservedHarvest())
      local info = X2Butler:GetMyHarvestInfo()
      rightFrame:UpdateHarvestSlot(info)
    elseif event == "specialtyTradeSlot" then
      local info = X2Butler:GetMyGardenInfo()
      bottomLeftFrame:UpdateGardenInfo(info)
    elseif event == "exp" and arg1 == true then
      local info = X2Butler:GetMyGardenInfo()
      topLeftFrame:UpdateGarden(info)
      bottomLeftFrame:UpdateGardenInfo(info)
    end
  end
end
