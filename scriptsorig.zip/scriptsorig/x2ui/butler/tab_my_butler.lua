local CreateBindInfoFrame = function(id, parent)
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  local worldName = wnd:CreateChildWidget("label", "worldName", 0, true)
  worldName:AddAnchor("TOP", wnd, 0, 0)
  worldName:SetHeight(FONT_SIZE.LARGE)
  worldName:SetAutoResize(true)
  worldName.style:SetFontSize(FONT_SIZE.LARGE)
  worldName.style:SetColorByKey("middle_title")
  local desc = wnd:CreateChildWidget("textbox", "desc", 0, true)
  desc:AddAnchor("BOTTOM", wnd, 0, 0)
  desc:SetWidth(700)
  desc:SetAutoResize(true)
  desc.style:SetColorByKey("default")
  desc:SetText(GetCommonText("butler_bind_other_world"))
  wnd:SetExtent(700, worldName:GetHeight() + desc:GetHeight() + FONT_SIZE.LARGE)
  function wnd:UpdateBind(info)
    worldName:SetText(string.format("[%s]", info.bindWorldName))
  end
  return wnd
end
local CreateLeftFrame = function(id, parent, desc)
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  wnd:SetExtent(316, 604)
  local butlerInfo = W_MODULE:Create("butlerInfo", wnd, W_MODULE.TYPES.TITLE_BOX, {
    title = GetCommonText("my_butler_info"),
    [W_MODULE.ATTRIBUTE.GUIDE_TOOLTIP] = GetCommonText("my_butler_info_tip", GetCommonText(X2Butler:GetResetWeeklyDay()))
  }, {
    [W_MODULE.ATTRIBUTE.LAYOUT_PRESET] = W_MODULE.LAYOUT_PRESET_TYPE.VARIETY_1,
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = wnd:GetWidth(),
    [W_MODULE.ATTRIBUTE.BODY_INSET] = {
      10,
      10,
      10,
      15
    }
  })
  butlerInfo:SetHeight(wnd:GetHeight())
  butlerInfo:AddAnchor("TOPLEFT", wnd, 0, 0)
  local nameInfo = butlerInfo:CreateChildWidget("emptywidget", "nameInfo", 0, true)
  nameInfo:SetHeight(26)
  butlerInfo:AddBody(nameInfo)
  local nameLabel = W_CTRL.CreateEdit("nameLabel", nameInfo)
  nameLabel:SetHeight(nameInfo:GetHeight())
  nameLabel:AddAnchor("LEFT", nameInfo, "LEFT", 0, 0)
  nameLabel.style:SetAlign(ALIGN_LEFT)
  nameLabel.style:SetColorByKey("off_gray")
  nameLabel:SetMaxTextLength(25)
  nameLabel:Enable(false)
  local changeNameBtn = nameInfo:CreateChildWidget("button", "changeNameBtn", 0, true)
  changeNameBtn:SetStyle("write")
  changeNameBtn:AddAnchor("RIGHT", nameInfo, "RIGHT", 0, 0)
  local blockRename = X2Player:GetFeatureSet().blockRename
  if blockRename then
    nameLabel:SetWidth(butlerInfo:GetWidth() - 20)
  else
    nameLabel:SetWidth(butlerInfo:GetWidth() - changeNameBtn:GetWidth() - 20)
  end
  local screenWidth = UIParent:GetScreenWidth()
  local screenHeight = UIParent:GetScreenHeight()
  local modelView = CreateModelview("modelView", butlerInfo)
  modelView:SetExtent(300, 300)
  butlerInfo:AddBody(modelView, false)
  modelView:SetTextureSize(screenWidth, screenHeight)
  modelView:SetModelViewExtent(300, 300)
  modelView:SetModelViewCoords((screenWidth - 300) / 2, (screenHeight - 300) / 2, 300, 300)
  modelView:SetModelViewBackground(TEXTURE_PATH.FAIRY, "fairy_bg")
  modelView:ShowRotateButton(false)
  modelView:SetDisableColorGrading(true)
  local butlerResourceBg = CreateContentBackground(wnd, "TYPE11", "bg_02")
  butlerResourceBg:AddAnchor("TOP", butlerInfo, "BOTTOM", 0, 5)
  butlerResourceBg:SetExtent(316, 90)
  local productionCostBar = W_BAR.CreateStatusBar("productionCostBar", wnd, "butlerProductionCostGuage")
  productionCostBar:AddAnchor("TOP", butlerResourceBg, 0, 30)
  productionCostBar:SetExtent(288, 11)
  local productionCostLabel = wnd:CreateChildWidget("label", "productionCostLabel", 0, true)
  productionCostLabel:AddAnchor("BOTTOMLEFT", productionCostBar, "TOPLEFT", 0, -2)
  productionCostLabel:SetHeight(FONT_SIZE.MIDDLE)
  productionCostLabel:SetAutoResize(true)
  productionCostLabel.style:SetAlign(ALIGN_LEFT)
  productionCostLabel.style:SetColorByKey("default")
  local lpBar = W_BAR.CreateStatusBar("lpbar", wnd, "butlerLpGuage")
  lpBar:AddAnchor("BOTTOM", butlerResourceBg, 0, -10)
  lpBar:SetExtent(288, 11)
  local lpLabel = wnd:CreateChildWidget("label", "lpLabel", 0, true)
  lpLabel:AddAnchor("BOTTOMLEFT", lpBar, "TOPLEFT", 0, -2)
  lpLabel:SetHeight(FONT_SIZE.MIDDLE)
  lpLabel:SetAutoResize(true)
  lpLabel.style:SetAlign(ALIGN_LEFT)
  lpLabel.style:SetColorByKey("default")
  local expBg = CreateContentBackground(wnd, "TYPE11", "bg_02")
  expBg:AddAnchor("TOP", butlerResourceBg, "BOTTOM", 0, 5)
  expBg:SetExtent(316, 52)
  local expBar = W_BAR.CreateStatusBar("expBar", wnd, "butlerExpGuage")
  expBar:AddAnchor("BOTTOM", expBg, 0, -5)
  expBar:SetExtent(288, 14)
  function expBar:OnEnter()
    if expBar.tooltip ~= nil then
      SetTooltip(expBar.tooltip, self)
    else
      HideTooltip()
    end
  end
  expBar:SetHandler("OnEnter", expBar.OnEnter)
  local levelLabel = wnd:CreateChildWidget("label", "levelLabel", 0, true)
  levelLabel:AddAnchor("BOTTOMLEFT", expBar, "TOPLEFT", 0, -2)
  levelLabel:SetHeight(FONT_SIZE.XLARGE)
  levelLabel:SetAutoResize(true)
  levelLabel.style:SetAlign(ALIGN_LEFT)
  levelLabel.style:SetFontSize(FONT_SIZE.XLARGE)
  levelLabel.style:SetColorByKey("default")
  local levelBg = wnd:CreateDrawable(TEXTURE_PATH.FAIRY, "fairy", "background")
  levelBg:AddAnchor("TOPLEFT", expBg, 12, 0)
  local tipBtn = wnd:CreateChildWidget("button", "tipBtn", 0, true)
  tipBtn:SetStyle("question_mark")
  tipBtn:AddAnchor("BOTTOMRIGHT", expBar, "TOPRIGHT", 0, -3)
  local tipLabel = wnd:CreateChildWidget("label", "tipLabel", 0, true)
  tipLabel:AddAnchor("RIGHT", tipBtn, "LEFT", -3, 0)
  tipLabel:SetHeight(FONT_SIZE.MIDDLE)
  tipLabel:SetAutoResize(true)
  tipLabel.style:SetAlign(ALIGN_RIGHT)
  tipLabel.style:SetFontSize(FONT_SIZE.MIDDLE)
  tipLabel.style:SetColorByKey("middle_title")
  local bindingInfoBtn = wnd:CreateChildWidget("button", "bindingInfoBtn", 0, true)
  bindingInfoBtn:SetText(GetUIText(MSG_BOX_TITLE_TEXT, "butler_binding_info"))
  bindingInfoBtn:SetStyle("text_default")
  local changeLookBtn = wnd:CreateChildWidget("button", "changeLookBtn", 0, true)
  changeLookBtn:SetStyle("butler_change_look")
  local chargeProductionCostBtn = wnd:CreateChildWidget("button", "chargeProductionCostBtn", 0, true)
  chargeProductionCostBtn:SetStyle("plus")
  chargeProductionCostBtn:AddAnchor("BOTTOMRIGHT", productionCostBar, "TOPRIGHT", 0, -2)
  local effectDrawable = chargeProductionCostBtn:CreateEffectDrawableByKey(TEXTURE_PATH.FAIRY, "fairy_btn_alarm", "artwork")
  effectDrawable:SetVisible(false)
  effectDrawable:SetEffectPriority(1, "alpha", 0, 0)
  effectDrawable:SetEffectInitialColor(1, 1, 1, 1, 0)
  effectDrawable:SetEffectFinalColor(1, 1, 1, 1, 0)
  effectDrawable:SetEffectInterval(1, 4602678819172646912)
  effectDrawable:SetEffectPriority(2, "alpha", 0, 0)
  effectDrawable:SetEffectInitialColor(2, 1, 1, 1, 1)
  effectDrawable:SetEffectFinalColor(2, 1, 1, 1, 1)
  effectDrawable:SetEffectInterval(2, 4602678819172646912)
  effectDrawable:AddAnchor("CENTER", chargeProductionCostBtn, 0, 0)
  local chargeLpBtn = wnd:CreateChildWidget("button", "chargeLpBtn", 0, true)
  chargeLpBtn:SetStyle("plus")
  chargeLpBtn:AddAnchor("BOTTOMRIGHT", lpBar, "TOPRIGHT", 0, -2)
  bindingInfoBtn:AddAnchor("BOTTOMLEFT", wnd, "BOTTOMLEFT", 10, 0)
  changeLookBtn:AddAnchor("BOTTOMRIGHT", wnd, "BOTTOMRIGHT", -10, 0)
  function tipBtn:OnClick()
    ShowButlerLevelEffectTipDialog(parent:GetParent(), desc.levelEffects, wnd.effectLevel)
  end
  tipBtn:SetHandler("OnClick", tipBtn.OnClick)
  function changeNameBtn:OnClick()
    ShowDialogChangeNameButler(parent:GetParent(), nameLabel:GetText())
  end
  changeNameBtn:SetHandler("OnClick", changeNameBtn.OnClick)
  function bindingInfoBtn:OnClick()
    ShowButlerBindingInfoDialog(parent:GetParent(), wnd.isMine)
  end
  bindingInfoBtn:SetHandler("OnClick", bindingInfoBtn.OnClick)
  function changeLookBtn:OnClick()
    ShowButlerChangeLookDialog(parent:GetParent())
  end
  changeLookBtn:SetHandler("OnClick", changeLookBtn.OnClick)
  changeLookBtn:SetHandler("OnEnter", function(self)
    SetTooltip(GetCommonText("change_butler_look_tip"), self)
  end)
  function chargeProductionCostBtn:OnClick()
    ShowRechargeProductionCostDialog(parent:GetParent())
  end
  chargeProductionCostBtn:SetHandler("OnClick", chargeProductionCostBtn.OnClick)
  chargeProductionCostBtn.productionCostFreeChargeCount = 0
  chargeProductionCostBtn:SetHandler("OnEnter", function(self)
    SetTooltip(GetCommonText("remain_free_recharge_count", tostring(chargeProductionCostBtn.productionCostFreeChargeCount)), self)
  end)
  function chargeLpBtn:OnClick()
    ShowButlerRechargeLpDialog(parent:GetParent())
  end
  chargeLpBtn:SetHandler("OnClick", chargeLpBtn.OnClick)
  function wnd:UpdateName(info)
    nameLabel:SetText(info.name)
  end
  function wnd:UpdateModel(info)
    modelView:StopAnimation()
    modelView:InitByModelRef(info.model, "dwarf", "female", true)
    modelView:PlayAnimation("fist_ba_relaxed_idle", true)
    modelView:AdjustCameraPosToModel(0, info.testModelViewOffsetZ)
  end
  function wnd:UpdateProductionCost(info)
    local lpStr = string.format("%s %s", GetCommonText("butler_production_cost"), F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(info.remainProductionCost, true), F_TEXT.SetCommaFormat(info.maxProductionCost, true)))
    productionCostLabel:SetText(lpStr)
    productionCostBar:SetMinMaxValues(0, info.maxProductionCost)
    productionCostBar:SetValue(info.remainProductionCost)
  end
  function wnd:UpdateProductionCostChargeButton()
    chargeProductionCostBtn.productionCostFreeChargeCount = X2Butler:GetProductionCostFreeChargeCount()
    if chargeProductionCostBtn.productionCostFreeChargeCount > 0 then
      effectDrawable:SetStartEffect(true)
    else
      effectDrawable:SetStartEffect(false)
    end
  end
  function wnd:UpdateLaborpower(info)
    local lpStr = string.format("%s %s", GetUIText(ATTRIBUTE_TEXT, "labor_power"), F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(info.laborPower, true), F_TEXT.SetCommaFormat(info.maxLaborPower, true)))
    lpLabel:SetText(lpStr)
    lpBar:SetMinMaxValues(0, info.maxLaborPower)
    lpBar:SetValue(info.laborPower)
  end
  function wnd:UpdateExp(info)
    local maxExp = info.maxExp and info.maxExp or info.exp
    expBar:SetMinMaxValues(info.minExp, maxExp)
    expBar:SetValue(info.exp)
    local currentExp = info.exp - info.minExp
    if currentExp >= maxExp - info.minExp then
      currentExp = maxExp - info.minExp - 1
    end
    expBar.tooltip = F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(currentExp), F_TEXT.SetCommaFormat(maxExp - info.minExp))
    levelLabel:SetText(tostring(info.level))
    tipLabel:Show(info.effectLevel ~= nil)
    tipLabel:SetText(GetCommonText("butler_level_effect_applied", tostring(info.effectLevel)))
    wnd.effectLevel = info.effectLevel
    if wnd.level ~= nil and wnd.level ~= info.level then
      wnd:UpdateLaborpower(info)
    end
    wnd.level = info.level
  end
  function wnd:UpdateBind(info)
    wnd:UpdateName(info)
    wnd:UpdateModel(info)
    wnd:UpdateProductionCost(info)
    wnd:UpdateProductionCostChargeButton()
    wnd:UpdateLaborpower(info)
    wnd:UpdateExp(info)
    changeNameBtn:Enable(info.isMine and not blockRename)
    changeNameBtn:Show(not blockRename)
    bindingInfoBtn:Enable(not info.isFree)
    changeLookBtn:Enable(info.isMine)
    chargeProductionCostBtn:Enable(info.isMine)
    chargeLpBtn:Enable(info.isMine)
    wnd.isMine = info.isMine
  end
  function wnd:Clear()
    modelView:StopAnimation()
    modelView:ClearModel()
  end
  return wnd
end
local CreateCenterFrame = function(id, parent, desc)
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  wnd:SetExtent(269, 604)
  local equipInfo = W_MODULE:Create("equipInfo", wnd, W_MODULE.TYPES.TITLE_BOX, {
    title = GetCommonText("butler_production_equip")
  }, {
    [W_MODULE.ATTRIBUTE.LAYOUT_PRESET] = W_MODULE.LAYOUT_PRESET_TYPE.VARIETY_1,
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = wnd:GetWidth()
  })
  equipInfo:AddAnchor("TOP", wnd, 0, 0)
  local equipSlots = W_MODULE:Create("equipSlots", equipInfo, W_MODULE.TYPES.ICON_GROUP, {
    emptyIconShow = true,
    maxIconCount = table.getn(desc.equipSlots),
    [W_MODULE.ATTRIBUTE.ICON_CLICK_FUNC] = function(arg, index, iconInfo)
      if wnd.isMine == true then
        if arg == "LeftButton" then
          X2Butler:PickupButlerEquipment(desc.equipSlots[index])
        else
          X2Butler:UnequipButlerEquipment(desc.equipSlots[index])
        end
      end
    end
  })
  equipSlots:RegisterForClick("RightButton")
  equipInfo:AddBody(equipSlots)
  local changeBtn = equipInfo:CreateChildWidget("button", "changeBtn", 0, true)
  changeBtn:SetText(GetCommonText("change_butler_equipment"))
  changeBtn:SetStyle("text_default")
  equipInfo:AddBody(changeBtn, false)
  function changeBtn:OnClick()
    ADDON:ShowContent(UIC_BAG, true)
    X2Butler:EnterInteractionMode(SWAP_EQUIPMENT_MODE)
  end
  changeBtn:SetHandler("OnClick", changeBtn.OnClick)
  local modifierInfo = W_MODULE:Create("modifierInfo", wnd, W_MODULE.TYPES.TITLE_BOX, {
    preset = "other",
    title = GetCommonText("butler_production_info")
  }, {
    [W_MODULE.ATTRIBUTE.LAYOUT_PRESET] = W_MODULE.LAYOUT_PRESET_TYPE.VARIETY_1,
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = wnd:GetWidth()
  })
  modifierInfo:AddAnchor("TOP", equipInfo, "BOTTOM", 0, 0)
  local scrollFrame = CreateScrollWindow(modifierInfo, "scrollFrame", 0)
  scrollFrame:SetExtent(245, 328)
  modifierInfo:AddBody(scrollFrame, false)
  local attributes = W_MODULE:Create("attributes", scrollFrame.content, W_MODULE.TYPES.HEADER_TABLE_BASE, {
    width = 220,
    [W_MODULE.ATTRIBUTE.LEFT_WIDTH_RATIO] = 4604930618986332160,
    valueAnchor = "RIGHT"
  })
  attributes:AddAnchor("TOPLEFT", scrollFrame.content, 0, 0)
  attributes:AddAnchor("TOPRIGHT", scrollFrame.content, -5, 0)
  for ig, attributeGroup in ipairs(desc.attributes) do
    if ig ~= 1 then
      attributes:AddRow("line", {
        [W_MODULE.ATTRIBUTE.LINE_ROW] = true
      })
    end
    for ia, info in ipairs(attributeGroup) do
      attributes:AddRow(info.name, {
        title = {
          string = GetUIText(ATTRIBUTE_TEXT, info.name)
        },
        value = {string = "0%"}
      })
    end
  end
  scrollFrame:ResetScroll(attributes:GetHeight())
  local gradeInfo = W_MODULE:Create("gradeInfo", wnd, W_MODULE.TYPES.TITLE_BOX, {
    preset = "other",
    title = GetCommonText("butler_grade_info")
  }, {
    [W_MODULE.ATTRIBUTE.LAYOUT_PRESET] = W_MODULE.LAYOUT_PRESET_TYPE.VARIETY_1,
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = wnd:GetWidth()
  })
  gradeInfo:AddAnchor("TOP", modifierInfo, "BOTTOM", 0, 0)
  local gradeExplain = W_MODULE:Create("gradeExplain", gradeInfo, W_MODULE.TYPES.HEADER_TABLE_BASE, {
    width = 205,
    [W_MODULE.ATTRIBUTE.LEFT_WIDTH_RATIO] = 4604029899060858061,
    valueAnchor = "RIGHT"
  })
  local rowInfo = {
    {
      key = "harvestGrade",
      body = {
        title = {
          string = GetCommonText("butler_harvest_grade_property")
        },
        value = {string = "-"}
      }
    }
  }
  for i = 1, #rowInfo do
    gradeExplain:AddRow(rowInfo[i].key, rowInfo[i].body)
  end
  local harvestGradeTipBtn = gradeExplain:CreateChildWidget("button", "harvestGradeTipBtn", 0, true)
  harvestGradeTipBtn:SetStyle("question_mark")
  function harvestGradeTipBtn:OnClick()
    ShowButlerHarvestGradeTipDialog(parent:GetParent(), desc.harvestGrades, wnd.harvestGrade)
  end
  harvestGradeTipBtn:SetHandler("OnClick", harvestGradeTipBtn.OnClick)
  harvestGradeTipBtn:AddAnchor("LEFT", gradeExplain, "RIGHT", 4, 0)
  gradeInfo:AddBody(gradeExplain, false)
  function wnd:UpdateAttribute()
    for ig, attributeGroup in ipairs(desc.attributes) do
      for ia, info in ipairs(attributeGroup) do
        attributes:UpdateRow(info.name, {
          title = {
            string = GetUIText(ATTRIBUTE_TEXT, info.name)
          },
          value = {
            string = AddSignChar(info.name, X2Butler:GetAttribute(info.type))
          }
        })
      end
    end
  end
  function wnd:UpdateBind(info)
    wnd.isMine = info.isMine
    changeBtn:Enable(info.isMine)
    wnd:UpdateEquipment()
    wnd:UpdateGrade(info)
  end
  function wnd:UpdateEquipment()
    local data = equipSlots:GetData()
    data.iconInfo = {}
    for i = 1, #desc.equipSlots do
      local slotNo = desc.equipSlots[i]
      data.iconInfo[i] = {
        info = X2Butler:GetEquipment(slotNo),
        stack = 1
      }
    end
    equipSlots:SetData(data)
    wnd:UpdateAttribute()
  end
  function wnd:UpdateGrade(info)
    wnd.harvestGrade = info.harvestGrade
    gradeExplain:UpdateRow("harvestGrade", {
      value = {
        string = GetCommonText("butler_harvest_grade", tostring(info.harvestGrade))
      }
    })
  end
  local wndHeight = wnd:GetHeight()
  local totalHeight = equipInfo:GetHeight() + modifierInfo:GetHeight() + gradeInfo:GetHeight()
  if wndHeight < totalHeight then
    scrollFrame:SetHeight(scrollFrame:GetHeight() - (totalHeight - wndHeight))
    modifierInfo:Refresh()
  end
  return wnd
end
local CreateRightFrame = function(id, parent, desc)
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  wnd:SetExtent(269, 604)
  local actabilityInfo = W_MODULE:Create("actabilityInfo", wnd, W_MODULE.TYPES.TITLE_BOX, {
    preset = "other",
    title = GetCommonText("butler_actability"),
    [W_MODULE.ATTRIBUTE.GUIDE_TOOLTIP] = GetCommonText("my_butler_actability_tip")
  }, {
    [W_MODULE.ATTRIBUTE.LAYOUT_PRESET] = W_MODULE.LAYOUT_PRESET_TYPE.VARIETY_1,
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = wnd:GetWidth(),
    [W_MODULE.ATTRIBUTE.BODY_INSET] = {
      15,
      10,
      10,
      10
    }
  })
  actabilityInfo:AddAnchor("TOP", wnd, 0, 0)
  local previewInfo = {
    remainStat = 0,
    applyStat = {}
  }
  local function ActabilityDataSetFunc(subItem, data)
    if data then
      local actability = data.type
      subItem.name:SetText(data.actability ~= nil and data.name or "")
      subItem.point:SetText(F_TEXT.SetCommaFormat(data.point + data.added, true))
      subItem.stat:SetText(tostring(data.stat))
      subItem.upBtn:Enable(wnd.isMine and previewInfo.remainStat > 0)
      if data.added > 0 then
        subItem.point.style:SetColorByKey("green")
        subItem.point.tooltip = string.format("%s%s+%s|r", F_TEXT.SetCommaFormat(data.point), F_COLOR.GetColor("green", true), F_TEXT.SetCommaFormat(data.added))
      else
        subItem.point.style:SetColorByKey("default")
        subItem.point.tooltip = string.format("%s", F_TEXT.SetCommaFormat(data.point))
      end
      local advantageStr = F_TEXT.SetColonFormat(string.format("\r%s", GetCommonText("use_labor_power_decrease")), string.format("%d%%", X2Butler:GetActabilityAdvantage(data.point + data.added)))
      subItem.point.tooltip = F_TEXT.SetEnterString(subItem.point.tooltip, advantageStr)
      function subItem.upBtn:OnClick()
        wnd:Preview(data.actability, data.stat + 1)
      end
      subItem.upBtn:SetHandler("OnClick", subItem.upBtn.OnClick)
      subItem:Show(true)
    else
      subItem:Show(false)
    end
  end
  local ActabilityLayoutSetFunc = function(subItem, row, listCtrl)
    local name = subItem:CreateChildWidget("label", "name", 0, true)
    name:AddAnchor("TOPLEFT", subItem, "TOPLEFT", 0, 10)
    name:SetHeight(FONT_SIZE.MIDDLE)
    name:SetAutoResize(true)
    name.style:SetColorByKey("default")
    name.style:SetAlign(ALIGN_LEFT)
    local point = subItem:CreateChildWidget("label", "point", 0, true)
    point:AddAnchor("TOPLEFT", name, "BOTTOMLEFT", 0, 6)
    point:SetHeight(FONT_SIZE.MIDDLE)
    point:SetAutoResize(true)
    point.style:SetColorByKey("default")
    point.style:SetAlign(ALIGN_LEFT)
    point:SetHandler("OnEnter", function(self)
      SetTooltip(self.tooltip, self)
    end)
    local upBtn = subItem:CreateChildWidget("button", "upBtn", 0, true)
    upBtn:SetStyle("up_arrow")
    upBtn:AddAnchor("BOTTOMRIGHT", subItem, 0, -5)
    local bg = CreateContentBackground(subItem, "TYPE2", "default")
    bg:SetExtent(70, 30)
    bg:AddAnchor("RIGHT", upBtn, 0, 3)
    local stat = subItem:CreateChildWidget("label", "stat", 0, true)
    stat:AddAnchor("RIGHT", upBtn, "LEFT", -5, 1)
    stat:SetHeight(FONT_SIZE.MIDDLE)
    stat:SetAutoResize(true)
    stat.style:SetColorByKey("default")
    stat.style:SetAlign(ALIGN_LEFT)
  end
  local columWidth = 220
  local scrollFrame = actabilityInfo:AddModule("scrollFrame", W_MODULE.TYPES.LISTCTRL, nil, {
    [W_MODULE.ATTRIBUTE.HAS_SCROLL] = true,
    [W_MODULE.ATTRIBUTE.LAYOUT_BG_TYPE] = nil,
    [W_MODULE.ATTRIBUTE.ROW_COUNT] = 7,
    [W_MODULE.ATTRIBUTE.COLUMN_HEIGHT_TYPE] = nil,
    [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = "text_multiline",
    [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = true,
    [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = columWidth,
        [W_MODULE.ATTRIBUTE.TEXT] = "",
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = ActabilityLayoutSetFunc,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = ActabilityDataSetFunc
      }
    }
  })
  local buttonSet = W_MODULE:Create("buttonSet", wnd, W_MODULE.TYPES.BUTTON_SET)
  buttonSet:AddAnchor("BOTTOM", wnd, 0, 0)
  buttonSet:AddButton("apply", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("apply"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    clickFunc = function()
      local info = {}
      for i = 1, #desc.actabilities do
        local actability = desc.actabilities[i].type
        local name = desc.actabilities[i].name
        if previewInfo.applyStat[actability] ~= nil then
          info[#info + 1] = {
            name = name,
            type = actability,
            val = previewInfo.applyStat[actability]
          }
        end
      end
      ShowButlerApplyStatDialog(parent:GetParent(), info, wnd.remainStat - previewInfo.remainStat)
    end
  })
  buttonSet:AddButton("reset", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "init"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    clickFunc = function()
      if previewInfo.remainStat ~= wnd.remainStat then
        wnd:UpdateRemainStat()
        wnd:UpdateActability()
      else
        ShowButlerResetStatDialog(parent:GetParent(), {
          currency = desc.statReset.currency,
          cost = desc.statReset.cost,
          remainResetCount = wnd.remainResetCount
        })
      end
    end
  })
  local description = wnd:CreateChildWidget("textbox", "description", 0, true)
  description:SetWidth(wnd:GetWidth())
  description:AddAnchor("TOP", actabilityInfo, "BOTTOM", 0, 0)
  description:AddAnchor("BOTTOM", wnd, "BOTTOM", 0, -buttonSet:GetHeight())
  description:SetText(GetCommonText("butler_actability_info"))
  description.style:SetColorByKey("off_gray")
  function wnd:Preview(actability, previewStat)
    previewInfo.remainStat = previewInfo.remainStat - 1
    previewInfo.applyStat[actability] = previewInfo.applyStat[actability] == nil and 1 or previewInfo.applyStat[actability] + 1
    description:SetText(GetCommonText("butler_actability_info", tostring(previewInfo.remainStat)))
    local point, stat = X2Butler:GetActability(actability)
    for i = 1, #desc.actabilities do
      if desc.actabilities[i].type == actability then
        local data = scrollFrame:GetDataPartially(W_MODULE.ATTRIBUTE.DATA, i)
        data.point = X2Butler:GetActabilityPoint(previewStat)
        data.stat = previewStat
        scrollFrame:SetDataPartially(W_MODULE.ATTRIBUTE.DATA, {key = i, data = data})
        break
      end
    end
    buttonSet:UpdateButton("apply", {
      [W_MODULE.ATTRIBUTE.ENABLE] = true
    })
    buttonSet:UpdateButton("reset", {
      [W_MODULE.ATTRIBUTE.ENABLE] = true
    })
  end
  function wnd:UpdateActability()
    buttonSet:UpdateButton("apply", {
      [W_MODULE.ATTRIBUTE.ENABLE] = false
    })
    buttonSet:UpdateButton("reset", {
      [W_MODULE.ATTRIBUTE.ENABLE] = false
    })
    local datas = {}
    for i = 1, #desc.actabilities do
      local data
      data = desc.actabilities[i]
      data.actability = desc.actabilities[i].type
      data.point, data.stat = X2Butler:GetActability(data.actability)
      data.added = X2Butler:GetAttribute(desc.actabilities[i].attribute)
      data.name = desc.actabilities[i].name
      if data.stat > 0 then
        buttonSet:UpdateButton("reset", {
          [W_MODULE.ATTRIBUTE.ENABLE] = self.isMine
        })
      end
      table.insert(datas, data)
    end
    scrollFrame:SetData({
      [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
      data = datas
    })
  end
  function wnd:UpdateRemainStat(info)
    if info ~= nil then
      wnd.remainStat = info.remainStat
      wnd.remainResetCount = info.remainStatResetCount
      wnd.isMine = info.isMine
    end
    previewInfo.remainStat = wnd.remainStat
    previewInfo.applyStat = {}
    description:SetText(GetCommonText("butler_actability_info", tostring(wnd.remainStat)))
  end
  function wnd:UpdateBind(info)
    wnd:UpdateRemainStat(info)
    wnd:UpdateActability()
  end
  return wnd
end
function CreateMyButlerWnd(parent)
  local wnd = parent
  local bindInfoFrame = CreateBindInfoFrame("bindInfoFrame", wnd)
  bindInfoFrame:AddAnchor("CENTER", wnd, 0, 0)
  local butlerInfoFrame = wnd:CreateChildWidget("emptywidget", "butlerInfoFrame", 0, true)
  butlerInfoFrame:AddAnchor("TOPLEFT", wnd, 0, 0)
  butlerInfoFrame:AddAnchor("BOTTOMRIGHT", wnd, 0, 0)
  local desc = X2Butler:GetButlerDesc()
  local leftFrame = CreateLeftFrame("leftFrame", butlerInfoFrame, desc)
  leftFrame:AddAnchor("TOPLEFT", butlerInfoFrame, 0, 10)
  local centerFrame = CreateCenterFrame("centerFrame", butlerInfoFrame, desc)
  centerFrame:AddAnchor("TOPLEFT", leftFrame, "TOPRIGHT", 3, 0)
  local rightFrame = CreateRightFrame("rightFrame", butlerInfoFrame, desc)
  rightFrame:AddAnchor("TOPLEFT", centerFrame, "TOPRIGHT", 3, 0)
  function wnd:Refresh()
    local info = X2Butler:GetMyButlerInfo()
    if info.bindWorldName ~= nil then
      bindInfoFrame:UpdateBind(info)
      bindInfoFrame:Show(true)
      butlerInfoFrame:Show(false)
    else
      leftFrame:UpdateBind(info)
      centerFrame:UpdateBind(info)
      rightFrame:UpdateBind(info)
      bindInfoFrame:Show(false)
      butlerInfoFrame:Show(true)
    end
  end
  function wnd:Clear()
    X2DialogManager:DeleteByOwnerWindow(wnd:GetId())
    X2Butler:LeaveInteractionMode()
    leftFrame:Clear()
  end
  wnd:SetHandler("OnHide", wnd.Clear)
  function wnd:HandleEvent(event)
    if event == "bind" or event == "unbind" then
      wnd:Refresh()
    elseif event == "name" then
      local info = X2Butler:GetMyButlerInfo()
      leftFrame:UpdateName(info)
    elseif event == "look" then
      local info = X2Butler:GetMyButlerInfo()
      leftFrame:UpdateModel(info)
    elseif event == "productionCost" then
      local info = X2Butler:GetMyButlerInfo()
      leftFrame:UpdateProductionCost(info)
    elseif event == "production_cost_free_charged_count" then
      leftFrame:UpdateProductionCostChargeButton()
    elseif event == "labowPower" then
      local info = X2Butler:GetMyButlerInfo()
      leftFrame:UpdateLaborpower(info)
    elseif event == "exp" then
      local info = X2Butler:GetMyButlerInfo()
      leftFrame:UpdateExp(info)
      rightFrame:UpdateRemainStat(info)
      rightFrame:UpdateActability()
      centerFrame:UpdateGrade(info)
    elseif event == "equipment" then
      centerFrame:UpdateEquipment()
      rightFrame:UpdateRemainStat(info)
      rightFrame:UpdateActability()
    elseif event == "actability" then
      local info = X2Butler:GetMyButlerInfo()
      rightFrame:UpdateRemainStat(info)
      rightFrame:UpdateActability()
    end
  end
end
