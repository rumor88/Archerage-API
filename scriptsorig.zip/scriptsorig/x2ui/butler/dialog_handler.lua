function ShowButlerLevelEffectTipDialog(parent, desc, effectLevel)
  local function DialogHandler(wnd)
    wnd:UseExpandWidth()
    wnd:SetWindowModal(false)
    wnd:SetTitle(GetUIText(MSG_BOX_TITLE_TEXT, "butler_level_info"))
    local textbox = W_MODULE:Create("textbox", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(MSG_BOX_BODY_TEXT, "butler_level_info")
    })
    wnd:RegisterStack(textbox)
    local listCtrl = W_MODULE:Create("listCtrl", wnd, W_MODULE.TYPES.LISTCTRL, {
      [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = false,
      [W_MODULE.ATTRIBUTE.DATA] = desc
    }, {
      [W_MODULE.ATTRIBUTE.HAS_SCROLL] = true,
      [W_MODULE.ATTRIBUTE.LAYOUT_BG_TYPE] = "type_1",
      [W_MODULE.ATTRIBUTE.LAYOUT_COLUMN_BG_TYPE] = "type_1",
      [W_MODULE.ATTRIBUTE.COLUMN_HEIGHT_TYPE] = "large",
      [W_MODULE.ATTRIBUTE.ROW_COUNT] = 3,
      [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = true,
      [W_MODULE.ATTRIBUTE.ROW_BACKGROUND_TYPE] = "type_1",
      [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = 105,
      [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
        {
          [W_MODULE.ATTRIBUTE.WIDTH] = 130,
          [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "butler_level_step"),
          [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_STRING,
          [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
            if data then
              subItem:SetText(tostring(data.level))
              local row = subItem:GetParent()
              row:ShowRowBackground(effectLevel == data.level)
            else
              subItem:SetText("")
            end
          end
        },
        {
          [W_MODULE.ATTRIBUTE.WIDTH] = 240,
          [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "butler_level_effect"),
          [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_TEXTBOX,
          [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
            if data then
              subItem:SetText(data.effect)
            else
              subItem:SetText("")
            end
          end
        }
      }
    })
    wnd:RegisterStack(listCtrl)
  end
  X2DialogManager:DeleteByOwnerWindow(parent:GetId())
  X2DialogManager:RequestDialog(DialogHandler, parent:GetId(), {buttonType = DBT_OK})
end
function ShowButlerHarvestGradeTipDialog(parent, desc, grade)
  local function DialogHandler(wnd)
    wnd:UseExpandWidth()
    wnd:SetWindowModal(false)
    wnd:SetTitle(GetUIText(MSG_BOX_TITLE_TEXT, "butler_grade_info"))
    local textbox = W_MODULE:Create("textbox", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(MSG_BOX_BODY_TEXT, "butler_grade_info")
    })
    wnd:RegisterStack(textbox)
    local listCtrl = W_MODULE:Create("listCtrl", wnd, W_MODULE.TYPES.LISTCTRL, {
      [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = false,
      [W_MODULE.ATTRIBUTE.DATA] = desc
    }, {
      [W_MODULE.ATTRIBUTE.HAS_SCROLL] = true,
      [W_MODULE.ATTRIBUTE.LAYOUT_BG_TYPE] = "type_1",
      [W_MODULE.ATTRIBUTE.LAYOUT_COLUMN_BG_TYPE] = "type_1",
      [W_MODULE.ATTRIBUTE.COLUMN_HEIGHT_TYPE] = "large",
      [W_MODULE.ATTRIBUTE.ROW_COUNT] = 3,
      [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = true,
      [W_MODULE.ATTRIBUTE.ROW_BACKGROUND_TYPE] = "type_1",
      [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = "text_multiline",
      [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
        {
          [W_MODULE.ATTRIBUTE.WIDTH] = 130,
          [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "butler_level_step"),
          [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_STRING,
          [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
            if data then
              subItem:SetText(tostring(data.grade))
              local row = subItem:GetParent()
              row:ShowRowBackground(grade == data.grade)
            else
              subItem:SetText("")
            end
          end
        },
        {
          [W_MODULE.ATTRIBUTE.WIDTH] = 240,
          [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "butler_level_effect"),
          [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_TEXTBOX,
          [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
            if data then
              subItem:SetText(data.desc)
            else
              subItem:SetText("")
            end
          end
        }
      }
    })
    wnd:RegisterStack(listCtrl)
  end
  X2DialogManager:DeleteByOwnerWindow(parent:GetId())
  X2DialogManager:RequestDialog(DialogHandler, parent:GetId(), {buttonType = DBT_OK})
end
function ShowButlerRechargeLpDialog(parent)
  local CalcRechargeLp = function(consumeLp, lpChargeRate)
    return math.floor(consumeLp * (lpChargeRate / 100) + 4602678819172646912)
  end
  local function CalcNeedLp(rechargingLp, lpChargeRate)
    local needPlayerLp = math.floor(rechargingLp / (lpChargeRate / 100))
    if rechargingLp ~= CalcRechargeLp(needPlayerLp, lpChargeRate) then
      needPlayerLp = needPlayerLp + 1
    end
    return needPlayerLp
  end
  local function DialogHandler(wnd)
    wnd:SetTitle(GetUIText(MSG_BOX_TITLE_TEXT, "butler_recharge_lp"))
    local description = W_MODULE:Create("description", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(MSG_BOX_BODY_TEXT, "butler_recharge_lp_tip")
    })
    wnd:RegisterStack(description)
    local info = X2Butler:GetChargeLpInfo()
    local possibleRechargeLp = info.maxLp - info.curLp
    if info.maxChargeAmount - info.curChargedAmount > 0 then
      possibleRechargeLp = math.min(info.maxChargeAmount - info.curChargedAmount, possibleRechargeLp)
    end
    local lpMin = 1
    local lpChargeRate = 100
    if info.maxChargeAmount - info.curChargedAmount <= 0 then
      lpChargeRate = info.lpChargeRate
      lpMin = info.lpChargeMin
    end
    local needPlayerLp = CalcNeedLp(possibleRechargeLp, lpChargeRate)
    local changeInfo = W_MODULE:Create("chargeInfo", wnd, W_MODULE.TYPES.HEADER_TABLE_C, {
      title = GetCommonText("butler_recharge_lp")
    })
    wnd:RegisterStack(changeInfo)
    function changeInfo.Satisfy()
      return possibleRechargeLp > 0 and wnd.spinner:GetCurValue() >= lpMin and not wnd.spinner:IsEmpyValue()
    end
    changeInfo:AddRow("input", {
      title = {
        string = GetCommonText("recharge_labor_power")
      },
      value = {
        [W_MODULE.ATTRIBUTE.CREATE_ROW_FUNC] = function(valueWidgetName, valueMaxWidth, rowFrame)
          local spinner = W_ETC.CreateSpinner(valueWidgetName, rowFrame, {
            textUpdateFunc = function(curText)
              if curText == "" then
                wnd:UpdateAmount(0)
                wnd:ApplyOkButtonEnablement()
              end
            end
          })
          spinner:SetMinMaxValues(1, needPlayerLp)
          function spinner:OnSpinnerValueChangeProc(curValue)
            wnd:UpdateAmount(curValue)
            wnd:ApplyOkButtonEnablement()
          end
          wnd.spinner = spinner
          return spinner
        end
      }
    })
    changeInfo:AddRow("efficiency", {
      title = {
        string = GetCommonText("lp_efficiency")
      },
      value = {
        string = string.format("%d%%", lpChargeRate)
      }
    })
    changeInfo:AddRow("lineRow", {
      [W_MODULE.ATTRIBUTE.LINE_ROW] = true
    })
    changeInfo:AddRow("result", {
      title = {
        string = GetCommonText("total_recharge_amount")
      },
      value = {
        string = F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(1, true), F_TEXT.SetCommaFormat(possibleRechargeLp, true))
      }
    })
    local remain = W_MODULE:Create("remain", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("recharge_amount_limit", F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(math.max(0, info.maxChargeAmount - info.curChargedAmount), true), F_TEXT.SetCommaFormat(info.maxChargeAmount, true)))
    })
    wnd:RegisterStack(remain)
    if info.maxChargeAmount - info.curChargedAmount > 0 then
      local warning = W_MODULE:Create("warning", wnd, W_MODULE.TYPES.TEXTBOX, {
        [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("butler_recharge_lp_warning"),
        type = "warning"
      })
      wnd:RegisterStack(warning)
    else
      local warning = W_MODULE:Create("warning", wnd, W_MODULE.TYPES.TEXTBOX, {
        [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("butler_recharge_lp_warning_over", tostring(lpChargeRate), tostring(lpMin)),
        type = "warning"
      })
      wnd:RegisterStack(warning)
    end
    function wnd:UpdateAmount(amount)
      changeInfo:UpdateRow("result", {
        value = {
          string = F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(CalcRechargeLp(amount, lpChargeRate), true), F_TEXT.SetCommaFormat(possibleRechargeLp, true))
        }
      })
    end
    wnd.spinner:SetValue(lpMin, true)
    function wnd:OkProc()
      X2Butler:ChargeLp(wnd.spinner:GetCurValue())
    end
  end
  X2DialogManager:RequestDialog(DialogHandler, parent:GetId())
end
local butlerLocale = GetLayoutSetButler()
function ShowButlerBindingInfoDialog(parent, isMine)
  local info = X2Butler:GetBindInfo()
  local function DialogHandler(wnd)
    wnd:UseExpandWidth()
    wnd:SetTitle(GetUIText(MSG_BOX_TITLE_TEXT, "butler_binding_info"))
    local desc = W_MODULE:Create("desc", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(MSG_BOX_BODY_TEXT, "butler_binding_info")
    })
    wnd:RegisterStack(desc)
    local bindInfo = W_MODULE:Create("bindInfo", wnd, W_MODULE.TYPES.HEADER_TABLE_B, {
      title = GetCommonText("butler_bound_housing_info"),
      [W_MODULE.ATTRIBUTE.LEFT_WIDTH_PRESET] = butlerLocale.butlerBindingInfoDialogLeftPresetWidth
    })
    wnd:RegisterStack(bindInfo)
    function bindInfo.Satisfy()
      return isMine
    end
    bindInfo:AddRow("house", {
      title = {
        string = GetUIText(TOOLTIP_TEXT, "owner")
      },
      value = {
        string = info.bindOwnerName
      }
    })
    bindInfo:AddRow("owner", {
      title = {
        string = GetCommonText("housing_name")
      },
      value = {
        string = info.bindHouseName
      }
    })
    local warning = W_MODULE:Create("warning", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("butler_binding_warning"),
      type = "warning"
    })
    wnd:RegisterStack(warning)
    wnd:SetOkButtonString(GetUIText(MSG_BOX_BTN_TEXT, "butler_unbind"))
    function wnd.OkProc()
      X2Butler:Unbind()
    end
  end
  X2DialogManager:RequestDialog(DialogHandler, parent:GetId())
end
function ShowButlerChangeLookDialog(parent)
  local DialogHandler = function(wnd)
    ADDON:ShowContent(UIC_BAG, true)
    X2Butler:EnterInteractionMode(CHANGE_LOOK_MODE)
    wnd:SetWindowModal(false)
    wnd:SetTitle(GetUIText(MSG_BOX_TITLE_TEXT, "change_butler_look"))
    local description = W_MODULE:Create("description", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("change_butler_look_tip"),
      type = "default"
    })
    wnd:RegisterStack(description)
    local iconInfo = {
      titleInfo = {
        title = GetUIText(MSG_BOX_BODY_TEXT, "butler_look_info")
      },
      itemIconInfo = {}
    }
    local itemIconBox = W_MODULE:Create("itemIconBox", wnd, W_MODULE.TYPES.ICON_VERTICAL_TITLE_BOX, iconInfo)
    itemIconBox.iconButton:RegisterForClicks("RightButton")
    wnd:RegisterStack(itemIconBox)
    wnd.hasLookItem = false
    local lookItemInfo = X2Butler:GetLookItem()
    if lookItemInfo ~= nil then
      iconInfo.itemIconInfo.itemInfo = lookItemInfo
      iconInfo.itemIconInfo.stack = 1
      itemIconBox:SetData(iconInfo)
      wnd.hasLookItem = true
    end
    function itemIconBox:Satisfy()
      return false
    end
    function itemIconBox.iconButton:OnClickProc(arg)
      if arg == "LeftButton" then
        X2Butler:SetReservedSlot()
      else
        iconInfo.itemIconInfo.itemInfo = nil
        iconInfo.itemIconInfo.stack = 1
        itemIconBox:SetData(iconInfo)
        wnd.btnOk:Enable(wnd.hasLookItem)
        X2Butler:ClearReservedSlot()
      end
    end
    function wnd:OkProc()
      X2Butler:ChangeLook()
    end
    function wnd:OnHide()
      X2Butler:LeaveInteractionMode()
      X2Butler:ClearReservedSlot()
    end
    wnd:SetHandler("OnHide", wnd.OnHide)
    local wndEvents = {
      BUTLER_INFO_UPDATED = function(event)
        if event == "reservedSlot" then
          local itemInfo, _ = X2Butler:GetReservedSlotItem()
          if itemInfo == nil then
            wnd.btnOk:Enable(false)
            itemInfo = X2Butler:GetLookItem()
          else
            wnd.btnOk:Enable(true)
          end
          iconInfo.itemIconInfo.itemInfo = itemInfo
          iconInfo.itemIconInfo.stack = 1
          itemIconBox:SetData(iconInfo)
        end
      end
    }
    wnd:SetHandler("OnEvent", function(this, event, ...)
      wndEvents[event](...)
    end)
    RegistUIEvent(wnd, wndEvents)
  end
  X2DialogManager:DeleteByOwnerWindow(parent:GetId())
  X2DialogManager:RequestDialog(DialogHandler, parent:GetId())
end
function ShowRegisterTractorDialog(parent)
  local DialogHandler = function(wnd)
    ADDON:ShowContent(UIC_BAG, true)
    X2Butler:EnterInteractionMode(REGISTER_TRACTOR_MODE)
    wnd:SetWindowModal(false)
    wnd:SetTitle(GetUIText(MSG_BOX_TITLE_TEXT, "register_butler_tractor"))
    local iconInfo = {
      titleInfo = {
        title = GetUIText(MSG_BOX_BODY_TEXT, "butler_tractor_info")
      },
      itemIconInfo = {}
    }
    local itemIconBox = W_MODULE:Create("itemIconBox", wnd, W_MODULE.TYPES.ICON_VERTICAL_TITLE_BOX, iconInfo)
    wnd:RegisterStack(itemIconBox)
    itemIconBox.iconButton:RegisterForClicks("RightButton")
    function itemIconBox.iconButton:OnClickProc(arg)
      if arg == "LeftButton" then
        X2Butler:SetReservedSlot()
      else
        X2Butler:ClearReservedSlot()
      end
    end
    function wnd:OkProc()
      X2Butler:RegisterTractor()
    end
    function wnd:OnHide()
      X2Butler:LeaveInteractionMode()
      X2Butler:ClearReservedSlot()
    end
    wnd:SetHandler("OnHide", wnd.OnHide)
    local wndEvents = {
      BUTLER_INFO_UPDATED = function(event)
        if event == "reservedSlot" then
          local itemInfo, extra = X2Butler:GetReservedSlotItem()
          iconInfo.itemIconInfo.itemInfo = itemInfo
          iconInfo.itemIconInfo.stack = 1
          itemIconBox:SetData(iconInfo)
          wnd.btnOk:Enable(itemInfo ~= nil)
        end
      end
    }
    wnd:SetHandler("OnEvent", function(this, event, ...)
      wndEvents[event](...)
    end)
    RegistUIEvent(wnd, wndEvents)
  end
  X2DialogManager:DeleteByOwnerWindow(parent:GetId())
  X2DialogManager:RequestDialog(DialogHandler, parent:GetId())
end
function ShowRemoveTractorDialog(parent, info)
  local function DialogHandler(wnd)
    wnd:SetTitle(GetUIText(MSG_BOX_TITLE_TEXT, "remove_butler_tractor"))
    local itemIconBox = W_MODULE:Create("itemIconBox", wnd, W_MODULE.TYPES.ICON_VERTICAL_TITLE_BOX, {
      titleInfo = {
        title = GetUIText(MSG_BOX_BODY_TEXT, "butler_tractor_info")
      },
      itemIconInfo = {
        itemInfo = info.itemInfo,
        stack = 1
      }
    })
    wnd:RegisterStack(itemIconBox)
    local description = W_MODULE:Create("description", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("remove_butler_tractor_tip"),
      type = "warning"
    })
    wnd:RegisterStack(description)
    function wnd:OkProc()
      X2Butler:RemoveTractor()
    end
  end
  X2DialogManager:DeleteByOwnerWindow(parent:GetId())
  X2DialogManager:RequestDialog(DialogHandler, parent:GetId())
end
function ShowButlerResetStatDialog(parent, info)
  local function DialogHandler(wnd)
    wnd:SetTitle(GetUIText(MSG_BOX_TITLE_TEXT, "butler_reset_actability"))
    local actability = W_MODULE:Create("actability", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(MSG_BOX_BODY_TEXT, "butler_reset_actability")
    })
    wnd:RegisterStack(actability)
    local useStat = W_MODULE:Create("useStat", wnd, W_MODULE.TYPES.VALUE_BOX, {
      [W_MODULE.ATTRIBUTE.TYPE] = "cost",
      [W_MODULE.ATTRIBUTE.CURRENCY] = info.currency,
      [W_MODULE.ATTRIBUTE.VALUE] = tostring(info.cost)
    })
    wnd:RegisterStack(useStat)
    if info.remainResetCount ~= nil then
      local resetCount = W_MODULE:Create("resetCount", wnd, W_MODULE.TYPES.TEXTBOX, {
        [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("available_reset_count_value", tostring(info.remainResetCount))
      })
      wnd:RegisterStack(resetCount)
      function resetCount.Satisfy()
        return info.remainResetCount > 0
      end
    end
    function wnd.OkProc()
      X2Butler:ResetActabiltiyStat()
    end
  end
  X2DialogManager:RequestDialog(DialogHandler, parent:GetId())
end
function ShowButlerApplyStatDialog(parent, info, usedStat)
  local function DialogHandler(wnd)
    wnd:SetTitle(GetUIText(MSG_BOX_TITLE_TEXT, "butler_apply_actability"))
    if #info > 1 then
      local text = ""
      for i = 1, #info do
        text = F_TEXT.SetEnterString(text, string.format("- %s (%d)", info[i].name, info[i].val))
      end
      local actability = W_MODULE:Create("actability", wnd, W_MODULE.TYPES.SCROLL_TITLE_BOX, {
        titleInfo = {
          title = GetCommonText("butler_apply_actability")
        },
        [W_MODULE.ATTRIBUTE.TEXT] = text
      })
      wnd:RegisterStack(actability)
    else
      local actability = W_MODULE:Create("actability", wnd, W_MODULE.TYPES.TEXTBOX, {
        text = string.format("%s[%s]", F_COLOR.GetColor("blue", true), info[1].name)
      })
      wnd:RegisterStack(actability)
    end
    local useStat = W_MODULE:Create("useStat", wnd, W_MODULE.TYPES.VALUE_BOX_DIALOG, {
      [W_MODULE.ATTRIBUTE.TYPE] = "stat_point",
      [W_MODULE.ATTRIBUTE.VALUE] = tostring(usedStat)
    })
    wnd:RegisterStack(useStat)
    function wnd.OkProc()
      X2Butler:ApplyActabiltiyStats(info)
    end
  end
  X2DialogManager:RequestDialog(DialogHandler, parent:GetId())
end
function ShowAddGardenDialog(parent, info)
  local function DialogHandler(wnd)
    ADDON:ShowContent(UIC_BAG, true)
    X2Butler:EnterInteractionMode(ADD_GARDEN_MODE)
    wnd:SetWindowModal(false)
    wnd:SetTitle(GetUIText(MSG_BOX_TITLE_TEXT, "add_butler_garden"))
    local iconInfo = {
      titleInfo = {
        title = GetUIText(MSG_BOX_BODY_TEXT, "butler_garden_info")
      },
      itemIconInfo = {}
    }
    local itemIconBox = W_MODULE:Create("itemIconBox", wnd, W_MODULE.TYPES.ICON_VERTICAL_TITLE_BOX, iconInfo)
    wnd:RegisterStack(itemIconBox)
    itemIconBox.iconButton:RegisterForClicks("RightButton")
    function itemIconBox.iconButton:OnClickProc(arg)
      if arg == "LeftButton" then
        X2Butler:SetReservedSlot()
      else
        X2Butler:ClearReservedSlot()
      end
    end
    local description = W_MODULE:Create("description", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("add_butler_garden_info", F_TEXT.SetSlashFormat(info.usedGardenCount, info.maxGardenCount))
    })
    wnd:RegisterStack(description)
    function wnd:OkProc()
      X2Butler:AddGarden()
    end
    function wnd:OnHide()
      X2Butler:LeaveInteractionMode()
      X2Butler:ClearReservedSlot()
    end
    wnd:SetHandler("OnHide", wnd.OnHide)
    local wndEvents = {
      BUTLER_INFO_UPDATED = function(event)
        if event == "reservedSlot" then
          local itemInfo, extra = X2Butler:GetReservedSlotItem()
          iconInfo.itemIconInfo.itemInfo = itemInfo
          iconInfo.itemIconInfo.stack = 1
          itemIconBox:SetData(iconInfo)
          wnd.btnOk:Enable(itemInfo ~= nil)
        end
      end
    }
    wnd:SetHandler("OnEvent", function(this, event, ...)
      wndEvents[event](...)
    end)
    RegistUIEvent(wnd, wndEvents)
  end
  X2DialogManager:DeleteByOwnerWindow(parent:GetId())
  X2DialogManager:RequestDialog(DialogHandler, parent:GetId())
end
function ShowRemoveGardenDialog(parent, info)
  local function DialogHandler(wnd)
    wnd:SetTitle(GetUIText(MSG_BOX_TITLE_TEXT, "remove_butler_gargen"))
    local itemIconBox = W_MODULE:Create("itemIconBox", wnd, W_MODULE.TYPES.ICON_VERTICAL_TITLE_BOX, {
      titleInfo = {
        title = GetUIText(MSG_BOX_BODY_TEXT, "butler_garden_info")
      },
      itemIconInfo = {
        itemInfo = info.itemInfo,
        stack = 1
      }
    })
    wnd:RegisterStack(itemIconBox)
    local description = W_MODULE:Create("description", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("remove_butler_garden_tip"),
      type = "warning"
    })
    wnd:RegisterStack(description)
    function wnd:OkProc()
      X2Butler:RemoveGarden(info.gardenId)
    end
  end
  X2DialogManager:DeleteByOwnerWindow(parent:GetId())
  X2DialogManager:RequestDialog(DialogHandler, parent:GetId())
end
function ShowRechargeProductionCostDialog(parent)
  local info = X2Butler:GetChargeInfo()
  local function DialogHandler(wnd)
    if not info.isFree then
      ADDON:ShowContent(UIC_BAG, true)
      X2Butler:EnterInteractionMode(RECHARGE_COST_MODE)
    end
    if butlerLocale.rechargeProductionCostDialogExpandWidth then
      wnd:UseExpandWidth()
    end
    wnd:SetWindowModal(info.isFree)
    wnd:SetTitle(GetUIText(MSG_BOX_TITLE_TEXT, "recharge_butler_production_cost"))
    local msg = GetUIText(MSG_BOX_BODY_TEXT, "recharge_butler_production_cost_reset", GetCommonText(X2Butler:GetResetWeeklyDay()))
    if info.isFree then
      msg = F_TEXT.SetEnterString(GetUIText(MSG_BOX_BODY_TEXT, "recharge_butler_production_cost_free"), msg)
    else
      msg = F_TEXT.SetEnterString(GetUIText(MSG_BOX_BODY_TEXT, "recharge_butler_production_cost"), msg)
    end
    local msgModule = W_MODULE:Create("msgModule", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = msg
    })
    wnd:RegisterStack(msgModule)
    if not info.isFree then
      local itemIconBox = W_MODULE:Create("itemIconBox", wnd, W_MODULE.TYPES.ICON_VERTICAL, {})
      wnd:RegisterStack(itemIconBox)
      itemIconBox.iconButton:RegisterForClicks("RightButton")
      function itemIconBox.iconButton:OnClickProc(arg)
        if arg == "LeftButton" then
          X2Butler:SetReservedSlot()
        else
          X2Butler:ClearReservedSlot()
        end
      end
    end
    local chargeInfo = W_MODULE:Create("chargeInfo", wnd, W_MODULE.TYPES.HEADER_TABLE_A, {
      [W_MODULE.ATTRIBUTE.LEFT_WIDTH_PRESET] = "large"
    })
    wnd:RegisterStack(chargeInfo)
    local chargeAmount = "-"
    if info.isFree then
      chargeInfo:AddRow("free_recharge_count", {
        title = {
          string = GetCommonText("free_recharge_count")
        },
        value = {
          string = F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(info.freeChargeCount, true), F_TEXT.SetCommaFormat(info.maxFreeChargeCount, true))
        }
      })
      chargeAmount = tostring(info.freeChargeAmount)
    end
    chargeInfo:AddRow("recharge_amount", {
      title = {
        string = GetCommonText("recharge_amount")
      },
      value = {string = chargeAmount}
    })
    chargeInfo:AddRow("remain_recharge_amount", {
      title = {
        string = GetCommonText("remain_recharge_amount")
      },
      value = {
        string = F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(info.remainWeeklyChargeAmount, true), F_TEXT.SetCommaFormat(info.maxWeeklychargeAmount, true))
      }
    })
    if info.isFree then
      local warning = W_MODULE:Create("warning", wnd, W_MODULE.TYPES.TEXTBOX, {
        [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("overcharge_butler_production_cost_warning"),
        type = "warning"
      })
      wnd:RegisterStack(warning)
    end
    wnd.btnOk:Enable(info.isFree)
    function wnd:OkProc()
      X2Butler:RechargeProductionCost()
    end
    function wnd:OnHide()
      if not info.isFree then
        X2Butler:LeaveInteractionMode()
        X2Butler:ClearReservedSlot()
      end
    end
    wnd:SetHandler("OnHide", wnd.OnHide)
    if not info.isFree then
      do
        local wndEvents = {
          BUTLER_INFO_UPDATED = function(event)
            if event == "reservedSlot" then
              local itemInfo, extra = X2Butler:GetReservedSlotItem()
              wnd.itemIconBox:SetData({itemInfo = itemInfo, stack = 1})
              chargeInfo:UpdateRow("recharge_amount", {
                value = {
                  string = extra and F_TEXT.SetCommaFormat(extra, true) or "-"
                }
              })
              wnd.btnOk:Enable(extra ~= nil and extra > 0 and extra <= info.remainWeeklyChargeAmount)
            end
          end
        }
        wnd:SetHandler("OnEvent", function(this, event, ...)
          wndEvents[event](...)
        end)
        RegistUIEvent(wnd, wndEvents)
      end
    end
  end
  X2DialogManager:DeleteByOwnerWindow(parent:GetId())
  X2DialogManager:RequestDialog(DialogHandler, parent:GetId())
end
function ShowCancelHarvestDialog(parent, harvestId)
  local function DialogHandler(wnd)
    wnd:SetTitle(GetUIText(MSG_BOX_TITLE_TEXT, "cancel_harvest"))
    local description = W_MODULE:Create("description", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(MSG_BOX_BODY_TEXT, "cancel_harvest"),
      type = "warning"
    })
    wnd:RegisterStack(description)
    function wnd:OkProc()
      X2Butler:UnregisterHarvest(harvestId)
    end
  end
  X2DialogManager:RequestDialog(DialogHandler, parent:GetId())
end
function ShowCancelTradingSpecialtyDialog(parent, specialtyTradeId)
  local function DialogHandler(wnd)
    wnd:SetTitle(GetUIText(MSG_BOX_TITLE_TEXT, "cancel_specialty_trade"))
    local description = W_MODULE:Create("description", wnd, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(MSG_BOX_BODY_TEXT, "cancel_specialty_trade"),
      type = "warning"
    })
    wnd:RegisterStack(description)
    function wnd:OkProc()
      X2Butler:UnregisterSpecialtyTrade(specialtyTradeId)
    end
  end
  X2DialogManager:RequestDialog(DialogHandler, parent:GetId())
end
function ShowExpandButlerFuncSlotDialog(parent, itemInfo, stack, where)
  local function DialogHandler(wnd)
    wnd:SetTitle(GetUIText(MSG_BOX_TITLE_TEXT, "expand_harvest"))
    local itemSlot = W_MODULE:Create("itemSlot", wnd, W_MODULE.TYPES.ICON_VERTICAL, {
      itemInfo = itemInfo,
      stack = {
        X2Bag:CountBagItemByItemType(itemInfo.itemType),
        stack
      }
    })
    wnd:RegisterStack(itemSlot)
    function wnd:OkProc()
      if where == "harvestSlot" then
        X2Butler:ExpandHarvestSlot()
      elseif where == "specialtyTradeSlot" then
        X2Butler:ExpandSpecialtyTradeSlot()
      end
    end
  end
  X2DialogManager:RequestDialog(DialogHandler, parent:GetId())
end
