## author : prodg
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## butler

locale/layout_set.lua

dialog_handler.lua
tab_my_butler.lua
tab_farming.lua
tab_trading.lua
butler_info.lua