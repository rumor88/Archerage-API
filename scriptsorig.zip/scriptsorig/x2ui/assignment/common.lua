ACHIEVEMENT_PAGE = {
  SUMMARY = {
    value = 0,
    text = GetUIText(COMMON_TEXT, "sumup")
  },
  COMPLETE = {
    value = 0,
    text = GetUIText(COMMON_TEXT, "accomplishment")
  },
  TRACING = {
    value = 0,
    text = GetUIText(COMMON_TEXT, "tracing")
  }
}
local categoryPrefixValue = 1000
function GetAchievementPrefixValue()
  return categoryPrefixValue
end
local mainCategories = {}
function GetAchievementCategoryInfos(kind)
  local list = X2Achievement:GetCategories(kind)
  local categoryInfo = {}
  if kind == EAK_ACHIEVEMENT or kind == EAK_ARCHERAGE then
    local summaryCategoryInfo = {
      text = ACHIEVEMENT_PAGE.SUMMARY.text,
      value = ACHIEVEMENT_PAGE.SUMMARY.value,
      defaultColor = F_COLOR.GetColor("gray_purple"),
      selectColor = F_COLOR.GetColor("blue"),
      overColor = F_COLOR.GetColor("blue"),
      useColor = true
    }
    table.insert(categoryInfo, summaryCategoryInfo)
  end
  local completeCategoryInfo = {
    text = ACHIEVEMENT_PAGE.COMPLETE.text,
    value = ACHIEVEMENT_PAGE.COMPLETE.value,
    defaultColor = F_COLOR.GetColor("gray_purple"),
    selectColor = F_COLOR.GetColor("blue"),
    overColor = F_COLOR.GetColor("blue"),
    useColor = true,
    subtext = "",
    subColor = F_COLOR.GetColor("blue")
  }
  table.insert(categoryInfo, completeCategoryInfo)
  local tracingCategoryInfo = {
    text = ACHIEVEMENT_PAGE.TRACING.text,
    value = ACHIEVEMENT_PAGE.TRACING.value,
    defaultColor = F_COLOR.GetColor("gray_purple"),
    selectColor = F_COLOR.GetColor("blue"),
    overColor = F_COLOR.GetColor("blue"),
    useColor = true,
    subtext = "",
    subColor = F_COLOR.GetColor("blue")
  }
  table.insert(categoryInfo, tracingCategoryInfo)
  if kind == EAK_RACIAL_MISSION then
    for depth1, info in ipairs(list) do
      local index = #categoryInfo + 1
      categoryInfo[index] = {}
      categoryInfo[index].text = info.name
      categoryInfo[index].value = info.subCategoryType
      categoryInfo[index].subtext = ""
      categoryInfo[index].subColor = F_COLOR.GetColor("blue")
      if info.isHeirLevelCategory then
        categoryInfo[index].iconPath = TEXTURE_PATH.MONEY_WINDOW
        categoryInfo[index].infoKey = "successor_16"
        categoryInfo[index].defaultColor = F_COLOR.GetColor("level_successor")
      end
    end
  else
    mainCategories[kind] = {}
    for depth1, info in ipairs(list) do
      local index = #categoryInfo + 1
      categoryInfo[index] = {}
      categoryInfo[index].text = info.name
      categoryInfo[index].value = info.categoryType + categoryPrefixValue
      categoryInfo[index].subtext = ""
      categoryInfo[index].subColor = F_COLOR.GetColor("blue")
      local mainCategoryInfo = {
        category = info.categoryType,
        name = info.name
      }
      table.insert(mainCategories[kind], mainCategoryInfo)
      if info.subCategories ~= nil then
        categoryInfo[index].child = {}
        for depth2, subInfo in ipairs(info.subCategories) do
          categoryInfo[index].child[depth2] = {}
          categoryInfo[index].child[depth2].text = subInfo.name
          categoryInfo[index].child[depth2].value = subInfo.subCategoryType
          categoryInfo[index].child[depth2].subtext = ""
          categoryInfo[index].child[depth2].subColor = F_COLOR.GetColor("blue")
        end
      end
    end
  end
  return categoryInfo
end
function GetAchievementMainCategories(kind)
  if mainCategories[kind] == nil then
    return
  end
  return mainCategories[kind]
end
function CreateRankIconSet(id, parent)
  local size = F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_52)
  local iconSet = CreateIconButton(id, parent)
  iconSet:SetExtent(size, size)
  iconSet:EnablePick(false)
  local rankDeco = iconSet:CreateDrawable(TEXTURE_PATH.ACHIEVEMENT_RANK, "high_rank", "overlay")
  rankDeco:AddAnchor("CENTER", iconSet, 0, 0)
  return iconSet
end
