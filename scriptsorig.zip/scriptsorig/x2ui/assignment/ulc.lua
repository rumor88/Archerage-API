local selectedULCType, ulcWnd
local function CreateUnlockEffectWidget(parent)
  local widget = parent:CreateChildWidget("emptywidget", "unlockEffect", 0, true)
  widget:Show(false)
  function widget:CreateEffect()
    local bg = self:CreateEffectDrawableByKey(TEXTURE_PATH.DEFAULT, "ulc_effect_bg", "background")
    bg:SetTextureColor("gray_60")
    bg:AddAnchor("TOPLEFT", self, -10, 0)
    bg:AddAnchor("BOTTOMRIGHT", self, 10, 15)
    bg:SetEffectPriority(1, "alpha", 4599075939470750515, 0)
    bg:SetEffectInitialColor(1, 0, 0, 0, 0)
    bg:SetEffectFinalColor(1, 4591870180066957722, 4591870180066957722, 4591870180066957722, 4603579539098121011)
    bg:SetEffectInterval(1, 4609434218613702656)
    bg:SetEffectPriority(2, "alpha", 4602678819172646912, 0)
    bg:SetEffectInitialColor(2, 4591870180066957722, 4591870180066957722, 4591870180066957722, 4603579539098121011)
    bg:SetEffectFinalColor(2, 0, 0, 0, 0)
    bg:SetRepeatCount(1)
    self.bg = bg
    local lock = self:CreateEffectDrawableByKey(TEXTURE_PATH.ULC_ULCOCK_EFFECT_LOCK, "eff_lock", "artwork")
    lock:AddAnchor("CENTER", bg, 0, 0)
    lock:SetEffectPriority(1, "alpha", 4596373779694328218, 0)
    lock:SetEffectInitialColor(1, 1, 1, 1, 0)
    lock:SetEffectFinalColor(1, 1, 1, 1, 1)
    lock:SetRepeatCount(1)
    self.lock = lock
    local lockWhite = self:CreateEffectDrawableByKey(TEXTURE_PATH.ULC_ULCOCK_EFFECT_LOCK, "eff_lock_white", "overlay")
    lockWhite:AddAnchor("CENTER", lock, 0, 0)
    lockWhite:SetEffectPriority(1, "alpha", 4596373779694328218, 0)
    lockWhite:SetEffectInitialColor(1, 1, 1, 1, 0)
    lockWhite:SetEffectFinalColor(1, 1, 1, 1, 1)
    lockWhite:SetRepeatCount(1)
    self.lockWhite = lockWhite
    local shine = self:CreateEffectDrawableByKey(TEXTURE_PATH.ULC_ULCOCK_EFFECT_LOCK, "eff_shine", "overlay")
    shine:AddAnchor("CENTER", lockWhite, 10, 15)
    shine:SetEffectPriority(1, "scalex", 4599075939470750515, 0)
    shine:SetEffectScale(1, 4602678819172646912, 2, 4602678819172646912, 2)
    shine:SetEffectInitialColor(1, 1, 1, 1, 0)
    shine:SetEffectFinalColor(1, 1, 1, 1, 1)
    shine:SetEffectPriority(2, "scalex", 4600877379321698714, 4600877379321698714)
    shine:SetEffectScale(2, 2, 4602678819172646912, 2, 4602678819172646912)
    shine:SetEffectInitialColor(2, 1, 1, 1, 1)
    shine:SetEffectFinalColor(2, 1, 1, 1, 0)
    shine:SetRepeatCount(1)
    self.shine = shine
  end
  function widget:CreateAnimationTexture()
    local animTime = 50
    local UNLOCK_EFFECT_SIZE = 256
    local aniTexture = self:CreateDrawable(TEXTURE_PATH.ULC_ULCOCK_EFFECT_BLAST, "eff_blast", "overlay")
    aniTexture:SetExtent(UNLOCK_EFFECT_SIZE, UNLOCK_EFFECT_SIZE)
    aniTexture:AddAnchor("CENTER", self, 10, -5)
    self.aniTexture = aniTexture
    local info = {}
    for y = 1, 4 do
      for x = 1, 4 do
        info[x + (y - 1) * 4] = {
          x = (x - 1) * 256,
          y = (y - 1) * 256,
          w = UNLOCK_EFFECT_SIZE,
          h = UNLOCK_EFFECT_SIZE,
          time = animTime,
          scale = 2
        }
      end
    end
    info[17] = {
      x = 0,
      y = 0,
      w = 1,
      h = 1,
      time = animTime,
      scale = 2
    }
    aniTexture:SetAnimFrameInfo(info)
  end
  function widget:ChangeUpdateStepFunc(func)
    self.func = func
    self.time = 0
  end
  function widget:IsEffectDoing()
    if self.func ~= nil then
      return true
    end
    return false
  end
  function widget:FireEffect(postRefreshFunc)
    self:Show(true)
    F_SOUND.PlayUISound("event_ulc_activate", false)
    if self.init == nil then
      self:CreateEffect()
      self:CreateAnimationTexture()
      self.init = true
    end
    self:ChangeUpdateStepFunc(self.OnUpdateStep1)
    self:SetHandler("OnUpdate", self.OnUpdate)
    self.postRefreshFunc = postRefreshFunc
  end
  function widget:OnUpdate(dt)
    self:func(dt)
    self.time = self.time + dt
  end
  function widget:OnUpdateStep1(dt)
    if self.time == 0 then
      self.bg:SetStartEffect(true)
    elseif self.time > 200 then
      self.lock:SetStartEffect(true)
      self:ChangeUpdateStepFunc(self.OnUpdateStep2)
    end
  end
  function widget:OnUpdateStep2(dt)
    if self.time > 200 then
      self.lockWhite:SetStartEffect(true)
      self:ChangeUpdateStepFunc(self.OnUpdateStep3)
    end
  end
  function widget:OnUpdateStep3(dt)
    self:OnUpdate_ShakeLock()
    if self.time > 300 then
      self.shine:SetStartEffect(true)
      self:ChangeUpdateStepFunc(self.OnUpdateStep4)
    end
  end
  function widget:OnUpdateStep4(dt)
    self:OnUpdate_ShakeLock()
    if self.time > 250 then
      self.lock:SetVisible(false)
      self.lockWhite:SetVisible(false)
      self.aniTexture:Animation(true, false, true)
      self:ChangeUpdateStepFunc(self.OnUpdateStep5)
    end
  end
  function widget:OnUpdateStep5(dt)
    if self.time > 1300 then
      self:postRefreshFunc(selectedULCType)
      self:ChangeUpdateStepFunc(self.OnUpdateStepFinal)
    end
  end
  function widget:OnUpdateStepFinal(dt)
    self:Show(false)
    self:ReleaseHandler("OnUpdate")
    self:ChangeUpdateStepFunc(nil)
    self.postRefreshFunc = nil
  end
  function widget:OnUpdate_ShakeLock(dt)
    local ang = math.random(360)
    local x = math.cos(ang)
    local y = math.sin(ang)
    self.lock:AddAnchor("CENTER", self, x * 5, y * 5)
  end
  return widget
end
local CreateULCListbox = function(id, parent, width, height)
  local wnd = W_CTRL.CreateScrollListBox(id, parent, parent)
  wnd:SetExtent(width, height)
  wnd.content.itemStyle:SetFontSize(FONT_SIZE.LARGE)
  wnd.content:SetHeight(FONT_SIZE.MIDDLE)
  wnd.content.itemStyle:SetAlign(ALIGN_LEFT)
  wnd.content.itemStyleSub:SetFontSize(FONT_SIZE.SMALL)
  local line = wnd.content:CreateSeparatorImageDrawable(TEXTURE_PATH.DEFAULT, "background")
  line:SetTextureInfo("line_01", "default")
  line:SetWidth(wnd.content:GetWidth() - MARGIN.WINDOW_SIDE)
  return wnd
end
local CreateContent = function(id, parent, width)
  local wnd = W_MODULE:Create(id, parent, W_MODULE.TYPES.TITLE_BOX, {title = ""}, {
    [W_MODULE.ATTRIBUTE.LAYOUT_PRESET] = W_MODULE.LAYOUT_PRESET_TYPE.VARIETY_1,
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = width
  })
  local bodyWidth = width - MARGIN.WINDOW_SIDE * 2
  local banner = wnd:CreateChildWidget("emptywidget", "banner", 0, true)
  banner:SetExtent(bodyWidth, 160)
  wnd:AddBody(banner)
  local img = banner:CreateImageDrawable(INVALID_ICON_PATH, "artwork")
  img:AddAnchor("TOPLEFT", banner, 5, 2)
  img:SetVisible(true)
  banner.img = img
  local desc = banner:CreateChildWidget("textbox", "desc", 0, true)
  desc:SetWidth(bodyWidth - 30)
  desc:SetAutoResize(true)
  desc.style:SetAlign(ALIGN_LEFT)
  desc.style:SetColorByKey("default")
  desc:AddAnchor("LEFT", banner, 15, 0)
  local listTitle = wnd:CreateChildWidget("label", "listTitle", 0, false)
  listTitle:SetExtent(bodyWidth, FONT_SIZE.LARGE)
  listTitle.style:SetFontSize(FONT_SIZE.LARGE)
  listTitle.style:SetAlign(ALIGN_LEFT)
  listTitle.style:SetColorByKey("middle_title")
  listTitle:SetText(GetUIText(COMMON_TEXT, "craft_order_tab_search"))
  wnd:AddBody(listTitle)
  local listCtrl = wnd:AddModule("listCtrl", W_MODULE.TYPES.LISTCTRL, nil, {
    [W_MODULE.ATTRIBUTE.HAS_SCROLL] = true,
    [W_MODULE.ATTRIBUTE.COLUMN_HEIGHT_TYPE] = nil,
    [W_MODULE.ATTRIBUTE.ROW_COUNT] = 3,
    [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = false,
    [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = 73,
    [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = bodyWidth - 25,
        [W_MODULE.ATTRIBUTE.TEXT] = "",
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
          local frameBg = subItem:CreateDrawable(TEXTURE_PATH.DEFAULT, "activation_box", "background")
          frameBg:SetExtent(subItem:GetWidth(), subItem:GetHeight() - 2)
          frameBg:AddAnchor("TOPLEFT", subItem, 0, 0)
          subItem.frameBg = frameBg
          local margin = 10
          local icon = CreateRankIconSet("icon", subItem)
          icon:AddAnchor("TOPLEFT", subItem, margin, margin)
          local guide = W_ICON.CreateGuideIconWidget(subItem)
          guide:AddAnchor("TOPRIGHT", subItem, -guide:GetWidth() * 4602678819172646912, guide:GetHeight() * 4602678819172646912)
          subItem.guide = guide
          local descWidth = subItem:GetWidth() - icon:GetWidth() - guide:GetWidth() - margin * 4
          local desc = subItem:CreateChildWidget("textbox", "desc", 0, true)
          desc:SetExtent(descWidth, 40)
          desc.style:SetAlign(ALIGN_LEFT)
          desc.style:SetFontSize(FONT_SIZE.LARGE)
          desc:AddAnchor("LEFT", icon, "RIGHT", 10, 0)
          desc.style:SetColorByKey("default")
          subItem.desc = desc
          local function OnEnterGuide()
            SetTooltip(guide.guideText, guide)
          end
          guide:SetHandler("OnEnter", OnEnterGuide)
        end,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data == nil then
            return
          end
          if data.having then
            subItem.frameBg:SetTextureInfo("activation_box")
          else
            subItem.frameBg:SetTextureInfo("locked_box")
          end
          subItem.frameBg:SetExtent(subItem:GetWidth(), subItem:GetHeight() - 2)
          subItem.icon:SetIconDirectly({
            icon = data.iconPath
          })
          subItem.desc:SetText(data.name)
          subItem.guide.guideText = data.desc
        end
      }
    }
  })
  wnd.listCtrl = listCtrl
  local bottom = wnd:CreateChildWidget("emptywidget", "bottom", 0, true)
  bottom:SetExtent(bodyWidth, 30)
  wnd:AddBody(bottom)
  local ulcGuideLabel = bottom:CreateChildWidget("label", "ulcGuideLabel", 0, false)
  ulcGuideLabel:SetExtent(150, FONT_SIZE.MIDDLE)
  ulcGuideLabel.style:SetAlign(ALIGN_LEFT)
  ulcGuideLabel:SetInset(20, 0, 0, 0)
  ulcGuideLabel.style:SetColorByKey("middle_title")
  ulcGuideLabel:SetText(GetCommonText("ulc_guide_label"))
  ulcGuideLabel:AddAnchor("TOPLEFT", bottom, 0, 10)
  local ulcGuide = W_ICON.CreateGuideIconWidget(ulcGuideLabel)
  ulcGuide:AddAnchor("LEFT", ulcGuideLabel, 0, 0)
  local function OnEnterUlcGuide()
    SetTooltip(GetCommonText("ulc_guide"), ulcGuide)
  end
  ulcGuide:SetHandler("OnEnter", OnEnterUlcGuide)
  local buyULCBtn = bottom:CreateChildWidget("button", "buyULCBtn", 0, false)
  buyULCBtn:SetText(GetCommonText("buy_ulc"))
  buyULCBtn:SetStyle("text_default")
  buyULCBtn:AddAnchor("TOPRIGHT", bottom, 0, 0)
  local function OnClickBuyULCBtn()
    if X2Player:UseSteam() then
      X2Player:RequestULCBuy()
      return
    end
    local func = function(wnd)
      function wnd:OkProc()
        X2Player:RequestULCBuy()
      end
      wnd:SetTitle(GetCommonText("buy_ulc"))
      local textData = {
        [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("buy_ulc_notice")
      }
      wnd:RegisterStack(W_MODULE:Create("textbox", wnd, W_MODULE.TYPES.TEXTBOX, textData))
    end
    X2DialogManager:RequestDialog(func, wnd:GetId())
  end
  buyULCBtn:SetHandler("OnClick", OnClickBuyULCBtn)
  wnd.buyULCBtn = buyULCBtn
  return wnd
end
local UpdateContent = function(content, ulcType)
  local ulcInfo = X2Player:GetULCInfo(ulcType)
  if ulcInfo == nil then
    return
  end
  content:SetData({
    title = ulcInfo.name
  })
  if ulcInfo.image ~= nil and ulcInfo.image ~= "" then
    content.banner.img:SetTexture(string.format("%s/%s.dds", TEXTURE_PATH.ULC_IMAGE_PREFIX, ulcInfo.image))
    content.banner.img:SetTextureInfo("image")
    content.banner.img:SetExtent(content.banner:GetWidth(), content.banner:GetHeight())
  end
  if ulcInfo.having then
    content.banner.desc:SetText(GetCommonText("ulc_activated"))
  else
    content.banner.desc:SetText(ulcInfo.desc)
  end
  local guideInfo = X2Player:GetULCGuideInfo(ulcType)
  content.listCtrl:SetData({
    [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
    [W_MODULE.ATTRIBUTE.DATA] = guideInfo
  })
  content.buyULCBtn:Enable(ulcInfo.having == false)
end
local GetULCList = function()
  local list = X2Player:GetULCList()
  local ulcList = {}
  if list ~= nil then
    for _, info in ipairs(list) do
      local index = #ulcList + 1
      ulcList[index] = {}
      ulcList[index].text = info.name
      ulcList[index].value = info.type
      if info.having == false then
        ulcList[index].iconPath = TEXTURE_PATH.DEFAULT
        ulcList[index].infoKey = "icon_locked"
      end
    end
  end
  return ulcList
end
local function UpdateULCList(ulcList)
  ulcList:SetItemTrees(GetULCList())
end
function CreateULC(wnd)
  local layousSet = GetLayoutSetAssignment()
  local width = wnd:GetWidth() * layousSet.assignmentInnerRatioLeft
  local height = wnd:GetHeight() - MARGIN.WINDOW_SIDE
  local ulcList = CreateULCListbox("ULCList", wnd, width, height)
  ulcList:AddAnchor("TOPLEFT", wnd, 0, MARGIN.WINDOW_SIDE)
  wnd.ulcList = ulcList
  width = wnd:GetWidth() - ulcList:GetWidth() - MARGIN.WINDOW_SIDE
  local content = CreateContent("Content", wnd, width)
  content:AddAnchor("TOPLEFT", ulcList, "TOPRIGHT", MARGIN.WINDOW_SIDE, 0)
  wnd.content = content
  local unlockEffect = CreateUnlockEffectWidget(wnd)
  unlockEffect:AddAnchor("CENTER", wnd, 0, 0)
  unlockEffect:SetExtent(wnd:GetExtent())
  wnd.unlockEffect = unlockEffect
  function ulcList:OnSelChanged()
    local value = self.content:GetSelectedValue()
    if selectedULCType == value then
      return
    end
    selectedULCType = value
    UpdateContent(content, selectedULCType)
  end
  UpdateULCList(ulcList)
  ulcList.content:InitializeSelect(0)
  function wnd:OnTabSelected(selected)
  end
  function wnd:Refresh(ulcType)
    selectedULCType = nil
    UpdateULCList(ulcList)
    ulcList.content:SelectWithValue(ulcType)
  end
  local events = {
    ACCOUNT_ATTRIBUTE_UPDATED = function(kind, extraKind, state)
      if state == false and unlockEffect:IsEffectDoing() == false then
        wnd:Refresh(selectedULCType)
      end
    end
  }
  wnd:SetHandler("OnEvent", function(this, event, ...)
    events[event](...)
  end)
  RegistUIEvent(wnd, events)
  ulcWnd = wnd
end
local function ULCActivate(ulcType)
  ShowULCTab()
  if ulcWnd == nil then
    return
  end
  ulcWnd:Refresh(ulcType)
  ulcWnd.unlockEffect:FireEffect(ulcWnd.Refresh)
end
UIParent:SetEventHandler("ULC_ACTIVATE", ULCActivate)
