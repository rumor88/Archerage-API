A_SUBJECT_STYLE = {TODAY_ASSIGNMENT_LIST = 1, TODAY_ASSIGNMENT_DESC = 2}
A_TODAY_STATUS = {
  LOCKED = 0,
  READY = 1,
  PROGRESS = 2,
  DONE = 3
}
function MakeTodayQuestInfo(style, qType)
  local qInfo = X2Quest:GetTodayQuestInfo(qType)
  if qInfo == nil then
    return
  end
  local info = {}
  info.qType = qType
  info.titleStr = qInfo.title
  info.summaryStr = qInfo.summary
  info.curValue = qInfo.curValue
  info.maxValue = qInfo.maxValue
  info.itemType = X2Quest:GetQuestContextRewardItemIconType(qType, 1)
  info.itemCount = X2Quest:GetQuestContextRewardItemCount(qType, 1)
  info.rewardCopper = X2Quest:GetQuestContextRewardCopper(qType)
  info.rewardLivingPoint = X2Quest:RewardLivingPoint(qType)
  info.rewardHonorPoint = X2Quest:RewardHonorPoint(qType)
  info.rewardLeadershipPoint = X2Quest:RewardLeadershipPoint(qType)
  info.grade = qInfo.grade
  return info
end
function TodayAssignmentActived()
  local cnt = X2Achievement:GetTodayAssignmentCount(TADT_TODAY)
  for index = 1, cnt do
    local info = X2Achievement:GetTodayAssignmentInfo(TADT_TODAY, index)
    if info.status == A_TODAY_STATUS.LOCKED and info.satisfy then
      return true
    end
    if info.status == A_TODAY_STATUS.READY then
      return true
    end
  end
  return false
end
