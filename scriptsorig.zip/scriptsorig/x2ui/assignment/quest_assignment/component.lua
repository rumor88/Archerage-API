local gaugePath = TEXTURE_PATH.ACHIEVEMENT_GAUGE
local blueColor = F_COLOR.GetColor("blue", true)
local visibleTime = 180
local function CreateLightEffect(icon, wnd)
  local light1 = wnd:CreateEffectDrawableByKey(TEXTURE_PATH.ACHIEVEMENT_LIGHT, "light", "background")
  light1:AddAnchor("CENTER", icon, 0, 0)
  light1:SetInterval(4602678819172646912)
  light1:SetEffectPriority(1, "alpha", 4604480259023595110, 4604480259023595110)
  light1:SetEffectInitialColor(1, 1, 1, 1, 0)
  light1:SetEffectFinalColor(1, 1, 1, 1, 4600697235336603894)
  light1:SetEffectScale(1, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light1:SetEffectPriority(2, "alpha", 4600877379321698714, 4600877379321698714)
  light1:SetEffectInitialColor(2, 1, 1, 1, 4600697235336603894)
  light1:SetEffectFinalColor(2, 1, 1, 1, 4599075939470750515)
  light1:SetEffectRotate(2, 0, -15)
  light1:SetEffectScale(2, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light1:SetEffectPriority(3, "alpha", 4600877379321698714, 4600877379321698714)
  light1:SetEffectInitialColor(3, 1, 1, 1, 4599075939470750515)
  light1:SetEffectFinalColor(3, 1, 1, 1, 4593851763903000740)
  light1:SetEffectRotate(3, -15, 0)
  light1:SetEffectScale(3, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light1:SetEffectPriority(4, "alpha", 4600877379321698714, 4600877379321698714)
  light1:SetEffectInitialColor(4, 1, 1, 1, 4593851763903000740)
  light1:SetEffectFinalColor(4, 1, 1, 1, 4599075939470750515)
  light1:SetEffectRotate(4, 0, 15)
  light1:SetEffectScale(4, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light1:SetEffectPriority(5, "rotate", 4600877379321698714, 4600877379321698714)
  light1:SetEffectInitialColor(5, 1, 1, 1, 4599075939470750515)
  light1:SetEffectFinalColor(5, 1, 1, 1, 4599075939470750515)
  light1:SetEffectRotate(5, 15, -15)
  light1:SetEffectScale(5, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light1:SetEffectPriority(6, "alpha", 4602678819172646912, 4602678819172646912)
  light1:SetEffectInitialColor(6, 1, 1, 1, 4599075939470750515)
  light1:SetEffectFinalColor(6, 1, 1, 1, 4593851763903000740)
  light1:SetEffectRotate(6, -15, 0)
  light1:SetEffectScale(6, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light1:SetEffectPriority(7, "alpha", 4600877379321698714, 4600877379321698714)
  light1:SetEffectInitialColor(7, 1, 1, 1, 4593851763903000740)
  light1:SetEffectFinalColor(7, 1, 1, 1, 4599075939470750515)
  light1:SetEffectRotate(7, 0, -15)
  light1:SetEffectScale(7, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light1:SetEffectPriority(8, "alpha", 4600877379321698714, 4600877379321698714)
  light1:SetEffectInitialColor(8, 1, 1, 1, 4599075939470750515)
  light1:SetEffectFinalColor(8, 1, 1, 1, 4593851763903000740)
  light1:SetEffectRotate(8, -15, 0)
  light1:SetEffectScale(8, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light1:SetEffectPriority(9, "alpha", 4602678819172646912, 4602678819172646912)
  light1:SetEffectInitialColor(9, 1, 1, 1, 4593851763903000740)
  light1:SetEffectFinalColor(9, 1, 1, 1, 4599075939470750515)
  light1:SetEffectRotate(9, 0, -15)
  light1:SetEffectScale(9, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light1:SetEffectPriority(10, "alpha", 4602678819172646912, 4602678819172646912)
  light1:SetEffectInitialColor(10, 1, 1, 1, 4599075939470750515)
  light1:SetEffectFinalColor(10, 1, 1, 1, 4593851763903000740)
  light1:SetEffectRotate(10, -15, 0)
  light1:SetEffectScale(10, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light1:SetEffectPriority(11, "alpha", 4600877379321698714, 4600877379321698714)
  light1:SetEffectInitialColor(11, 1, 1, 1, 4593851763903000740)
  light1:SetEffectFinalColor(11, 1, 1, 1, 0)
  light1:SetEffectRotate(11, 0, 0)
  light1:SetEffectScale(11, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light1:SetEffectInterval(11, visibleTime - 4618891777831180698)
  light1:SetEffectPriority(12, "alpha", 4600877379321698714, 4600877379321698714)
  light1:SetEffectInitialColor(12, 1, 1, 1, 0)
  light1:SetEffectFinalColor(12, 1, 1, 1, 4593851763903000740)
  light1:SetEffectRotate(12, 0, 0)
  light1:SetEffectScale(12, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light1:SetEffectPriority(13, "alpha", 4599075939470750515, 4599075939470750515)
  light1:SetEffectInitialColor(13, 1, 1, 1, 4593851763903000740)
  light1:SetEffectFinalColor(13, 1, 1, 1, 4599075939470750515)
  light1:SetEffectRotate(13, 0, -15)
  light1:SetEffectScale(13, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light1:SetEffectPriority(14, "alpha", 4599075939470750515, 4599075939470750515)
  light1:SetEffectInitialColor(14, 1, 1, 1, 4599075939470750515)
  light1:SetEffectFinalColor(14, 1, 1, 1, 4593851763903000740)
  light1:SetEffectRotate(14, -15, 0)
  light1:SetEffectScale(14, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light1:SetEffectPriority(15, "alpha", 4600877379321698714, 4600877379321698714)
  light1:SetEffectInitialColor(15, 1, 1, 1, 4593851763903000740)
  light1:SetEffectFinalColor(15, 1, 1, 1, 0)
  light1:SetEffectRotate(15, 0, 0)
  light1:SetEffectScale(15, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light1:SetRepeatCount(1)
  icon.light1 = light1
  local light2 = wnd:CreateEffectDrawableByKey(TEXTURE_PATH.ACHIEVEMENT_LIGHT, "light", "background")
  light2:AddAnchor("CENTER", icon, 0, 0)
  light2:SetInterval(4602678819172646912)
  light2:SetEffectPriority(1, "alpha", 4607632778762754458, 4607632778762754458)
  light2:SetEffectInitialColor(1, 1, 1, 1, 0)
  light2:SetEffectFinalColor(1, 1, 1, 1, 4600877379321698714)
  light2:SetEffectRotate(1, 0, 15)
  light2:SetEffectScale(1, 4603039107142836552, 4604029899060858061, 4603039107142836552, 4604029899060858061)
  light2:SetEffectPriority(2, "alpha", 4600877379321698714, 4600877379321698714)
  light2:SetEffectInitialColor(2, 1, 1, 1, 4600877379321698714)
  light2:SetEffectFinalColor(2, 1, 1, 1, 4602949035150289142)
  light2:SetEffectRotate(2, 15, 0)
  light2:SetEffectScale(2, 4604029899060858061, 4603309323120478781, 4604029899060858061, 4603309323120478781)
  light2:SetEffectPriority(3, "alpha", 4600877379321698714, 4600877379321698714)
  light2:SetEffectInitialColor(3, 1, 1, 1, 4602949035150289142)
  light2:SetEffectFinalColor(3, 1, 1, 1, 4600877379321698714)
  light2:SetEffectRotate(3, 0, -15)
  light2:SetEffectScale(3, 4603309323120478781, 4604029899060858061, 4603309323120478781, 4604029899060858061)
  light2:SetEffectPriority(4, "rotate", 4600877379321698714, 4600877379321698714)
  light2:SetEffectInitialColor(4, 1, 1, 1, 4600877379321698714)
  light2:SetEffectFinalColor(4, 1, 1, 1, 4600877379321698714)
  light2:SetEffectRotate(4, -15, 15)
  light2:SetEffectScale(4, 4604029899060858061, 4604029899060858061, 4604029899060858061, 4604029899060858061)
  light2:SetEffectPriority(5, "alpha", 4602678819172646912, 4602678819172646912)
  light2:SetEffectInitialColor(5, 1, 1, 1, 4600877379321698714)
  light2:SetEffectFinalColor(5, 1, 1, 1, 4602949035150289142)
  light2:SetEffectRotate(5, 15, 0)
  light2:SetEffectScale(5, 4604029899060858061, 4603309323120478781, 4604029899060858061, 4603309323120478781)
  light2:SetEffectPriority(6, "alpha", 4600877379321698714, 4600877379321698714)
  light2:SetEffectInitialColor(6, 1, 1, 1, 4602949035150289142)
  light2:SetEffectFinalColor(6, 1, 1, 1, 4600877379321698714)
  light2:SetEffectRotate(6, 0, 15)
  light2:SetEffectScale(6, 4603309323120478781, 4604029899060858061, 4603309323120478781, 4604029899060858061)
  light2:SetEffectPriority(7, "alpha", 4600877379321698714, 4600877379321698714)
  light2:SetEffectInitialColor(7, 1, 1, 1, 4600877379321698714)
  light2:SetEffectFinalColor(7, 1, 1, 1, 4602949035150289142)
  light2:SetEffectRotate(7, 15, 0)
  light2:SetEffectScale(7, 4604029899060858061, 4603309323120478781, 4604029899060858061, 4603309323120478781)
  light2:SetEffectPriority(8, "alpha", 4600877379321698714, 4600877379321698714)
  light2:SetEffectInitialColor(8, 1, 1, 1, 4602949035150289142)
  light2:SetEffectFinalColor(8, 1, 1, 1, 4600877379321698714)
  light2:SetEffectRotate(8, 0, 15)
  light2:SetEffectScale(8, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light2:SetEffectPriority(9, "alpha", 4602678819172646912, 4602678819172646912)
  light2:SetEffectInitialColor(9, 1, 1, 1, 4600877379321698714)
  light2:SetEffectFinalColor(9, 1, 1, 1, 4602949035150289142)
  light2:SetEffectRotate(9, 15, 0)
  light2:SetEffectScale(9, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light2:SetEffectPriority(10, "alpha", 4600877379321698714, 4600877379321698714)
  light2:SetEffectInitialColor(10, 1, 1, 1, 4602949035150289142)
  light2:SetEffectFinalColor(10, 1, 1, 1, 0)
  light2:SetEffectRotate(10, 0, 0)
  light2:SetEffectScale(10, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light2:SetEffectInterval(10, visibleTime - 4618891777831180698)
  light2:SetEffectPriority(11, "alpha", 4600877379321698714, 4600877379321698714)
  light2:SetEffectInitialColor(11, 1, 1, 1, 0)
  light2:SetEffectFinalColor(11, 1, 1, 1, 4602949035150289142)
  light2:SetEffectRotate(11, 0, 0)
  light2:SetEffectScale(11, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light2:SetEffectPriority(12, "alpha", 4599075939470750515, 4599075939470750515)
  light2:SetEffectInitialColor(12, 1, 1, 1, 4602949035150289142)
  light2:SetEffectFinalColor(12, 1, 1, 1, 4600877379321698714)
  light2:SetEffectRotate(12, 0, 15)
  light2:SetEffectScale(12, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light2:SetEffectPriority(13, "alpha", 4599075939470750515, 4599075939470750515)
  light2:SetEffectInitialColor(13, 1, 1, 1, 4600877379321698714)
  light2:SetEffectFinalColor(13, 1, 1, 1, 4602949035150289142)
  light2:SetEffectRotate(13, 15, 0)
  light2:SetEffectScale(13, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light2:SetEffectPriority(14, "alpha", 4600877379321698714, 4600877379321698714)
  light2:SetEffectInitialColor(14, 1, 1, 1, 4602949035150289142)
  light2:SetEffectFinalColor(14, 1, 1, 1, 0)
  light2:SetEffectRotate(14, 0, 0)
  light2:SetEffectScale(14, 4603309323120478781, 4603309323120478781, 4603309323120478781, 4603309323120478781)
  light2:SetRepeatCount(1)
  icon.light2 = light2
end
local function CreateASubjectWnd(wnd)
  local bg = CreateContentBackground(wnd, "TYPE12", "brown")
  bg:AddAnchor("TOPLEFT", wnd, 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", wnd, 0, 0)
  bg:SetVisible(true)
  wnd.bg = bg
  local size = F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_52)
  local iconBg = wnd:CreateDrawable(TEXTURE_PATH.DEFAULT, "icon_button_bg", "artwork")
  iconBg:SetExtent(size, size)
  iconBg:AddAnchor("LEFT", wnd, 11, 0)
  local icon = wnd:CreateIconDrawable("artwork")
  icon:AddAnchor("TOPLEFT", iconBg, 2, 2)
  icon:AddAnchor("BOTTOMRIGHT", iconBg, -2, -2)
  wnd.icon = icon
  local statusIcon = wnd:CreateDrawable(TEXTURE_PATH.EVENT_CENTER_TODAY, "icon_gray", "background")
  statusIcon:AddAnchor("LEFT", wnd, 16, 0)
  CreateLightEffect(icon, wnd)
  icon.effected = false
  local status = W_BAR.CreateStatusBar("status", wnd, "achievement")
  status:AddAnchor("BOTTOMLEFT", icon, "BOTTOMRIGHT", 9, 0)
  status:AddAnchor("BOTTOMRIGHT", wnd, -MARGIN.WINDOW_SIDE / 2, -12)
  status:SetHeight(7)
  status:SetBarTextureCoords(gaugePath, "gauge_list", gaugePath, "gauge_bg")
  wnd.status = status
  local maxWidth = status:GetWidth() - 7
  local titleLabel = wnd:CreateChildWidget("label", "titleLabel", 0, true)
  titleLabel:SetExtent(maxWidth, FONT_SIZE.LARGE)
  titleLabel.style:SetAlign(ALIGN_LEFT)
  titleLabel.style:SetFontSize(FONT_SIZE.LARGE)
  titleLabel.style:SetColorByKey("high_title")
  local todayGradeIcon = W_ICON.CreateQuestGradeMarker(wnd)
  todayGradeIcon:AddAnchor("LEFT", titleLabel, "RIGHT", 2, -3)
  local completeLabel = wnd:CreateChildWidget("label", "completeLabel", 0, true)
  completeLabel:SetHeight(FONT_SIZE.MIDDLE)
  completeLabel:AddAnchor("TOPLEFT", titleLabel, "BOTTOMLEFT", 0, 5)
  completeLabel:SetAutoResize(true)
  completeLabel:SetText(string.format("[%s]", GetUIText(QUEST_TEXT, "complete")))
  completeLabel.style:SetColorByKey("blue")
  local descLabel = wnd:CreateChildWidget("label", "descLabel", 0, true)
  descLabel:SetExtent(maxWidth, FONT_SIZE.MIDDLE)
  descLabel.style:SetEllipsis(true)
  descLabel.style:SetAlign(ALIGN_LEFT)
  descLabel.style:SetColorByKey("default")
  local OnEnter = function(self)
    local str = self:GetText()
    local strWidth = self.style:GetTextWidth(str)
    if strWidth > self:GetWidth() then
      SetTooltip(self:GetText(), self)
    end
  end
  titleLabel:SetHandler("OnEnter", OnEnter)
  descLabel:SetHandler("OnEnter", OnEnter)
  local rewardString = wnd:CreateChildWidget("textbox", "rewardString", 0, true)
  rewardString.style:SetAlign(ALIGN_RIGHT)
  rewardString:SetExtent(500, FONT_SIZE.MIDDLE)
  rewardString:SetAutoWordwrap(false)
  rewardString.style:SetColorByKey("blue")
  local count = wnd:CreateChildWidget("label", "count", 0, true)
  count:SetAutoResize(true)
  count:SetHeight(FONT_SIZE.MIDDLE)
  count.style:SetColorByKey("default")
  count:AddAnchor("BOTTOMRIGHT", status, "TOPRIGHT", 0, -5)
  local checkBtn = CreateCheckButton("checkBtn", wnd)
  checkBtn:AddAnchor("TOPRIGHT", wnd, -7, 5)
  wnd.checkBtn = checkBtn
  local buffSize = F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_24)
  local itemBtn = CreateIconButton("itemBtn", wnd)
  itemBtn:SetExtent(buffSize, buffSize)
  wnd.itemBtn = itemBtn
  wnd.familyRoleIcon = {}
  for i = 1, 6 do
    local familyRoleIcon = wnd:CreateIconDrawable("background")
    familyRoleIcon:AddAnchor("RIGHT", wnd, (i - 1) * -30 - 13, 0)
    familyRoleIcon:SetExtent(28, 28)
    familyRoleIcon:Show(false)
    wnd.familyRoleIcon[i] = familyRoleIcon
  end
  local function SetTodayAssignmentInfo(info, todayType)
    iconBg:SetVisible(false)
    checkBtn:Show(false)
    status:Show(false)
    itemBtn:Show(false)
    itemBtn:Init()
    if wnd.rewardMoney ~= nil then
      wnd.rewardMoney:SetText("")
      wnd.rewardMoney:Show(false)
    end
    for i = 1, #wnd.familyRoleIcon do
      wnd.familyRoleIcon[i]:Show(false)
    end
    icon.light1:SetVisible(false)
    icon.light2:SetVisible(false)
    todayGradeIcon:Show(false)
    completeLabel:Show(false)
    titleLabel:RemoveAllAnchors()
    descLabel:RemoveAllAnchors()
    descLabel:Show(true)
    rewardString:Show(false)
    count:Show(false)
    icon:SetVisible(false)
    statusIcon:SetVisible(false)
    if info.status < A_TODAY_STATUS.PROGRESS then
      titleLabel:SetText(info.title)
      statusIcon:SetVisible(true)
      bg:SetTexture(TEXTURE_PATH.EVENT_CENTER_TODAY)
      titleLabel:AddAnchor("TOPLEFT", icon, "TOPRIGHT", 10, 5)
      descLabel:AddAnchor("TOPLEFT", titleLabel, "BOTTOMLEFT", 0, 5)
      descLabel:SetHeight(FONT_SIZE.LARGE)
      descLabel.style:SetFontSize(FONT_SIZE.LARGE)
      if info.status == A_TODAY_STATUS.LOCKED then
        if info.satisfy then
          titleLabel.style:SetColorByKey("battlefield_yellow")
          descLabel.style:SetColorByKey("white")
          descLabel:SetText(info.desc)
          statusIcon:SetTextureInfo("icon_green")
          bg:SetTextureInfo("bg_green")
          bg:SetColor(1, 1, 1, 1)
        else
          titleLabel.style:SetColorByKey("gray")
          descLabel.style:SetColorByKey("red")
          local conditionStrs = {}
          if 0 < info.requireLevel then
            table.insert(conditionStrs, string.format("%s %s", GetCommonText("level"), tostring(info.requireLevel)))
          end
          if info.levelMin ~= nil and 0 < info.levelMin then
            if info.sort == TADT_EXPEDITION then
              table.insert(conditionStrs, string.format("%s %s", GetUIText(COMMON_TEXT, "expedition_guide_title_1"), tostring(info.levelMin)))
            elseif info.sort == TADT_FAMILY then
              table.insert(conditionStrs, string.format("%s %s", GetUIText(COMMON_TEXT, "family_level"), tostring(info.levelMin)))
            end
          end
          if info.requireItem ~= nil and info.requireItem ~= 0 then
            table.insert(conditionStrs, GetCommonText("item"))
            local itemInfo = X2Item:GetItemInfoByType(info.requireItem)
            itemBtn:SetInfo(itemInfo)
            itemBtn:SetStack(info.requireItemCount or 0)
            itemBtn:SetOverlayColor(ICON_BUTTON_OVERLAY_COLOR.RED)
            itemBtn:RemoveAllAnchors()
            itemBtn:AddAnchor("BOTTOMRIGHT", wnd, "BOTTOMRIGHT", -10, -10)
            itemBtn:Show(true)
          end
          if info.familyRoleIcons and info.sort == TADT_FAMILY then
            for i = 1, #info.familyRoleIcons do
              wnd.familyRoleIcon[i]:ClearAllTextures()
              wnd.familyRoleIcon[i]:AddTexture(info.familyRoleIcons[i])
              wnd.familyRoleIcon[i]:Show(true)
            end
          end
          local descStr = ""
          for i = 1, #conditionStrs do
            if i == 1 then
              descStr = F_TEXT.SetColonFormat(GetCommonText("require_condition"), conditionStrs[i])
            else
              descStr = string.format("%s, %s", descStr, conditionStrs[i])
            end
          end
          if info.sort ~= TADT_ARCHE_PASS then
            descLabel:SetText(descStr)
          else
            local curCompleteCnt, maxCompleteCnt = X2ArchePass:GetMissionCompleteCount()
            if info.progressArchePass == 1 and curCompleteCnt < maxCompleteCnt and info.maxTier ~= true then
              if info.premiumMission ~= nil and 0 < info.premiumMission then
                descLabel:SetText(GetCommonText("arche_pass_mission_premium"))
              else
                descLabel:SetText(descStr)
              end
            else
              titleLabel:SetText("")
              descLabel:SetText("")
              itemBtn:Show(false)
            end
          end
          statusIcon:SetTextureInfo("icon_gray")
          bg:SetTextureInfo("bg_gray")
          bg:SetColor(1, 1, 1, 1)
        end
      elseif info.status == A_TODAY_STATUS.READY then
        statusIcon:SetVisible(true)
        statusIcon:SetTextureInfo("icon_blue")
        if icon.effected == false then
          icon.effected = true
          icon.light1:SetVisible(true)
          icon.light1:SetStartEffect(true)
          icon.light2:SetVisible(true)
          icon.light2:SetStartEffect(true)
        end
        bg:SetTextureInfo("bg_blue")
        bg:SetColor(1, 1, 1, 1)
        titleLabel.style:SetColorByKey("quest_task")
        descLabel.style:SetColorByKey("white")
        descLabel:SetText(info.desc)
        if info.familyRoleIcons and info.sort == TADT_FAMILY then
          for i = 1, #info.familyRoleIcons do
            wnd.familyRoleIcon[i]:ClearAllTextures()
            wnd.familyRoleIcon[i]:AddTexture(info.familyRoleIcons[i])
            wnd.familyRoleIcon[i]:Show(true)
          end
        end
      end
    else
      local qInfo = MakeTodayQuestInfo(wnd.style, info.questType)
      if qInfo == nil then
        return
      end
      local descWidth = status:GetWidth()
      local titleWidth = status:GetWidth()
      bg:SetTexture(TEXTURE_PATH.DEFAULT)
      if wnd.style == A_SUBJECT_STYLE.TODAY_ASSIGNMENT_LIST then
        bg:SetTextureInfo("type_12", "brown_2")
      else
        bg:SetTextureInfo("type_10", "brown_2")
        count:Show(true)
        count:SetText(F_TEXT.SetSlashFormat(qInfo.curValue, qInfo.maxValue))
        descWidth = descWidth - count:GetWidth() - 5
      end
      icon:SetVisible(true)
      icon:ClearAllTextures()
      icon:AddTexture(info.iconPath)
      iconBg:SetVisible(true)
      descLabel:SetHeight(FONT_SIZE.MIDDLE)
      descLabel.style:SetFontSize(FONT_SIZE.MIDDLE)
      titleLabel:AddAnchor("TOPLEFT", icon, "TOPRIGHT", 10, 0)
      if qInfo.maxValue == 0 and qInfo.curValue == 0 then
        qInfo.maxValue = 1
        qInfo.curValue = 1
      end
      status:SetMinMaxValues(0, qInfo.maxValue)
      status:SetValue(qInfo.curValue)
      status:Show(true)
      titleLabel.style:SetColorByKey("high_title")
      titleLabel:SetText(qInfo.titleStr)
      todayGradeIcon:SetQuestGrade(qInfo.grade)
      if todayGradeIcon:IsVisible() then
        titleWidth = titleWidth - todayGradeIcon:GetWidth()
      end
      descLabel.style:SetColorByKey("default")
      descLabel:SetText(qInfo.summaryStr)
      descLabel.style:SetEllipsis(true)
      if info.status == A_TODAY_STATUS.PROGRESS then
        if wnd.style == A_SUBJECT_STYLE.TODAY_ASSIGNMENT_LIST then
          local rewardStrs = {}
          local visible = false
          if qInfo.rewardCopper ~= nil and qInfo.rewardCopper ~= "" and qInfo.rewardCopper ~= "0" then
            table.insert(rewardStrs, string.format("%s%s", blueColor, F_MONEY:GetCostStringByCurrency(CURRENCY_GOLD, qInfo.rewardCopper)))
          end
          if qInfo.rewardLivingPoint ~= nil and qInfo.rewardLivingPoint ~= 0 then
            table.insert(rewardStrs, string.format("%s%s", blueColor, F_MONEY:GetCostStringByCurrency(CURRENCY_LIVING_POINT, qInfo.rewardLivingPoint)))
          end
          if qInfo.rewardHonorPoint ~= nil and qInfo.rewardHonorPoint ~= 0 then
            table.insert(rewardStrs, string.format("%s%s", blueColor, F_MONEY:GetCostStringByCurrency(CURRENCY_HONOR_POINT, qInfo.rewardHonorPoint)))
          end
          if qInfo.rewardLeadershipPoint ~= nil and qInfo.rewardLeadershipPoint ~= 0 then
            table.insert(rewardStrs, string.format("%s|sd%d;", blueColor, qInfo.rewardLeadershipPoint))
          end
          if #rewardStrs > 0 then
            if qInfo.itemType ~= nil then
              rewardString:AddAnchor("BOTTOMRIGHT", itemBtn, "BOTTOMLEFT", -5, -3)
            else
              rewardString:AddAnchor("BOTTOMRIGHT", status, "TOPRIGHT", 7, -7)
            end
            local str = ""
            for i = 1, #rewardStrs do
              if str == "" then
                str = rewardStrs[i]
              else
                str = string.format("%s %s", str, rewardStrs[i])
              end
            end
            rewardString:SetWidth(500)
            rewardString:SetText(str)
            rewardString:SetWidth(rewardString:GetLongestLineWidth() + 5)
            rewardString:Show(true)
            descWidth = descWidth - rewardString:GetWidth()
          end
        end
        if qInfo.itemType ~= nil and wnd.style == A_SUBJECT_STYLE.TODAY_ASSIGNMENT_LIST then
          itemBtn:Show(true)
          itemBtn:RemoveAllAnchors()
          itemBtn:AddAnchor("BOTTOMRIGHT", status, "TOPRIGHT", 0, -3)
          local itemInfo = X2Item:GetItemInfoByType(qInfo.itemType)
          itemBtn:SetInfo(itemInfo)
          itemBtn:SetStack(qInfo.itemCount or 0)
          descWidth = descWidth - itemBtn:GetWidth()
        end
        local IsTracingQuest = function(qType)
          local notifierData = X2:GetQuestNotifierListUiData()
          if notifierData.todayQuestList == nil then
            return false
          end
          for i = 1, #notifierData.todayQuestList do
            if notifierData.todayQuestList[i] == qType then
              return true
            end
          end
          return false
        end
        if todayType ~= TADT_EXPEDITION_PUBLIC then
          checkBtn:Show(true)
          titleWidth = titleWidth - checkBtn:GetWidth()
          if HasTodayQuestList == nil then
            checkBtn:SetChecked(IsTracingQuest(info.questType), false)
          else
            checkBtn:SetChecked(HasTodayQuestList(info.questType), false)
          end
        end
        descLabel:AddAnchor("TOPLEFT", titleLabel, "BOTTOMLEFT", 0, 5)
        titleWidth = titleWidth - 5
        descWidth = descWidth - 5
      else
        completeLabel:Show(true)
        descWidth = descWidth - completeLabel:GetWidth()
        descLabel:AddAnchor("LEFT", completeLabel, "RIGHT", 2, 0)
      end
      if titleLabel.style:GetTextWidth(qInfo.titleStr) >= 430 then
        titleLabel:SetAutoResize(false)
        titleLabel.style:SetEllipsis(true)
        titleLabel:SetExtent(titleWidth, FONT_SIZE.LARGE)
      else
        titleLabel.style:SetEllipsis(false)
        titleLabel:SetAutoResize(true)
      end
      descLabel:SetExtent(descWidth, FONT_SIZE.MIDDLE)
    end
    wnd:Show(true)
  end
  local function ClearInfo()
    wnd:Show(false)
  end
  function checkBtn:CheckBtnCheckChagnedProc()
    if wnd.checkFunc ~= nil then
      wnd.checkFunc(checkBtn)
    end
  end
  local function EnterCheckBtn()
    if wnd.enterFunc ~= nil then
      wnd.enterFunc(checkBtn)
    end
  end
  checkBtn:SetHandler("OnEnter", EnterCheckBtn)
  function wnd:SetAchievement(style, aType, checkFunc, enterFunc)
    wnd.style = style
    wnd.aType = aType
    wnd.checkFunc = checkFunc
    wnd.enterFunc = enterFunc
    wnd:Update()
  end
  function wnd:SetTodayAssignment(style, todayType, index, checkFunc, enterFunc)
    wnd.style = style
    wnd.todayType = todayType
    wnd.index = index
    wnd.checkFunc = checkFunc
    wnd.enterFunc = enterFunc
    wnd:Update()
  end
  function wnd:Update()
    if wnd.style == A_SUBJECT_STYLE.ACHIEVEMENT_LIST or wnd.style == A_SUBJECT_STYLE.ACHIEVEMENT_DESC then
      if wnd.aType ~= nil then
        local info = MakeAchievementSubjectInfo(wnd.style, wnd.aType)
        SetAchievementInfo(info)
        return
      end
    elseif (wnd.style == A_SUBJECT_STYLE.TODAY_ASSIGNMENT_LIST or wnd.style == A_SUBJECT_STYLE.TODAY_ASSIGNMENT_DESC) and wnd.index ~= nil then
      local info = X2Achievement:GetTodayAssignmentInfo(wnd.todayType, wnd.index)
      if info ~= nil then
        SetTodayAssignmentInfo(info, wnd.todayType)
        return
      end
    end
    ClearInfo()
  end
  return wnd
end
local function CreateAAchievementDescWnd(id, parent)
  local wnd = CreateScrollWindow(parent, "id", 0)
  wnd:AddAnchor("TOPLEFT", wnd, "BOTTOMLEFT", 0, 5)
  wnd:AddAnchor("BOTTOMRIGHT", wnd, 0, -35)
  wnd:ResetScroll(0)
  local descriptionWnd = wnd.content:CreateChildWidget("emptywidget", "descriptionWnd", 0, true)
  descriptionWnd:AddAnchor("TOPLEFT", wnd.content, 0, 0)
  descriptionWnd:AddAnchor("TOPRIGHT", wnd.content, 0, 0)
  local descLabel = descriptionWnd:CreateChildWidget("textbox", "descLabel", 0, true)
  descLabel:AddAnchor("TOPLEFT", descriptionWnd, 20, 20)
  descLabel:AddAnchor("TOPRIGHT", descriptionWnd, 0, 0)
  descLabel.style:SetAlign(ALIGN_LEFT)
  descLabel:SetAutoResize(true)
  descLabel.style:SetColorByKey("blue")
  local descBg = CreateContentBackground(descriptionWnd, "TYPE7", "achievement_window_bg")
  descBg:AddAnchor("TOPLEFT", descLabel, -MARGIN.WINDOW_SIDE, -MARGIN.WINDOW_SIDE)
  descBg:AddAnchor("BOTTOMRIGHT", descLabel, 0, MARGIN.WINDOW_SIDE)
  wnd.descBg = descBg
  local objectiveWnd = wnd.content:CreateChildWidget("emptywidget", "objectiveWnd", 0, true)
  objectiveWnd:AddAnchor("TOPLEFT", descriptionWnd, "BOTTOMLEFT", 20, 5)
  objectiveWnd:AddAnchor("TOPRIGHT", descriptionWnd, "BOTTOMRIGHT", -10, 5)
  local objectiveDesc = objectiveWnd:CreateChildWidget("textbox", "objectiveDesc", 0, true)
  objectiveDesc:AddAnchor("TOPLEFT", objectiveWnd, 0, 0)
  objectiveDesc:AddAnchor("TOPRIGHT", objectiveWnd, 0, 0)
  objectiveDesc:SetAutoResize(true)
  objectiveDesc:SetLineSpace(TEXTBOX_LINE_SPACE.LARGE)
  objectiveDesc.style:SetAlign(ALIGN_LEFT)
  objectiveDesc.style:SetColorByKey("high_title")
  local anchorTarget = objectiveDesc
  local anchorOffset = 15
  local objectiveLabel = {}
  for i = 1, MAX_QUEST_OBJECTIVE do
    objectiveLabel[i] = objectiveWnd:CreateChildWidget("label", "objectiveLabel", i, true)
    objectiveLabel[i]:AddAnchor("TOPLEFT", anchorTarget, "BOTTOMLEFT", anchorOffset, 8)
    objectiveLabel[i]:SetAutoResize(true)
    objectiveLabel[i]:SetHeight(FONT_SIZE.MIDDLE)
    objectiveLabel[i].style:SetColorByKey("default")
    anchorTarget = objectiveLabel[i]
    anchorOffset = 0
  end
  local rewardWnd = wnd.content:CreateChildWidget("emptywidget", "rewardWnd", 0, true)
  local rewardTitle = rewardWnd:CreateChildWidget("textbox", "rewardTitle", 0, true)
  rewardTitle:AddAnchor("TOPLEFT", rewardWnd, 0, 0)
  rewardTitle:AddAnchor("TOPRIGHT", rewardWnd, 0, 0)
  rewardTitle.style:SetAlign(ALIGN_LEFT)
  rewardTitle.style:SetFontSize(FONT_SIZE.LARGE)
  rewardTitle:SetAutoResize(true)
  rewardTitle:SetHeight(FONT_SIZE.LARGE)
  rewardTitle.style:SetColorByKey("high_title")
  rewardTitle:SetText(GetCommonText("achievement_reward"))
  local function CreateRewardTextBox(name)
    local wnd = rewardWnd:CreateChildWidget("textbox", name, 0, true)
    wnd:AddAnchor("TOPLEFT", rewardWnd, 10, 0)
    wnd:AddAnchor("TOPRIGHT", rewardWnd, 0, 0)
    wnd:SetAutoResize(true)
    wnd.style:SetAlign(ALIGN_LEFT)
    wnd.style:SetColorByKey("default")
    wnd:Show(false)
    return wnd
  end
  local rewardExp = CreateRewardTextBox("rewardExp")
  local rewardMoney = CreateRewardTextBox("rewardMoney")
  local rewardAAPoint = CreateRewardTextBox("rewardAAPoint")
  local rewardExpeditionExp = CreateRewardTextBox("rewardExpeditionExp")
  local rewardFamilyExp = CreateRewardTextBox("rewardFamilyExp")
  local rewardLaborPower = CreateRewardTextBox("rewardLaborPower")
  local rewardLocalLaborPower = CreateRewardTextBox("rewardLocalLaborPower")
  local rewardHonorPoint = CreateRewardTextBox("rewardHonorPoint")
  local rewardDisHonorPoint = CreateRewardTextBox("rewardDisHonorPoint")
  local rewardLivingPoint = CreateRewardTextBox("rewardLivingPoint")
  local rewardContributionPoint = CreateRewardTextBox("rewardContributionPoint")
  local rewardActability = CreateRewardTextBox("rewardActability")
  local rewardLeadershipPoint = CreateRewardTextBox("rewardLeadershipPoint")
  local rewardResidentPoint = CreateRewardTextBox("rewardResidentPoint")
  local rewardArchePassPoint = CreateRewardTextBox("rewardArchePassPoint")
  local rewardItem = W_ETC.CreateRewardItem("rewardItem", rewardWnd, 0, false)
  rewardItem:AddAnchor("TOPLEFT", rewardTitle, "BOTTOMLEFT", 0, 7)
  local bubble = wnd.content:CreateChildWidget("gametooltip", "bubble", 0, true)
  bubble:AddAnchor("TOPLEFT", rewardWnd, "BOTTOMLEFT", 0, 30)
  bubble:AddAnchor("TOPRIGHT", rewardWnd, "TOPRIGHT", 0, 30)
  bubble:SetAutoWordwrap(true)
  bubble.style:SetSnap(true)
  bubble.style:SetColorByKey("default")
  local function UpdateBubble(qType)
    bubble:ClearLines()
    local bubbles = X2Quest:AcceptBubbleText(qType)
    if bubbles == nil or #bubbles == 0 then
      bubble:Show(false)
      return
    end
    local DecoSystemChatBubble = function(str)
      return string.format(localeView.questContextList.systemChatBubbleDecoFormat, str)
    end
    local RemovedGestureText = function(str)
      return string.gsub(str, "/(%w+) ", "")
    end
    local height = 0
    for i = 1, #bubbles do
      local speech = bubbles[i]
      if speech.kind == CBK_SYSTEM then
        speech.text = DecoSystemChatBubble(speech.text)
      elseif bubbles[i - 1] == nil or bubbles[i - 1].who ~= speech.who then
        local str = string.format("%s%s", F_COLOR.GetColor("middle_title", true), speech.who)
        local index = bubble:AddLine(str, FONT_PATH.DEFAULT, FONT_SIZE.LARGE, "left", ALIGN_LEFT, 0)
        if i ~= 1 then
          bubble:AttachUpperSpaceLine(index, MARGIN.WINDOW_SIDE / 3)
        end
        bubble:AttachLowerSpaceLine(index, 3)
      end
      local index = bubble:AddLine(RemovedGestureText(speech.text), FONT_PATH.DEFAULT, FONT_SIZE.MIDDLE, "left", ALIGN_LEFT, MARGIN.WINDOW_SIDE / 2)
      bubble:AttachLowerSpaceLine(index, MARGIN.WINDOW_SIDE / 3)
    end
    bubble:Show(true)
  end
  local function UpdateObjectiveWnd(qType, qInfo)
    if X2Quest:IsSelectiveQuest(qType) then
      objectiveDesc:SetText(locale.questContext.selectiveObj)
    elseif X2Quest:IsScoreQuest(qType) then
      local str = ""
      local titleStr = X2Quest:GetQuestJournalProgTitleByType(qType)
      local scoreStr = string.format("%s %s", locale.questContext.scoreCount, F_TEXT.SetSlashFormat(qInfo.curValue, qInfo.maxValue))
      if titleStr == nil then
        str = scoreStr
      else
        str = string.format([[
%s
%s]], titleStr, scoreStr)
      end
      objectiveDesc:SetText(str)
    else
      objectiveDesc:SetText("")
      objectiveDesc:SetHeight(0)
    end
    local count = X2Quest:GetObjectiveComponentCount(qType)
    for i = 1, #objectiveLabel do
      if i <= count then
        local str = X2Quest:GetObjective(qType, i)
        objectiveLabel[i]:SetText(str)
        objectiveLabel[i]:Show(true)
      else
        objectiveLabel[i]:SetText("")
        objectiveLabel[i]:Show(false)
      end
    end
    objectiveWnd:SetHeight(objectiveDesc:GetHeight() + math.min(count, 5) * (FONT_SIZE.MIDDLE + 8))
    objectiveWnd:Show(true)
  end
  function wnd:SetAchievementInfo(aType, selectFunc)
    wnd.aType = aType
    wnd.qType = nil
    wnd.selectFunc = selectFunc
    wnd:Update()
  end
  function wnd:SetTodayAssignmentInfo(qType)
    wnd.aType = nil
    wnd.qType = qType
    wnd.selectFunc = nil
    wnd:Update()
  end
  local function UpdateQuestReward(qType)
    local lastTarget = rewardTitle
    local xOffset = 15
    local yOffset = 8
    local function SetLastTarget(widget)
      widget:RemoveAllAnchors()
      widget:AddAnchor("TOPLEFT", lastTarget, "BOTTOMLEFT", xOffset, yOffset)
      widget:AddAnchor("TOPRIGHT", lastTarget, "BOTTOMRIGHT", 0, yOffset)
      xOffset = 0
      yOffset = 8
      lastTarget = widget
    end
    local expValue = X2Quest:GetQuestContextRewardExp(qType)
    if expValue ~= nil and tonumber(expValue) ~= 0 then
      local str = string.format("%s %s|,%s;", GetUIText(COMMON_TEXT, "exp"), blueColor, tostring(expValue))
      rewardExp:SetText(str)
      SetLastTarget(rewardExp)
      rewardExp:Show(true)
    else
      rewardExp:SetText("")
      rewardExp:Show(false)
    end
    local money = X2Quest:GetQuestContextRewardCopper(qType)
    if money ~= nil and money ~= "" and money ~= "0" then
      local str = string.format("%s %s%s", locale.questContext.rewardMoney, blueColor, F_MONEY:GetCostStringByCurrency(CURRENCY_GOLD, money))
      rewardMoney:SetText(str)
      SetLastTarget(rewardMoney)
      rewardMoney:Show(true)
    else
      rewardMoney:SetText("")
      rewardMoney:Show(false)
    end
    local aaPoint = X2Quest:GetQuestContextRewardAAPoint(qType)
    if aaPoint ~= nil and aaPoint ~= 0 then
      local str = string.format("%s %s|p%d;", locale.questContext.rewardAAPoint, F_COLOR.GetColor("deep_orange", true), aaPoint)
      rewardAAPoint:SetText(str)
      SetLastTarget(rewardAAPoint)
      rewardAAPoint:Show(true)
    else
      rewardAAPoint:SetText("")
      rewardAAPoint:Show(false)
    end
    local expeditionExpValue = X2Quest:RewardExpeditionExp(qType)
    if expeditionExpValue ~= nil and expeditionExpValue ~= 0 then
      local str = string.format("%s %s %s|,%s;", GetUIText(COMMUNITY_TEXT, "expedition"), GetUIText(COMMON_TEXT, "exp"), blueColor, tostring(expeditionExpValue))
      rewardExpeditionExp:SetText(str)
      SetLastTarget(rewardExpeditionExp)
      rewardExpeditionExp:Show(true)
    else
      rewardExpeditionExp:SetText("")
      rewardExpeditionExp:Show(false)
    end
    local familyExpValue = X2Quest:RewardFamilyExp(qType)
    if familyExpValue ~= nil and familyExpValue ~= 0 then
      local str = string.format("%s %s %s|,%s;", GetUIText(COMMON_TEXT, "family"), GetUIText(COMMON_TEXT, "exp"), blueColor, tostring(familyExpValue))
      rewardFamilyExp:SetText(str)
      SetLastTarget(rewardFamilyExp)
      rewardFamilyExp:Show(true)
    else
      rewardFamilyExp:SetText("")
      rewardFamilyExp:Show(false)
    end
    local laborPower = X2Quest:RewardLaborPower(qType)
    if laborPower ~= nil and laborPower ~= 0 then
      local str = string.format("%s %s|,%s;", locale.attribute("labor_power"), blueColor, tostring(laborPower))
      rewardLaborPower:SetText(str)
      SetLastTarget(rewardLaborPower)
      rewardLaborPower:Show(true)
    else
      rewardLaborPower:SetText("")
      rewardLaborPower:Show(false)
    end
    local localLaborPower = X2Quest:RewardLocalLaborPower(qType)
    if localLaborPower ~= nil and localLaborPower ~= 0 then
      local str = string.format("%s %s|,%s;", GetUIText(COMMON_TEXT, "local_labor_power"), blueColor, tostring(localLaborPower))
      rewardLocalLaborPower:SetText(str)
      SetLastTarget(rewardLocalLaborPower)
      rewardLocalLaborPower:Show(true)
    else
      rewardLocalLaborPower:SetText("")
      rewardLocalLaborPower:Show(false)
    end
    local honor = X2Quest:RewardHonorPoint(qType)
    if honor ~= nil and honor ~= 0 then
      local str = string.format("%s %s|h%d;", GetUIText(COMMON_TEXT, "honor_point"), blueColor, honor)
      rewardHonorPoint:SetText(str)
      SetLastTarget(rewardHonorPoint)
      rewardHonorPoint:Show(true)
    else
      rewardHonorPoint:SetText("")
      rewardHonorPoint:Show(false)
    end
    local crime = X2Quest:RewardCrimePoint(qType)
    if crime ~= nil and crime ~= 0 then
      local str = string.format("%s %s|d%d;", locale.money.dishonor, blueColor, crime)
      rewardDisHonorPoint:SetText(str)
      SetLastTarget(rewardDisHonorPoint)
      rewardDisHonorPoint:Show(true)
    else
      rewardDisHonorPoint:SetText("")
      rewardDisHonorPoint:Show(false)
    end
    local livingPoint = X2Quest:RewardLivingPoint(qType)
    if livingPoint ~= nil and livingPoint ~= 0 then
      local str = string.format("%s %s%s", locale.questContext.livingPoint, blueColor, F_MONEY:GetCostStringByCurrency(CURRENCY_LIVING_POINT, livingPoint))
      rewardLivingPoint:SetText(str)
      SetLastTarget(rewardLivingPoint)
      rewardLivingPoint:Show(true)
    else
      rewardLivingPoint:SetText("")
      rewardLivingPoint:Show(false)
    end
    local contributionPoint = X2Quest:RewardContributionPoint(qType)
    if contributionPoint ~= nil and contributionPoint ~= 0 then
      local str = string.format("%s %s|w%d", locale.money.contribution_point, blueColor, contributionPoint)
      rewardContributionPoint:SetText(str)
      SetLastTarget(rewardContributionPoint)
      rewardContributionPoint:Show(true)
    else
      rewardContributionPoint:SetText("")
      rewardContributionPoint:Show(false)
    end
    local actabilityInfo = X2Quest:RewardActability(qType)
    if actabilityInfo ~= nil and actabilityInfo.point ~= 0 then
      local str = string.format("%s %s %s%d", actabilityInfo.name, locale.skill.actabilityButtonText, blueColor, actabilityInfo.point)
      rewardActability:SetText(str)
      SetLastTarget(rewardActability)
      rewardActability:Show(true)
    else
      rewardActability:SetText("")
      rewardActability:Show(false)
    end
    local leadershipPoint = X2Quest:RewardLeadershipPoint(qType)
    if leadershipPoint ~= nil and leadershipPoint ~= 0 then
      local str = string.format("%s %s|sd%d;", questLocale:GetLeaderShipPointText(), blueColor, leadershipPoint)
      rewardLeadershipPoint:SetText(str)
      SetLastTarget(rewardLeadershipPoint)
      rewardLeadershipPoint:Show(true)
    else
      rewardLeadershipPoint:SetText("")
      rewardLeadershipPoint:Show(false)
    end
    local residentZone, residentPoint = X2Quest:RewardResidentPoint(qType)
    if residentZone ~= nil and residentZone ~= 0 then
      local zoneName = X2Dominion:GetZoneGroupName(residentZone)
      local str = string.format("%s %s%d", GetCommonText("resident_zone_point", zoneName), blueColor, residentPoint)
      rewardResidentPoint:SetText(str)
      SetLastTarget(rewardResidentPoint)
      rewardResidentPoint:Show(true)
    else
      rewardResidentPoint:SetText("")
      rewardResidentPoint:Show(false)
    end
    local archePassPoint = X2Quest:RewardArchePassPoint(qType)
    if archePassPoint ~= nil and archePassPoint ~= 0 then
      local str = string.format("%s %s|,%s;", GetCommonText("arche_pass_point"), blueColor, tostring(archePassPoint))
      rewardArchePassPoint:SetText(str)
      SetLastTarget(rewardArchePassPoint)
      rewardArchePassPoint:Show(true)
    else
      rewardArchePassPoint:SetText("")
      rewardArchePassPoint:Show(false)
    end
    if 0 < X2Quest:GetQuestContextRewardItemAllCount(wnd.qType) then
      local itemType = X2Quest:GetQuestContextRewardItemIconType(wnd.qType, 1)
      local itemCount = X2Quest:GetQuestContextRewardItemCount(wnd.qType, 1)
      local itemInfo = X2Item:GetItemInfoByType(itemType)
      rewardItem:SetInfo(itemInfo, itemCount)
      if lastTarget == rewardTitle then
        rewardItem:AddAnchor("TOPLEFT", lastTarget, "BOTTOMLEFT", 0, yOffset)
      else
        rewardItem:AddAnchor("TOPLEFT", lastTarget, "BOTTOMLEFT", -15, yOffset)
      end
      lastTarget = rewardItem
      rewardItem:Show(true)
    else
      rewardItem:Show(false)
    end
    if lastTarget == rewardTitle then
      rewardWnd:SetHeight(0)
      rewardWnd:Show(false)
    else
      local _, rY = rewardWnd:GetOffset()
      local _, tY = lastTarget:GetOffset()
      local height = tY + lastTarget:GetHeight() - rY
      rewardWnd:SetHeight(height)
    end
  end
  function wnd:Update()
    if wnd.qType ~= nil then
      local info = X2Quest:GetTodayQuestInfo(wnd.qType)
      descLabel:SetText(info.description)
      descriptionWnd:SetHeight(descBg:GetHeight())
      rewardWnd:RemoveAllAnchors()
      if X2Quest:IsProgressQuestInJournal(wnd.qType) then
        UpdateObjectiveWnd(wnd.qType, info)
        rewardWnd:AddAnchor("TOPLEFT", objectiveWnd, "BOTTOMLEFT", 0, 10)
        rewardWnd:AddAnchor("TOPRIGHT", objectiveWnd, "BOTTOMRIGHT", 0, 10)
      else
        objectiveWnd:Show(false)
        rewardWnd:AddAnchor("TOPLEFT", descriptionWnd, "BOTTOMLEFT", 10, 5)
        rewardWnd:AddAnchor("TOPRIGHT", descriptionWnd, "BOTTOMRIGHT", 0, 5)
      end
      UpdateQuestReward(wnd.qType)
      UpdateBubble(wnd.qType)
    end
    local height = 0
    wnd:SetValue(0)
    local _, cY = wnd:GetOffset()
    if bubble:IsVisible() then
      local _, rY = bubble:GetOffset()
      local rH = bubble:GetHeight()
      height = rY + rH - cY + 5
    else
      local _, rY = rewardWnd:GetOffset()
      local rH = rewardWnd:GetHeight()
      height = rY + rH - cY + 5
    end
    wnd:ResetScroll(height)
  end
  return wnd
end
local TodayAssignmentLayoutInfos = {
  [TADT_TODAY] = {
    rowCount = 6,
    rowWidth = 535,
    rowHeight = 67,
    bottomInfo = {
      width = 559,
      height = 86,
      useCompleteLabel = true,
      useChangeLabel = true,
      useAutoAcceptBtn = true,
      useChangeBtn = true,
      guideStr = GetUIText(TOOLTIP_TEXT, "today_assignment_reset_guide")
    }
  },
  [TADT_EXPEDITION] = {
    rowCount = 6,
    rowWidth = 535,
    rowHeight = 85,
    bottomInfo = {
      width = 559,
      height = 86,
      useCompleteLabel = false,
      useChangeLabel = true,
      useAutoAcceptBtn = true,
      useChangeBtn = true
    }
  },
  [TADT_FAMILY] = {
    rowCount = 6,
    rowWidth = 535,
    rowHeight = 85,
    bottomInfo = {
      width = 559,
      height = 85,
      useCompleteLabel = false,
      useChangeLabel = false,
      useAutoAcceptBtn = true,
      useChangeBtn = false
    }
  },
  [TADT_HERO] = {
    rowCount = 6,
    rowWidth = 514,
    rowHeight = 80,
    bottomInfo = {
      width = 538,
      height = 81,
      useCompleteLabel = false,
      useChangeLabel = false,
      useAutoAcceptBtn = true,
      useChangeBtn = false
    }
  },
  [TADT_ARCHE_PASS] = {
    rowCount = 4,
    rowWidth = 415,
    rowHeight = 73,
    bottomInfo = {
      width = 439,
      height = 73,
      useCompleteLabel = true,
      useChangeLabel = true,
      useAutoAcceptBtn = true,
      useChangeBtn = true,
      guideStr = GetUIText(TOOLTIP_TEXT, "arche_pass_mission_guide", GetCommonText(X2ArchePass:GetArchePassResetWeeklyDay()))
    }
  }
}
local TracingBtnEntered = function(checkBtn)
  SetTooltip(GetCommonText("trace_today_quest_tooltip"), checkBtn)
end
local TracingBtnChecked = function(checkBtn)
  local index = checkBtn:GetParent().index
  local todayType = checkBtn:GetParent().todayType
  if index == nil or todayType == nil then
    return
  end
  local checked = checkBtn:GetChecked()
  local info = X2Achievement:GetTodayAssignmentInfo(todayType, index)
  if info ~= nil and info.questType ~= nil and info.questType ~= 0 then
    if checked then
      AddQuestToNotifier(info.questType)
    else
      RemoveQuestFromNotifier(info.questType)
    end
  end
end
local function CreateASubjectListWnd(id, parent, layoutInfo)
  if layoutInfo == nil then
    return nil
  end
  local listCtrl = W_MODULE:Create("listCtrl", parent, W_MODULE.TYPES.LISTCTRL, nil, {
    [W_MODULE.ATTRIBUTE.HAS_SCROLL] = true,
    [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = false,
    [W_MODULE.ATTRIBUTE.ROW_COUNT] = layoutInfo.rowCount,
    [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = layoutInfo.rowHeight,
    [W_MODULE.ATTRIBUTE.COLUMN_HEIGHT_TYPE] = nil,
    [W_MODULE.ATTRIBUTE.OVER_SELECT_IMAGE_TYPE] = "type_4",
    [W_MODULE.ATTRIBUTE.ONSELCHANGED_PROC] = function(index, doubleClick, moduleFrame)
      local rowItem = moduleFrame:GetRow(index)
      if rowItem == nil then
        return
      end
      if (rowItem.handleClick == nil or not rowItem:handleClick()) and moduleFrame.ToggleWndFunc ~= nil and type(moduleFrame.ToggleWndFunc) == "function" then
        moduleFrame:ToggleWndFunc(index, moduleFrame.info)
      end
    end,
    [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = layoutInfo.rowWidth,
        [W_MODULE.ATTRIBUTE.TEXT] = "",
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
          CreateASubjectWnd(subItem)
          function row:handleClick()
            return subItem.checkBtn:IsMouseOver()
          end
        end,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data == nil then
            subItem:SetTodayAssignment()
            subItem:Show(false)
          else
            subItem:Show(true)
            subItem:SetTodayAssignment(A_SUBJECT_STYLE.TODAY_ASSIGNMENT_LIST, data.todayType, data.index, TracingBtnChecked, TracingBtnEntered)
          end
        end
      }
    }
  })
  local emptyLabel = listCtrl:CreateChildWidget("textbox", "emptyLabel", 0, true)
  emptyLabel:SetExtent(listCtrl:GetWidth(), FONT_SIZE.MIDDLE)
  emptyLabel.style:SetFontSize(FONT_SIZE.LARGE)
  emptyLabel:AddAnchor("LEFT", listCtrl, 0, 0)
  emptyLabel:AddAnchor("RIGHT", listCtrl, 0, 0)
  emptyLabel.style:SetColorByKey("default")
  emptyLabel:SetText(GetCommonText("no_achievement"))
  emptyLabel:SetHeight(emptyLabel:GetTextHeight())
  emptyLabel:Show(false)
  function listCtrl:FillListData(todayType)
    local info = {}
    local cnt = X2Achievement:GetTodayAssignmentCount(todayType)
    if cnt > 0 then
      for index = 1, cnt do
        info[index] = {index = index, todayType = todayType}
      end
      emptyLabel:Show(false)
    else
      emptyLabel:Show(true)
    end
    self:SetData({
      [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
      [W_MODULE.ATTRIBUTE.DATA] = info
    })
    listCtrl.info = info
  end
  return listCtrl
end
local CreateASubjectBottomWnd = function(id, parent, todayType, layoutInfo)
  if layoutInfo == nil then
    return nil
  end
  local bottomWnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  bottomWnd:SetExtent(layoutInfo.width, layoutInfo.height)
  bottomWnd.todayType = todayType
  bottomWnd.updateFunc = nil
  bottomWnd.changeFunc = nil
  bottomWnd.autoAcceptFunc = nil
  local offsetX = 5
  local offsetY = 5
  local targetAnchor = bottomWnd
  local changeCountLabel, completeCountLabel
  if layoutInfo.useChangeLabel == true then
    changeCountLabel = bottomWnd:CreateChildWidget("label", "changeCountLabel", 0, true)
    changeCountLabel:SetExtent(layoutInfo.width - 10, FONT_SIZE.MIDDLE)
    changeCountLabel.style:SetAlign(ALIGN_LEFT)
    changeCountLabel.style:SetFontSize(FONT_SIZE.MIDDLE)
    changeCountLabel.style:SetColorByKey("default")
    changeCountLabel:AddAnchor("TOPLEFT", targetAnchor, offsetX, offsetY)
    changeCountLabel:SetText("")
    offsetX = 0
    offsetY = 7
    targetAnchor = changeCountLabel
  end
  if layoutInfo.useCompleteLabel == true then
    completeCountLabel = bottomWnd:CreateChildWidget("label", "completeCountLabel", 0, true)
    completeCountLabel:SetExtent(layoutInfo.width - 10, FONT_SIZE.MIDDLE)
    completeCountLabel.style:SetAlign(ALIGN_LEFT)
    completeCountLabel.style:SetFontSize(FONT_SIZE.MIDDLE)
    completeCountLabel.style:SetColorByKey("default")
    completeCountLabel:AddAnchor("TOPLEFT", targetAnchor, "BOTTOMLEFT", offsetX, offsetY)
    completeCountLabel:SetText("")
  end
  if layoutInfo.guideStr ~= nil then
    do
      local guide = W_ICON.CreateGuideIconWidget(bottomWnd)
      guide:AddAnchor("TOPRIGHT", bottomWnd, 0, 5)
      local width = bottomWnd:GetWidth() - 10 - guide:GetWidth()
      if changeCountLabel ~= nil then
        changeCountLabel:SetWidth(width)
      end
      if completeCountLabel ~= nil then
        completeCountLabel:SetWidth(width)
      end
      local function OnEnterGuide()
        SetTooltip(layoutInfo.guideStr, guide)
      end
      guide:SetHandler("OnEnter", OnEnterGuide)
    end
  end
  local buttonSet = W_MODULE:Create("buttonSet", bottomWnd, W_MODULE.TYPES.BUTTON_SET)
  buttonSet:AddAnchor("BOTTOMRIGHT", bottomWnd, 0, 0)
  if layoutInfo.useChangeBtn == true then
    buttonSet:AddButton("change", {
      [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("today_assignment_reset_title"),
      [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.RIGHT,
      [W_MODULE.ATTRIBUTE.ENABLE] = false,
      clickFunc = function()
        if bottomWnd.changeFunc ~= nil and type(bottomWnd.changeFunc) == "function" then
          bottomWnd.changeFunc(bottomWnd.todayType)
        end
      end
    })
  end
  if layoutInfo.useAutoAcceptBtn == true then
    buttonSet:AddButton("autoAccept", {
      [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("today_assignment_all_accept"),
      [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.RIGHT,
      [W_MODULE.ATTRIBUTE.ENABLE] = false,
      clickFunc = function()
        if bottomWnd.autoAcceptFunc ~= nil and type(bottomWnd.autoAcceptFunc) == "function" then
          bottomWnd:autoAcceptFunc(bottomWnd.todayType)
        else
          X2Achievement:RequestTodayAssignmentAllAccept(bottomWnd.todayType)
        end
      end,
      tooltip = function(self)
        if self:IsEnabled() then
          return
        end
        if X2Achievement:GetTodayAssignmentAllAcceptState() == true then
          SetTooltip(GetUIText(COMMON_TEXT, "today_assignment_all_accept_cooltime_tooltip"), self)
        else
          SetTooltip(GetUIText(COMMON_TEXT, "today_assignment_all_accept_disable_tooltip"), self)
        end
      end
    })
  end
  function bottomWnd:RegistBottomUpdateFunc(updateFunc)
    self.updateFunc = updateFunc
  end
  function bottomWnd:RegistButtonSetFunc(changeFunc, autoAcceptFunc)
    self.changeFunc = changeFunc
    self.autoAcceptFunc = autoAcceptFunc
  end
  function bottomWnd:RegisterButtonTooltipFunc(key, func)
    if buttonSet:GetButton(key) ~= nil then
      buttonSet:UpdateButton(key, {tooltip = func})
    end
  end
  function bottomWnd:UpdateData(todayType)
    if self.updateFunc ~= nil and type(self.updateFunc) == "function" then
      self.updateFunc(todayType)
    end
  end
  function bottomWnd:UpdateInfo(updateInfo)
    if changeCountLabel ~= nil then
      if updateInfo.changeStr == nil then
        changeCountLabel:Show(false)
      else
        changeCountLabel:Show(true)
        changeCountLabel:SetText(updateInfo.changeStr)
      end
    end
    if completeCountLabel ~= nil then
      if updateInfo.completeStr == nil then
        completeCountLabel:Show(false)
      else
        completeCountLabel:Show(true)
        completeCountLabel:SetText(updateInfo.completeStr)
      end
    end
    if buttonSet:GetButton("change") ~= nil then
      buttonSet:UpdateButton("change", {
        [W_MODULE.ATTRIBUTE.ENABLE] = updateInfo.changeBtnState ~= nil and updateInfo.changeBtnState or false
      })
    end
    if buttonSet:GetButton("autoAccept") ~= nil then
      buttonSet:UpdateButton("autoAccept", {
        [W_MODULE.ATTRIBUTE.ENABLE] = updateInfo.autoAcceptBtnState ~= nil and updateInfo.autoAcceptBtnState or false
      })
    end
  end
  return bottomWnd
end
local function CreateTodayAssignmentDescWnd(id, parent, todayType)
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  wnd.todayType = todayType
  local prevPageBtn = wnd:CreateChildWidget("button", "prevPageBtn", 0, true)
  prevPageBtn:AddAnchor("TOPLEFT", wnd, 0, 0)
  prevPageBtn:SetText(GetCommonText("prev_page"))
  prevPageBtn:SetStyle("prev_page_back")
  local subjectWnd = wnd:CreateChildWidget("emptywidget", "subjectWnd", 0, true)
  CreateASubjectWnd(subjectWnd)
  subjectWnd:AddAnchor("TOPLEFT", prevPageBtn, "BOTTOMLEFT", 0, 5)
  subjectWnd:AddAnchor("BOTTOMRIGHT", wnd, "TOPRIGHT", 0, 105)
  local categoryLabel = wnd:CreateChildWidget("label", "categoryLabel", 0, true)
  categoryLabel:SetHeight(FONT_SIZE.MIDDLE)
  categoryLabel:SetAutoResize(true)
  categoryLabel.style:SetAlign(ALIGN_RIGHT)
  categoryLabel:AddAnchor("BOTTOMRIGHT", subjectWnd, "TOPRIGHT", -5, -10)
  categoryLabel.style:SetColorByKey("default")
  local descWnd = CreateAAchievementDescWnd("descWnd", wnd)
  descWnd:AddAnchor("TOPLEFT", subjectWnd, "BOTTOMLEFT", 0, 5)
  descWnd:AddAnchor("BOTTOMRIGHT", wnd, "BOTTOMRIGHT", 0, -40)
  local prevBtn = wnd:CreateChildWidget("button", "prevBtn", 0, true)
  prevBtn:AddAnchor("RIGHT", wnd, "BOTTOM", -5, -20)
  prevBtn:SetStyle("prev_page")
  local nextBtn = wnd:CreateChildWidget("button", "nextBtn", 0, true)
  nextBtn:AddAnchor("LEFT", wnd, "BOTTOM", 5, -20)
  nextBtn:SetStyle("next_page")
  function wnd:SetInfo(index, aList, prevPage, CheckFunc, TracingBtnEntered)
    local info = X2Achievement:GetTodayAssignmentInfo(self.todayType, index)
    if info == nil then
      return
    elseif info.status == A_TODAY_STATUS.LOCKED then
      if wnd.lastQuest ~= nil then
        prevPageBtn:OnClick()
        return
      end
      if info.satisfy then
        local str
        if self.todayType == TADT_TODAY then
          str = GetUIText(COMMON_TEXT, "today_assignment")
        elseif self.todayType == TADT_EXPEDITION then
          str = GetUIText(COMMON_TEXT, "expedition_today_quest")
        elseif self.todayType == TADT_ARCHE_PASS then
          str = GetUIText(COMMON_TEXT, "today_quest")
        elseif self.todayType == TADT_HERO then
          str = GetUIText(COMMON_TEXT, "hero_quest")
        elseif self.todayType == TADT_FAMILY then
          str = GetUIText(COMMON_TEXT, "family_happy_life")
        end
        if str ~= nil then
          CallUnlockTodayQuestDialog(str, self.todayType, info)
        end
      end
      return
    elseif info.status == A_TODAY_STATUS.READY then
      if wnd.lastQuest ~= nil then
        prevPageBtn:OnClick()
        return
      end
      X2Achievement:HandleClickTodayAssignment(self.todayType, info.realStep)
      return
    end
    wnd.viewInfo = {
      index = index,
      aList = aList,
      prevPage = prevPage
    }
    categoryLabel:SetText(info.title)
    subjectWnd:SetTodayAssignment(A_SUBJECT_STYLE.TODAY_ASSIGNMENT_DESC, self.todayType, index, CheckFunc, TracingBtnEntered)
    descWnd:SetTodayAssignmentInfo(info.questType)
    wnd.lastQuest = info.questType
    local function RefreshMoveBtn()
      local cIndex = 1
      while aList[cIndex].index ~= index do
        cIndex = cIndex + 1
      end
      prevBtn:Enable(false)
      for i = cIndex - 1, 1, -1 do
        local sInfo = X2Achievement:GetTodayAssignmentInfo(wnd.todayType, aList[i].index)
        if sInfo ~= nil and sInfo.status >= A_TODAY_STATUS.PROGRESS then
          prevBtn.index = aList[i].index
          prevBtn:Enable(true)
          break
        end
      end
      nextBtn:Enable(false)
      for i = cIndex + 1, #aList do
        local sInfo = X2Achievement:GetTodayAssignmentInfo(wnd.todayType, aList[i].index)
        if sInfo ~= nil and sInfo.status >= A_TODAY_STATUS.PROGRESS then
          nextBtn.index = aList[i].index
          nextBtn:Enable(true)
          break
        end
      end
    end
    RefreshMoveBtn()
    if prevPage ~= wnd then
      prevPage:Show(false)
      wnd:Show(true)
    end
  end
  function prevPageBtn:OnClick()
    wnd.lastQuest = nil
    wnd.viewInfo.prevPage:Update()
    wnd.viewInfo.prevPage:Show(true)
    wnd:Show(false)
    wnd.viewInfo = nil
  end
  prevPageBtn:SetHandler("OnClick", prevPageBtn.OnClick)
  function prevBtn:OnClick()
    wnd:SetInfo(prevBtn.index, wnd.viewInfo.aList, wnd.viewInfo.prevPage)
  end
  prevBtn:SetHandler("OnClick", prevBtn.OnClick)
  function nextBtn:OnClick()
    wnd:SetInfo(nextBtn.index, wnd.viewInfo.aList, wnd.viewInfo.prevPage)
  end
  nextBtn:SetHandler("OnClick", nextBtn.OnClick)
  function wnd:Update()
    if wnd.viewInfo ~= nil then
      wnd:SetInfo(wnd.viewInfo.index, wnd.viewInfo.aList, wnd.viewInfo.prevPage)
    end
  end
  function wnd:OnHide()
    wnd.viewInfo = nil
  end
  wnd:SetHandler("OnHide", wnd.OnHide)
  return wnd
end
local function CreateTodayAssignmentListWnd(id, parent, todayType)
  local info = TodayAssignmentLayoutInfos[todayType]
  if info == nil then
    return nil
  end
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  wnd.todayType = todayType
  local subjectList = CreateASubjectListWnd("subjectList", wnd, info)
  subjectList:AddAnchor("TOP", wnd, 0, 0)
  wnd.subjectList = subjectList
  local subjectBottom
  if info.bottomInfo == nil then
    wnd:SetExtent(subjectList:GetWidth(), subjectList:Height())
  else
    subjectBottom = CreateASubjectBottomWnd("subjectBottom", wnd, todayType, info.bottomInfo)
    subjectBottom:AddAnchor("TOPLEFT", subjectList, "BOTTOMLEFT", 0, 0)
    local _, height = F_LAYOUT.GetExtentWidgets(subjectList, subjectBottom)
    wnd:SetExtent(subjectList:GetWidth(), height)
  end
  local function Update()
    subjectList:FillListData(wnd.todayType)
    if subjectBottom ~= nil then
      subjectBottom:UpdateData(wnd.todayType)
    end
  end
  function wnd:RegistBottomUpdateFunc(func)
    if subjectBottom ~= nil then
      subjectBottom:RegistBottomUpdateFunc(func)
    end
  end
  function wnd:RegistButtonSetFunc(changeFunc, autoAcceptFunc)
    if subjectBottom ~= nil then
      subjectBottom:RegistButtonSetFunc(changeFunc, autoAcceptFunc)
    end
  end
  function wnd:RegisterButtonTooltipFunc(key, func)
    if subjectBottom ~= nil then
      subjectBottom:RegisterButtonTooltipFunc(key, func)
    end
  end
  function wnd:ToggleDetailWnd(index, aList)
    if subjectList.toggleFunc ~= nil and type(subjectList.toggleFunc) == "function" then
      subjectList.toggleFunc(index, aList)
    end
  end
  function wnd:Init()
    Update()
  end
  function wnd:Update()
    Update()
  end
  return wnd
end
function CreateCommonTodayAssignmentListWnd(id, parent, anchor, todayType)
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  wnd.todayType = todayType
  local listWnd = CreateTodayAssignmentListWnd("listWnd", wnd, todayType)
  listWnd:AddAnchor("TOPLEFT", anchor, "TOPRIGHT", 8, 0)
  listWnd:Init()
  local descWnd = CreateTodayAssignmentDescWnd("descWnd", wnd, todayType)
  descWnd:AddAnchor("TOPLEFT", listWnd, 0, 0)
  descWnd:AddAnchor("BOTTOMRIGHT", listWnd, 0, 0)
  descWnd:Show(false)
  function listWnd.subjectList:ToggleWndFunc(index, aList)
    descWnd:SetInfo(index, aList, listWnd, TracingBtnChecked, TracingBtnEntered)
  end
  function wnd:ToggleWithQuest(qType, todayType)
    local cnt = X2Achievement:GetTodayAssignmentCount(todayType)
    local info = {}
    for index = 1, cnt do
      info[index] = {index = index, todayType = todayType}
    end
    for index = 1, #info do
      local tInfo = X2Achievement:GetTodayAssignmentInfo(todayType, index)
      if tInfo ~= nil and tInfo.questType == qType then
        listWnd.subjectList:ToggleWndFunc(index, info)
        return
      end
    end
  end
  function wnd:UpdateTodayType(todayType)
    listWnd.todayType = todayType
    if listWnd.subjectBottom ~= nil then
      listWnd.subjectBottom.todayType = todayType
    end
    descWnd.todayType = todayType
  end
  function wnd:UpdateBottomInfo(updateInfo)
    if listWnd.subjectBottom ~= nil then
      listWnd.subjectBottom:UpdateInfo(updateInfo)
    end
  end
  function wnd:Update()
    listWnd:Update()
    descWnd:Update()
  end
  return wnd
end
function CreateChangeObjectWnd(id, parent, todayType)
  local window = CreateWindow(id, "UIParent")
  window:SetWindowModal(true)
  window:SetExtent(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_510), 530)
  window:AddAnchor("CENTER", "UIParent", 0, 0)
  window:SetTitle(GetCommonText("today_assignment_reset_title"))
  window:EnableHidingIsRemove(true)
  local selectRealStep = 0
  local listCtrl
  local contentWidth = window:GetWidth() - 60
  local buttonSet = W_MODULE:Create("buttonSet", window, W_MODULE.TYPES.BUTTON_SET)
  buttonSet:AddButton("ok", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "ok"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    enable = false,
    clickFunc = function()
      local data = listCtrl:GetDataPartially(W_MODULE.ATTRIBUTE.SELECTED_DATA)
      if data == nil then
        return
      end
      X2Achievement:ResetTodayAssignment(todayType, data.realStep)
      window:Show(false)
    end
  })
  buttonSet:AddButton("cancel", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "cancel"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    enable = true,
    clickFunc = function()
      window:Show(false)
    end
  })
  listCtrl = W_MODULE:Create("listCtrl", window, W_MODULE.TYPES.LISTCTRL, nil, {
    [W_MODULE.ATTRIBUTE.HAS_SCROLL] = true,
    [W_MODULE.ATTRIBUTE.COLUMN_HEIGHT_TYPE] = nil,
    [W_MODULE.ATTRIBUTE.ROW_COUNT] = 6,
    [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = false,
    [W_MODULE.ATTRIBUTE.ROW_BACKGROUND_TYPE] = "type_3",
    [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = "icon_large",
    [W_MODULE.ATTRIBUTE.ROW_INSET_TYPE] = "icon_large",
    [W_MODULE.ATTRIBUTE.OVER_SELECT_IMAGE_TYPE] = "type_4",
    [W_MODULE.ATTRIBUTE.ONSELCHANGED_PROC] = function(index, doubleClick, moduleFrame)
      buttonSet:UpdateButton("ok", {enable = true})
    end,
    [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = contentWidth,
        [W_MODULE.ATTRIBUTE.TEXT] = "",
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
          local size = F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_52)
          local iconOffset = 10
          local iconBg = subItem:CreateDrawable(TEXTURE_PATH.DEFAULT, "icon_button_bg", "background")
          iconBg:SetExtent(size, size)
          iconBg:AddAnchor("LEFT", subItem, iconOffset, 0)
          local icon = subItem:CreateIconDrawable("artwork")
          icon:AddAnchor("TOPLEFT", iconBg, 2, 2)
          icon:AddAnchor("BOTTOMRIGHT", iconBg, -2, -2)
          subItem.icon = icon
          local inset = 5
          local width = subItem:GetWidth() - iconBg:GetWidth() - inset - iconOffset - 15
          local title = subItem:CreateChildWidget("label", "title", 0, true)
          title:SetExtent(width, FONT_SIZE.MIDDLE)
          title.style:SetAlign(ALIGN_LEFT)
          title.style:SetEllipsis(true)
          title.style:SetColorByKey("high_title")
          title:AddAnchor("LEFT", iconBg, "RIGHT", inset, -10)
          subItem.title = title
          local desc = subItem:CreateChildWidget("label", "desc", 0, true)
          desc:SetExtent(width, FONT_SIZE.MIDDLE)
          desc.style:SetAlign(ALIGN_LEFT)
          desc.style:SetEllipsis(true)
          desc:AddAnchor("TOPLEFT", title, "BOTTOMLEFT", 0, inset)
          desc.style:SetColorByKey("default")
          subItem.desc = desc
          local OnEnter = function(self)
            local curText = self:GetText()
            if self.style:GetTextWidth(curText) < self:GetWidth() then
              return
            end
            SetTooltip(curText, self)
          end
          title:SetHandler("OnEnter", OnEnter)
          desc:SetHandler("OnEnter", OnEnter)
        end,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          local row = subItem:GetParent()
          if data then
            subItem.icon:ClearAllTextures()
            subItem.icon:AddTexture(data.iconPath)
            subItem.icon:SetVisible(true)
            subItem.title:SetText(data.title)
            local qInfo = MakeTodayQuestInfo(A_SUBJECT_STYLE.TODAY_ASSIGNMENT_LIST, data.questType)
            subItem.desc:SetText(qInfo.titleStr or "")
            row:ShowRowBackground(true)
          else
            subItem.icon:SetVisible(false)
            row:ShowRowBackground(false)
          end
        end
      }
    }
  })
  window:RegisterStack(listCtrl)
  window:RegisterStack(buttonSet)
  window:ApplyAutoHeightByStack()
  function window:ShowProc()
    buttonSet:UpdateButton("ok", {enable = false})
    local maxCnt = X2Achievement:GetTodayAssignmentCount(todayType)
    local datas = {}
    for i = 1, maxCnt do
      local info = X2Achievement:GetTodayAssignmentInfo(todayType, i)
      if info.status == A_TODAY_STATUS.PROGRESS then
        table.insert(datas, info)
      end
    end
    listCtrl:SetData({
      [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
      [W_MODULE.ATTRIBUTE.DATA] = datas
    })
  end
  return window
end
