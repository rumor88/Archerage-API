local layoutSet = {
  default = {
    windowWidth = F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_800),
    assignmentInnerRatioLeft = 4599075939470750515,
    assignmentInnerRatioRight = 4604480259023595110,
    appellationColumWidth = 321
  },
  [KAKAONA] = {
    windowWidth = F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_900),
    assignmentInnerRatioLeft = 4599976659396224614,
    assignmentInnerRatioRight = 4604029899060858061,
    appellationColumWidth = 369
  }
}
layoutSet[XLGAMES_TH] = layoutSet[KAKAONA]
layoutSet[MAILRU] = layoutSet[KAKAONA]
function GetLayoutSetAssignment()
  return L_HELPER.Get(layoutSet)
end
