## author : yoshimom
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## assignment

locale/layout_set.lua

common.lua
component.lua

assignment.lua

## quest_assignment
quest_assignment/common.lua
quest_assignment/component.lua

appellation/stamp.lua
appellation/appellation_view.lua
appellation/appellation.lua

ulc.lua
