local gaugePath = TEXTURE_PATH.ACHIEVEMENT_GAUGE
local unknownString = "?????"
local mainItemHeight = 73
local subItemHeight = 29
local default_bg = "achievement_bg_blue"
local complete_bg = "achievement_bg_yellow"
local STATE = {
  DEFAULT = 1,
  SUMMARY = 2,
  COMPLETE = 3,
  TRACING = 4
}
local GetSummaryMainList = function(kind, subCategoryType, _)
  return X2Achievement:GetAchievementMainList(kind, subCategoryType, AF_COMPLETE)
end
local GetCompleteMainList = function(kind, subCategoryType, _)
  local list = X2Achievement:GetAchievementMainList(kind, subCategoryType, AF_ALL)
  local ret = {}
  for i = 1, #list do
    local mainKey = list[i]
    local subItemList = X2Achievement:GetAchievementSubList(mainKey, AF_COMPLETE)
    if subItemList ~= nil and #subItemList > 0 then
      table.insert(ret, mainKey)
    else
      local info = X2Achievement:GetAchievementInfo(mainKey)
      if info.complete then
        table.insert(ret, mainKey)
      end
    end
  end
  return ret
end
local GetTracingMainList = function(kind, _, __)
  return X2Achievement:GetAchievementTracingList(kind)
end
local GetDefaultMainList = function(kind, subCategoryType, filter)
  return X2Achievement:GetAchievementMainList(kind, subCategoryType, filter)
end
local STATE_GET_MAIN_LIST_FUNC = {
  [STATE.DEFAULT] = GetDefaultMainList,
  [STATE.SUMMARY] = GetSummaryMainList,
  [STATE.COMPLETE] = GetCompleteMainList,
  [STATE.TRACING] = GetTracingMainList
}
local currentInfo = {
  kind = EAK_RACIAL_MISSION,
  values = {}
}
function currentInfo:GetInfo()
  if self.kind == nil then
    return
  end
  return self.values[self.kind]
end
function currentInfo:GetKind()
  return self.kind
end
function currentInfo:SetValue(key, value)
  local info = self:GetInfo()
  if info == nil then
    return
  end
  info[key] = value
end
function currentInfo:GetValue(key)
  local info = self:GetInfo()
  if info == nil then
    return
  end
  return info[key]
end
local function UpdateCurrentAchievementKind(kind)
  currentInfo.kind = kind
end
local function InitCurrentAchievementKind(kind)
  currentInfo.values[kind] = {}
end
local function SameCategory(categoryText, subCategoryType)
  return currentInfo:GetValue("categoryText") == categoryText and currentInfo:GetValue("subCategoryType") == subCategoryType
end
local function GetMainList(kind, subCategoryType, filter)
  local state = currentInfo:GetValue("state")
  if state == nil then
    state = STATE.DEFAULT
  end
  local GetMainListFunc = STATE_GET_MAIN_LIST_FUNC[state]
  if GetMainListFunc == nil then
    return nil
  end
  return GetMainListFunc(kind, subCategoryType, filter)
end
local SetReward = function(target, infoType, info)
  target:Show(true)
  target:Init()
  if infoType == "item" then
    target:SetInfo(X2Item:GetItemInfoByType(info.itemType))
    target:SetStack(info.count)
    target.procOnEnter = nil
  else
    target:SetIconDirectly({
      icon = info.iconPath
    })
    function target:procOnEnter()
      SetTooltip(F_TEXT.SetColonFormat(GetUIText(CHARACTER_SUBTITLE_TEXT, "appellation"), info.name), self)
    end
  end
end
local GetDateString = function(info)
  if info == nil then
    return ""
  end
  return baselibLocale:GetDefaultDateString(string.format("%02d", info.year - 2000), info.month, info.day)
end
local function GetDateStringWithComplete(info)
  return string.format("[%s] %s", GetCommonText("complete"), GetDateString(info.completeDate))
end
local layousSet = GetLayoutSetAssignment()
local function CreateCategoryListbox(id, parent)
  local width = parent:GetWidth() * layousSet.assignmentInnerRatioLeft
  local height = parent:GetHeight() - MARGIN.WINDOW_SIDE
  local wnd = W_CTRL.CreateScrollListBox(id, parent, parent)
  wnd:SetExtent(width, height)
  wnd.content.itemStyle:SetFontSize(FONT_SIZE.LARGE)
  wnd.content:SetHeight(FONT_SIZE.MIDDLE)
  wnd.content.itemStyle:SetAlign(ALIGN_LEFT)
  wnd.content.itemStyleSub:SetFontSize(FONT_SIZE.SMALL)
  wnd.content:SetTreeTypeIndent(true, 20, 20)
  local line = wnd.content:CreateSeparatorImageDrawable(TEXTURE_PATH.DEFAULT, "background")
  line:SetTextureInfo("line_01", "default")
  line:SetWidth(wnd.content:GetWidth() - MARGIN.WINDOW_SIDE)
  wnd:SetTreeImage()
  wnd.content:EnableSelectParent(false)
  wnd.content:UseChildStyle(true)
  wnd.content.childStyle:SetFontSize(FONT_SIZE.MIDDLE)
  wnd.content.childStyleSub:SetFontSize(FONT_SIZE.SMALL)
  wnd.content.childStyle:SetColorByKey("default")
  return wnd
end
local CreateFilterCombobox = function(id, parent)
  local filter = {
    {
      GetCommonText("show_all"),
      AF_ALL
    },
    {
      GetCommonText("accomplishment_filter"),
      AF_COMPLETE
    },
    {
      GetCommonText("not_accomplishment"),
      AF_UNCOMPLETE
    }
  }
  local datas = {}
  for i, v in ipairs(filter) do
    local data = {
      text = filter[i][1],
      value = filter[i][2]
    }
    table.insert(datas, data)
  end
  local filterCombobox = W_CTRL.CreateComboBox(id, parent)
  filterCombobox:SetWidth(180)
  filterCombobox:AppendItems(datas)
  return filterCombobox
end
local function CreateSubCategoryInfoSection(id, parent)
  local colletionPath = "ui/achievement/collection.dds"
  local subCategoryFrame = parent:CreateChildWidget("emptywidget", id, 0, true)
  subCategoryFrame:AddAnchor("TOPLEFT", parent, 0, 0)
  local bg = subCategoryFrame:CreateDrawable(colletionPath, "title_bg", "background")
  bg:AddAnchor("TOPLEFT", subCategoryFrame, 0, 0)
  subCategoryFrame:SetExtent(bg:GetExtent())
  local leftInset = 8
  local title = subCategoryFrame:CreateChildWidget("textbox", "title", 0, false)
  title:SetExtent(378, FONT_SIZE.LARGE)
  title:AddAnchor("TOPLEFT", subCategoryFrame, leftInset, 6)
  title.style:SetAlign(ALIGN_LEFT)
  title.style:SetFontSize(FONT_SIZE.LARGE)
  title.style:SetEllipsis(true)
  title.style:SetColorByKey("middle_title")
  local desc = subCategoryFrame:CreateChildWidget("label", "desc", 0, false)
  desc:SetExtent(title:GetWidth(), FONT_SIZE.MIDDLE)
  desc:AddAnchor("TOPLEFT", title, "BOTTOMLEFT", 0, 7)
  desc.style:SetAlign(ALIGN_LEFT)
  desc.style:SetEllipsis(true)
  desc.style:SetColorByKey("default")
  local function OnEnter(self)
    local text = self:GetText()
    if desc:GetWidth() > self.style:GetTextWidth(text) then
      return
    end
    SetTooltip(text, self)
  end
  desc:SetHandler("OnEnter", OnEnter)
  local status = subCategoryFrame:CreateChildWidget("label", "status", 0, false)
  status:Show(false)
  status:SetExtent(50, FONT_SIZE.MIDDLE)
  status:SetAutoResize(true)
  status:AddAnchor("TOPLEFT", desc, "BOTTOMLEFT", 0, 5)
  status.style:SetColorByKey("blue")
  local progressBar = W_BAR.CreateStatusBar("progressBar", subCategoryFrame)
  progressBar:Show(false)
  progressBar:SetBarTextureCoords(gaugePath, "gauge_list", gaugePath, "gauge_bg")
  progressBar:SetExtent(subCategoryFrame:GetWidth() - leftInset * 2, 9)
  progressBar:AddAnchor("TOPLEFT", desc, "BOTTOMLEFT", 0, 9)
  local rightReward = CreateIconButton("rightReward", subCategoryFrame)
  rightReward:Show(false)
  rightReward:AddAnchor("TOPRIGHT", subCategoryFrame, -leftInset, 4)
  local rewardInset = 4
  local leftReward = CreateIconButton("leftReward", subCategoryFrame)
  leftReward:Show(false)
  leftReward:AddAnchor("TOPRIGHT", rightReward, "TOPLEFT", -rewardInset, 0)
  local heirIcon = subCategoryFrame:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "successor", "artwork")
  heirIcon:SetVisible(false)
  heirIcon:AddAnchor("LEFT", title, 0, 0)
  function subCategoryFrame:SetInfo(subCategoryType)
    local info = X2Achievement:GetSubcategoryInfo(subCategoryType)
    if info == nil then
      return
    end
    local completed = info.completedCount
    local total = info.totalCount
    local commonWidth = self:GetWidth() - leftInset * 2
    title:SetWidth(commonWidth)
    desc:SetWidth(commonWidth)
    title:SetText(string.format("%s %s(%s)", info.name, F_COLOR.GetColor("blue", true), F_TEXT.SetSlashFormat(completed, total)))
    desc:SetText(info.desc)
    if info.isHeirLevelCategory then
      heirIcon:SetVisible(true)
      title:SetInset(heirIcon:GetWidth() + 2, 0, 0, 0)
    else
      heirIcon:SetVisible(false)
      title:SetInset(0, 0, 0, 0)
    end
    local rewardAchievementType = info.rewardAchievementType
    if rewardAchievementType == nil then
      return
    end
    local achievementInfo = X2Achievement:GetAchievementInfo(rewardAchievementType)
    if achievementInfo == nil then
      return
    end
    local rewardInfo = achievementInfo.reward
    if rewardInfo ~= nil then
      local itemRewardInfo = rewardInfo.item
      local appellationInfo = rewardInfo.appellation
      commonWidth = commonWidth - rightReward:GetWidth() - leftInset
      if itemRewardInfo ~= nil and appellationInfo ~= nil then
        SetReward(rightReward, "item", itemRewardInfo)
        SetReward(leftReward, "appellation", appellationInfo)
        commonWidth = commonWidth - leftReward:GetWidth() - rewardInset
      elseif itemRewardInfo ~= nil or appellationInfo ~= nil then
        local infoType = itemRewardInfo ~= nil and "item" or "appellation"
        local taregetInfo = itemRewardInfo ~= nil and itemRewardInfo or appellationInfo
        SetReward(rightReward, infoType, taregetInfo)
      end
      title:SetWidth(commonWidth)
      desc:SetWidth(commonWidth)
    else
      leftReward:Show(false)
      rightReward:Show(false)
    end
    if achievementInfo.completeDate then
      progressBar:Show(false)
      status:Show(true)
      local dateStr = GetDateStringWithComplete(achievementInfo)
      status:SetText(dateStr)
      bg:SetTextureInfo("title_bg_finish")
    else
      progressBar:Show(true)
      status:Show(false)
      progressBar:SetMinMaxValues(0, total)
      progressBar:SetValue(completed)
      bg:SetTextureInfo("title_bg")
    end
    currentInfo:SetValue("subCategoryTotal", total)
    currentInfo:SetValue("subCategoryComplete", completed)
  end
  function subCategoryFrame:Update(newInfo, tracingUpdate)
    if not subCategoryFrame:IsVisible() then
      return
    end
    if tracingUpdate then
      return
    end
    local subCategoryType = currentInfo:GetValue("subCategoryType")
    if subCategoryType == nil then
      return
    end
    self:SetInfo(subCategoryType)
  end
  return subCategoryFrame
end
local function CreateSummaryInfoSection(id, parent)
  local frame = parent:CreateChildWidget("emptywidget", id, 0, true)
  frame:SetExtent(parent:GetWidth(), 250)
  local bg = frame:CreateDrawable(TEXTURE_PATH.ACHIEVEMENT_MAIN_PAGE, "logo", "background")
  bg:AddAnchor("CENTER", frame, 0, 0)
  local title = frame:CreateChildWidget("label", "title", 0, true)
  title:SetExtent(frame:GetWidth(), FONT_SIZE.LARGE)
  title:SetText(GetUIText(COMMON_TEXT, "accomplishment_status"))
  title:AddAnchor("TOPLEFT", frame, 0, 0)
  title.style:SetFontSize(FONT_SIZE.LARGE)
  title.style:SetColorByKey("middle_title")
  local function CreateItem(index, isAll)
    local itemFrame = frame:CreateChildWidget("emptywidget", "progressBar", index, true)
    itemFrame:Show(true)
    local title = itemFrame:CreateChildWidget("label", "title", index, true)
    title:AddAnchor("TOPLEFT", itemFrame, 0, 0)
    title.style:SetAlign(ALIGN_LEFT)
    title.style:SetColorByKey("default")
    local progressBar = W_BAR.CreateStatusBar("progressBar", itemFrame)
    if isAll then
      itemFrame:SetExtent(frame:GetWidth(), 31)
      title:SetExtent(frame:GetWidth(), FONT_SIZE.LARGE)
      title.style:SetFontSize(FONT_SIZE.LARGE)
      progressBar:SetBarTextureCoords(TEXTURE_PATH.ACHIEVEMENT_MAIN_PAGE, "gauge_orange", gaugePath, "gauge_bg")
    else
      itemFrame:SetExtent(frame:GetWidth() / 2 - 5, 26)
      title:SetExtent(itemFrame:GetWidth(), FONT_SIZE.MIDDLE)
      progressBar:SetBarTextureCoords(TEXTURE_PATH.ACHIEVEMENT_MAIN_PAGE, "gauge_blue", gaugePath, "gauge_bg")
    end
    progressBar:SetWidth(itemFrame:GetWidth() - 5)
    progressBar:AddAnchor("BOTTOMLEFT", itemFrame, 0, 0)
    function itemFrame:SetInfo(kind, info)
      local complete, total = X2Achievement:GetCategoryCount(kind, info.category, 0, AF_ALL)
      progressBar:SetMinMaxValues(0, total)
      progressBar:SetValue(complete)
      title:SetText(string.format("%s (%s)", info.name, F_TEXT.SetSlashFormat(complete, total)))
    end
    return itemFrame
  end
  local totalProgress = CreateItem(0, true)
  totalProgress:AddAnchor("TOPLEFT", title, "BOTTOMLEFT", 0, MARGIN.WINDOW_SIDE / 2)
  local offset = 10
  local function GetProgressBar(index)
    if frame.progressBar[index] ~= nil then
      return frame.progressBar[index]
    end
    local progressBar = CreateItem(index, false)
    if index % 2 ~= 0 then
      progressBar:AddAnchor("TOPLEFT", totalProgress, "BOTTOMLEFT", 0, offset)
    else
      progressBar:AddAnchor("TOPRIGHT", totalProgress, "BOTTOMRIGHT", 0, offset)
    end
    if index % 2 == 0 then
      offset = offset + progressBar:GetHeight() + 10
    end
    return progressBar
  end
  function frame:SetSummary(kind)
    local totalInfo = {
      name = GetUIText(COMMON_TEXT, "all"),
      category = 0
    }
    totalProgress:SetInfo(kind, totalInfo)
    local info = GetAchievementMainCategories(kind)
    for i = 1, #info do
      local progressBar = GetProgressBar(i)
      progressBar:SetInfo(kind, info[i])
    end
  end
  function frame:Update(newInfo, tracingUpdate)
    if not frame:IsVisible() then
      return
    end
    if tracingUpdate then
      return
    end
    local kind = currentInfo:GetKind()
    if kind == nil then
      return
    end
    frame:SetSummary(kind)
  end
  return frame
end
local buffSize = F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_24)
local function SetViewOfMainAchievementItem(frame)
  local margin = 10
  local icon = CreateRankIconSet("icon", frame)
  icon:AddAnchor("TOPLEFT", frame, margin, margin)
  local inset = 6
  local gaugeWidth = 412
  local progressBar = W_BAR.CreateStatusBar("progressBar", frame)
  progressBar:SetExtent(gaugeWidth, 7)
  progressBar:SetBarTextureCoords(TEXTURE_PATH.ACHIEVEMENT_GAUGE, "gauge_list", TEXTURE_PATH.ACHIEVEMENT_GAUGE, "gauge_bg")
  progressBar:AddAnchor("BOTTOMLEFT", icon, "BOTTOMRIGHT", inset, 0)
  progressBar:AddAnchor("RIGHT", frame, -margin, 0)
  progressBar:EnablePick(false)
  progressBar.statusBar:EnablePick(false)
  frame.progressBar = progressBar
  local status = frame:CreateChildWidget("label", "status", 0, true)
  status:Show(false)
  status:SetExtent(50, FONT_SIZE.MIDDLE)
  status:SetAutoResize(true)
  status:AddAnchor("BOTTOMLEFT", icon, "BOTTOMRIGHT", inset, 0)
  status:AddAnchor("RIGHT", frame, inset, 0)
  status.style:SetFontSize(FONT_SIZE.SMALL)
  status.style:SetAlign(ALIGN_LEFT)
  status:EnablePick(false)
  status.style:SetColorByKey("blue")
  frame.status = status
  local rightReward = CreateIconButton("rightReward", frame)
  rightReward:SetExtent(buffSize, buffSize)
  rightReward:AddAnchor("BOTTOMRIGHT", progressBar, "TOPRIGHT", 0, -3)
  frame.rightReward = rightReward
  inset = -2
  local leftReward = CreateIconButton("leftReward", frame)
  leftReward:SetExtent(rightReward:GetWidth(), rightReward:GetHeight())
  leftReward:AddAnchor("RIGHT", rightReward, "LEFT", inset, 0)
  frame.leftReward = leftReward
  local checkbox = CreateCheckButton("checkbox", frame)
  checkbox:AddAnchor("TOPRIGHT", frame, -7, 7)
  frame.checkbox = checkbox
  local desc = frame:CreateChildWidget("label", "desc", 0, true)
  desc.style:SetEllipsis(true)
  desc:SetExtent(50, FONT_SIZE.MIDDLE)
  desc:AddAnchor("BOTTOMLEFT", progressBar, "TOPLEFT", 0, -8)
  desc:AddAnchor("RIGHT", leftReward, "LEFT", -7, 0)
  desc.style:SetAlign(ALIGN_LEFT)
  desc.style:SetColorByKey("default")
  frame.desc = desc
  local title = frame:CreateChildWidget("label", "title", 0, true)
  title.style:SetEllipsis(true)
  title:SetExtent(50, FONT_SIZE.LARGE)
  title.style:SetAlign(ALIGN_LEFT)
  title.style:SetFontSize(FONT_SIZE.LARGE)
  title:AddAnchor("BOTTOMLEFT", frame.desc, "TOPLEFT", 0, -5)
  title:AddAnchor("BOTTOMRIGHT", frame.desc, "TOPRIGHT", 0, -5)
  title.style:SetColorByKey("middle_title")
  frame.title = title
  local openStateIcon = frame:CreateDrawable(TEXTURE_PATH.ACHIEVEMENT, "icon_plus", "artwork")
  openStateIcon:AddAnchor("TOP", frame, 0, 10)
  frame.openStateIcon = openStateIcon
end
local function CreateAchievementItem(subItem, index)
  SetViewOfMainAchievementItem(subItem)
  local OnEnter = function(target)
    local str = target:GetText()
    local strWidth = target.style:GetTextWidth(str)
    if strWidth > target:GetWidth() then
      SetTooltip(target:GetText(), target)
    end
  end
  subItem.title:SetHandler("OnEnter", OnEnter)
  subItem.desc:SetHandler("OnEnter", OnEnter)
  local function OnEnterMainItem(self)
    SetTooltip(subItem.tooltip, self)
  end
  subItem:SetHandler("OnEnter", OnEnterMainItem)
  local function OnEnterCheckBox(self)
    local kind = currentInfo:GetKind()
    if kind == nil then
      return
    end
    local complete, total = X2Achievement:GetCategoryCount(kind, 0, 0, AF_TRACING)
    if complete == total and not self:GetChecked() then
      SetTooltip(GetCommonText("can_not_trace_achievement_tooltip", tostring(total)), self)
    else
      SetTooltip(GetCommonText("trace_achievement_tooltip"), self)
    end
  end
  subItem.checkbox:SetHandler("OnEnter", OnEnterCheckBox)
  function subItem.checkbox:CheckBtnCheckChagnedProc(checked)
    local kind = currentInfo:GetKind()
    local aType = subItem.achievementType
    if kind == nil or aType == nil then
      return
    end
    local tracing = X2Achievement:IsTracingAchievement(kind, aType)
    if checked and not tracing then
      local result = X2Achievement:AddTracingAchievement(kind, aType)
      if not result then
        self:SetChecked(false, false)
      end
    elseif not checked and tracing then
      X2Achievement:RemoveTracingAchievement(kind, aType)
    end
  end
  function subItem.checkbox:OnClick()
  end
  subItem.checkbox:SetHandler("OnClick", subItem.checkbox.OnClick)
  function subItem:SetInfo(info, isOpen, frameBg, subListSize)
    if info == nil then
      self.achievementType = nil
      return
    end
    if subListSize <= 0 then
      subItem.openStateIcon:SetVisible(false)
    else
      subItem.openStateIcon:SetVisible(true)
      if isOpen then
        subItem.openStateIcon:SetTextureInfo("icon_minus")
      else
        subItem.openStateIcon:SetTextureInfo("icon_plus")
      end
    end
    subItem.checkbox:Show(false)
    subItem.progressBar:Show(false)
    subItem.leftReward:Show(false)
    subItem.rightReward:Show(false)
    subItem.icon:SetIconDirectly({
      icon = info.iconPath
    })
    subItem.desc:SetText(info.summary or unknownString)
    subItem.tooltip = info.desc
    if info.totalSubCount then
      subItem.title:SetText(string.format("%s (%s)", info.name, F_TEXT.SetSlashFormat(info.completeSubCount, info.totalSubCount)))
    else
      subItem.title:SetText(info.name)
    end
    frameBg:SetTexture(TEXTURE_PATH.ACHIEVEMENT)
    if info.complete then
      if frameBg ~= nil then
        frameBg:SetTextureInfo(complete_bg)
      end
      subItem.openStateIcon:AddAnchor("RIGHT", subItem, -10, 0)
      subItem.status:Show(true)
      local dateStr = GetDateStringWithComplete(info)
      subItem.status:SetText(dateStr)
    else
      if frameBg ~= nil then
        frameBg:SetTextureInfo(default_bg)
      end
      subItem.title:SetText(string.format("%s (%d/%d)", info.name, info.current, info.completeNum))
      subItem.openStateIcon:AddAnchor("RIGHT", subItem.checkbox, "LEFT", -4, 0)
      subItem.status:Show(false)
      subItem.checkbox:Show(true)
      subItem.checkbox:SetChecked(info.tracing, false)
      subItem.progressBar:Show(true)
      subItem.progressBar:SetMinMaxValues(0, info.completeNum)
      subItem.progressBar:SetValue(info.current)
      local rewardInfo = info.reward
      if rewardInfo ~= nil then
        local itemRewardInfo = rewardInfo.item
        local appellationInfo = rewardInfo.appellation
        if itemRewardInfo ~= nil and appellationInfo ~= nil then
          SetReward(subItem.rightReward, "item", itemRewardInfo)
          SetReward(subItem.leftReward, "appellation", appellationInfo)
        elseif itemRewardInfo ~= nil or appellationInfo ~= nil then
          local infoType = itemRewardInfo ~= nil and "item" or "appellation"
          local info = itemRewardInfo ~= nil and itemRewardInfo or appellationInfo
          SetReward(subItem.rightReward, infoType, info)
        end
      end
    end
    self.achievementType = info.type
  end
end
local function SetViewOfSubAchievementItem(frame)
  local margin = 10
  local status = frame:CreateChildWidget("label", "status", 0, true)
  status:Show(false)
  status:SetExtent(47, FONT_SIZE.MIDDLE)
  status:AddAnchor("RIGHT", frame, -margin, 0)
  status.style:SetAlign(ALIGN_RIGHT)
  status.style:SetFontSize(FONT_SIZE.SMALL)
  status.style:SetColorByKey("blue")
  frame.status = status
  local checkIcon = frame:CreateDrawable(TEXTURE_PATH.DEFAULT, "common_v", "artwork")
  checkIcon:AddAnchor("RIGHT", status, "LEFT", -3, 0)
  checkIcon:AddAnchor("TOP", frame, 0, 6)
  checkIcon:SetTextureColor("green")
  frame.checkIcon = checkIcon
  local rightReward = CreateIconButton("rightReward", frame)
  rightReward:SetExtent(buffSize, buffSize)
  rightReward:AddAnchor("RIGHT", frame, -10, -2)
  frame.rightReward = rightReward
  local inset = -2
  local leftReward = CreateIconButton("leftReward", frame)
  leftReward:SetExtent(rightReward:GetWidth(), rightReward:GetHeight())
  leftReward:AddAnchor("RIGHT", rightReward, "LEFT", inset, 0)
  frame.leftReward = leftReward
  local title = frame:CreateChildWidget("label", "title", 0, true)
  title.style:SetEllipsis(true)
  title:SetExtent(50, FONT_SIZE.MIDDLE)
  title.style:SetAlign(ALIGN_LEFT)
  title:AddAnchor("LEFT", frame, margin, 0)
  title.style:SetColorByKey("default")
  frame.title = title
  local line = CreateLine(frame, "TYPE8")
  line:AddAnchor("TOP", frame, 0, -1)
  line:SetWidth(frame:GetWidth() - 25)
  frame.line = line
end
local function CreateSubAchievementItem(subItem)
  SetViewOfSubAchievementItem(subItem)
  function subItem:SetInfo(info, subItemInfo)
    if info == nil or subItemInfo == nil then
      return
    end
    subItem.checkIcon:Show(false)
    subItem.status:Show(false)
    subItem.leftReward:Show(false)
    subItem.rightReward:Show(false)
    if info.complete then
      subItem.checkIcon:Show(true)
      subItem.status:Show(true)
      subItem.status:SetText(GetDateString(info.completeDate))
      local titleWidth = subItem:GetWidth() - (26 + subItem.checkIcon:GetWidth() + subItem.status:GetWidth())
      local titleStr = string.format("[%s] %s", GetCommonText("complete"), info.summary)
      subItem.title:SetWidth(titleWidth)
      subItem.title:SetText(titleStr)
      subItem.title.style:SetColorByKey("blue")
    else
      subItem.status:Show(false)
      subItem.checkIcon:Show(false)
      local titleWidth = subItem:GetWidth() - (28 + subItem.leftReward:GetWidth() + 2 + subItem.rightReward:GetWidth())
      local titleStr = info.summary
      local fontColorKey = "gray"
      if info.canProgress then
        titleStr = string.format("[%s] %s (%s)", GetUIText(QUEST_STATUS_TEXT, "progress"), info.summary, F_TEXT.SetSlashFormat(info.current, info.completeNum))
        fontColor = "default"
      end
      subItem.title:SetWidth(titleWidth)
      subItem.title:SetText(titleStr)
      subItem.title.style:SetColorByKey(fontColor)
      local rewardInfo = info.reward
      if rewardInfo ~= nil then
        local itemRewardInfo = rewardInfo.item
        local appellationInfo = rewardInfo.appellation
        if itemRewardInfo ~= nil and appellationInfo ~= nil then
          SetReward(subItem.rightReward, "item", itemRewardInfo)
          SetReward(subItem.leftReward, "appellation", appellationInfo)
        elseif itemRewardInfo ~= nil or appellationInfo ~= nil then
          local infoType = itemRewardInfo ~= nil and "item" or "appellation"
          local info = itemRewardInfo ~= nil and itemRewardInfo or appellationInfo
          SetReward(subItem.rightReward, infoType, info)
        end
      end
    end
    if info.isParentComplete then
      subItem.line:SetTextureColor("deepbrown_15")
    else
      subItem.line:SetTextureColor("deepblue_15")
    end
  end
end
local function mainLayoutFunc(subItem, index)
  CreateAchievementItem(subItem, index)
end
local mainDataFunc = function(subItem, mainKey, isOpen, frameBg, subListSize)
  if mainKey == nil then
    return
  end
  local info = X2Achievement:GetAchievementInfo(mainKey)
  subItem:SetInfo(info, isOpen, frameBg, subListSize)
end
local function subLayoutFunc(subItem, index)
  CreateSubAchievementItem(subItem)
end
local subDataFunc = function(subItem, subItemInfo, isClicked)
  if subItemInfo == nil or subItemInfo.key == nil then
    return
  end
  local info = X2Achievement:GetAchievementInfo(subItemInfo.key)
  subItem:SetInfo(info, subItemInfo)
end
local function GetSubItemList(mainKey)
  local filter = AF_ALL
  local state = currentInfo:GetValue("state")
  if state ~= nil and state == STATE.COMPLETE then
    filter = AF_COMPLETE
  end
  local subList = X2Achievement:GetAchievementSubList(mainKey, filter)
  if subList == nil then
    return nil
  end
  return subList
end
local function CreateAchievementList(id, parent)
  local frame = parent:CreateChildWidget("emptywidget", id, 0, true)
  frame:SetExtent(parent:GetWidth(), mainItemHeight)
  local listTitle = frame:CreateChildWidget("label", "listTitle", 0, true)
  listTitle:SetExtent(frame:GetWidth(), FONT_SIZE.LARGE)
  listTitle:AddAnchor("TOPLEFT", frame, 0, 0)
  listTitle.style:SetFontSize(FONT_SIZE.LARGE)
  listTitle.style:SetAlign(ALIGN_LEFT)
  listTitle.style:SetColorByKey("middle_title")
  local filterCombobox = CreateFilterCombobox("filterCombobox", frame)
  filterCombobox:AddAnchor("TOPRIGHT", frame, -25, -7)
  frame.filterCombobox = filterCombobox
  local inset = listTitle:GetHeight() + 10
  local dynamicList = CreateDynamicListWindow(frame, "dynamicList")
  dynamicList:SetExtent(frame:GetWidth() - dynamicList.scroll:GetWidth() - 3, frame:GetHeight() - inset)
  dynamicList:AddAnchor("TOPLEFT", frame, 0, inset)
  frame.dynamicList = dynamicList
  dynamicList:InitFunc(mainLayoutFunc, mainDataFunc, subLayoutFunc, subDataFunc)
  dynamicList:InitBgType(UOT_NINE_PART_DRAWABLE)
  dynamicList:UseOverTexture("achievement")
  dynamicList.scroll:RemoveAllAnchors()
  dynamicList.scroll:AddAnchor("TOPRIGHT", dynamicList, 0, 0)
  dynamicList.scroll:AddAnchor("BOTTOMRIGHT", dynamicList, 0, 0)
  local emptyListText = frame:CreateChildWidget("textbox", "emptyListText", 0, true)
  emptyListText:Show(false)
  emptyListText:SetExtent(dynamicList:GetWidth(), FONT_SIZE.MIDDLE)
  emptyListText:SetAutoResize(true)
  emptyListText.style:SetFontSize(FONT_SIZE.LARGE)
  emptyListText:AddAnchor("CENTER", dynamicList, 0, 0)
  emptyListText.style:SetColorByKey("default")
  local emptyString = {
    [AF_COMPLETE] = GetUIText(COMMON_TEXT, "no_accomplished_achievement"),
    [AF_TRACING] = GetUIText(COMMON_TEXT, "no_tracing_achievement", tostring(MAX_TRACING_ACHIEVEMENT)),
    [AF_UNCOMPLETE] = {
      allComplete = GetUIText(COMMON_TEXT, "no_uncompleted_achievement"),
      notYetAllComplete = GetUIText(COMMON_TEXT, "have_hidden_achivement")
    }
  }
  local function GetEmptyString(filter, subFilter)
    if type(emptyString[filter]) == "table" then
      return emptyString[filter][subFilter] or ""
    else
      return emptyString[filter] or ""
    end
  end
  function frame:SetEmptyListString(count, filter)
    if count > 0 then
      emptyListText:Show(false)
      return
    end
    emptyListText:Show(true)
    local str = ""
    if filter == AF_UNCOMPLETE then
      local total = currentInfo:GetValue("subCategoryTotal") or 0
      local completed = currentInfo:GetValue("subCategoryComplete") or 0
      if total == completed then
        str = GetEmptyString(filter, "allComplete")
      else
        str = GetEmptyString(filter, "notYetAllComplete")
      end
    else
      str = GetEmptyString(filter)
    end
    emptyListText:SetText(str)
  end
  return frame
end
local function CreateAchievementListPage(id, parent)
  local frame = parent:CreateChildWidget("emptywidget", id, 0, true)
  frame:SetExtent(parent:GetWidth(), parent:GetHeight())
  local subCategoryFrame = CreateSubCategoryInfoSection("subCategoryFrame", frame)
  frame.subCategoryFrame = subCategoryFrame
  local summaryFrame = CreateSummaryInfoSection("summaryFrame", frame)
  summaryFrame:AddAnchor("TOPLEFT", frame, 0, 0)
  frame.summaryFrame = summaryFrame
  local achievementList = CreateAchievementList("achievementList", frame)
  local filterCombobox = achievementList.filterCombobox
  function frame:SelectAchievement(kind, categoryText, subCategoryType, info)
    filterCombobox:Select(AF_ALL)
    frame:SetPage(kind, categoryText, subCategoryType)
    local mainKey = info.highRankAchievementType and info.highRankAchievementType or info.type
    local index = achievementList.dynamicList:FindIndex(mainKey)
    achievementList.dynamicList:MoveIndexScroll(index, 0, true)
  end
  local prevViewRowCount = 0
  local prevlimitViewCount = 0
  function frame:GetFilterIndex()
    local state = currentInfo:GetValue("state")
    if state == STATE.SUMMARY then
      return AF_COMPLETE
    elseif state == STATE.COMPLETE then
      return AF_COMPLETE
    elseif state == STATE.TRACING then
      return AF_TRACING
    elseif state == STATE.DEFAULT then
      local info = filterCombobox:GetSelectedInfo()
      if info == nil then
        return
      end
      return info.value
    end
    return nil
  end
  function frame:SetPage(kind, categoryText, subCategoryType)
    if not SameCategory(categoryText, subCategoryType) then
      local viewRowCount = 0
      local limitViewCount = 30
      local pageControlVisible = false
      achievementList.listTitle:SetText(GetUIText(COMMON_TEXT, "craft_order_tab_search"))
      achievementList.listTitle.style:SetAlign(ALIGN_LEFT)
      achievementList.listTitle:SetInset(8, 0, 0, 0)
      summaryFrame:Show(false)
      if subCategoryType == 0 then
        subCategoryFrame:Show(false)
        filterCombobox:Show(false)
        achievementList:RemoveAllAnchors()
        if categoryText == ACHIEVEMENT_PAGE.SUMMARY.text then
          currentInfo:SetValue("state", STATE.SUMMARY)
          viewRowCount = 3
          achievementList:AddAnchor("BOTTOMLEFT", frame, 0, 0)
          limitViewCount = 10
          summaryFrame:Show(true)
          summaryFrame:SetSummary(kind)
          achievementList.listTitle:SetText(GetUIText(COMMON_TEXT, "recently_accomplished_achievement"))
          achievementList.listTitle:SetInset(0, 0, 0, 0)
        elseif categoryText == ACHIEVEMENT_PAGE.COMPLETE.text then
          currentInfo:SetValue("state", STATE.COMPLETE)
          viewRowCount = 6
          pageControlVisible = true
          achievementList:AddAnchor("TOPLEFT", frame, 0, 0)
        elseif categoryText == ACHIEVEMENT_PAGE.TRACING.text then
          currentInfo:SetValue("state", STATE.TRACING)
          viewRowCount = 6
          limitViewCount = 6
          achievementList:AddAnchor("TOPLEFT", frame, 0, 0)
        end
      else
        currentInfo:SetValue("state", STATE.DEFAULT)
        subCategoryFrame:Show(true)
        subCategoryFrame:SetInfo(subCategoryType)
        filterCombobox:Show(true)
        achievementList:RemoveAllAnchors()
        achievementList:AddAnchor("TOPLEFT", subCategoryFrame, "BOTTOMLEFT", 0, 15)
        viewRowCount = 5
        pageControlVisible = true
      end
      if viewRowCount == 0 then
        return
      end
      if viewRowCount ~= prevViewRowCount then
        local viewHeight = mainItemHeight * viewRowCount
        achievementList.dynamicList:SetExtent(frame:GetWidth(), viewHeight)
        achievementList.dynamicList:InitHeight(viewHeight, mainItemHeight, subItemHeight)
        achievementList.dynamicList:InitCreateWidgetPool()
      end
      prevViewRowCount = viewRowCount
      prevlimitViewCount = limitViewCount
      achievementList.dynamicList.pageControl:Show(pageControlVisible)
      local _, height = F_LAYOUT.GetExtentWidgets(achievementList.listTitle, achievementList.dynamicList)
      achievementList:SetHeight(height)
    end
    currentInfo:SetValue("categoryText", categoryText)
    currentInfo:SetValue("subCategoryType", subCategoryType)
    achievementList.dynamicList:ClearPageData()
    local filter = frame:GetFilterIndex()
    local list = GetMainList(kind, subCategoryType, filter)
    local dataCount = list == nil and 0 or #list
    dataCount = achievementList.dynamicList.pageControl:IsVisible() == false and dataCount > prevlimitViewCount and prevlimitViewCount or dataCount
    achievementList.dynamicList.pageControl:SetPageByItemCount(dataCount, prevlimitViewCount)
    for i = 1, dataCount do
      local mainKey = list[i]
      local subItemList = GetSubItemList(mainKey)
      achievementList.dynamicList:PushPageData(mainKey, subItemList)
    end
    achievementList.dynamicList.pageControl:MoveFirstPage()
    achievementList:SetEmptyListString(dataCount, filter)
  end
  function filterCombobox:SelectedProc()
    local kind = currentInfo:GetKind()
    local prevCategoryText = currentInfo:GetValue("categoryText")
    local prevSubCategoryType = currentInfo:GetValue("subCategoryType")
    frame:SetPage(kind, prevCategoryText, prevSubCategoryType)
  end
  function frame:RefreshView()
    local kind = currentInfo:GetKind()
    local prevCategoryText = currentInfo:GetValue("categoryText")
    local prevSubCategoryType = currentInfo:GetValue("subCategoryType")
    if kind == nil or prevCategoryText == nil or prevSubCategoryType == nil then
      return
    end
    achievementList.dynamicList:SaveCurrentPage()
    frame:SetPage(kind, prevCategoryText, prevSubCategoryType)
    achievementList.dynamicList:LoadCurrentPage()
  end
  function frame:Update(newInfo, tracingUpdate)
    subCategoryFrame:Update(newInfo, tracingUpdate)
    summaryFrame:Update(newInfo, tracingUpdate)
    local state = currentInfo:GetValue("state")
    if state == STATE.DEFAULT and not SameCategory(newInfo.subCategoryName, newInfo.subCategoryType) then
      return
    end
    local mainKey = newInfo.highRankAchievementType and newInfo.highRankAchievementType or newInfo.type
    local subItemList = GetSubItemList(mainKey)
    local findedMainIndex = achievementList.dynamicList:FindIndex(mainKey)
    if findedMainIndex == nil then
      local kind = currentInfo:GetKind()
      local prevSubCategoryType = currentInfo:GetValue("subCategoryType")
      local filter = frame:GetFilterIndex()
      local list = GetMainList(kind, prevSubCategoryType, filter)
      local insertIndex = -1
      for i = 1, #list do
        if list[i] == mainKey then
          insertIndex = i
          break
        end
      end
      if insertIndex ~= -1 then
        achievementList.dynamicList:InsertPageData(insertIndex, mainKey, subItemList, true)
      end
    else
      achievementList.dynamicList:UpdateDatas(mainKey, subItemList)
    end
  end
  return frame
end
local function CreateAchievemntContent(id, parent)
  local width = parent:GetWidth() * layousSet.assignmentInnerRatioRight - MARGIN.WINDOW_SIDE
  local height = parent:GetHeight() - MARGIN.WINDOW_SIDE
  local frame = parent:CreateChildWidget("emptywidget", id, 0, true)
  frame:SetExtent(width, height)
  local listPage = CreateAchievementListPage("listPage", frame)
  listPage:AddAnchor("TOPLEFT", frame, 0, 0)
  function frame:SelectAchievement(kind, categoryText, value, info)
    listPage:SelectAchievement(kind, categoryText, value, info)
  end
  function frame:SetPage(kind, categoryText, value)
    listPage:SetPage(kind, categoryText, value)
  end
  function frame:Update(newInfo, tracingUpdate)
    listPage:Update(newInfo, tracingUpdate)
  end
  function frame:RefreshView()
    listPage:RefreshView()
  end
  return frame
end
function CreateAchievementTabPage(wnd, kind)
  local categoryList = CreateCategoryListbox("categoryList", wnd)
  categoryList:AddAnchor("TOPLEFT", wnd, 0, MARGIN.WINDOW_SIDE)
  categoryList:SetItemTrees(GetAchievementCategoryInfos(kind))
  wnd.categoryList = categoryList
  local content = CreateAchievemntContent("content", wnd)
  content:AddAnchor("TOPLEFT", categoryList, "TOPRIGHT", MARGIN.WINDOW_SIDE, 0)
  local function UpdateCategoryCount()
    local infos = categoryList.content:GetViewItemsInfo()
    for i = 1, #infos do
      local value = infos[i].value
      local text = infos[i].text
      local childCount = infos[i].childCount
      local completedCount, totalCount = 0, 0
      local datas = {
        indexing = infos[i].indexing,
        subtext = ""
      }
      if value == 0 and text ~= nil then
        if text == ACHIEVEMENT_PAGE.COMPLETE.text then
          completedCount, totalCount = X2Achievement:GetCategoryCount(kind, 0, 0, AF_COMPLETE)
        elseif text == ACHIEVEMENT_PAGE.TRACING.text then
          completedCount, totalCount = X2Achievement:GetCategoryCount(kind, 0, 0, AF_TRACING)
        end
      elseif childCount == 0 then
        completedCount, totalCount = X2Achievement:GetCategoryCount(kind, 0, value, AF_ALL)
      else
        local amendedValue = value - GetAchievementPrefixValue()
        if amendedValue > 0 then
          completedCount, totalCount = X2Achievement:GetCategoryCount(kind, amendedValue, 0, AF_ALL)
        end
      end
      datas.subtext = string.format("(%s)", F_TEXT.SetSlashFormat(completedCount, totalCount))
      categoryList.content:UpdateItem(datas)
    end
  end
  UpdateCategoryCount()
  function categoryList:OnSelChanged()
    local value = self.content:GetSelectedValue()
    local text = self.content:GetSelectedText()
    if SameCategory(text, value) then
      return
    end
    content:SetPage(kind, text, value)
  end
  InitCurrentAchievementKind(kind)
  local GetInitInfo = function(kind)
    if kind == EAK_ACHIEVEMENT or kind == EAK_ARCHERAGE then
      return ACHIEVEMENT_PAGE.SUMMARY
    else
      return ACHIEVEMENT_PAGE.COMPLETE
    end
  end
  local info = GetInitInfo(kind)
  categoryList.content:SelectWithText(info.text, true)
  function categoryList:ProcOnListboxToggled()
    UpdateCategoryCount()
  end
  function categoryList:ProcSliderChanged()
    UpdateCategoryCount()
  end
  function wnd:SelectAchievement(info)
    categoryList.content:SelectWithValue(info.subCategoryType, false)
    UpdateCategoryCount()
    local value = self.categoryList.content:GetSelectedValue()
    local text = self.categoryList.content:GetSelectedText()
    content:SelectAchievement(info.achievementKind, text, value, info)
  end
  function wnd:OnTabSelected(selected)
    UpdateCurrentAchievementKind(selected)
    UpdateCategoryCount()
    content:RefreshView()
  end
  local events = {
    ACHIEVEMENT_UPDATE = function(status, newAchievementType)
      if not wnd:IsVisible() then
        return
      end
      UpdateCategoryCount()
      local newInfo = X2Achievement:GetAchievementInfo(newAchievementType)
      if newInfo == nil then
        return
      end
      if kind ~= newInfo.achievementKind then
        return
      end
      content:Update(newInfo, status ~= "update")
    end,
    COMPLETE_ACHIEVEMENT = function(newAchievementType)
      if not wnd:IsVisible() then
        return
      end
      UpdateCategoryCount()
      local newInfo = X2Achievement:GetAchievementInfo(newAchievementType)
      if newInfo == nil then
        return
      end
      if kind ~= newInfo.achievementKind then
        return
      end
      content:Update(newInfo, false)
    end
  }
  wnd:SetHandler("OnEvent", function(this, event, ...)
    events[event](...)
  end)
  RegistUIEvent(wnd, events)
end
