function CreateAppellationStampWindow(parent)
  local frame = CreateWindow("stampWnd", parent)
  frame:SetTitle(GetCommonText("appellation_stamp"))
  frame:SetExtent(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_300), 430)
  frame:AddAnchor("CENTER", "UIParent", 0, 0)
  parent.stampWnd = frame
  local desc = W_MODULE:Create("desc", frame, W_MODULE.TYPES.TEXTBOX, {
    [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("appellation_select_stamp")
  })
  frame:RegisterStack(desc)
  local maxIconCount = 25
  local data = {
    newLineCount = 5,
    maxIconCount = maxIconCount,
    iconType = "stamp",
    [W_MODULE.ATTRIBUTE.HIGHLIGHTED_ICON] = {
      use = true,
      [W_MODULE.ATTRIBUTE.HIGHLIGHTED_ICON_CHECKER] = function(iconInfo)
        if iconInfo == nil then
          return false
        end
        local info = iconInfo.info
        if info.applied == true then
          return false
        end
        if info.level == nil or info.reqlevel == nil then
          return false
        end
        if info.level < info.reqlevel then
          return false
        end
        if info.canEquip == 0 then
          return false
        end
        return true
      end
    }
  }
  local iconGroup = W_MODULE:Create("iconGroup", frame, W_MODULE.TYPES.ICON_GROUP, data)
  iconGroup:SetWidth(frame:GetWidth() - MARGIN.WINDOW_SIDE * 2)
  frame:RegisterStack(iconGroup)
  local bg = CreateContentBackground(iconGroup, "TYPE2", "brown_2")
  bg:AddAnchor("TOPLEFT", iconGroup, 0, -MARGIN.WINDOW_SIDE / 4609434218613702656)
  bg:AddAnchor("BOTTOMRIGHT", iconGroup, 0, MARGIN.WINDOW_SIDE / 4609434218613702656)
  local pageControlKey = "pageControl"
  local pageControl = W_CTRL.CreatePageControl(pageControlKey, frame)
  frame:RegisterStack(pageControl, MARGIN.WINDOW_SIDE)
  local selectedInfo
  local buttonSet = W_MODULE:Create("buttonSet", frame, W_MODULE.TYPES.BUTTON_SET)
  buttonSet:AddButton("ok", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "ok"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    enable = false,
    clickFunc = function()
      if selectedInfo == nil then
        return
      end
      local selectStampId = selectedInfo.id
      local item = X2Player:GetStampChangeItemInfo()
      if item == nil or item.itemType == nil or item.itemType == 0 or selectStampId == 0 then
        X2Player:SetAppellationStamp(selectStampId)
        return
      end
      local function DialogHandler(wnd)
        wnd:SetTitle(GetUIText(COMMON_TEXT, "change_stamp"))
        local data = {
          itemInfo = X2Item:GetItemInfoByType(item.itemType),
          stack = {
            item.has,
            item.need
          }
        }
        local itemIcon = W_MODULE:Create("itemIcon", wnd, W_MODULE.TYPES.ICON_VERTICAL, data)
        wnd:RegisterStack(itemIcon)
        function wnd:OkProc()
          X2Player:SetAppellationStamp(selectStampId)
          frame:Show(false)
        end
      end
      X2DialogManager:RequestDialog(DialogHandler, parent:GetId())
    end
  })
  buttonSet:AddButton("cancel", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "cancel"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    enable = true,
    clickFunc = function()
      frame:Show(false)
    end
  })
  frame:RegisterStack(buttonSet)
  frame:ApplyAutoHeightByStack()
  iconGroup:SetDataPartially(W_MODULE.ATTRIBUTE.ICON_CLICK_FUNC, function(arg, index, info)
    if arg ~= "LeftButton" then
      return
    end
    selectedInfo = info
    local myStampInfo = X2Player:GetAppellationMyStamp()
    if myStampInfo ~= nil and info.id == myStampInfo.id then
      buttonSet:UpdateButton("ok", {enable = false})
      return
    end
    buttonSet:UpdateButton("ok", {enable = true})
  end)
  function frame:ShowProc()
    local stamps = X2Player:GetAppellationStampInfo()
    pageControl:SetPageByItemCount(#stamps, maxIconCount)
    pageControl:SetCurrentPage(1, true)
  end
  function pageControl:ProcOnPageChanged(pageIndex, countPerPage)
    selectedInfo = nil
    buttonSet:UpdateButton("ok", {enable = false})
    local data = iconGroup:GetData()
    iconGroup:Clear()
    local stamps = X2Player:GetAppellationStampInfo()
    local startIndex = (pageIndex - 1) * maxIconCount + 1
    if startIndex > #stamps then
      iconGroup:SetData(data)
      return
    end
    local myStampInfo = X2Player:GetAppellationMyStamp()
    local levelInfo = X2Player:GetAppellationMyLevelInfo()
    local endIndex = pageIndex * maxIconCount
    local iconInfo = {}
    for i = startIndex, endIndex do
      local info = stamps[i]
      if info ~= nil then
        local applied = info.id ~= nil and myStampInfo ~= nil and myStampInfo.id ~= nil and info.id == myStampInfo.id
        info.level = levelInfo.level
        info.highlightImgInfo = {
          type = applied and "green" or nil,
          show = applied and true or false
        }
        info.applied = applied
        info.showTooltip = info.id ~= 0
        local enable = true
        if info.level < info.reqlevel or info.canEquip == 0 then
          enable = false
        end
        local processed = {
          info = info,
          [W_MODULE.ATTRIBUTE.ENABLE] = enable
        }
        table.insert(iconInfo, processed)
      end
    end
    data.iconInfo = iconInfo
    iconGroup:SetData(data)
  end
  return frame
end
