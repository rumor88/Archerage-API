function CreateAppellation(tabWindow, keyValue, tabIndex)
  local window = SetViewOfAppellation(tabWindow, keyValue, tabIndex)
  function window:UpdateList(filter, page)
    local info = X2Player:GetAppellations(filter, page)
    window.listSection.appellationList:SetData({
      [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
      [W_MODULE.ATTRIBUTE.DATA] = info,
      [W_MODULE.ATTRIBUTE.MAX_DATA_COUNT] = X2Player:GetAppellationsCount(filter),
      [W_MODULE.ATTRIBUTE.PAGE_PER_DATA_COUNT] = APPELLATION_LIST_PER_PAGE,
      [W_MODULE.ATTRIBUTE.CURRENT_PAGE] = page
    })
    window:SetListEmpty(info == nil or #info <= 0)
  end
  function window:routePopupProc(type)
    if type == nil then
      return
    end
    local routeDescription = X2Player:GetAppellationRouteInfo(type)
    if routeDescription == nil then
      return
    end
    local kind = routeDescription.kind
    if kind == APPELATION_ROUTE_TYPE_HIDDEN or kind == APPELATION_ROUTE_TYPE_ETC then
      return
    end
    if kind == APPELATION_ROUTE_TYPE_QUEST_CONTEXTS then
      ShowHiddenQuestReport(routeDescription.type, true)
    elseif kind == APPELATION_ROUTE_TYPE_ACHIEVEMENTS then
      ToggleAssignmentWithAcheivement(routeDescription.type)
    elseif kind == APPELATION_ROUTE_TYPE_MERCHANT_PACKS then
      DirectOpenStore(routeDescription.type)
    end
  end
  function window.listSection.comboBox:SelectedProc()
    local info = self:GetSelectedInfo()
    if info == nil then
      return
    end
    window:UpdateList(info.value, 1)
  end
  window.listSection.comboBox:Select(1)
  local function Refresh()
    window:FillTopSection()
    window.listSection.appellationList:SetDataPartially(W_MODULE.ATTRIBUTE.VIEW_REFRESH)
  end
  function window:OnTabSelected(selected)
    Refresh()
  end
  local function OnHide()
    if not UIParent:GetPermission(UIC_APPELLATION) then
      HideHiddenQuestReport()
    end
    window.stampWnd:Show(false)
  end
  window:SetHandler("OnHide", OnHide)
  local Events = {
    APPELLATION_GAINED = function()
      local page = window.listSection.appellationList:GetDataPartially(W_MODULE.ATTRIBUTE.CURRENT_PAGE)
      if page == nil then
        return
      end
      local topDataIndex = window.listSection.appellationList:GetDataPartially(W_MODULE.ATTRIBUTE.TOP_DATA_INDEX)
      if topDataIndex == nil then
        return
      end
      local info = window.listSection.comboBox:GetSelectedInfo()
      if info == nil then
        return
      end
      window:FillTopSection()
      window:UpdateList(info.value, page)
      window.listSection.appellationList:SetDataPartially(W_MODULE.ATTRIBUTE.SCROLL_BY_DATA_INDEX, topDataIndex - 1)
    end,
    APPELLATION_CHANGED = function(stringId, isChanged)
      if not W_UNIT.IsMyUnitId(stringId) then
        return
      end
      Refresh()
    end,
    APPELLATION_STAMP_SET = function()
      window.stampWnd:Show(false)
      local stampInfo = X2Player:GetAppellationMyStamp()
      if stampInfo == nil then
        return
      end
      window:ChangeAppellationIcon(stampInfo)
    end
  }
  window:SetHandler("OnEvent", function(this, event, ...)
    Events[event](...)
  end)
  RegistUIEvent(window, Events)
end
