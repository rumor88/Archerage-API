APPELLATION_INFO = {
  TYPE = 1,
  NAME = 2,
  GRADE = 3,
  ISHAVE = 4,
  ORDER = 5,
  BUFF_INFO = 6
}
function SetViewOfAppellation(tabWindow, keyValue, tabIndex)
  local width = tabWindow:GetWidth()
  local tab = tabWindow:GetParent()
  local levelInfo = X2Player:GetAppellationMyLevelInfo()
  local topSection = W_MODULE:Create("topSection", tabWindow, W_MODULE.TYPES.TITLE_BOX, {
    title = GetCommonText("my_appellation"),
    [W_MODULE.ATTRIBUTE.GUIDE_TOOLTIP] = GetCommonText("appellation_help", tonumber(levelInfo.maxlevel) - 1)
  }, {
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = width
  })
  local bodyFrame = topSection:CreateChildWidget("emptywidget", "bodyFrame", 0, false)
  bodyFrame:SetExtent(width, 70)
  topSection:AddBody(bodyFrame)
  local curAppellation = CreateIconButton("curAppellation", bodyFrame, "stamp")
  local size = F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_50)
  curAppellation:SetExtent(size, size)
  curAppellation:AddAnchor("TOPLEFT", bodyFrame, 0, 0)
  function curAppellation:procOnEnter()
    SetTooltip(GetCommonText("appellation_guide"), self)
  end
  local deco = curAppellation:CreateDrawable("ui/icon_button.dds", "btn_stamp_ov", "overlay")
  deco:AddAnchor("TOPLEFT", curAppellation, 0, 0)
  deco:AddAnchor("BOTTOMRIGHT", curAppellation, 0, 0)
  local iconButtonWidth = curAppellation:GetWidth()
  local curLevel = bodyFrame:CreateChildWidget("label", "curLevel", 0, false)
  curLevel:SetExtent(iconButtonWidth, FONT_SIZE.LARGE)
  curLevel.style:SetColorByKey("default")
  curLevel:AddAnchor("TOP", curAppellation, "BOTTOM", 0, 3)
  local function CreateBadgeFunc(id)
    local badge = W_ICON.CreateTextBadge(id, bodyFrame, {
      info = {
        appellation = {
          text = GetUIText(CHARACTER_POPUP_SUBTITLE_TEXT, "appellation"),
          colorKey = "default"
        },
        effect = {
          text = GetUIText(COMMON_TEXT, "effect"),
          colorKey = "default"
        }
      },
      minWidth = 56,
      textureKey = "icon_text_bg"
    })
    return badge
  end
  local titleOffset = 10
  local appellationTitle = CreateBadgeFunc("appellationTitle")
  appellationTitle:Set("appellation")
  appellationTitle:AddAnchor("TOPLEFT", curAppellation, "TOPRIGHT", titleOffset, 0)
  local effectTitle = CreateBadgeFunc("effectTitle")
  effectTitle:Set("effect")
  effectTitle:AddAnchor("TOPLEFT", appellationTitle, "BOTTOMLEFT", 0, 2)
  local gradeOffset = 2
  local appellationGrade = W_ICON.CreateGradeIcon(appellationTitle)
  appellationGrade:AddAnchor("LEFT", appellationTitle, "RIGHT", gradeOffset, 1)
  appellationGrade:SetGrade(1)
  local effectGrade = W_ICON.CreateGradeIcon(effectTitle)
  effectGrade:AddAnchor("LEFT", effectTitle, "RIGHT", gradeOffset, 1)
  effectGrade:SetGrade(1)
  local textOffset = 5
  local bodyFrameWidth = bodyFrame:GetWidth()
  local textWidth = bodyFrameWidth - iconButtonWidth - appellationTitle:GetWidth() - appellationGrade:GetWidth() - textOffset - gradeOffset - titleOffset
  local appellationName = bodyFrame:CreateChildWidget("label", "appellationName", 0, false)
  appellationName:AddAnchor("LEFT", appellationGrade, "RIGHT", textOffset, 0)
  appellationName:SetExtent(textWidth, FONT_SIZE.MIDDLE)
  appellationName.style:SetColorByKey("default")
  appellationName.style:SetAlign(ALIGN_LEFT)
  F_TEXT.ApplyAutoEllipsisTooltipText(appellationName)
  local effectDesc = bodyFrame:CreateChildWidget("textbox", "effectDesc", 0, false)
  effectDesc:AddAnchor("LEFT", effectGrade, "RIGHT", textOffset, 0)
  effectDesc:SetExtent(textWidth, FONT_SIZE.MIDDLE)
  effectDesc.style:SetColorByKey("default")
  effectDesc.style:SetAlign(ALIGN_LEFT)
  F_TEXT.ApplyAutoEllipsisTooltipText(effectDesc)
  effectDesc:SetAutoWordwrap(false)
  local effectInfoButtonOffset = 5
  local effectInfoButton = bodyFrame:CreateChildWidget("button", "effectInfoButton", 0, false)
  effectInfoButton:SetStyle("question_mark")
  local barWidth = bodyFrameWidth - iconButtonWidth - titleOffset - effectInfoButtonOffset - effectInfoButton:GetWidth()
  local expBar = W_BAR.CreateAppellationBar("expBar", bodyFrame)
  expBar:AddAnchor("LEFT", curLevel, "RIGHT", titleOffset, 0)
  expBar:SetExtent(barWidth, 14)
  local OnEnterExpBar = function(self)
    if self.tipStr == nil then
      return
    end
    SetTooltip(self.tipStr, self)
  end
  expBar:SetHandler("OnEnter", OnEnterExpBar)
  effectInfoButton:AddAnchor("LEFT", expBar, "RIGHT", effectInfoButtonOffset, 0)
  local GetInfo = function()
    local newInfo = {}
    local out = X2Player:GetAppellationBuffInfoByLevels()
    for i, v in ipairs(out) do
      newInfo[i] = {}
      newInfo[i].levelName = string.format(F_TEXT.SetColonFormat(GetCommonText("appellation_buff_info_grade"), i))
      newInfo[i].buffInfo = v
    end
    return newInfo
  end
  local gradeGuideWnd
  local function LeftClickEffectInfoButton()
    if gradeGuideWnd == nil then
      gradeGuideWnd = CreateInfoByGradeOrLevel("gradeGuideWnd", {
        title = GetCommonText("appellation_buff_info_title"),
        info = GetInfo()
      })
    end
    gradeGuideWnd:Show(not gradeGuideWnd:IsVisible())
  end
  ButtonOnClickHandler(effectInfoButton, LeftClickEffectInfoButton)
  function curAppellation:OnClickProc(arg)
    if arg ~= "LeftButton" then
      return
    end
    if tabWindow.stampWnd:IsVisible() == false then
      tabWindow.stampWnd:Show(true)
    else
      tabWindow.stampWnd:Show(false)
    end
  end
  local selectedNameType, selectedEffectType
  function tabWindow:ChangeAppellationIcon(stampInfo)
    if stampInfo == nil then
      return
    end
    curAppellation:SetInfo(stampInfo)
  end
  function tabWindow:FillTopSection()
    local showingInfo = X2Player:GetShowingAppellation()
    local effectInfo = X2Player:GetEffectAppellation()
    local levelInfo = X2Player:GetAppellationMyLevelInfo()
    local stampInfo = X2Player:GetAppellationMyStamp()
    if showingInfo ~= nil and showingInfo[APPELLATION_INFO.TYPE] ~= 0 then
      appellationName:SetText(showingInfo[APPELLATION_INFO.NAME])
      appellationGrade:SetGrade(showingInfo[APPELLATION_INFO.GRADE])
      selectedNameType = showingInfo[APPELLATION_INFO.TYPE]
    else
      appellationName:SetText(GetUIText(TOOLTIP_TEXT, "nobody"))
      appellationGrade:SetGrade(1)
      selectedNameType = 0
    end
    if effectInfo ~= nil and effectInfo[APPELLATION_INFO.TYPE] ~= 0 then
      if effectInfo[APPELLATION_INFO.BUFF_INFO] ~= nil then
        local text = effectInfo[APPELLATION_INFO.BUFF_INFO].description
        text = string.gsub(text, "\r\n", "")
        text = string.gsub(text, "\n", "")
        effectDesc:SetText(text)
      else
        effectDesc:SetText(GetUIText(TOOLTIP_TEXT, "nobody"))
      end
      effectGrade:SetGrade(effectInfo[APPELLATION_INFO.GRADE])
      selectedEffectType = effectInfo[APPELLATION_INFO.TYPE]
    else
      effectDesc:SetText(GetUIText(TOOLTIP_TEXT, "nobody"))
      effectGrade:SetGrade(1)
      selectedEffectType = 0
    end
    curLevel:SetText(string.format("%s %d", GetCommonText("butler_level_step"), levelInfo.level))
    expBar:SetMinMaxValues(levelInfo.minExp, levelInfo.maxExp)
    expBar:SetValue(levelInfo.exp)
    local visible = levelInfo.exp > levelInfo.minExp and levelInfo.exp < levelInfo.maxExp
    expBar.shadowDeco:SetVisible(visible)
    local str = F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(levelInfo.exp - levelInfo.minExp), F_TEXT.SetCommaFormat(levelInfo.maxExp - levelInfo.minExp))
    local max = levelInfo.maxExp - levelInfo.minExp
    local val = levelInfo.exp - levelInfo.minExp
    local percent = string.format("(%.2f%%)", math.min(val / max * 100, 100))
    expBar.tipStr = string.format("%s %s", str, percent)
    tabWindow:ChangeAppellationIcon(stampInfo)
  end
  tab:RegisterStack(tabIndex, topSection)
  local function IsSame()
    local showingInfo = X2Player:GetShowingAppellation()
    local effectInfo = X2Player:GetEffectAppellation()
    local same = false
    if showingInfo ~= nil and effectInfo ~= nil and showingInfo[APPELLATION_INFO.TYPE] == selectedNameType and effectInfo[APPELLATION_INFO.TYPE] == selectedEffectType then
      same = true
    end
    return same
  end
  local buttonSet = W_MODULE:Create("buttonSet", tabWindow, W_MODULE.TYPES.BUTTON_SET, nil, {
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = width
  })
  buttonSet:AddButton("apply", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "apply"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.RIGHT,
    enable = false,
    clickFunc = function()
      if selectedNameType == nil or selectedEffectType == nil then
        AddMessageToSysMsgWindow(GetUIText(COMMON_TEXT, "appellation_cannot_change"))
        return
      end
      if IsSame() then
        AddMessageToSysMsgWindow(GetUIText(COMMON_TEXT, "appellation_cannot_change"))
        return
      end
      local item = X2Player:GetAppellationChangeItemInfo()
      if item == nil or item.itemType == nil or item.itemType == 0 then
        X2Player:ChangeAppellation(selectedNameType, selectedEffectType)
        return
      end
      local function DialogHandler(wnd)
        wnd:SetTitle(GetUIText(COMMON_TEXT, "appellation_change"))
        local data = {
          itemInfo = X2Item:GetItemInfoByType(item.itemType),
          stack = {
            item.has,
            item.need
          }
        }
        local itemIcon = W_MODULE:Create("itemIcon", wnd, W_MODULE.TYPES.ICON_VERTICAL, data)
        wnd:RegisterStack(itemIcon)
        function wnd:OkProc()
          X2Player:ChangeAppellation(selectedNameType, selectedEffectType)
        end
      end
      X2DialogManager:RequestDialog(DialogHandler, tabWindow:GetId())
    end
  })
  local listSection = tabWindow:CreateChildWidget("emptywidget", "listSection", 0, true)
  listSection:SetExtent(width, 270)
  tab:RegisterStack(tabIndex, listSection, 2)
  local comboboxWidth = 195
  local comboBox = W_CTRL.CreateComboBox("comboBox", listSection)
  comboBox:SetWidth(comboboxWidth)
  comboBox:AddAnchor("TOPRIGHT", listSection, -3, 0)
  local datas = {}
  local firstData = {
    text = GetCommonText("show_all"),
    value = APPELATION_ROUTE_TYPE_MAX,
    color = F_COLOR.GetColor("default"),
    disableColor = F_COLOR.GetColor("gray"),
    useColor = true,
    enable = true
  }
  table.insert(datas, firstData)
  local filterList = X2Player:GetUnitAppellationRouteList()
  for i = 1, #filterList do
    local info = filterList[i]
    if info.value ~= nil and info.value ~= "hidden" then
      local data = {
        text = GetCommonText(info.value),
        value = info.key
      }
      table.insert(datas, data)
    end
  end
  local comboOffset = 10
  local title = listSection:CreateChildWidget("label", "title", 0, false)
  title:SetExtent(width - comboboxWidth - comboOffset - 5, FONT_SIZE.LARGE)
  title.style:SetColorByKey("title")
  title.style:SetAlign(ALIGN_LEFT)
  title.style:SetFontSize(FONT_SIZE.LARGE)
  title:SetText(GetCommonText("appellation_list"))
  title:AddAnchor("TOPLEFT", listSection, comboOffset, 5)
  local secondColumnRadioImgs = {}
  local thirdColumnRadioImgs = {}
  local ClearRadioImgs = function(target)
    for i, v in ipairs(target) do
      v:SetTextureInfo("radio_button_df")
    end
  end
  local function UpdateButtonSet()
    local showingInfo = X2Player:GetShowingAppellation()
    local effectInfo = X2Player:GetEffectAppellation()
    local enable = true
    if showingInfo ~= nil and effectInfo ~= nil and showingInfo[APPELLATION_INFO.TYPE] == selectedNameType and effectInfo[APPELLATION_INFO.TYPE] == selectedEffectType then
      enable = false
    end
    buttonSet:UpdateButton("apply", {
      enable = not IsSame()
    })
  end
  local CommonLayoutFunc = function(subItem, row, listCtrl, useLabel)
    local appliedImage = subItem:CreateDrawable(TEXTURE_PATH.DEFAULT, "list_title_select", "background")
    appliedImage:AddAnchor("TOPLEFT", subItem, 0, 0)
    appliedImage:AddAnchor("BOTTOMRIGHT", subItem, 0, 0)
    appliedImage:SetTextureColor("default")
    appliedImage:SetVisible(false)
    subItem.appliedImage = appliedImage
    local radioBtnImg = subItem:CreateDrawable(TEXTURE_PATH.DEFAULT, "radio_button_df", "overlay")
    radioBtnImg:AddAnchor("LEFT", subItem, 5, 0)
    subItem.radioBtnImg = radioBtnImg
    local offset = radioBtnImg:GetWidth() + 8
    local text
    local widgetType = useLabel and "label" or "textbox"
    local text = subItem:CreateChildWidget(widgetType, "text", 0, true)
    text:SetExtent(subItem:GetWidth() - offset - 5, FONT_SIZE.MIDDLE)
    text:AddAnchor("LEFT", subItem, offset, 0)
    text.style:SetAlign(ALIGN_LEFT)
    text.style:SetEllipsis(true)
    if useLabel then
      F_TEXT.ApplyAutoEllipsisTooltipText(text)
    else
      text:SetAutoWordwrap(false)
      local function OnEnter(self)
        if subItem.tooltip == nil then
          return
        end
        SetTooltip(subItem.tooltip, self)
      end
      text:SetHandler("OnEnter", OnEnter)
    end
  end
  local layoutSet = GetLayoutSetAssignment()
  local appellationList
  appellationList = W_MODULE:Create("appellationList", listSection, W_MODULE.TYPES.LISTCTRL, nil, {
    [W_MODULE.ATTRIBUTE.COLUMN_HEIGHT_TYPE] = "small",
    [W_MODULE.ATTRIBUTE.LAYOUT_BG_TYPE] = "type_2",
    [W_MODULE.ATTRIBUTE.LAYOUT_COLUMN_BG_TYPE] = "type_2",
    [W_MODULE.ATTRIBUTE.ROW_COUNT] = 6,
    [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = true,
    [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = "text_small",
    [W_MODULE.ATTRIBUTE.HAS_SCROLL] = true,
    [W_MODULE.ATTRIBUTE.HAS_PAGE] = true,
    [W_MODULE.ATTRIBUTE.OVER_SELECT_IMAGE_TYPE] = "type_1",
    [W_MODULE.ATTRIBUTE.ROW_BACKGROUND_TYPE] = "type_2",
    [W_MODULE.ATTRIBUTE.PAGE_CHANGED_PROC] = function(pageIndex, countPerPage)
      local info = comboBox:GetSelectedInfo()
      if info == nil then
        return
      end
      tabWindow:UpdateList(info.value, pageIndex)
    end,
    [W_MODULE.ATTRIBUTE.ONSELCHANGED_PROC] = function(index, doubleClick, moduleFrame)
      local data = moduleFrame:GetDataPartially(W_MODULE.ATTRIBUTE.SELECTED_DATA)
      if data == nil then
        return
      end
      tabWindow:UpdateRouteInfo(data[APPELLATION_INFO.TYPE])
    end,
    [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = 70,
        [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(RANKING_TEXT, "rank"),
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
          local gradeIcon = W_ICON.CreateGradeIcon(subItem)
          gradeIcon:AddAnchor("CENTER", subItem, 0, 0)
          subItem.gradeIcon = gradeIcon
        end,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data then
            if data[APPELLATION_INFO.GRADE] >= 0 then
              subItem.gradeIcon:SetGrade(data[APPELLATION_INFO.GRADE])
              subItem.gradeIcon:Show(true)
            else
              subItem.gradeIcon:Show(false)
            end
          else
            subItem.gradeIcon:Show(false)
          end
        end
      },
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = layoutSet.appellationColumWidth,
        [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("appellation_title"),
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
          CommonLayoutFunc(subItem, row, listCtrl, true)
          table.insert(secondColumnRadioImgs, subItem.radioBtnImg)
          local function OnClick(self, arg)
            if arg ~= "LeftButton" then
              return
            end
            appellationList:SetDataPartially(W_MODULE.ATTRIBUTE.SELECT_BY_DATA, {
              compareFunc = function(data)
                return data[APPELLATION_INFO.TYPE] == subItem.selectedNameType
              end,
              trigger = true
            })
            if subItem.isDisabled then
              return
            end
            ClearRadioImgs(secondColumnRadioImgs)
            self.radioBtnImg:SetTextureInfo("radio_button_chk_df")
            selectedNameType = subItem.selectedNameType
            UpdateButtonSet()
          end
          subItem:SetHandler("OnClick", OnClick)
        end,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data then
            subItem.selectedNameType = data[APPELLATION_INFO.TYPE]
            subItem.isDisabled = data[APPELLATION_INFO.ISHAVE] == 0
            local row = subItem:GetParent()
            if subItem.isDisabled then
              row:ChangeColorRowBackground("list_dis")
              row:ShowRowBackground(true)
              subItem.text.style:SetColorByKey("original_light_gray")
            else
              row:ShowRowBackground(false)
              local colorKey = data[APPELLATION_INFO.TYPE] == 0 and "blue" or "default"
              subItem.text.style:SetColorByKey(colorKey)
            end
            if data[APPELLATION_INFO.TYPE] ~= nil and data[APPELLATION_INFO.TYPE] ~= 0 then
              subItem.text:SetText(data[APPELLATION_INFO.NAME])
            else
              subItem.text:SetText(GetCommonText("appellation_unable"))
            end
            local showingInfo = X2Player:GetShowingAppellation()
            if showingInfo ~= nil and showingInfo[APPELLATION_INFO.TYPE] == data[APPELLATION_INFO.TYPE] then
              subItem.appliedImage:SetVisible(true)
              if selectedNameType == nil then
                selectedNameType = data[APPELLATION_INFO.TYPE]
              end
            else
              subItem.appliedImage:SetVisible(false)
            end
            if selectedNameType == data[APPELLATION_INFO.TYPE] then
              subItem.radioBtnImg:SetTextureInfo("radio_button_chk_df")
            else
              subItem.radioBtnImg:SetTextureInfo("radio_button_df")
            end
            subItem:Show(true)
          else
            subItem:Show(false)
          end
        end
      },
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = layoutSet.appellationColumWidth,
        [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("effect"),
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
          CommonLayoutFunc(subItem, row, listCtrl, false)
          table.insert(thirdColumnRadioImgs, subItem.radioBtnImg)
          local function OnClick(self, arg)
            if arg ~= "LeftButton" then
              return
            end
            appellationList:SetDataPartially(W_MODULE.ATTRIBUTE.SELECT_BY_DATA, {
              compareFunc = function(data)
                return data[APPELLATION_INFO.TYPE] == subItem.selectedEffectType
              end,
              trigger = true
            })
            if subItem.isDisabled then
              return
            end
            ClearRadioImgs(thirdColumnRadioImgs)
            self.radioBtnImg:SetTextureInfo("radio_button_chk_df")
            selectedEffectType = subItem.selectedEffectType
            UpdateButtonSet()
          end
          subItem:SetHandler("OnClick", OnClick)
        end,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data then
            subItem.selectedEffectType = data[APPELLATION_INFO.TYPE]
            subItem.isDisabled = data[APPELLATION_INFO.ISHAVE] == 0
            if subItem.isDisabled then
              subItem.text.style:SetColorByKey("original_light_gray")
            else
              local colorKey = data[APPELLATION_INFO.TYPE] == 0 and "blue" or "default"
              subItem.text.style:SetColorByKey(colorKey)
            end
            if data[APPELLATION_INFO.TYPE] ~= nil and data[APPELLATION_INFO.TYPE] ~= 0 then
              if data[APPELLATION_INFO.BUFF_INFO] ~= nil then
                subItem.tooltip = data[APPELLATION_INFO.BUFF_INFO].description
                local text = subItem.tooltip
                text = string.gsub(text, "\r\n", "")
                text = string.gsub(text, "\n", "")
                subItem.text:SetText(text)
              else
                subItem.tooltip = ""
                subItem.text:SetText(GetUIText(TOOLTIP_TEXT, "nobody"))
              end
            else
              subItem.tooltip = GetCommonText("appellation_effect_unable")
              subItem.text:SetText(GetCommonText("appellation_effect_unable"))
            end
            local effectInfo = X2Player:GetEffectAppellation()
            if effectInfo ~= nil and effectInfo[APPELLATION_INFO.TYPE] == data[APPELLATION_INFO.TYPE] then
              subItem.appliedImage:SetVisible(true)
              if selectedEffectType == nil then
                selectedEffectType = data[APPELLATION_INFO.TYPE]
              end
            else
              subItem.appliedImage:SetVisible(false)
            end
            if selectedEffectType == data[APPELLATION_INFO.TYPE] then
              subItem.radioBtnImg:SetTextureInfo("radio_button_chk_df")
            else
              subItem.radioBtnImg:SetTextureInfo("radio_button_df")
            end
            subItem:Show(true)
          else
            subItem:Show(false)
          end
        end
      }
    }
  })
  appellationList:AddAnchor("TOPRIGHT", comboBox, "BOTTOMRIGHT", 0, 5)
  local emptyLabel = tabWindow:CreateChildWidget("textbox", "emptyLabel", 0, true)
  emptyLabel:AddAnchor("CENTER", appellationList, 0, 0)
  emptyLabel:SetExtent(width, FONT_SIZE.MIDDLE)
  emptyLabel.style:SetColorByKey("default")
  emptyLabel:SetAutoResize(true)
  emptyLabel:SetText(GetCommonText("appellation_empty_guide1"))
  emptyLabel:Show(false)
  function tabWindow:SetListEmpty(isEmpty)
    emptyLabel:Show(isEmpty)
  end
  local bottomSection = W_MODULE:Create("bottomSection", tabWindow, W_MODULE.TYPES.TITLE_BOX, {
    title = GetCommonText("hero_bonus_conditon")
  }, {
    [W_MODULE.ATTRIBUTE.FIXED_WIDTH] = width
  })
  tab:RegisterStack(tabIndex, bottomSection, -15)
  local bodyFrame = bottomSection:CreateChildWidget("emptywidget", "bodyFrame", 0, false)
  local popupBtn = bodyFrame:CreateChildWidget("button", "popupBtn", 0, true)
  popupBtn:AddAnchor("RIGHT", bodyFrame, 0, 0)
  popupBtn:SetStyle("button_common_book")
  local popupBtnHeight = popupBtn:GetHeight()
  local function LeftClickEffectInfoButton(self)
    local data = appellationList:GetDataPartially(W_MODULE.ATTRIBUTE.SELECTED_DATA)
    if data == nil then
      return
    end
    tabWindow:routePopupProc(data[APPELLATION_INFO.TYPE])
  end
  ButtonOnClickHandler(popupBtn, LeftClickEffectInfoButton)
  bodyFrame:SetExtent(width, popupBtnHeight)
  bottomSection:AddBody(bodyFrame)
  local routeDesc = bodyFrame:CreateChildWidget("textbox", "routeDesc", 0, true)
  routeDesc:AddAnchor("LEFT", bodyFrame, 0, 0)
  routeDesc:SetExtent(bodyFrame:GetWidth() - popupBtn:GetWidth() - 5, popupBtnHeight)
  routeDesc.style:SetColorByKey("default")
  routeDesc.style:SetAlign(ALIGN_LEFT)
  function tabWindow:UpdateRouteInfo(type)
    routeDesc:SetText("")
    popupBtn:Enable(false)
    if type == nil then
      return
    end
    local routeDescription = X2Player:GetAppellationRouteInfo(type)
    if routeDescription ~= nil then
      routeDesc:SetText(X2Util:ApplyUIMacroString(routeDescription.routeDesc))
      if routeDescription.kind == APPELATION_ROUTE_TYPE_QUEST_CONTEXTS or routeDescription.kind == APPELATION_ROUTE_TYPE_ACHIEVEMENTS or routeDescription.kind == APPELATION_ROUTE_TYPE_MERCHANT_PACKS then
        popupBtn:Enable(routeDescription.routePopup or false)
      else
        popupBtn:Enable(false)
      end
    end
  end
  CreateAppellationStampWindow(tabWindow)
  comboBox:AppendItems(datas, false)
  tab:RegisterStack(tabIndex, buttonSet)
  return tabWindow
end
