local assignmentWnd, appellationTabIndex
local function UpdatePermission()
  if appellationTabIndex ~= nil then
    assignmentWnd.tab:EnableTab(appellationTabIndex, UIParent:GetPermission(UIC_APPELLATION))
    if not UIParent:GetPermission(UIC_APPELLATION) and assignmentWnd.tab:GetSelectedTab() == appellationTabIndex then
      assignmentWnd.tab:SelectTab(1)
    end
  end
end
UIParent:SetEventHandler("UI_PERMISSION_UPDATE", UpdatePermission)
local function CreateAssignmentWindow(id, parent)
  local wnd = CreateWindow(id, parent)
  wnd:SetTitle(GetUIText(COMMON_TEXT, "assignment_system"))
  wnd:SetExtent(GetLayoutSetAssignment().windowWidth, 620)
  wnd:AddAnchor("CENTER", "UIParent", 0, 0)
  wnd:SetSounds("achievement")
  local tabTexts = {}
  local tabInfo = {}
  local orderTable = {
    EAK_RACIAL_MISSION,
    EAK_ACHIEVEMENT,
    EAK_COLLECTION,
    EAK_ARCHERAGE
  }
  local tab = W_TAB.CreateTab("tab", wnd)
  local index = 1
  for _, keyValue in ipairs(orderTable) do
    local item = baselibLocale.achievementKindString[keyValue]
    if item ~= nil and item.enable == true then
      tabTexts[index] = item.text
      local info = {
        data = {index, keyValue},
        func = CreateAchievementTabPage
      }
      tabInfo[index] = info
      index = index + 1
    end
  end
  tabTexts[index] = GetCommonText("appellation_title")
  local info = {
    data = {index},
    func = CreateAppellation
  }
  tabInfo[index] = info
  appellationTabIndex = index
  local ulcTabIndex
  if X2Player:GetUseULC() then
    index = index + 1
    tabTexts[index] = GetCommonText("ulc_title")
    local info = {
      data = {index},
      func = CreateULC
    }
    tabInfo[index] = info
    ulcTabIndex = index
  end
  tab:AddTabs(tabTexts)
  for i = 1, #tabInfo do
    local info = tabInfo[i]
    info.func(tab.window[info.data[1]], info.data[2], info.data[1])
  end
  function wnd:SelectAchievement(info)
    local kind = info.achievementKind
    tab:SelectTab(kind)
    tab.window[kind]:SelectAchievement(info)
  end
  function wnd:SelectULCTab()
    if ulcTabIndex ~= nil then
      tab:SelectTab(ulcTabIndex)
    end
  end
  function tab:OnTabChangedProc(selected)
    tab.window[selected]:OnTabSelected(selected)
    tab.window[selected]:Raise()
  end
  return wnd
end
local function ToggleAssignement(isShow)
  if assignmentWnd == nil then
    assignmentWnd = CreateAssignmentWindow("assignmentWnd", "UIParent")
    UpdatePermission()
  end
  if isShow == nil then
    isShow = not assignmentWnd:IsVisible()
  end
  if isShow then
    UpdatePermission()
  end
  assignmentWnd:Show(isShow)
end
ADDON:RegisterContentTriggerFunc(UIC_ACHIEVEMENT, ToggleAssignement)
function ToggleAssignmentWithAcheivement(aType)
  local aInfo = X2Achievement:GetAchievementInfo(aType)
  if aInfo == nil then
    return
  end
  ToggleAssignement(true)
  assignmentWnd:SelectAchievement(aInfo)
  assignmentWnd:Raise()
end
function ShowULCTab()
  ToggleAssignement(true)
  assignmentWnd:SelectULCTab()
  assignmentWnd:Raise()
end
