local noteWindow = {}
noteWindow.page = nil
noteWindow.book = nil
local BookPageGuideFormatter = function(pageType)
  local pageInfo = X2Book:GetPageInfo(pageType)
  context = {}
  contentStr = ""
  for i = 1, #pageInfo.contents do
    local content = pageInfo.contents[i].text
    if content == "" then
      if contentStr ~= "" then
        table.insert(context, {content = contentStr, raw = true})
        contentStr = ""
      end
      table.insert(context, {
        image = pageInfo.contents[i].illust
      })
    else
      contentStr = string.format("%s%s", contentStr, content)
    end
  end
  if contentStr ~= "" then
    table.insert(context, {content = contentStr, raw = true})
    contentStr = ""
  end
  return context
end
local function CreatePageWindow(id, parent)
  local window = CreateEmptyWindow(id, parent)
  window:SetExtent(375, 293)
  window:SetSounds("web_note")
  window:EnableHidingIsRemove(true)
  window:SetCloseOnEscape(true)
  window:AddAnchor("CENTER", parent, 0, 0)
  local bg = window:CreateDrawable(TEXTURE_PATH.GRADE_ENCHANT_ALARM, "bg_paper", "background")
  bg:AddAnchor("TOPLEFT", window, 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", window, 0, 0)
  local guideContext = CreateInfomationGuideContext(window, {
    56,
    50,
    -33,
    -50
  })
  window.guideContext = guideContext
  local titleBar = CreateTitleBar("titleBar", window)
  titleBar:SetHeight(50)
  window.titleBar = titleBar
  window.titleBar.closeButton:RemoveAllAnchors()
  window.titleBar.closeButton:AddAnchor("TOPRIGHT", window, -30, 10)
  local function OnHideWindow()
    noteWindow.page = nil
  end
  window:SetHandler("OnHide", OnHideWindow)
  local events = {
    INTERACTION_END = function()
      if window:IsVisible() then
        window:Show(false)
      end
    end
  }
  window:SetHandler("OnEvent", function(this, event, ...)
    events[event](...)
  end)
  RegistUIEvent(window, events)
  return window
end
local function ShowPageWindow(idx)
  if noteWindow.page == nil then
    noteWindow.page = CreatePageWindow("noteWindow.page", "UIParent")
  else
    noteWindow.page:Clear()
  end
  noteWindow.page:Show(true)
  noteWindow.page.guideContext:Show(true)
  noteWindow.page:FillData(BookPageGuideFormatter(idx), 5)
end
local function CreateBookWindow(id, parent)
  local window = CreateWindow(id, parent)
  window:SetExtent(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_600), 570)
  window:SetSounds("web_note")
  window:EnableHidingIsRemove(true)
  window:SetCloseOnEscape(true)
  window:AddAnchor("CENTER", parent, 0, 0)
  local coverFrame = window:CreateChildWidget("emptywidget", "coverFrame", 0, true)
  coverFrame:Show(false)
  coverFrame:AddAnchor("CENTER", window, 0, 0)
  local coverTitle = coverFrame:CreateChildWidget("textbox", "coverTitle", 0, true)
  coverTitle:SetExtent(window:GetWidth() - 40, FONT_SIZE.LARGE)
  coverTitle:SetAutoResize(true)
  coverTitle:AddAnchor("CENTER", coverFrame, 0, 0)
  coverTitle.style:SetFontSize(FONT_SIZE.LARGE)
  coverTitle.style:SetColorByKey("middle_title")
  local upperDeco = coverFrame:CreateDrawable(TEXTURE_PATH.PAPER_DECO, "upper_deco", "artwork")
  upperDeco:AddAnchor("BOTTOM", coverTitle, "TOP", 0, -20)
  local lowerDeco = coverFrame:CreateDrawable(TEXTURE_PATH.PAPER_DECO, "lower_deco", "artwork")
  lowerDeco:AddAnchor("TOP", coverTitle, "BOTTOM", 0, 20)
  local readButton = window:CreateChildWidget("button", "readButton", 0, true)
  readButton:Enable(true)
  readButton:SetText(GetUIText(COMMON_TEXT, "reading"))
  ApplyButtonSkin(readButton, BUTTON_CONTENTS.BOOK_READ)
  readButton:AddAnchor("BOTTOM", window, "BOTTOM", 0, -30)
  local guideFrame = CreateGuideBookBaseFrame(window, {
    32,
    50,
    -32,
    -70
  }, {20, 32})
  guideFrame:Show(false)
  window.guideFrame = guideFrame
  local contentFrame = window:CreateChildWidget("emptywidget", "contentFrame", 0, true)
  contentFrame:Show(false)
  contentFrame:AddAnchor("TOP", window.titleBar, "BOTTOM", 0, 0)
  local listCtrl = W_MODULE:Create("listCtrl", contentFrame, W_MODULE.TYPES.LISTCTRL, {
    [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
    [W_MODULE.ATTRIBUTE.DATA] = nil
  }, {
    [W_MODULE.ATTRIBUTE.HAS_SCROLL] = false,
    [W_MODULE.ATTRIBUTE.SHOW_SCROLL] = false,
    [W_MODULE.ATTRIBUTE.ROW_COUNT] = window.guideFrame:GetContentMaxSize(),
    [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = 34,
    [W_MODULE.ATTRIBUTE.ROW_BACKGROUND_TYPE] = "type_1",
    [W_MODULE.ATTRIBUTE.OVER_SELECT_IMAGE_TYPE] = "type_1",
    [W_MODULE.ATTRIBUTE.ONSELCHANGED_PROC] = function(index, doubleClick, moduleFrame)
      local data = moduleFrame:GetDataPartially(W_MODULE.ATTRIBUTE.SELECTED_DATA)
      if data == nil then
        return
      end
      window.guideFrame.pageControl:SetCurrentPage(data.startPage, true)
    end,
    [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = 480,
        [W_MODULE.ATTRIBUTE.TEXT] = "",
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_STRING,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
          subItem.style:SetAlign(ALIGN_LEFT)
          subItem.style:SetColorByKey("default")
        end,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          local row = subItem:GetParent()
          if data then
            subItem:SetText(data.name)
            row:ShowRowBackground(true)
          else
            subItem:SetText("")
            row:ShowRowBackground(false)
          end
        end
      },
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = 32,
        [W_MODULE.ATTRIBUTE.TEXT] = "",
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_STRING,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
          subItem.style:SetAlign(ALIGN_RIGHT)
          subItem.style:SetColorByKey("default")
        end,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data then
            subItem:SetText(string.format("p.%d", data.startPage))
          else
            subItem:SetText("")
          end
        end
      }
    }
  })
  listCtrl:AddAnchor("TOP", contentFrame, 0, 0)
  local function OnHideWindow()
    noteWindow.book = nil
  end
  window:SetHandler("OnHide", OnHideWindow)
  local function SetContentTitle(name)
    if name then
      window:SetTitle(name)
    else
      window:SetTitle("")
    end
  end
  local function ReadButtonLeftClickFunc()
    coverFrame:Show(false)
    readButton:Show(false)
    window.guideFrame:Show(true)
    window.guideFrame:ShowPage()
  end
  ButtonOnClickHandler(window.readButton, ReadButtonLeftClickFunc)
  local function SetContentList(contents, contentPageSize, nowPage)
    local datas = {}
    if contents then
      local startPos = 1
      local endPos = #contents
      if contentPageSize > 1 and nowPage > 1 then
        startPos = startPos + (nowPage - 1) * window.guideFrame:GetContentMaxSize()
        if nowPage < contentPageSize then
          endPos = nowPage * window.guideFrame:GetContentMaxSize()
        end
      end
      for i = startPos, endPos do
        table.insert(datas, {
          name = contents[i].title,
          startPage = contents[i].startPage
        })
      end
    end
    listCtrl:SetData({
      [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
      [W_MODULE.ATTRIBUTE.DATA] = datas
    })
  end
  function window:SetBookInfos(bookInfo)
    SetContentTitle()
    SetContentList()
    self.guideFrame:Show(false)
    self.guideFrame:SetBookInfo(bookInfo)
    coverFrame:Show(true)
    readButton:Show(true)
    coverTitle:SetText(bookInfo.name)
  end
  local function UpdateContentInfo(useContent, contents, bookPages, contentPageCount, nowPage)
    window.contentFrame:Show(false)
    window.guideFrame.guideWindow:Show(true)
    if useContent then
      if nowPage <= contentPageCount then
        window.contentFrame:Show(true)
        window.guideFrame.guideWindow:Show(false)
        SetContentTitle(GetUIText(COMMON_TEXT, "book_content_title"))
        SetContentList(contents, contentPageCount, nowPage)
      else
        SetContentTitle(bookPages[nowPage - contentPageCount].title)
      end
    else
      SetContentTitle(bookPages[nowPage].title)
    end
  end
  window.guideFrame:SetExtendSetPageFunc(UpdateContentInfo)
  local events = {
    INTERACTION_END = function()
      if window:IsVisible() then
        window:Show(false)
      end
    end
  }
  window:SetHandler("OnEvent", function(this, event, ...)
    events[event](...)
  end)
  RegistUIEvent(window, events)
  return window
end
local function ShowBookWindow(bookInfo)
  if noteWindow.book == nil then
    noteWindow.book = CreateBookWindow("noteWindow.book", "UIParent")
  end
  noteWindow.book:Show(true)
  noteWindow.book:SetBookInfos(bookInfo)
end
local function OpenPaper(type, idx)
  if type == nil or idx == nil then
    return
  end
  if type == "page" then
    ShowPageWindow(idx)
  elseif type == "book" then
    local bookInfo = X2Book:GetBookInfo(idx)
    if bookInfo == nil then
      return
    end
    ShowBookWindow(bookInfo)
  else
    LuaAssert("error!!!")
  end
end
UIParent:SetEventHandler("OPEN_PAPER", OpenPaper)
local function ClosePaper()
  if noteWindow.book ~= nil then
    noteWindow.book:Show(false)
  end
  if noteWindow.page ~= nil then
    noteWindow.page:Show(false)
  end
end
UIParent:SetEventHandler("DESTROY_PAPER", ClosePaper)
UIParent:SetEventHandler("LEFT_LOADING", ClosePaper)
UIParent:SetEventHandler("ENTERED_WORLD", ClosePaper)
