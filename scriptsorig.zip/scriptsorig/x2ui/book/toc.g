﻿## author : yoshimom
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## book

book.lua