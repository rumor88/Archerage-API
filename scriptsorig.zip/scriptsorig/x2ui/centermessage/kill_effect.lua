local killEffect, killEffectSound, specialKillCount, straightKillSoundId
local function CreateKillEffect(id, parent)
  local widget = UIParent:CreateWidget("window", id, parent)
  widget:SetExtent(243, 189)
  widget:AddAnchor("TOP", parent, 0, 60)
  widget:EnableHidingIsRemove(true)
  widget:SetUILayer("system")
  widget:EnablePick(false)
  local bottomBg = widget:CreateDrawable(TEXTURE_PATH.KILL_EFFECT_BG, "bg", "background")
  bottomBg:AddAnchor("CENTER", widget, 0, MARGIN.WINDOW_SIDE * 4609434218613702656)
  local circleBooldstain = widget:CreateEffectDrawableByKey(TEXTURE_PATH.KILL_EFFECT_FIFTH_BELOW_DECO, "circle", "background")
  circleBooldstain:Show(false)
  circleBooldstain:AddAnchor("CENTER", bottomBg, 0, -MARGIN.WINDOW_SIDE * 4609434218613702656)
  circleBooldstain:SetRepeatCount(1)
  local verticalBooldstain = widget:CreateEffectDrawableByKey(TEXTURE_PATH.KILL_EFFECT_FIFTH_BELOW_DECO, "vertical", "background")
  verticalBooldstain:Show(false)
  verticalBooldstain:AddAnchor("CENTER", bottomBg, 0, -MARGIN.WINDOW_SIDE * 4609434218613702656)
  verticalBooldstain:SetRepeatCount(1)
  local circleFifthKill = widget:CreateEffectDrawableByKey(TEXTURE_PATH.KILL_EFFECT_FIFTH_KILL, "circle", "background")
  circleFifthKill:Show(false)
  circleFifthKill:AddAnchor("CENTER", bottomBg, 0, -MARGIN.WINDOW_SIDE * 4609434218613702656)
  circleFifthKill:SetRepeatCount(1)
  circleFifthKill:SetMoveRepeatCount(1)
  local warOfGodBg = widget:CreateDrawable(TEXTURE_PATH.KILL_EFFECT_WAR_OF_GOD, "bg", "background")
  warOfGodBg:Show(false)
  warOfGodBg:AddAnchor("CENTER", widget, -MARGIN.WINDOW_SIDE / 2, MARGIN.WINDOW_SIDE)
  local helmet = widget:CreateDrawable(TEXTURE_PATH.KILL_EFFECT_WAR_OF_GOD, "helmet", "artwork")
  helmet:AddAnchor("CENTER", widget, 0, 5)
  local warOfGodLaurel_O = widget:CreateDrawable(TEXTURE_PATH.KILL_EFFECT_WAR_OF_GOD, "deco", "artwork")
  warOfGodLaurel_O:Show(false)
  warOfGodLaurel_O:AddAnchor("BOTTOM", helmet, -MARGIN.WINDOW_SIDE / 2, MARGIN.WINDOW_SIDE / 2)
  local warOfGodLaurel_W = widget:CreateEffectDrawableByKey(TEXTURE_PATH.KILL_EFFECT_WAR_OF_GOD, "deco_bg", "artwork")
  warOfGodLaurel_W:Show(false)
  warOfGodLaurel_W:AddAnchor("BOTTOM", helmet, -MARGIN.WINDOW_SIDE / 2, MARGIN.WINDOW_SIDE / 2)
  warOfGodLaurel_W:SetRepeatCount(1)
  local textImage = widget:CreateDrawable(TEXTURE_PATH.KILL_EFFECT_FIRST_KILL, "first", "overlay")
  textImage:AddAnchor("BOTTOM", widget, 0, 0)
  widget.textImage = textImage
  local textbox = widget:CreateChildWidget("textbox", "textbox", 0, true)
  textbox:SetExtent(200, FONT_SIZE.LARGE)
  textbox:AddAnchor("TOP", textImage, "BOTTOM", 0, MARGIN.WINDOW_SIDE / 4)
  textbox.style:SetFontSize(FONT_SIZE.LARGE)
  textbox.style:SetShadow(true)
  widget.killCount = nil
  widget.animState = nil
  local function ResetAllTexture()
    warOfGodBg:Show(false)
    warOfGodLaurel_O:Show(false)
    warOfGodLaurel_W:Show(false)
    verticalBooldstain:Show(false)
    circleBooldstain:Show(false)
    circleFifthKill:Show(false)
    helmet:RemoveAllAnchors()
  end
  local GetTexts = function(count, killerName, victimName, threeKillCount)
    if threeKillCount ~= nil and threeKillCount ~= 0 then
      if threeKillCount % 3 == 1 then
        return X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "kill_alarm_text_1", killerName)
      elseif threeKillCount % 3 == 2 then
        return X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "kill_alarm_text_2", killerName)
      elseif threeKillCount % 3 == 0 then
        return X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "kill_alarm_text_3", killerName)
      end
    else
      return X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "kill_alarm_text_4", killerName, victimName)
    end
  end
  function widget:SetKillCountText(count, killerName, victimName, threeKillCount)
    self.textbox:SetTextAutoWidth(1000, GetTexts(count, killerName, victimName, threeKillCount), 10)
    specialKillCount = threeKillCount
  end
  function widget:SetKillCountTexture(count)
    local textures = centerMessageLocale.killEffect.resource
    local coords, helmetCoords, path
    if textures[count] ~= nil then
      coords = textures[count].key
      path = textures[count].texture
      helmetCoords = textures[count].helmetKey
    else
      coords = textures[6].key
      path = textures[6].texture
      helmetCoords = textures[6].helmetKey
    end
    self.textImage:SetTexture(path)
    self.textImage:SetTextureInfo(coords)
    self:SetAlphaAnimation(0, 1, 4599075939470750515, 4596373779694328218)
    self:SetStartAnimation(true, false)
    self.textbox:SetAlphaAnimation(0, 1, 4602678819172646912, 4600877379321698714)
    self.textbox:SetStartAnimation(true, false)
    self.killCount = count
    ResetAllTexture()
    helmet:SetTexture(path)
    if count >= 6 then
      warOfGodBg:Show(true)
      warOfGodLaurel_O:Show(true)
      helmet:SetTextureInfo(helmetCoords)
      helmet:AddAnchor("CENTER", self, 0, -MARGIN.WINDOW_SIDE / 2)
    else
      helmet:RemoveAllAnchors()
      if count < 5 then
        helmet:SetTextureInfo(helmetCoords)
        helmet:AddAnchor("CENTER", self, 0, 5)
      else
        helmet:SetTextureInfo(helmetCoords)
        helmet:SetExtent(134, 136)
        helmet:AddAnchor("CENTER", self, 0, -MARGIN.WINDOW_SIDE / 2)
      end
    end
  end
  function widget:SetKillCountSound(count)
    local soundTable = {
      "battlefield_kill_first",
      "battlefield_kill_second",
      "battlefield_kill_third",
      "battlefield_kill_fourth",
      "battlefield_kill_fifth",
      "battlefield_kill_more_than_sixth"
    }
    if count > 6 then
      count = 6
    end
    straightKillSoundId = F_SOUND.PlayUISound(soundTable[count], false)
  end
  local function SetKillCountVisibleEffect(count)
    if count >= 6 then
      warOfGodLaurel_W:SetVisible(true)
      warOfGodLaurel_W:SetEffectPriority(1, "alpha", 4596373779694328218, 4591870180066957722)
      warOfGodLaurel_W:SetEffectInitialColor(1, 1, 1, 1, 0)
      warOfGodLaurel_W:SetEffectFinalColor(1, 1, 1, 1, 1)
      warOfGodLaurel_W:SetEffectPriority(2, "alpha", 4596373779694328218, 4591870180066957722)
      warOfGodLaurel_W:SetEffectInitialColor(2, 1, 1, 1, 1)
      warOfGodLaurel_W:SetEffectFinalColor(2, 1, 1, 1, 0)
      warOfGodLaurel_W:SetStartEffect(true)
    else
      verticalBooldstain:SetVisible(true)
      verticalBooldstain:SetEffectPriority(1, "alpha", 4591870180066957722, 4587366580439587226)
      verticalBooldstain:SetEffectInitialColor(1, ConvertColor(224), 0, 0, 0)
      verticalBooldstain:SetEffectFinalColor(1, ConvertColor(224), 0, 0, 1)
      circleBooldstain:SetVisible(true)
      circleBooldstain:SetEffectPriority(1, "alpha", 4591870180066957722, 4587366580439587226)
      circleBooldstain:SetEffectInitialColor(1, ConvertColor(89), ConvertColor(26), ConvertColor(26), 0)
      circleBooldstain:SetEffectFinalColor(1, ConvertColor(89), ConvertColor(26), ConvertColor(26), 1)
      verticalBooldstain:SetStartEffect(true)
      circleBooldstain:SetStartEffect(true)
      if count == 1 then
        local coords = centerMessageLocale.killEffect.firstKilBloodlHelmetCoords
        helmet:SetTexture(TEXTURE_PATH.KILL_EFFECT_FIRST_KILL)
        helmet:SetTextureInfo(coords)
        helmet:SetExtent(104, 112)
      elseif count == 5 then
        circleFifthKill:SetVisible(true)
        circleFifthKill:SetMoveEffectType(1, "circle", 0, 0, 4599075939470750515, 4596373779694328218)
        circleFifthKill:SetMoveEffectCircle(1, 0, -40)
        circleFifthKill:SetEffectPriority(1, "colorr", 4599075939470750515, 4596373779694328218)
        circleFifthKill:SetEffectInitialColor(1, 1, 1, 1, 1)
        circleFifthKill:SetEffectFinalColor(1, ConvertColor(182), 0, 0, 1)
        circleFifthKill:SetStartEffect(true)
        verticalBooldstain:SetInterval(4591870180066957722)
        circleBooldstain:SetInterval(4591870180066957722)
      end
    end
  end
  local function SetKillCountUnvisibleEffect(count)
    if count < 6 then
      verticalBooldstain:SetVisible(false)
      circleBooldstain:SetVisible(false)
      if count == 5 then
        circleFifthKill:SetVisible(false)
      end
    else
      warOfGodBg:SetVisible(false)
    end
  end
  local isPlay = false
  local visibleTime
  local function OnAlphaAnimeEnd(self)
    if self.killCount == nil then
      return
    end
    SetKillCountVisibleEffect(self.killCount)
    if self.animState == "end_anim_end" then
      self:Show(false)
      self.animState = nil
      self.killCount = nil
    end
    visibleTime = 0
  end
  widget:SetHandler("OnAlphaAnimeEnd", OnAlphaAnimeEnd)
  local function FadeAwayEffectWidget(self, dt)
    if visibleTime == nil then
      return
    end
    if visibleTime ~= nil then
      visibleTime = visibleTime + dt
    end
    if self.animState == nil and visibleTime >= 800 then
      SetKillCountUnvisibleEffect(self.killCount)
      self.animState = "end_anim_end"
      self:SetAlphaAnimation(1, 0, 4602678819172646912, 4600877379321698714)
      self:SetStartAnimation(true, false)
      visibleTime = nil
    end
  end
  widget:SetHandler("OnUpdate", FadeAwayEffectWidget)
  local function OnHide()
    widget:ReleaseHandler("OnUpdate")
  end
  widget:SetHandler("OnHide", OnHide)
  local function OnEndFadeOut()
    killEffect = nil
    StartNextImgEvent()
  end
  widget:SetHandler("OnEndFadeOut", OnEndFadeOut)
  return widget
end
local specialKillSoundId
local function CreateKillSoundWidget(id, parent)
  local widget = UIParent:CreateWidget("window", id, parent)
  widget:SetExtent(1, 1)
  widget:AddAnchor("TOP", "UIParent", 0, -1)
  widget:EnableHidingIsRemove(true)
  widget:SetUILayer("game")
  local PlayThreeKillCountSound = function(threeKillCount)
    local sound
    if threeKillCount % 3 == 1 then
      sound = "battlefield_kill_eyes_on_fire"
    elseif threeKillCount % 3 == 2 then
      sound = "battlefield_kill_amazing_spirit"
    elseif threeKillCount % 3 == 0 then
      sound = "battlefield_kill_destruction_god"
    end
    if sound == nil then
      return
    end
    return F_SOUND.PlayUISound(sound, false)
  end
  local specialKillSoundPlayed = false
  local function OnUpdate(self, dt)
    if straightKillSoundId == nil then
      return
    end
    if specialKillCount == nil or specialKillCount == 0 then
      self:Show(false)
      return
    end
    if specialKillSoundPlayed and not X2Sound:IsPlaying(specialKillSoundId) then
      self:Show(false)
      return
    end
    local isPlaying = X2Sound:IsPlaying(straightKillSoundId)
    if not specialKillSoundPlayed and not isPlaying then
      specialKillSoundPlayed = true
      specialKillSoundId = PlayThreeKillCountSound(specialKillCount)
    end
  end
  widget:SetHandler("OnUpdate", OnUpdate)
  local function OnHide()
    X2BattleField:EndKillStreakSound()
    killEffectSound = nil
    straightKillSoundId = nil
    widget:ReleaseHandler("OnUpdate")
  end
  widget:SetHandler("OnHide", OnHide)
  return widget
end
function ShowKillEffectSound()
  if killEffectSound == nil then
    killEffectSound = CreateKillSoundWidget("killEffectSound", "UIParent")
  end
  killEffectSound:Show(true)
end
function ShowKillEffect(killStreak, killerName, victimName, threeKillCount)
  if killStreak <= 0 or killStreak == nil then
    UIParent:DevLog(string.format("invalid count, KName : %s", killerName or "nil"))
    return false
  end
  if killEffect == nil then
    killEffect = CreateKillEffect("killEffect", "UIParent")
  end
  killEffect:Show(true)
  ShowKillEffectSound()
  killEffect:SetKillCountTexture(killStreak)
  killEffect:SetKillCountSound(killStreak)
  killEffect:SetKillCountText(killStreak, killerName, victimName, threeKillCount)
  return true
end
