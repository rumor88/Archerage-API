local abilityLearnEffect
local function CreaetLearnAbilityEffect(id, parent)
  local window = UIParent:CreateWidget("window", id, parent)
  window:Show(false)
  window:SetExtent(515, 242)
  window:AddAnchor("TOP", "UIParent", 0, 60)
  window:SetUILayer("system")
  window:EnablePick(false)
  window:EnableHidingIsRemove(true)
  local imgframe = window:CreateChildWidget("emptyWidget", "imgframe", 0, true)
  imgframe:SetExtent(window:GetExtent())
  imgframe:AddAnchor("TOPLEFT", window, 0, 0)
  imgframe:EnablePick(false)
  local bg = imgframe:CreateEffectDrawableByKey(TEXTURE_PATH.LEARN_ABILITY, "bg", "background")
  bg:AddAnchor("TOPLEFT", imgframe, 3, 0)
  local effectSmoke = imgframe:CreateEffectDrawableByKey(TEXTURE_PATH.LEARN_ABILITY, "effect_smoke", "artwork")
  effectSmoke:AddAnchor("TOPLEFT", imgframe, 0, 3)
  local glow = imgframe:CreateEffectDrawableByKey(TEXTURE_PATH.LEARN_ABILITY, "glow", "artwork")
  glow:AddAnchor("TOPLEFT", imgframe, 15, 36)
  local sword = imgframe:CreateEffectDrawableByKey(TEXTURE_PATH.LEARN_ABILITY, "sword", "overlay")
  sword:AddAnchor("TOPLEFT", imgframe, 19, 45)
  local abilityBg = imgframe:CreateEffectDrawableByKey(TEXTURE_PATH.LEARN_ABILITY, "ability_bg", "overlay")
  abilityBg:AddAnchor("TOPLEFT", imgframe, 172, 59)
  abilityIconDrawables = {}
  abilityIconDrawableBgs = {}
  local abilityIconPosX = {
    188,
    254,
    320
  }
  function window:CreateLearnedAbilityDrawable(isSwap, abilityInfos)
    for i = 1, 3 do
      local coordInfo
      if abilityInfos[i] == nil then
        coordInfo = "icon_general"
      else
        coordInfo = string.format("icon_%s", X2Ability:GetAbilityStr(abilityInfos[i]))
      end
      abilityIconDrawables[i] = imgframe:CreateEffectDrawableByKey(TEXTURE_PATH.LEARN_ABILITY, coordInfo, "overlay")
      abilityIconDrawables[i]:AddAnchor("TOPLEFT", imgframe, abilityIconPosX[i], 64)
      abilityIconDrawableBgs[i] = imgframe:CreateEffectDrawableByKey(TEXTURE_PATH.LEARN_ABILITY, "icon_bg", "overlay")
      abilityIconDrawableBgs[i]:AddAnchor("TOPLEFT", imgframe, abilityIconPosX[i], 64)
    end
    self:SetAbilityText(isSwap, isHigAbility, abilityInfos)
    self:CreateAbilityIconAnimInfos(abilityIconDrawables, abilityIconDrawableBgs)
    self:SetAnimInfos()
  end
  local abilityBg = imgframe:CreateEffectDrawableByKey(TEXTURE_PATH.LEARN_ABILITY, "ability_bg", "overlay")
  abilityBg:AddAnchor("TOPLEFT", imgframe, 172, 59)
  local textFrame = window:CreateChildWidget("emptyWidget", "textFrame", 0, true)
  textFrame:AddAnchor("BOTTOM", window, "BOTTOM", 30, -70)
  textFrame:Show(false)
  textFrame:EnablePick(false)
  local titleMsg = textFrame:CreateChildWidget("label", "titleMsg", 0, true)
  titleMsg:SetExtent(100, FONT_SIZE.XLARGE)
  titleMsg:AddAnchor("TOP", textFrame, 0, 0)
  titleMsg.style:SetFontSize(FONT_SIZE.XLARGE)
  titleMsg.style:SetColorByKey("soft_yellow")
  titleMsg:EnablePick(false)
  local infoMsg = textFrame:CreateChildWidget("label", "infoMsg", 0, true)
  infoMsg:SetExtent(titleMsg:GetWidth(), FONT_SIZE.LARGE)
  infoMsg:AddAnchor("TOP", titleMsg, "BOTTOM", 0, 5)
  infoMsg.style:SetFontSize(FONT_SIZE.LARGE)
  infoMsg.style:SetColorByKey("soft_yellow")
  infoMsg:EnablePick(false)
  local width, height = F_LAYOUT.GetExtentWidgets(titleMsg, infoMsg)
  textFrame:SetExtent(width, height)
  function window:SetAbilityText(isSwap, isHigAbility, abilityInfos)
    local title = ""
    local info = ""
    if abilityInfos[2] and abilityInfos[3] == nil then
      local abilityName = X2Ability:GetAbilityStr(abilityInfos[2])
      local temp = locale.common.abilityNameWithStr(abilityName) or abilityName
      local result = string.format("[%s]", temp)
      title = X2Locale:LocalizeUiText(COMMON_TEXT, "learned_new_ability", result)
      info = GetCommonText("learned_new_ability_info_msg")
    end
    if isSwap or isSwap == false and abilityInfos[3] then
      local jobName = F_UNIT.GetPlayerJobName(abilityInfos[1], abilityInfos[2], abilityInfos[3])
      title = string.format("[%s]", jobName)
      info = X2Locale:LocalizeUiText(COMMON_TEXT, "had_job_msg", jobName)
    end
    titleMsg:SetText(title)
    infoMsg:SetText(info)
  end
  local swordImgMoveDist = sword:GetWidth() / 4
  local allDrawableAnimInfos = {
    {
      effectDrawable = bg,
      animData = {
        {
          startTime = 4607632778762754458,
          playTime = 4611235658464650854,
          scale = {4593311331947716280, 1},
          color = {
            {
              1,
              1,
              1,
              4593311331947716280
            },
            {
              1,
              1,
              1,
              1
            }
          }
        }
      }
    },
    {
      effectDrawable = effectSmoke,
      animData = {
        {
          startTime = 4612361558371493478,
          playTime = 4603579539098121011,
          scale = {4605380978949069210, 1},
          color = {
            {
              1,
              1,
              1,
              0
            },
            {
              1,
              1,
              1,
              1
            }
          }
        },
        {
          startTime = 4614838538166547251,
          playTime = 4600877379321698714,
          scale = {1, 4607407598781385933},
          color = {
            {
              1,
              1,
              1,
              1
            },
            {
              1,
              1,
              1,
              4602678819172646912
            }
          }
        }
      }
    },
    {
      effectDrawable = glow,
      animData = {
        {
          startTime = 4611911198408756429,
          playTime = 4606281698874543309,
          color = {
            {
              1,
              1,
              1,
              0
            },
            {
              1,
              1,
              1,
              1
            }
          }
        }
      }
    },
    {
      effectDrawable = sword,
      animData = {
        {
          startTime = 4608083138725491507,
          playTime = 4599075939470750515,
          color = {
            {
              1,
              1,
              1,
              0
            },
            {
              1,
              1,
              1,
              1
            }
          },
          moveX = {
            -swordImgMoveDist,
            0
          }
        },
        {
          startTime = 4609434218613702656,
          playTime = 4596373779694328218,
          moveX = {0, -5}
        },
        {
          startTime = 4610334938539176755,
          playTime = 4596373779694328218,
          moveX = {-5, 0}
        }
      }
    },
    {
      effectDrawable = abilityBg,
      animData = {
        {
          startTime = 0,
          playTime = 4596373779694328218,
          scale = {4605380978949069210, 1},
          color = {
            {
              1,
              1,
              1,
              0
            },
            {
              1,
              1,
              1,
              1
            }
          }
        },
        {
          startTime = 4608983858650965606,
          playTime = 4596373779694328218,
          moveX = {0, 2}
        },
        {
          startTime = 4609884578576439706,
          playTime = 4596373779694328218,
          moveX = {-2, 0}
        }
      }
    }
  }
  function window:CreateAbilityIconAnimInfos(abilityIconInfos, abilityIconInfoBgs)
    local firsetIconInfos = {
      effectDrawable = abilityIconInfos[1],
      animData = {
        {
          startTime = 4600877379321698714,
          playTime = 4599075939470750515,
          scale = {4608083138725491507, 1},
          color = {
            {
              1,
              1,
              1,
              0
            },
            {
              1,
              1,
              1,
              1
            }
          }
        },
        {
          startTime = 4608983858650965606,
          playTime = 4596373779694328218,
          moveX = {0, 2}
        },
        {
          startTime = 4609884578576439706,
          playTime = 4596373779694328218,
          moveX = {-2, 0}
        }
      }
    }
    table.insert(allDrawableAnimInfos, firsetIconInfos)
    local firsetIconBg = {
      effectDrawable = abilityIconInfoBgs[1],
      animData = {
        {
          startTime = 4608083138725491507,
          playTime = 4591870180066957722,
          color = {
            {
              1,
              1,
              1,
              0
            },
            {
              1,
              1,
              1,
              4602678819172646912
            }
          }
        },
        {
          startTime = 4608533498688228557,
          playTime = 4602678819172646912,
          color = {
            {
              1,
              1,
              1,
              4602678819172646912
            },
            {
              1,
              1,
              1,
              0
            }
          }
        }
      }
    }
    table.insert(allDrawableAnimInfos, firsetIconBg)
    local secondIconInfos = {
      effectDrawable = abilityIconInfos[2],
      animData = {
        {
          startTime = 4603579539098121011,
          playTime = 4599075939470750515,
          scale = {4608083138725491507, 1},
          color = {
            {
              1,
              1,
              1,
              0
            },
            {
              1,
              1,
              1,
              1
            }
          }
        },
        {
          startTime = 4608983858650965606,
          playTime = 4596373779694328218,
          moveX = {0, 2}
        },
        {
          startTime = 4609884578576439706,
          playTime = 4596373779694328218,
          moveX = {-2, 0}
        }
      }
    }
    table.insert(allDrawableAnimInfos, secondIconInfos)
    local secondIconBg = {
      effectDrawable = abilityIconInfoBgs[2],
      animData = {
        {
          startTime = 4608083138725491507,
          playTime = 4591870180066957722,
          color = {
            {
              1,
              1,
              1,
              0
            },
            {
              1,
              1,
              1,
              4602678819172646912
            }
          }
        },
        {
          startTime = 4608533498688228557,
          playTime = 4602678819172646912,
          color = {
            {
              1,
              1,
              1,
              4602678819172646912
            },
            {
              1,
              1,
              1,
              0
            }
          }
        }
      }
    }
    table.insert(allDrawableAnimInfos, secondIconBg)
    local thirdIconInfos = {
      effectDrawable = abilityIconInfos[3],
      animData = {
        {
          startTime = 4605380978949069210,
          playTime = 4599075939470750515,
          scale = {4608083138725491507, 1},
          color = {
            {
              1,
              1,
              1,
              0
            },
            {
              1,
              1,
              1,
              1
            }
          }
        },
        {
          startTime = 4608983858650965606,
          playTime = 4596373779694328218,
          moveX = {0, 2}
        },
        {
          startTime = 4609884578576439706,
          playTime = 4596373779694328218,
          moveX = {-2, 0}
        }
      }
    }
    table.insert(allDrawableAnimInfos, thirdIconInfos)
    local thirdIconBg = {
      effectDrawable = abilityIconInfoBgs[3],
      animData = {
        {
          startTime = 4608083138725491507,
          playTime = 4591870180066957722,
          color = {
            {
              1,
              1,
              1,
              0
            },
            {
              1,
              1,
              1,
              4602678819172646912
            }
          }
        },
        {
          startTime = 4608533498688228557,
          playTime = 4602678819172646912,
          color = {
            {
              1,
              1,
              1,
              4602678819172646912
            },
            {
              1,
              1,
              1,
              0
            }
          }
        }
      }
    }
    table.insert(allDrawableAnimInfos, thirdIconBg)
  end
  local allWidgetAnimInfos = {
    {
      widget = textFrame,
      animData = {
        {
          startTime = 4608983858650965606,
          playTime = 4599075939470750515,
          color = {
            {
              1,
              1,
              1,
              0
            },
            {
              1,
              1,
              1,
              1
            }
          }
        },
        {
          startTime = 4615739258092021350,
          playTime = 4605380978949069210,
          color = {
            {
              1,
              1,
              1,
              1
            },
            {
              1,
              1,
              1,
              0
            }
          }
        }
      }
    },
    {
      widget = imgframe,
      animData = {
        {
          startTime = 4615739258092021350,
          playTime = 4605380978949069210,
          scale = {1, 4607632778762754458},
          color = {
            {
              1,
              1,
              1,
              1
            },
            {
              1,
              1,
              1,
              0
            }
          }
        }
      }
    }
  }
  local function HideWindow()
    window:Show(false)
  end
  function window:SetAnimInfos()
    F_ANIMATION.SetEffectDrawableAnimInfos(allDrawableAnimInfos)
    F_ANIMATION.SetWidgetAnimInfos(window, allWidgetAnimInfos, 5100, HideWindow)
  end
  function window:OnDeleted()
    local procNextEvent = window.procNextEvent
    window:ReleaseHandler("OnUpdate")
    window = nil
    abilityLearnEffect = nil
    if procNextEvent == true then
      StartNextImgEvent()
    end
  end
  window:SetDeletedHandler(window.OnDeleted)
  local function OnEndFadeIn()
    F_ANIMATION.StartEffectDrawableAnimation(window, allDrawableAnimInfos, allWidgetAnimInfos)
  end
  window:SetHandler("OnEndFadeIn", OnEndFadeIn)
  return window
end
function ShowLearnAbilityEffect(isSwap)
  if abilityLearnEffect ~= nil then
    abilityLearnEffect.procNextEvent = false
    abilityLearnEffect:Show(false)
  end
  abilityLearnEffect = CreaetLearnAbilityEffect("learnAbilityEffect", "UIParent")
  abilityLearnEffect.procNextEvent = true
  local ab1 = X2Ability:GetAbilityFromView(1)
  local ab2 = X2Ability:GetAbilityFromView(2)
  local ab3 = X2Ability:GetAbilityFromView(3)
  abilityLearnEffect:CreateLearnedAbilityDrawable(isSwap, {
    ab1,
    ab2,
    ab3
  })
  abilityLearnEffect:Show(true)
  return true
end
