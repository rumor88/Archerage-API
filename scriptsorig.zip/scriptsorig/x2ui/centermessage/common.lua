function GetMessageWidgetHeight(widget)
  local lineSpace = 0
  local maxLine = widget:GetMaxLines()
  if maxLine > 1 then
    lineSpace = (maxLine - 1) * widget:GetLineSpace()
  end
  local height = maxLine * (widget.style:GetLineHeight() + 3)
  return height + lineSpace
end
CENTER_MSG_MAX_LINE = {SYS_ALERT = 2}
systemLayerParent = UIParent:CreateWidget("window", "systemLayerParent", "UIParent")
systemLayerParent:Show(true)
systemLayerParent:SetExtent(1, 1)
systemLayerParent:AddAnchor("TOPLEFT", "UIParent", 1, 1)
systemLayerParent:SetUILayer("system")
function SetHandlerOnUpdate(widget)
  local showingTime = 0
  function widget:OnUpdate(dt)
    showingTime = dt + showingTime
    if showingTime > 5000 then
      self:Show(false, 1000)
      self:ReleaseHandler("OnUpdate")
    end
  end
end
local CreateCenterMessageFrameType1 = function(id, parent)
  local window = UIParent:CreateWidget("window", id, parent)
  window:Show(false)
  window:SetExtent(946, 150)
  window:AddAnchor("TOP", "UIParent", 0, 60)
  window:EnablePick(false)
  window:SetUILayer("system")
  local bg = window:CreateDrawable(TEXTURE_PATH.ALARM_DECO, "bg", "background")
  bg:AddAnchor("BOTTOM", window, 0, 0)
  window.bg = bg
  local iconBg = window:CreateDrawable(TEXTURE_PATH.ALARM_DECO, "icon_bg", "background")
  iconBg:AddAnchor("CENTER", bg, "TOP", 0, 0)
  window.iconBg = iconBg
  local icon = window:CreateDrawable(TEXTURE_PATH.SIEGE_PERIOD, "start", "artwork")
  icon:AddAnchor("CENTER", window.iconBg, 0, 0)
  window.icon = icon
  local body = window:CreateChildWidget("textbox", "body", 0, true)
  body:SetLineSpace(TEXTBOX_LINE_SPACE.LARGE)
  body.style:SetFontSize(FONT_SIZE.LARGE)
  body.style:SetShadow(true)
  body:EnablePick(false)
  SetHandlerOnUpdate(window)
  return window
end
local CreateCenterMessageFrameType2 = function(id, parent)
  local frame = UIParent:CreateWidget("window", id, parent)
  frame:Show(false)
  frame:AddAnchor("TOP", "UIParent", 0, 60)
  frame:EnablePick(false)
  local bg = CreateContentBackground(frame, "TYPE8", "black")
  bg:AddAnchor("TOPLEFT", frame, -MARGIN.WINDOW_SIDE, MARGIN.WINDOW_SIDE / 4609434218613702656)
  bg:AddAnchor("BOTTOMRIGHT", frame, 0, MARGIN.WINDOW_SIDE / 4609434218613702656)
  frame.bg = bg
  local icon = frame:CreateDrawable(TEXTURE_PATH.SIEGE_PERIOD, "start", "overlay")
  icon:AddAnchor("LEFT", frame, -13, -7)
  frame.icon = icon
  local body = frame:CreateChildWidget("textbox", "body", 0, true)
  body:AddAnchor("LEFT", frame, 75, 5)
  body:SetLineSpace(TEXTBOX_LINE_SPACE.SMALL)
  body:SetExtent(1000, 30)
  body.style:SetSnap(true)
  body.style:SetFontSize(FONT_SIZE.XLARGE)
  body.style:SetShadow(true)
  body:EnablePick(false)
  function frame:SetTextWidth(str, minWidth)
    self.body:SetTextAutoWidth(1000, str, 5)
    local width = self.body:GetWidth()
    local height = self.body:GetTextHeight()
    width = width + self.icon:GetWidth()
    if minWidth > width then
      width = minWidth
    end
    self:SetExtent(width, height + MARGIN.WINDOW_SIDE * 4612811918334230528)
  end
  return frame
end
local function CreateCenterMessageFrameType3(id, parent)
  local window = UIParent:CreateWidget("window", id, parent)
  window:Show(false)
  window:SetExtent(0, 0)
  window:AddAnchor("TOP", "UIParent", 0, 60)
  window:EnablePick(false)
  window:SetUILayer("system")
  local smallLayoutContent = CreateCenterMessageFrameType2("smallLayoutContent", window)
  window.smallLayoutContent = smallLayoutContent
  smallLayoutContent:ReleaseHandler("OnUpdate")
  local bigLayoutContent = CreateCenterMessageFrameType1("bigLayoutContent", window)
  window.bigLayoutContent = bigLayoutContent
  bigLayoutContent:ReleaseHandler("OnUpdate")
  SetHandlerOnUpdate(window)
  return window
end
local CreateCenterMessageFrameType4 = function(id, parent)
  local window = UIParent:CreateWidget("window", id, parent)
  window:Show(false)
  window:SetExtent(946, 150)
  window:AddAnchor("TOP", "UIParent", 0, 60)
  window:EnablePick(false)
  window:SetUILayer("system")
  local bg = window:CreateDrawable(TEXTURE_PATH.ALARM_DECO, "bg", "background")
  bg:AddAnchor("BOTTOM", window, 0, 0)
  window.bg = bg
  local iconBg = window:CreateDrawable(TEXTURE_PATH.ALARM_DECO, "icon_bg", "background")
  iconBg:AddAnchor("CENTER", bg, "TOP", 0, 0)
  window.iconBg = iconBg
  local icon = window:CreateDrawable(TEXTURE_PATH.SIEGE_PERIOD, "start", "artwork")
  icon:AddAnchor("CENTER", window.iconBg, 0, 0)
  window.icon = icon
  local textImg = window:CreateDrawable(TEXTURE_PATH.HERO_ELECTION_RESULT_ICON, "hero_text", "overlay")
  textImg:AddAnchor("TOP", window, "BOTTOM", 0, MARGIN.WINDOW_SIDE / 4)
  window.textImg = textImg
  local body = window:CreateChildWidget("textbox", "body", 0, true)
  body.style:SetFontSize(FONT_SIZE.LARGE)
  body.style:SetShadow(true)
  body:EnablePick(false)
  SetHandlerOnUpdate(window)
  return window
end
local CreateCenterMessageFrameType5 = function(id, parent)
  local frame = UIParent:CreateWidget("window", id, parent)
  frame:Show(false)
  frame:SetExtent(445, 60)
  frame:AddAnchor("TOP", "UIParent", 0, 60)
  frame:EnablePick(false)
  frame:SetUILayer("system")
  local bg = CreateContentBackground(frame, "TYPE11", "black")
  bg:AddAnchor("TOPLEFT", frame, 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", frame, 0, 0)
  frame.bg = bg
  local itemIcon = CreateIconButton("icon", frame)
  itemIcon:AddAnchor("TOPLEFT", frame, 22, 9)
  itemIcon:EnablePick(false)
  frame.itemIcon = itemIcon
  local body = frame:CreateChildWidget("textbox", "body", 0, true)
  body:AddAnchor("LEFT", itemIcon, "RIGHT", 10, 0)
  body:SetWidth(350)
  body:SetAutoResize(true)
  body.style:SetFontSize(FONT_SIZE.XLARGE)
  body.style:SetShadow(true)
  body.style:SetAlign(ALIGN_LEFT)
  body:EnablePick(false)
  body.style:SetColorByKey("middle_brown")
  SetHandlerOnUpdate(frame)
  return frame
end
function CreateCenterMessageFrame(id, parent, styleType)
  if styleType == nil or styleType == "" then
    return
  end
  if styleType == "TYPE1" then
    return CreateCenterMessageFrameType1(id, parent)
  elseif styleType == "TYPE2" then
    return CreateCenterMessageFrameType2(id, parent)
  elseif styleType == "TYPE3" then
    return CreateCenterMessageFrameType3(id, parent)
  elseif styleType == "TYPE4" then
    return CreateCenterMessageFrameType4(id, parent)
  elseif styleType == "TYPE5" then
    return CreateCenterMessageFrameType5(id, parent)
  end
end
local imgEventPriority = {
  UNIT_KILL_STREAK = 1,
  LEVEL_CHANGED = 2,
  DOMINION_SIEGE_PERIOD_CHANGED = 3,
  DOMINION_SIEGE_UPDATE_TIMER = 3,
  DOMINION_GUARD_TOWER_STATE_NOTICE = 3,
  DOMINION = 3,
  FACTION_RELATION_CHANGED = 4,
  HERO_SEASON_OFF = 5,
  HERO_CANDIDATES_ANNOUNCED = 5,
  HERO_CANDIDATE_NOTI = 5,
  HERO_ELECTION_RESULT = 5,
  HERO_NOTI = 5,
  HERO_ELECTION_DAY_ALERT = 5,
  EQUIP_SLOT_REINFORCE_SLOT_LEVEL_UP = 6,
  EQUIP_SLOT_REINFORCE_SET_EFFECT = 6,
  EQUIP_SLOT_REINFORCE_LEVEL_EFFECT = 6,
  ABILITY_CHANGED = 7,
  SHOW_ADDED_ITEM = 8,
  COMPLETE_ACHIEVEMENT = 9,
  UPDATE_TODAY_ASSIGNMENT = 9,
  COMPLETE_CRAFT_ORDER = 10,
  TOWER_DEFENSE_MSG = 11,
  INSTANCE_ENTERABLE_MSG = 11,
  NUONS_ARROW_UI_MSG = 12,
  DOODAD_PHASE_UI_MSG = 12,
  EXPEDITION_LEVEL_UP = 13,
  EXPEDITION_WAR_STATE = 13,
  EXPEDITION_APPLICANT_ACCEPT = 13,
  EXPEDITION_APPLICANT_REJECT = 13,
  FAMILY_LEVEL_UP = 14,
  LOOT_PACK_ITEM_BROADCAST = 15,
  GRADE_ENCHANT_BROADCAST = 15,
  SCALE_ENCHANT_BROADCAST = 15,
  RANK_ALARM_MSG = 16,
  EVENT_SCHEDULE_START = 17,
  EVENT_SCHEDULE_STOP = 17
}
local imgEventDrawing = false
local imgEventQueue = {}
for k, v in pairs(imgEventPriority) do
  imgEventQueue[v] = {}
end
function GetImgEventPriority()
  return imgEventPriority
end
function MakeImgEventInfo(eventKey, pfunc, argList)
  local num = imgEventPriority[eventKey]
  if num == nil then
    return nil
  end
  local imgEventInfo = {
    key = eventKey,
    priority = imgEventPriority[eventKey],
    func = pfunc,
    params = argList
  }
  return imgEventInfo
end
function AddImgEventQueue(eventInfo, addDuplication)
  if eventInfo == nil then
    return
  end
  local queueTable = imgEventQueue[eventInfo.priority]
  local finded = false
  if addDuplication == nil or not addDuplication then
    for i = 1, #queueTable do
      if queueTable[i].key == eventInfo.key then
        queueTable[i] = eventInfo
        finded = true
        break
      end
    end
  end
  if not finded then
    queueTable[#queueTable + 1] = eventInfo
  end
  if not imgEventDrawing then
    StartNextImgEvent()
  end
end
function StartNextImgEvent()
  imgEventDrawing = false
  local eventInfo, index
  for i = 1, #imgEventQueue do
    for j = 1, #imgEventQueue[i] do
      if eventInfo == nil and imgEventQueue[i][j] ~= nil then
        eventInfo = imgEventQueue[i][j]
        index = j
        break
      end
    end
  end
  if eventInfo ~= nil then
    imgEventDrawing = eventInfo.func(eventInfo.params[1], eventInfo.params[2], eventInfo.params[3], eventInfo.params[4], eventInfo.params[5], eventInfo.params[6], eventInfo.params[7], eventInfo.params[8], eventInfo.params[9])
    local queueTable = imgEventQueue[eventInfo.priority]
    if index ~= nil then
      table.remove(queueTable, index)
    end
  end
end
