function CreateSiegeSystemAlarm(id, parent)
  local STATUS_ICON_SIZE = {
    WIDTH = 198,
    HEIGHT = 132,
    TEXTURE_WIDTH = 153,
    TEXTURE_HEIGHT = 102
  }
  local window = UIParent:CreateWidget("window", id, parent)
  window:Show(false)
  window:SetExtent(0, 0)
  window:AddAnchor("TOP", "UIParent", 0, 60)
  window:EnablePick(false)
  window:SetUILayer("system")
  local smallLayoutContent = window:CreateChildWidget("emptywidget", "smallLayoutContent", 0, true)
  smallLayoutContent:Show(false)
  smallLayoutContent:AddAnchor("TOP", window, 0, 80)
  smallLayoutContent:EnablePick(false)
  local bg = CreateContentBackground(smallLayoutContent, "TYPE8", "black")
  bg:AddAnchor("TOPLEFT", smallLayoutContent, -MARGIN.WINDOW_SIDE, MARGIN.WINDOW_SIDE / 4609434218613702656)
  bg:AddAnchor("BOTTOMRIGHT", smallLayoutContent, 0, MARGIN.WINDOW_SIDE / 4609434218613702656)
  smallLayoutContent.bg = bg
  local periodIcon = smallLayoutContent:CreateDrawable(TEXTURE_PATH.SIEGE_PERIOD, "start", "overlay")
  periodIcon:SetExtent(STATUS_ICON_SIZE.TEXTURE_WIDTH, STATUS_ICON_SIZE.TEXTURE_HEIGHT)
  periodIcon:AddAnchor("LEFT", smallLayoutContent, -13, -7)
  smallLayoutContent.periodIcon = periodIcon
  local statusText = smallLayoutContent:CreateChildWidget("textbox", "statusText", 0, true)
  statusText:AddAnchor("LEFT", smallLayoutContent, 75, 5)
  statusText:SetLineSpace(TEXTBOX_LINE_SPACE.SMALL)
  statusText:SetExtent(1000, 30)
  statusText.style:SetSnap(true)
  statusText.style:SetFontSize(FONT_SIZE.XLARGE)
  statusText.style:SetShadow(true)
  statusText:EnablePick(false)
  local bigLayoutContent = window:CreateChildWidget("emptywidget", "bigLayoutContent", 0, true)
  bigLayoutContent:Show(false)
  bigLayoutContent:SetExtent(946, 190)
  bigLayoutContent:AddAnchor("TOP", window, 0, 0)
  bigLayoutContent:EnablePick(false)
  local bg = bigLayoutContent:CreateDrawable(TEXTURE_PATH.ALARM_DECO, "bg", "background")
  bg:AddAnchor("BOTTOM", bigLayoutContent, 0, 0)
  local statusBg = bigLayoutContent:CreateDrawable(TEXTURE_PATH.ALARM_DECO, "icon_bg", "artwork")
  statusBg:AddAnchor("TOP", bigLayoutContent, 0, 0)
  bigLayoutContent.statusBg = statusBg
  local statusIcon = bigLayoutContent:CreateDrawable(TEXTURE_PATH.SIEGE_PERIOD, "start", "artwork")
  statusIcon:SetExtent(STATUS_ICON_SIZE.WIDTH, STATUS_ICON_SIZE.HEIGHT)
  statusIcon:AddAnchor("LEFT", statusBg, 10, -12)
  bigLayoutContent.statusIcon = statusIcon
  local statusTexture = bigLayoutContent:CreateDrawable(TEXTURE_PATH.SIEGE_PERIOD, "start", "overlay")
  statusTexture:AddAnchor("TOP", statusBg, "BOTTOM", 0, -(MARGIN.WINDOW_SIDE - 2))
  bigLayoutContent.statusTexture = statusTexture
  local statusText = bigLayoutContent:CreateChildWidget("textbox", "statusText", 0, true)
  statusText:AddAnchor("TOP", statusTexture, "BOTTOM", 0, 0)
  statusText:SetLineSpace(TEXTBOX_LINE_SPACE.SMALL)
  statusText.style:SetFontSize(FONT_SIZE.XLARGE)
  statusText.style:SetShadow(true)
  statusText:EnablePick(false)
  window.engravingName = nil
  local OnEndFadeOut = function(self)
    StartNextImgEvent()
  end
  window:SetHandler("OnEndFadeOut", OnEndFadeOut)
  local function BigLayoutDefaultSetting()
    window.bigLayoutContent.statusIcon:SetExtent(STATUS_ICON_SIZE.WIDTH, STATUS_ICON_SIZE.HEIGHT)
    window.bigLayoutContent.statusIcon:RemoveAllAnchors()
    window.bigLayoutContent.statusIcon:AddAnchor("LEFT", statusBg, 10, -12)
  end
  function window:SetInfo(period, str)
    if period ~= "siege_period_no_dominion" then
      self.bigLayoutContent.statusText:SetWidth(1000)
      self.bigLayoutContent.statusText:SetText(str)
    else
      return
    end
  end
  local function SetTextureBigLayout(coords)
    window.bigLayoutContent.statusTexture:SetTextureInfo(coords)
  end
  local function SetResultIcon(isWin)
    if isWin then
      window.bigLayoutContent.statusIcon:SetTexture(TEXTURE_PATH.SIEGE_ENGRAVING_START)
      window.bigLayoutContent.statusIcon:SetTextureInfo("image")
    else
      window.bigLayoutContent.statusIcon:SetTexture(TEXTURE_PATH.SIEGE_RESULT_ICON)
      window.bigLayoutContent.statusIcon:SetTextureInfo("image")
    end
  end
  local function SetResultTexture(zoneGroupType)
    local path = TEXTURE_PATH.SIEGE_RESULT_TEXT
    local coords
    window.bigLayoutContent.statusTexture:SetTexture(TEXTURE_PATH.SIEGE_RESULT_TEXT)
    local winner = X2Dominion:IsSiegeWinnerMyFaction(zoneGroupType)
    if winner then
      SetResultIcon(true)
      coords = "sieg"
    else
      SetResultIcon(false)
      coords = "niederlage"
    end
    SetTextureBigLayout(coords)
  end
  local function SetWatchGameResultTexture(isDefense)
    local path = TEXTURE_PATH.SIEGE_RESULT_WATCH
    local coords
    window.bigLayoutContent.statusTexture:SetTexture(TEXTURE_PATH.SIEGE_RESULT_WATCH)
    if isDefense then
      SetResultIcon(true)
      coords = "defenders"
    else
      SetResultIcon(true)
      coords = "invaders"
    end
    SetTextureBigLayout(coords)
  end
  function window:SetFontColor(period, team, defenseWin)
    self.bigLayoutContent.statusText.style:SetColorByKey("white")
    if period == "siege_period_peace" or period == "siege_period_auction" then
      if isMyInfo then
        local myTeamLose = false
        if defenseWin and team == "offense_team" then
          myTeamLose = true
        elseif defenseWin == false and team == "defense_team" then
          myTeamLose = true
        end
        if myTeamLose then
          self.bigLayoutContent.statusText.style:SetColorByKey("gray")
        end
      end
    else
      return
    end
  end
  function window:SetLayoutSiegeSchedule(period, action, onEvent, isMyInfo, defenseWin, zoneGroupType)
    self.bigLayoutContent:Show(false)
    self.smallLayoutContent:Show(false)
    local width = self.bigLayoutContent.statusText:GetLongestLineWidth()
    local height = self.bigLayoutContent.statusText:GetTextHeight()
    self.bigLayoutContent.statusText:SetExtent(width + 10, height)
    BigLayoutDefaultSetting()
    local anchorX = 10
    if period == "siege_period_ready_to_siege" then
      if action == "change_state" then
        self.bigLayoutContent.statusIcon:SetTexture(TEXTURE_PATH.SIEGE_READY_TO_SIEGE)
        self.bigLayoutContent.statusIcon:SetTextureInfo("image")
        self.bigLayoutContent.statusTexture:SetTexture(TEXTURE_PATH.SIEGE_READY_TO_SIEGE)
        if onEvent then
          self.bigLayoutContent.statusTexture:SetTextureInfo("start")
        else
          self.bigLayoutContent.statusTexture:SetTextureInfo("progress")
        end
      elseif action == "declared_siege" then
        anchorX = 21
        self.bigLayoutContent.statusIcon:SetTexture(TEXTURE_PATH.SIEGE_DECLARE)
        self.bigLayoutContent.statusIcon:SetTextureInfo("image")
        self.bigLayoutContent.statusTexture:SetTexture(TEXTURE_PATH.SIEGE_DECLARE)
        self.bigLayoutContent.statusTexture:SetTextureInfo("declared")
      end
    elseif period == "siege_period_siege" then
      self.bigLayoutContent.statusIcon:SetTexture(TEXTURE_PATH.SIEGE_PERIOD)
      self.bigLayoutContent.statusIcon:SetTextureInfo("image")
      self.bigLayoutContent.statusTexture:SetTexture(TEXTURE_PATH.SIEGE_PERIOD)
      if onEvent then
        self.bigLayoutContent.statusTexture:SetTextureInfo("start")
      else
        self.bigLayoutContent.statusTexture:SetTextureInfo("progress")
      end
    elseif period == "siege_period_peace" then
      if isMyInfo then
        SetResultTexture(zoneGroupType)
      else
        SetWatchGameResultTexture(defenseWin)
      end
    else
      return
    end
    self.bigLayoutContent.statusIcon:RemoveAllAnchors()
    self.bigLayoutContent.statusIcon:AddAnchor("LEFT", self.bigLayoutContent.statusBg, anchorX, -12)
    self.bigLayoutContent:Show(true)
  end
  function window:SetInfoGuardTower(msg)
    self.smallLayoutContent.statusText:SetWidth(1000)
    self.smallLayoutContent.statusText:SetText(msg)
  end
  function window:SetLayoutGuardTower()
    self.bigLayoutContent:Show(false)
    self.smallLayoutContent:Show(false)
    local width = self.smallLayoutContent.statusText:GetLongestLineWidth()
    local height = self.smallLayoutContent.statusText:GetTextHeight()
    self.smallLayoutContent:Show(true)
    self.smallLayoutContent:SetExtent(width + STATUS_ICON_SIZE.TEXTURE_WIDTH, height + MARGIN.WINDOW_SIDE * 4612811918334230528)
    self.smallLayoutContent.statusText.style:SetColorByKey("red")
    self.smallLayoutContent.statusText:SetExtent(width + 10, height)
    self.smallLayoutContent.statusText:RemoveAllAnchors()
    self.smallLayoutContent.statusText:AddAnchor("LEFT", self.smallLayoutContent, 75, 15)
    self.smallLayoutContent.periodIcon:SetTexture(TEXTURE_PATH.SIEGE_GUARD_TOWER_ATTACK)
    self.smallLayoutContent.periodIcon:SetTextureInfo("image")
  end
  function window:SetInfoEngraving(status, msg)
    if status == "siege_alert_engraving_started" or status == "siege_alert_engraving_stopped" then
      self.smallLayoutContent.statusText:SetWidth(1000)
      self.smallLayoutContent.statusText:SetText(msg)
    else
      return
    end
  end
  function window:SetLayoutEngraving(status)
    self.bigLayoutContent:Show(false)
    self.smallLayoutContent:Show(false)
    if status == "siege_alert_engraving_started" or status == "siege_alert_engraving_stopped" then
      local width = self.smallLayoutContent.statusText:GetLongestLineWidth()
      local height = self.smallLayoutContent.statusText:GetTextHeight()
      if status == "siege_alert_engraving_started" then
        self.smallLayoutContent.statusText.style:SetColorByKey("skyblue")
        self.smallLayoutContent.periodIcon:SetTexture(TEXTURE_PATH.SIEGE_ENGRAVING_START)
        self.smallLayoutContent.periodIcon:SetTextureInfo("image")
      elseif status == "siege_alert_engraving_stopped" then
        self.smallLayoutContent.statusText.style:SetColorByKey("original_light_gray")
        self.smallLayoutContent.periodIcon:SetTexture(TEXTURE_PATH.SIEGE_RESULT_ICON)
        self.smallLayoutContent.periodIcon:SetTextureInfo("image")
      else
        return
      end
      self.smallLayoutContent:Show(true)
      self.smallLayoutContent:SetExtent(width + STATUS_ICON_SIZE.TEXTURE_WIDTH, height + MARGIN.WINDOW_SIDE * 4612811918334230528)
      self.smallLayoutContent.statusText:SetExtent(width + 10, height)
      self.smallLayoutContent.statusText:RemoveAllAnchors()
      self.smallLayoutContent.statusText:AddAnchor("LEFT", self.smallLayoutContent, 75, 15)
    end
  end
  function window:SetInfoReinforcement(msg)
    self.smallLayoutContent.statusText:SetWidth(1000)
    self.smallLayoutContent.statusText:SetText(msg)
  end
  function window:SetLayoutReinforcement()
    self.bigLayoutContent:Show(false)
    self.smallLayoutContent:Show(false)
    local width = self.smallLayoutContent.statusText:GetLongestLineWidth()
    local height = self.smallLayoutContent.statusText:GetTextHeight()
    self.smallLayoutContent.statusText.style:SetColorByKey("white")
    self.smallLayoutContent.periodIcon:SetTexture(TEXTURE_PATH.SIEGE_REINFORCEMENT)
    self.smallLayoutContent.periodIcon:SetTextureInfo("image")
    self.smallLayoutContent:Show(true)
    self.smallLayoutContent:SetExtent(width + STATUS_ICON_SIZE.TEXTURE_WIDTH, height + MARGIN.WINDOW_SIDE * 4612811918334230528)
    self.smallLayoutContent.statusText:SetExtent(width + 10, height)
    self.smallLayoutContent.statusText:RemoveAllAnchors()
    self.smallLayoutContent.statusText:AddAnchor("LEFT", self.smallLayoutContent, 75, 15)
  end
  function window:SetInfoDeclareTerritor(msg)
    self.bigLayoutContent.statusText.style:SetColorByKey("white")
    self.bigLayoutContent.statusText:SetWidth(1000)
    self.bigLayoutContent.statusText:SetText(msg)
  end
  function window:SetLayoutDeclareTerritory()
    self.bigLayoutContent:Show(false)
    self.smallLayoutContent:Show(false)
    self.bigLayoutContent:Show(true)
    local width = self.bigLayoutContent.statusText:GetLongestLineWidth()
    local height = self.bigLayoutContent.statusText:GetTextHeight()
    self.bigLayoutContent.statusText:SetExtent(width + 10, height)
    self.bigLayoutContent.statusIcon:SetTexture(TEXTURE_PATH.SIEGE_DECLARE_TERRITORY)
    self.bigLayoutContent.statusIcon:SetTextureInfo("image")
    self.bigLayoutContent.statusIcon:RemoveAllAnchors()
    self.bigLayoutContent.statusIcon:AddAnchor("CENTER", self.bigLayoutContent.statusBg, 0, -5)
    self.bigLayoutContent.statusTexture:SetTexture(TEXTURE_PATH.SIEGE_DECLARE_TERRITORY)
    SetTextureBigLayout("territory")
  end
  return window
end
siegeSystemAlarmWindow = CreateSiegeSystemAlarm("siegeSystemAlarmWindow", systemLayerParent)
