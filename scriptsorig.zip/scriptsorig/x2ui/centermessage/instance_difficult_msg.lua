local TEXTURE_INFO = {
  NORMAL = {
    PATH = "ui/battlefield/wave_normal.dds",
    KEY = "wave_normal"
  }
}
local function CreateSelectedInstanceDifficult(id, parent)
  local wnd = UIParent:CreateWidget("window", id, parent)
  wnd:AddAnchor("TOP", "UIParent", 0, 53)
  wnd:EnableHidingIsRemove(true)
  wnd:SetUILayer("system")
  wnd:EnablePick(false)
  local bg = wnd:CreateDrawable(TEXTURE_INFO.NORMAL.PATH, TEXTURE_INFO.NORMAL.KEY, "background")
  bg:AddAnchor("CENTER", wnd, 0, 0)
  wnd:SetExtent(bg:GetExtent())
  local number = wnd:CreateChildWidget("label", "title", 0, true)
  number:SetAutoResize(true)
  number:SetHeight(60)
  number.style:SetFont("img_font_combat", 60, FTK_IMAGETEXT)
  local difficultString = wnd:CreateChildWidget("label", "difficultString", 0, true)
  difficultString:SetAutoResize(true)
  difficultString:SetHeight(FONT_SIZE.XXLARGE)
  difficultString.style:SetFontSize(FONT_SIZE.XXLARGE)
  difficultString.style:SetShadow(true)
  difficultString:SetText(GetUIText(COMMON_TEXT, "selected_difficult"))
  if baselibLocale.needChangeWordOrder then
    difficultString:AddAnchor("RIGHT", number, "LEFT", -10, 0)
  else
    difficultString:AddAnchor("LEFT", number, "RIGHT", 10, 0)
  end
  local elapsed = 0
  function wnd:OnUpdate(dt)
    elapsed = elapsed + dt
    if elapsed > 1000 then
      wnd:Show(false, 200)
      wnd:ReleaseHandler("OnUpdate")
      return
    end
  end
  function wnd:SetInfo(difficult)
    number:SetText(tostring(difficult))
    number:RemoveAllAnchors()
    local x = baselibLocale.needChangeWordOrder and difficultString:GetWidth() / 2 or -(difficultString:GetWidth() / 2)
    local y = 0
    bg:SetTexture(TEXTURE_INFO.NORMAL.PATH)
    bg:SetTextureInfo(TEXTURE_INFO.NORMAL.KEY)
    number:AddAnchor("CENTER", wnd, x, y)
    wnd:SetExtent(bg:GetExtent())
    elapsed = 0
    wnd:SetHandler("OnUpdate", wnd.OnUpdate)
  end
  return wnd
end
local selectedDifficultMsg
function ShowSelectedInstanceDifficultMessage(difficult)
  if selectedDifficultMsg == nil then
    selectedDifficultMsg = CreateSelectedInstanceDifficult("selectedInstanceDifficult", "UIParent")
    function selectedDifficultMsg:OnHide()
      selectedDifficultMsg = nil
    end
    selectedDifficultMsg:SetHandler("OnHide", selectedDifficultMsg.OnHide)
  end
  selectedDifficultMsg:SetInfo(difficult)
  selectedDifficultMsg:Show(true, 200)
  selectedDifficultMsg:Raise()
end
function ForceSelectedInstanceDifficultMessage()
  if selectedDifficultMsg ~= nil and selectedDifficultMsg:IsVisible() then
    selectedDifficultMsg:Show(false)
  end
end
