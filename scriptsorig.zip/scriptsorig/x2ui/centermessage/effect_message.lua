local WND_WIDTH = 300
local WND_HEIGHT = 153
local SHOW_TIME = 800
function CreateEffectMsgWindow(id, parent)
  local msgWnd = UIParent:CreateWidget("emptywidget", id, parent)
  msgWnd:SetExtent(WND_WIDTH, WND_HEIGHT)
  msgWnd:AddAnchor("TOP", "UIParent", 0, 35)
  local OnEndFadeOut = function(self)
    StartNextImgEvent()
  end
  msgWnd:SetHandler("OnEndFadeOut", OnEndFadeOut)
  return msgWnd
end
local delay = 1
local function Setting_levelup_effect(msgWnd, level_text)
  if msgWnd.levelup_wing_texture == nil then
    local levelup_wing_texture = msgWnd:CreateEffectDrawableByKey(TEXTURE_PATH.LEVLE_UP, "wing", "background")
    levelup_wing_texture:AddAnchor("CENTER", msgWnd, 0, 0)
    levelup_wing_texture:SetRepeatCount(1)
    levelup_wing_texture:SetEffectPriority(1, "alpha", 0, 0)
    levelup_wing_texture:SetEffectScale(1, 4607632778762754458, 4607632778762754458, 4607632778762754458, 4607632778762754458)
    levelup_wing_texture:SetEffectInitialColor(1, 1, 1, 1, 0)
    levelup_wing_texture:SetEffectFinalColor(1, 1, 1, 1, 0)
    levelup_wing_texture:SetEffectPriority(2, "alpha", 4606281698874543309, 4605380978949069210)
    levelup_wing_texture:SetEffectInitialColor(2, 1, 1, 1, 0)
    levelup_wing_texture:SetEffectFinalColor(2, 1, 1, 1, 1)
    levelup_wing_texture:SetEffectScale(2, 4607632778762754458, 4606281698874543309, 4607632778762754458, 4606281698874543309)
    levelup_wing_texture:SetEffectInterval(2, 4612586738352862003)
    levelup_wing_texture:SetEffectPriority(3, "alpha", 1 + delay, 4606281698874543309 + delay)
    levelup_wing_texture:SetEffectScale(3, 4606281698874543309, 4606281698874543309, 4606281698874543309, 4606281698874543309)
    levelup_wing_texture:SetEffectInitialColor(3, 1, 1, 1, 1)
    levelup_wing_texture:SetEffectFinalColor(3, 1, 1, 1, 0)
    msgWnd.levelup_wing_texture = levelup_wing_texture
  end
  if msgWnd.levelup_rotate_texture == nil then
    local levelup_rotate_texture = msgWnd:CreateEffectDrawableByKey(TEXTURE_PATH.LEVLE_UP, "rotate", "background")
    levelup_rotate_texture:AddAnchor("CENTER", msgWnd, -3, 0)
    levelup_rotate_texture:SetRepeatCount(1)
    levelup_rotate_texture:SetInterval(4608533498688228557)
    levelup_rotate_texture:SetEffectPriority(1, "rotate", 1, 4606281698874543309)
    levelup_rotate_texture:SetEffectRotate(1, 0, 360)
    levelup_rotate_texture:SetEffectScale(1, 4602678819172646912, 1, 4602678819172646912, 1)
    levelup_rotate_texture:SetEffectInitialColor(1, 1, 1, 1, 0)
    levelup_rotate_texture:SetEffectFinalColor(1, 1, 1, 1, 1)
    levelup_rotate_texture:SetEffectPriority(2, "rotate", 4603579539098121011 + delay, 4602678819172646912 + delay)
    levelup_rotate_texture:SetEffectRotate(2, 0, 15)
    levelup_rotate_texture:SetEffectScale(2, 1, 4608533498688228557, 1, 4608533498688228557)
    levelup_rotate_texture:SetEffectInitialColor(2, 1, 1, 1, 1)
    levelup_rotate_texture:SetEffectFinalColor(2, 1, 1, 1, 0)
    msgWnd.levelup_rotate_texture = levelup_rotate_texture
  end
  if msgWnd.levelup_shield_texture == nil then
    local levelup_shield_texture = msgWnd:CreateEffectDrawableByKey(TEXTURE_PATH.LEVLE_UP, "shield", "background")
    levelup_shield_texture:AddAnchor("CENTER", msgWnd, 0, 2)
    levelup_shield_texture:SetRepeatCount(1)
    levelup_shield_texture:SetInterval(4602678819172646912)
    local max_size = 4606281698874543309
    levelup_shield_texture:SetEffectPriority(1, "alpha", 4605380978949069210, 4604480259023595110)
    levelup_shield_texture:SetEffectScale(1, 4604480259023595110, max_size, 4604480259023595110, max_size)
    levelup_shield_texture:SetEffectInitialColor(1, 1, 1, 1, 0)
    levelup_shield_texture:SetEffectFinalColor(1, 1, 1, 1, 1)
    levelup_shield_texture:SetEffectPriority(2, "scalex", 4600877379321698714, 4599075939470750515)
    levelup_shield_texture:SetEffectScale(2, max_size, 4605380978949069210, max_size, 4605380978949069210)
    levelup_shield_texture:SetEffectInterval(2, 4609884578576439706)
    levelup_shield_texture:SetEffectPriority(3, "alpha", 1 + delay, 4606281698874543309 + delay)
    levelup_shield_texture:SetEffectScale(3, 4605380978949069210, 4605380978949069210, 4605380978949069210, 4605380978949069210)
    levelup_shield_texture:SetEffectInitialColor(3, 1, 1, 1, 1)
    levelup_shield_texture:SetEffectFinalColor(3, 1, 1, 1, 0)
    msgWnd.levelup_shield_texture = levelup_shield_texture
  end
  if msgWnd.text_bg == nil then
    local text_bg = msgWnd:CreateEffectDrawableByKey(TEXTURE_PATH.LEVLE_UP, "bg", "background")
    text_bg:SetRepeatCount(1)
    text_bg:SetInterval(4605380978949069210)
    text_bg:SetEffectPriority(1, "alpha", 4602678819172646912, 4600877379321698714)
    text_bg:SetEffectInitialColor(1, 1, 1, 1, 0)
    text_bg:SetEffectFinalColor(1, 1, 1, 1, 4605380978949069210)
    text_bg:SetEffectInterval(1, 4611235658464650854)
    text_bg:SetEffectPriority(2, "alpha", 4604480259023595110 + delay, 4603579539098121011 + delay)
    text_bg:SetEffectInitialColor(2, 1, 1, 1, 4605380978949069210)
    text_bg:SetEffectFinalColor(2, 1, 1, 1, 0)
    msgWnd.text_bg = text_bg
  end
  if msgWnd.content_frame == nil then
    local content_frame = msgWnd:CreateChildWidget("emptywidget", "content_frame", 0, true)
    content_frame:Show(false)
    content_frame:SetExtent(334, 31)
    content_frame:AddAnchor("BOTTOM", msgWnd, 0, 0)
    msgWnd.text_bg:AddAnchor("CENTER", content_frame, 0, 0)
    local text = content_frame:CreateChildWidget("label", "text", 0, true)
    text:SetAutoResize(true)
    text:SetHeight(FONT_SIZE.XXLARGE)
    text:AddAnchor("CENTER", content_frame, 0, 0)
    text.style:SetFont(FONT_PATH.SUB, FONT_SIZE.XLARGE)
    text.style:SetColorByKey("level_up_blue")
  end
  msgWnd.startEffect = false
  msgWnd.effectCount = 0
  msgWnd.content_frame.text:SetText(level_text)
  msgWnd.showingTime = 0
  msgWnd:SetHandler("OnUpdate", msgWnd.OnUpdate)
end
effectMsgWindow = CreateEffectMsgWindow("effectMsgWindow", systemLayerParent)
effectMsgWindow:Show(true)
effectMsgWindow:EnablePick(false)
local function Setting_Heir_levelup_effect(msgWnd, level_text)
  if msgWnd.levelup_shield_texture == nil then
    local levelup_shield_texture = msgWnd:CreateEffectDrawableByKey(TEXTURE_PATH.HEIR_LEVEL_UP, "level_up", "background")
    levelup_shield_texture:AddAnchor("CENTER", msgWnd, 0, 2)
    levelup_shield_texture:SetRepeatCount(1)
    levelup_shield_texture:SetInterval(4602678819172646912)
    levelup_shield_texture:SetEffectPriority(1, "alpha", 4605380978949069210, 4604480259023595110)
    levelup_shield_texture:SetEffectInitialColor(1, 1, 1, 1, 0)
    levelup_shield_texture:SetEffectFinalColor(1, 1, 1, 1, 1)
    levelup_shield_texture:SetEffectPriority(2, "scalex", 4600877379321698714, 4599075939470750515)
    levelup_shield_texture:SetEffectInterval(2, 4609884578576439706)
    levelup_shield_texture:SetEffectPriority(3, "alpha", 1 + delay, 4606281698874543309 + delay)
    levelup_shield_texture:SetEffectInitialColor(3, 1, 1, 1, 1)
    levelup_shield_texture:SetEffectFinalColor(3, 1, 1, 1, 0)
    msgWnd.levelup_shield_texture = levelup_shield_texture
  end
  if msgWnd.text_bg == nil then
    local text_bg = msgWnd:CreateEffectDrawableByKey(TEXTURE_PATH.LEVLE_UP, "bg", "background")
    text_bg:SetRepeatCount(1)
    text_bg:SetInterval(4605380978949069210)
    text_bg:SetEffectPriority(1, "alpha", 4602678819172646912, 4600877379321698714)
    text_bg:SetEffectInitialColor(1, 1, 1, 1, 0)
    text_bg:SetEffectFinalColor(1, 1, 1, 1, 4605380978949069210)
    text_bg:SetEffectInterval(1, 4611235658464650854)
    text_bg:SetEffectPriority(2, "alpha", 4604480259023595110 + delay, 4603579539098121011 + delay)
    text_bg:SetEffectInitialColor(2, 1, 1, 1, 4605380978949069210)
    text_bg:SetEffectFinalColor(2, 1, 1, 1, 0)
    msgWnd.text_bg = text_bg
  end
  if msgWnd.content_frame == nil then
    local content_frame = msgWnd:CreateChildWidget("emptywidget", "content_frame", 0, true)
    content_frame:Show(false)
    content_frame:SetExtent(334, 31)
    content_frame:AddAnchor("BOTTOM", msgWnd, 0, 30)
    msgWnd.text_bg:AddAnchor("CENTER", content_frame, 0, 0)
    local text = content_frame:CreateChildWidget("label", "text", 0, true)
    text:SetAutoResize(true)
    text:SetHeight(FONT_SIZE.XXLARGE)
    text:AddAnchor("CENTER", content_frame, 0, 0)
    text.style:SetFont(FONT_PATH.SUB, FONT_SIZE.XLARGE)
    text.style:SetColorByKey("level_up_blue")
  end
  msgWnd.startEffect = false
  msgWnd.effectCount = 0
  msgWnd.content_frame.text:SetText(level_text)
  msgWnd.showingTime = 0
  msgWnd:SetHandler("OnUpdate", msgWnd.OnUpdate)
end
local heirEffectMsgWindow = CreateEffectMsgWindow("effectHeirMsgWindow", systemLayerParent)
heirEffectMsgWindow:Show(true)
heirEffectMsgWindow:EnablePick(false)
function effectMsgWindow:OnUpdate(dt)
  if Movie:GetNumOfPlayingCutscenes() > 0 then
    if self.content_frame:IsVisible() then
      self.content_frame:Show(false)
    else
      self.content_frame:Show(true)
      self.content_frame:Show(false)
    end
    self.showingTime = 0
    self.startEffect = false
    return
  end
  self.showingTime = dt + self.showingTime
  if not self.startEffect then
    if self.effectCount >= 1 then
      self.effectCount = 0
      self:Show(false)
      return
    end
    self.effectCount = self.effectCount + 1
    self.levelup_wing_texture:SetStartEffect(true)
    self.levelup_shield_texture:SetStartEffect(true)
    self.levelup_rotate_texture:SetStartEffect(true)
    self.text_bg:SetStartEffect(true)
    self.startEffect = true
  end
  local t = self.showingTime / SHOW_TIME
  if t > 1 then
    self.content_frame:Show(true, 700)
  end
  if t > 4615063718147915776 then
    self.content_frame:Show(false, 700)
    self:Show(false, 700)
  end
end
function heirEffectMsgWindow:OnUpdate(dt)
  if Movie:GetNumOfPlayingCutscenes() > 0 then
    if self.content_frame:IsVisible() then
      self.content_frame:Show(false)
    else
      self.content_frame:Show(true)
      self.content_frame:Show(false)
    end
    self.showingTime = 0
    self.startEffect = false
    return
  end
  self.showingTime = dt + self.showingTime
  if not self.startEffect then
    if self.effectCount >= 1 then
      self.effectCount = 0
      self:Show(false)
      return
    end
    self.effectCount = self.effectCount + 1
    self.levelup_shield_texture:SetStartEffect(true)
    self.text_bg:SetStartEffect(true)
    self.startEffect = true
  end
  local t = self.showingTime / SHOW_TIME
  if t > 1 then
    self.content_frame:Show(true, 700)
  end
  if t > 4615063718147915776 then
    self.content_frame:Show(false, 700)
    self:Show(false, 700)
  end
end
function ShowEffectMsgMessage(msgInfo)
  if msgInfo.type == "levelup" then
    effectMsgWindow:Show(true)
    Setting_levelup_effect(effectMsgWindow, msgInfo.msg)
    X2Chat:DispatchChatMessage(CMF_SYSTEM, msgInfo.msg)
  end
  if msgInfo.type == "heir_levelup" then
    heirEffectMsgWindow:Show(true)
    Setting_Heir_levelup_effect(heirEffectMsgWindow, msgInfo.msg)
    X2Chat:DispatchChatMessage(CMF_SYSTEM, msgInfo.msg)
  end
  return true
end
function ll()
  effectMsgWindow:Show(true)
  Setting_levelup_effect(effectMsgWindow, "level")
  X2Chat:DispatchChatMessage(CMF_SYSTEM, "level")
end
function pp()
  heirEffectMsgWindow:Show(true)
  Setting_Heir_levelup_effect(heirEffectMsgWindow, "heir")
  X2Chat:DispatchChatMessage(CMF_SYSTEM, "heir")
end
