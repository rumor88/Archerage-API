local GetItemGrade = function(grade, color)
  return string.format("%s%s", F_COLOR.SetHexFormatToGradeColor(color), grade)
end
local width = 450
local contentWidth = width - MARGIN.WINDOW_SIDE * 2
local function CreateResultSection(parent)
  local resultSection = parent:CreateChildWidget("emptywidget", "resultSection", 0, false)
  resultSection:SetWidth(width)
  parent:RegisterStack(resultSection)
  local resultLabel = resultSection:CreateChildWidget("label", "resultLabel", 0, false)
  resultLabel:SetExtent(contentWidth, FONT_SIZE.XXLARGE)
  resultLabel:AddAnchor("TOP", resultSection, 0, 0)
  resultLabel.style:SetFontSize(FONT_SIZE.XXLARGE)
  local detailResult = W_MODULE:Create("detailResult", resultSection, W_MODULE.TYPES.TEXTBOX)
  detailResult:AddAnchor("TOP", resultLabel, "BOTTOM", 0, 10)
  function resultSection:UpdateHeight()
    local _, height = F_LAYOUT.GetExtentWidgets(resultLabel, detailResult:IsVisible() and detailResult or resultLabel)
    resultSection:SetHeight(height)
  end
  return resultSection, resultLabel, detailResult
end
local CreateOkButton = function(parent)
  local buttonSet = W_MODULE:Create("buttonSet", parent, W_MODULE.TYPES.BUTTON_SET)
  buttonSet:AddButton("ok", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "ok"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    clickFunc = function()
      parent:Show(false)
    end
  })
  parent:RegisterStack(buttonSet, MARGIN.WINDOW_SIDE)
end
local resultStrTable = {
  [IGER_BREAK] = GetUIText(COMMON_TEXT, "great_failure"),
  [IGER_SUCCESS] = GetUIText(COMMON_TEXT, "success"),
  [IGER_GREAT_SUCCESS] = GetUIText(COMMON_TEXT, "great_success"),
  [IGER_RESTORE_DISABLE] = GetUIText(COMMON_TEXT, "success")
}
local function GetResultStr(resultCode)
  return resultStrTable[resultCode] or GetUIText(COMMON_TEXT, "failure")
end
local resultColor = {
  [IGER_BREAK] = "red",
  [IGER_SUCCESS] = "original_dark_orange",
  [IGER_GREAT_SUCCESS] = "team_blue",
  [IGER_RESTORE_DISABLE] = "green"
}
local function GetResultColor(resultCode)
  return resultColor[resultCode] or "red"
end
local function CreateGradeEnchantAlarmMessage(id, parent)
  local frame = CreateWindow(id, parent)
  frame:AddAnchor("TOP", parent, 0, 70)
  frame:SetSounds("dialog_common")
  frame:SetWidth(width)
  local resultSection, resultLabel, detailResult = CreateResultSection(frame)
  local function SetResultStr(resultCode)
    resultLabel.style:SetColorByKey(GetResultColor(resultCode))
    resultLabel:SetText(GetResultStr(resultCode))
  end
  local function SetDetailResultStr(resultCode)
    if resultCode ~= IGER_BREAK and resultCode ~= IGER_DISABLE then
      detailResult:Activate(false)
      return
    end
    local str = ""
    if resultCode == IGER_BREAK then
      str = GetUIText(ITEM_GRADE, "enchant_break")
      if breakRewardItemType ~= nil and breakRewardItemType ~= 0 and breakRewardItemCount ~= nil and breakRewardByMail then
        str = F_TEXT.SetEnterString(str, X2Locale:LocalizeUiText(COMMON_TEXT, "item_grade_enchant_fail_break_reward_mail_msg"))
      end
    elseif resultCode == IGER_DISABLE then
      str = GetUIText(ITEM_GRADE, "disable_enchant")
    end
    detailResult:SetData({
      [W_MODULE.ATTRIBUTE.TEXT] = str,
      colorKey = GetResultColor(resultCode)
    })
    detailResult:Activate(true)
    return
  end
  local function SetTitle(resultCode)
    if resultCode == IGER_RESTORE_DISABLE then
      frame:SetTitle(GetUIText(COMMON_TEXT, "item_reparing_damage_result"))
    else
      frame:SetTitle(GetUIText(COMMON_TEXT, "item_enchantment_result"))
    end
  end
  local function FillResult(resultCode)
    SetTitle(resultCode)
    SetResultStr(resultCode)
    SetDetailResultStr(resultCode)
    resultSection:UpdateHeight()
  end
  local itemSection = frame:CreateChildWidget("emptywidget", "itemSection", 0, false)
  itemSection:SetWidth(width)
  frame:RegisterStack(itemSection, 10)
  local gradeChangebox = W_MODULE:Create("gradeChangebox", itemSection, W_MODULE.TYPES.CHANGE_BOX_A, nil, {
    [W_MODULE.ATTRIBUTE.HIDE_VALUE_TITLE] = true
  })
  gradeChangebox:AddAnchor("TOP", itemSection, 0, 0)
  local function FillGrade(resultCode, oldGrade, newGrade)
    if resultCode ~= IGER_SUCCESS and resultCode ~= IGER_GREAT_SUCCESS and resultCode ~= IGER_DOWNGRADE then
      gradeChangebox:Activate(false)
      return false
    end
    gradeChangebox:SetData({
      [W_MODULE.ATTRIBUTE.UES_DOUBLE_ARROW] = resultCode == IGER_GREAT_SUCCESS and true or false,
      titleInfo = {
        title = GetUIText(AUCTION_TEXT, "item_grade")
      },
      left = {
        UpdateValueFunc = function(leftValueWidget)
          local oldGradeColor = X2Item:GradeColor(oldGrade)
          oldGradeColor = F_COLOR.Hex2Dec(oldGradeColor)
          leftValueWidget:SetText(X2Item:GradeName(oldGrade))
          F_COLOR.ApplyTextColor(leftValueWidget, oldGradeColor)
        end
      },
      right = {
        UpdateValueFunc = function(rightValueWidget)
          local newGradeColor = X2Item:GradeColor(newGrade)
          newGradeColor = F_COLOR.Hex2Dec(newGradeColor)
          rightValueWidget:SetText(X2Item:GradeName(newGrade))
          F_COLOR.ApplyTextColor(rightValueWidget, newGradeColor)
        end
      }
    })
    gradeChangebox:Activate(true)
    return true
  end
  local itemIcon = W_MODULE:Create("itemIcon", itemSection, W_MODULE.TYPES.ICON_VERTICAL, nil, {
    [W_MODULE.ATTRIBUTE.USE_ICON_DECO] = true,
    [W_MODULE.ATTRIBUTE.USE_NAME_BG] = false
  })
  local breakReward = W_MODULE:Create("breakReward", itemSection, W_MODULE.TYPES.DOUBLE_TITLE_BOX)
  local function FillItem(resultCode, visibleGrade, newGrade, itemInfo, breakRewardItemType, breakRewardItemCount, breakRewardByMail)
    if resultCode == IGER_DISABLE then
      itemInfo.isEnchantDisable = true
    elseif resultCode == IGER_RESTORE_DISABLE then
      itemInfo.isEnchantDisable = false
    elseif resultCode == IGER_BREAK then
      itemInfo["break"] = true
    end
    local firstWidget = visibleGrade and gradeChangebox or nil
    local lastWidget
    if resultCode == IGER_BREAK and breakRewardItemType ~= nil and breakRewardItemType ~= 0 and breakRewardItemCount ~= nil then
      itemIcon:Activate(false)
      breakReward:SetData({
        left = {
          titleInfo = {
            title = GetUIText(INSTANT_GAME_TEXT, "destruction")
          },
          type = "item",
          infos = {
            {itemInfo = itemInfo, stack = 1}
          }
        },
        right = {
          titleInfo = {
            title = GetUIText(COMMON_TEXT, "achievement_reward")
          },
          type = "item",
          infos = {
            {
              itemInfo = X2Item:GetItemInfoByType(breakRewardItemType),
              stack = breakRewardItemCount
            }
          }
        }
      })
      breakReward:Activate(true)
      if firstWidget == nil then
        firstWidget = breakReward
      end
      lastWidget = breakReward
    else
      breakReward:Activate(false)
      itemIcon:SetData({itemInfo = itemInfo, stack = 1})
      itemIcon:Activate(true)
      if firstWidget == nil then
        firstWidget = itemIcon
      end
      lastWidget = itemIcon
    end
    if visibleGrade then
      lastWidget:AddAnchor("TOP", gradeChangebox, "BOTTOM", 0, 10)
    else
      lastWidget:AddAnchor("TOP", itemSection, 0, 0)
    end
    local _, height = F_LAYOUT.GetExtentWidgets(firstWidget, lastWidget)
    itemSection:SetHeight(height)
  end
  local function FillItemSection(resultCode, oldGrade, newGrade, itemInfo, breakRewardItemType, breakRewardItemCount, breakRewardByMail)
    local visibleGrade = FillGrade(resultCode, oldGrade, newGrade)
    FillItem(resultCode, visibleGrade, newGrade, itemInfo, breakRewardItemType, breakRewardItemCount, breakRewardByMail)
  end
  CreateOkButton(frame)
  function frame:SetResult(resultCode, itemLink, oldGrade, newGrade, breakRewardItemType, breakRewardItemCount, breakRewardByMail)
    local itemInfo = X2Item:InfoFromLink(itemLink)
    FillResult(resultCode)
    FillItemSection(resultCode, oldGrade, newGrade, itemInfo, breakRewardItemType, breakRewardItemCount, breakRewardByMail)
    frame:ApplyAutoHeightByStack()
    self:Show(true)
  end
  return frame
end
local gradeEnchantAlarm = CreateGradeEnchantAlarmMessage("gradeEnchantAlarm", "UIParent")
gradeEnchantAlarm:AddAnchor("TOP", "UIParent", 0, 70)
function ShowGradeEnchantAlarmMessage(resultCode, itemLink, oldGrade, newGrade, breakRewardItemType, breakRewardItemCount, breakRewardByMail)
  gradeEnchantAlarm:SetResult(resultCode, itemLink, oldGrade, newGrade, breakRewardItemType, breakRewardItemCount, breakRewardByMail)
  gradeEnchantAlarm:Raise()
end
local function CreateAwakenAlarmMessage(id, parent)
  local frame = CreateWindow(id, parent)
  frame:AddAnchor("TOP", parent, 0, 70)
  frame:SetSounds("dialog_common")
  frame:SetWidth(width)
  frame:SetTitle(GetUIText(COMMON_TEXT, "item_awaken_result"))
  local resultSection, resultLabel, detailResult = CreateResultSection(frame)
  detailResult:SetData({
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(ITEM_GRADE, "disable_enchant")
  })
  detailResult.style:SetColorByKey("red")
  local function SetResult(resultCode)
    local str = GetUIText(COMMON_TEXT, "success")
    local color = "original_dark_orange"
    local detailStr = ""
    if resultCode ~= ICMR_SUCCESS then
      str = GetUIText(COMMON_TEXT, "failure")
      color = "red"
    end
    detailResult:Show(resultCode == ICMR_FAIL_DISABLE_ENCHANT)
    resultLabel.style:SetColorByKey(color)
    resultLabel:SetText(str)
    resultSection:UpdateHeight()
  end
  local itemIcon = W_MODULE:Create("itemIcon", frame, W_MODULE.TYPES.ICON_VERTICAL, nil, {
    [W_MODULE.ATTRIBUTE.USE_ICON_DECO] = true,
    [W_MODULE.ATTRIBUTE.USE_NAME_BG] = false
  })
  frame:RegisterStack(itemIcon, 10)
  local headerTable = W_MODULE:Create("headerTable", frame, W_MODULE.TYPES.HEADER_TABLE_A, {
    [W_MODULE.ATTRIBUTE.LEFT_WIDTH_PRESET] = "large"
  })
  local gearScoreKey = "gearScore"
  headerTable:AddRow(gearScoreKey, {
    title = {
      string = GetCommonText("gear_score")
    }
  })
  local bonusRateKey = "bonusRate"
  headerTable:AddRow(bonusRateKey, {
    title = {
      string = GetCommonText("bonus_rate")
    }
  })
  frame:RegisterStack(headerTable)
  local function UpdateHeaderTable(gearScoreInfo, bonusRate)
    local gearScoreStr = gearScoreInfo.current ~= nil and string.format("%d \226\150\182 %d", gearScoreInfo.old, gearScoreInfo.current) or GetCommonText("no_infomation")
    headerTable:UpdateRow(gearScoreKey, {
      value = {string = gearScoreStr}
    })
    headerTable:UpdateRow(bonusRateKey, {
      value = {
        string = string.format("+%d%%", bonusRate / 100)
      }
    })
  end
  CreateOkButton(frame)
  function frame:SetResult(result, oldGrade, oldGearScore, itemLink, bonusRate)
    SetResult(result)
    local itemInfo = X2Item:InfoFromLink(itemLink)
    itemIcon:SetData({itemInfo = itemInfo, stack = 1})
    UpdateHeaderTable({
      old = oldGearScore,
      current = itemInfo.gearScore ~= nil and itemInfo.gearScore.total or nil
    }, bonusRate)
    frame:ApplyAutoHeightByStack()
    frame:Show(true)
  end
  return frame
end
local awakenAlarm = CreateAwakenAlarmMessage("awakenAlarmMessage", "UIParent")
awakenAlarm:AddAnchor("TOP", "UIParent", 0, 70)
function ShowAwakenAlarmMessage(result, oldGrade, oldGearScore, itemLink, bonusRate)
  awakenAlarm:SetResult(result, oldGrade, oldGearScore, itemLink, bonusRate)
  awakenAlarm:Raise()
end
local function CreateScaleAlarmMessage(id, parent)
  local frame = CreateWindow(id, parent)
  frame:AddAnchor("TOP", parent, 0, 70)
  frame:SetSounds("dialog_common")
  frame:SetWidth(width)
  frame:SetTitle(GetUIText(COMMON_TEXT, "item_scale_result"))
  local resultSection, resultLabel, detailResult = CreateResultSection(frame)
  local function SetResult(result)
    resultLabel.style:SetColorByKey(GetResultColor(result))
    resultLabel:SetText(GetResultStr(result))
  end
  local function SetDetailResultStr(resultCode)
    if resultCode ~= IGER_BREAK and resultCode ~= IGER_DISABLE then
      detailResult:Activate(false)
      return
    end
    local str = ""
    if resultCode == IGER_BREAK then
      str = GetUIText(ITEM_GRADE, "enchant_break")
    elseif resultCode == IGER_DISABLE then
      str = GetUIText(ITEM_GRADE, "disable_enchant")
    end
    detailResult:SetData({
      [W_MODULE.ATTRIBUTE.TEXT] = str,
      colorKey = GetResultColor(resultCode)
    })
    detailResult:Activate(true)
    return
  end
  local function FillResult(result)
    SetResult(result)
    SetDetailResultStr(result)
    resultSection:UpdateHeight()
  end
  local middleSection = frame:CreateChildWidget("emptywidget", "middleSection", 0, false)
  middleSection:SetWidth(width)
  frame:RegisterStack(middleSection, 10)
  local changeBox = W_MODULE:Create("changeBox", middleSection, W_MODULE.TYPES.CHANGE_BOX_A, nil, {
    [W_MODULE.ATTRIBUTE.HIDE_VALUE_TITLE] = true
  })
  changeBox:AddAnchor("TOP", middleSection, 0, 0)
  local function SetPerformance(resultCode, beforeScale, afterScale)
    if resultCode ~= IGER_SUCCESS and resultCode ~= IGER_GREAT_SUCCESS and resultCode ~= IGER_DOWNGRADE then
      changeBox:Activate(false)
      return false
    end
    changeBox:SetData({
      [W_MODULE.ATTRIBUTE.UES_DOUBLE_ARROW] = resultCode == IGER_GREAT_SUCCESS and true or false,
      titleInfo = {
        title = GetUIText(COMMON_TEXT, "performance")
      },
      left = {
        UpdateValueFunc = function(leftValueWidget)
          leftValueWidget:SetText(beforeScale)
        end
      },
      right = {
        UpdateValueFunc = function(rightValueWidget)
          local colorKey = resultCode ~= IGER_DOWNGRADE and "blue" or "red"
          rightValueWidget.style:SetColorByKey(colorKey)
          rightValueWidget:SetText(afterScale)
        end
      }
    })
    changeBox:Activate(true)
    return true
  end
  local itemIcon = W_MODULE:Create("itemIcon", middleSection, W_MODULE.TYPES.ICON_VERTICAL, nil, {
    [W_MODULE.ATTRIBUTE.USE_ICON_DECO] = true,
    [W_MODULE.ATTRIBUTE.USE_NAME_BG] = false
  })
  local function FillMiddleSection(resultCode, itemInfo, beforeScale, afterScale)
    SetPerformance(resultCode, beforeScale, afterScale)
    if changeBox:IsVisible() then
      itemIcon:AddAnchor("TOP", changeBox, "BOTTOM", 0, 10)
    else
      itemIcon:AddAnchor("TOP", middleSection, 0, 0)
    end
    itemIcon:SetData({itemInfo = itemInfo, stack = 1})
    local _, height = F_LAYOUT.GetExtentWidgets(changeBox:IsVisible() and changeBox or itemIcon, itemIcon)
    middleSection:SetHeight(height)
  end
  CreateOkButton(frame)
  function frame:SetResult(result, itemLink, beforeScale, afterScale)
    local itemInfo = X2Item:InfoFromLink(itemLink)
    FillResult(result)
    FillMiddleSection(result, itemInfo, beforeScale, afterScale)
    frame:ApplyAutoHeightByStack()
    self:Show(true)
  end
  return frame
end
local scaleAlarm = CreateScaleAlarmMessage("scaleAlarmMessage", "UIParent")
function ShowScaleAlarmMessage(result, itemLink, beforeScale, afterScale)
  if beforeScale == "none" then
    beforeScale = "+0"
  end
  scaleAlarm:SetResult(result, itemLink, beforeScale, afterScale)
  scaleAlarm:Raise()
  scaleAlarm:RemoveAllAnchors()
  scaleAlarm:AddAnchor("TOP", "UIParent", 0, 70)
end
