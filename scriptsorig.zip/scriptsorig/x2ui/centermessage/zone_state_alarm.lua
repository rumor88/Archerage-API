local DELAY = 5000
local SHOW_DELAY = 500
local HIDE_DELAY = 500
local function CreateZoneStateAlarmWindow(id, parent)
  local wnd = CreateHudCommonWindow(id, parent, true)
  wnd:SetWidth(448)
  wnd:EnableHidingIsRemove(true)
  wnd:SetUILayer("system")
  wnd:Clickable(true)
  local offset = 15
  local title = wnd:CreateChildWidget("label", "title", 0, true)
  title:SetAutoResize(true)
  title:SetHeight(FONT_SIZE.XXLARGE)
  title.style:SetFont(FONT_PATH.SUB, FONT_SIZE.XXLARGE)
  title:AddAnchor("TOP", wnd, 0, wnd:GetUpperOffset() + offset)
  title.style:SetColorByKey("subzone_state_alarm")
  local statusWnd = wnd:CreateChildWidget("emptywidget", "statusWnd", 0, true)
  statusWnd:SetHeight(FONT_SIZE.XXLARGE)
  statusWnd:AddAnchor("TOP", title, "BOTTOM", 0, MARGIN.WINDOW_SIDE)
  local bg = statusWnd:CreateDrawable(TEXTURE_PATH.RISK_ALARM, "risk_alarm_back02", "background")
  bg:AddAnchor("CENTER", statusWnd, 0, 0)
  local icon = statusWnd:CreateDrawable(TEXTURE_PATH.RISK_ALARM, "peace", "background")
  icon:AddAnchor("LEFT", statusWnd, 0, 0)
  local label = statusWnd:CreateChildWidget("label", "label", 0, true)
  label:SetHeight(FONT_SIZE.XXLARGE)
  label:SetAutoResize(true)
  label.style:SetFont(FONT_PATH.SUB, FONT_SIZE.XXLARGE)
  label:AddAnchor("LEFT", icon, "RIGHT", 0, 0)
  local desc = wnd:CreateChildWidget("textbox", "desc", 0, true)
  desc:SetWidth(wnd:GetWidth() - MARGIN.WINDOW_SIDE * 2)
  desc:AddAnchor("TOP", statusWnd, "BOTTOM", 0, MARGIN.WINDOW_SIDE)
  desc:SetAutoResize(true)
  desc.style:SetFontSize(FONT_SIZE.LARGE)
  local accumulate = 0
  function wnd:OnUpdate(dt)
    accumulate = accumulate + dt
    if accumulate > DELAY then
      wnd:Show(false, HIDE_DELAY)
    end
  end
  local function Resize()
    statusWnd:SetWidth(icon:GetWidth() + label:GetWidth())
    local _, y = F_LAYOUT.GetExtentWidgets(title, desc)
    wnd:SetHeight(y + wnd:GetUpperOffset() + wnd:GetLowerOffset() + offset * 2)
  end
  function wnd:SetInfo(zoneInfo)
    if zoneInfo == nil then
      return
    end
    local color = F_COLOR.GetMsgZoneStateFontColor(zoneInfo)
    if color ~= nil then
      label.style:SetColorByKey(color)
      local colorTable = F_COLOR.GetColor(color)
      icon:SetColor(colorTable[1], colorTable[2], colorTable[3], colorTable[4])
    end
    title:SetText(zoneInfo.zoneName)
    if zoneInfo.isFestivalZone then
      icon:SetTextureInfo("festival")
      label.style:SetFont(FONT_PATH.SUB, FONT_SIZE.XXLARGE)
      label:SetText(GetCommonText("festival_zone"))
      desc:SetText(GetCommonText("festival_zone_msg_desc"))
    elseif zoneInfo.isConflictZone then
      local stateText = X2Map:GetZoneStateTextInfo(zoneInfo.conflictState)
      local isDangerState = zoneInfo.conflictState < HPWS_BATTLE
      if isDangerState then
        icon:SetWidth(0)
        label.style:SetFontSize(FONT_SIZE.XLARGE)
        label:SetText(stateText.stateTitle)
        desc:SetText(GetCommonText("low_conflict_zone_msg_desc"))
      elseif zoneInfo.conflictState == HPWS_BATTLE then
        icon:SetTextureInfo("war")
        label.style:SetFontSize(FONT_SIZE.XXLARGE)
        label:SetText(stateText.stateTitle)
        if zoneInfo.warChaos or zoneInfo.nonPeaceState then
          desc:SetText(GetCommonText("conflict_zone_msg_desc"))
        else
          desc:SetText(GetCommonText("middle_conflict_zone_msg_desc"))
        end
      elseif zoneInfo.conflictState == HPWS_WAR then
        icon:SetTextureInfo("war")
        label.style:SetFontSize(FONT_SIZE.XXLARGE)
        label:SetText(stateText.stateTitle)
        if zoneInfo.warChaos then
          desc:SetText(X2Locale:LocalizeUiText(COMMON_TEXT, "chaos_zone_msg_desc", F_COLOR.GetColor(color, true)))
        elseif zoneInfo.nonRate then
          desc:SetText(GetCommonText("conflict_zone_msg_desc"))
        else
          local zoneText = X2Locale:LocalizeUiText(COMMON_TEXT, "high_conflict_zone_msg_desc", tostring(zoneInfo.dropRate - 100), tostring(zoneInfo.goldRate - 100))
          desc:SetText(zoneText)
        end
      elseif zoneInfo.conflictState == HPWS_PEACE then
        icon:SetTextureInfo("peace")
        label.style:SetFontSize(FONT_SIZE.XXLARGE)
        label:SetText(stateText.stateTitle)
        if zoneInfo.nonRate then
          desc:SetText(GetCommonText("peace_zero_rate_conflict_zone_msg_desc"))
        else
          local zoneText = X2Locale:LocalizeUiText(COMMON_TEXT, "peace_conflict_zone_msg_desc", tostring(100 - zoneInfo.dropRate), tostring(100 - zoneInfo.goldRate))
          desc:SetText(zoneText)
        end
      end
    elseif zoneInfo.isSiegeZone then
      icon:SetTextureInfo("war")
      label.style:SetFontSize(FONT_SIZE.XXLARGE)
      label:SetText(GetCommonText("conflict_zone"))
      desc:SetText(GetCommonText("conflict_zone_msg_desc"))
    elseif zoneInfo.isNuiaProtectedZone then
      icon:SetWidth(0)
      label.style:SetFontSize(FONT_SIZE.XLARGE)
      label:SetText(GetCommonText("nuia_protection_zone"))
      desc:SetText(GetCommonText("nuia_protection_zone_msg_desc"))
    elseif zoneInfo.isHariharaProtectedZone then
      icon:SetWidth(0)
      label.style:SetFontSize(FONT_SIZE.XLARGE)
      label:SetText(GetCommonText("harihara_protection_zone"))
      desc:SetText(GetCommonText("harihara_protection_zone_msg_desc"))
    elseif zoneInfo.isPeaceZone then
      icon:SetTextureInfo("peace")
      label.style:SetFontSize(FONT_SIZE.XXLARGE)
      label:SetText(GetCommonText("non_pvp_zone"))
      desc:SetText(GetCommonText("non_pvp_zone_msg_desc"))
    else
      icon:SetTextureInfo("war")
      label.style:SetFontSize(FONT_SIZE.XXLARGE)
      label:SetText(GetCommonText("conflict_zone"))
      desc:SetText(GetCommonText("conflict_zone_msg_desc"))
    end
    accumulate = 0
    Resize()
  end
  return wnd
end
local windowWidth = UIParent:GetScreenWidth()
local windowHeight = UIParent:GetScreenHeight()
local zoneStateAlarmWnd
function ShowZoneStateAlarmWindow(zoneInfo)
  if zoneStateAlarmWnd == nil then
    zoneStateAlarmWnd = CreateZoneStateAlarmWindow("zoneStateAlarmWnd", "UIParent")
    zoneStateAlarmWnd:AddAnchor("TOP", "UIParent", "TOPLEFT", windowWidth * 3 / 4, windowHeight / 4)
    local function OnHide()
      zoneStateAlarmWnd = nil
    end
    zoneStateAlarmWnd:SetHandler("OnHide", OnHide)
    zoneStateAlarmWnd:SetHandler("OnUpdate", zoneStateAlarmWnd.OnUpdate)
  end
  zoneStateAlarmWnd:SetInfo(zoneInfo)
  zoneStateAlarmWnd:Show(true, SHOW_DELAY)
end
