local grade_sound_type = {
  "",
  "",
  "event_item_uncommon_added",
  "event_item_rare_added",
  "event_item_ancient_added",
  "event_item_heroic_added",
  "event_item_unique_added",
  "event_item_artifact_added",
  "event_item_wonder_added",
  "event_item_epic_added",
  "event_item_legendary_added",
  "event_item_mythic_added"
}
local iconSize = F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_42)
local function CalcMessageTextExtent(widget, topText, bottomText)
  local message_widget_width = widget.style:GetTextWidth(topText)
  local name_textbox_width = widget.itemName:GetLongestLineWidth()
  return math.max(message_widget_width, name_textbox_width) + iconSize * 2
end
local function SetItemInfo(item)
  if item == nil then
    return
  end
  local itemType = item.itemType
  local isQuestStartItem = X2Quest:IsQuestStartItem(itemType)
  local isUseItemInActiveQuest = X2Quest:IsUseItemInActiveQuest(itemType)
  local sound_Type = "event_item_added"
  local topText = string.format("%s", locale.chatSystem.get_item)
  if isQuestStartItem == true then
    topText = string.format("%s", locale.chatSystem.get_quest_start_item)
  elseif isUseItemInActiveQuest == true then
    topText = string.format("%s", locale.chatSystem.get_use_item_in_active_quest)
  elseif item.item_impl == "weapon" or item.item_impl == "armor" or item.item_impl == "mate_armor" or item.item_impl == "accessory" then
    topText = string.format("%s", locale.chatSystem.get_quest_item)
    if item.itemGrade < 2 then
      sound_Type = grade_sound_type[item.itemGrade + 1]
    end
  else
    topText = string.format("%s", locale.chatSystem.get_quest_item)
  end
  if topText ~= "" then
    F_SOUND.PlayUISound(sound_Type, true)
    local bottomText = item.name
    local gradeColor = F_COLOR.SetHexFormatToGradeColor(item.gradeColor)
    addedItemWindow.itemName:SetTextAutoWidth(1000, string.format("%s%s", gradeColor, bottomText), 12)
    local width = CalcMessageTextExtent(addedItemWindow, topText, bottomText)
    addedItemWindow:SetWidth(width)
    addedItemWindow:AddMessage(string.format("%s%s", gradeColor, topText))
    addedItemWindow:ResetPosition()
    addedItemWindow:Show(true)
    addedItemWindow.showingTime = 0
    addedItemWindow:SetHandler("OnUpdate", addedItemWindow.OnUpdate)
    addedItemWindow.bg:SetTextureColor("deep_black")
    addedItemWindow.bg:SetExtent(width + 60, iconSize * 2)
    addedItemWindow.bg:RemoveAllAnchors()
    addedItemWindow.bg:AddAnchor("TOPLEFT", addedItemWindow, -40, -(iconSize / 4610785298501913805))
    addedItemWindow.itemSlot:SetInfo(item)
    addedItemWindow:Raise()
  end
end
function ShowAddedItemMsg(item, count)
  if count <= 0 then
    return false
  end
  if addedItemWindow:IsVisible() then
    return false
  end
  local OnEndFadeOut = function(self)
    StartNextImgEvent()
  end
  if not addedItemWindow:HasHandler("OnEndFadeOut") then
    addedItemWindow:SetHandler("OnEndFadeOut", OnEndFadeOut)
  end
  SetItemInfo(item)
  return true
end
function addedItemWindow:OnUpdate(dt)
  self.showingTime = dt + self.showingTime
  local showTime = 3000
  local t = self.showingTime / showTime
  if t > 1 then
    self:Show(false, 2000)
    self:ReleaseHandler("OnUpdate")
  end
end
