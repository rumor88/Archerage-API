local CreateGradeEnchantBroadcastAlarmMessage = function(id, parent)
  local frame = CreateEmptyWindow(id, parent)
  frame:SetExtent(946, 180)
  frame:AddAnchor("TOP", parent, 0, 60)
  frame:SetUILayer("system")
  frame:EnablePick(false)
  local bg = frame:CreateDrawable(TEXTURE_PATH.ALARM_DECO, "bg", "background")
  bg:AddAnchor("BOTTOM", frame, 0, 0)
  local statusBg = frame:CreateDrawable(TEXTURE_PATH.ALARM_DECO, "icon_bg", "artwork")
  statusBg:AddAnchor("TOP", frame, 0, 0)
  local itemBg = frame:CreateDrawable(TEXTURE_PATH.GRADE_ENCHANT_BROADCAST_ALARM, "bg", "artwork")
  itemBg:AddAnchor("CENTER", statusBg, -1, 2)
  frame.itemBg = itemBg
  local itemIcon = CreateIconButton("itemIcon", frame)
  itemIcon:EnablePick(false)
  itemIcon:AddAnchor("CENTER", itemBg, 1, 2)
  frame.itemIcon = itemIcon
  local itemName = frame:CreateChildWidget("label", "itemName", 0, true)
  itemName:SetAutoResize(true)
  itemName:SetHeight(FONT_SIZE.LARGE)
  itemName.style:SetShadow(true)
  itemName.style:SetFontSize(FONT_SIZE.LARGE)
  itemName:AddAnchor("TOP", itemIcon, "BOTTOM", 0, MARGIN.WINDOW_SIDE / 4)
  local arrow = frame:CreateDrawable(TEXTURE_PATH.HUD, "double_arrow", "overlay")
  arrow:AddAnchor("TOP", itemName, "BOTTOM", 0, MARGIN.WINDOW_SIDE / 4615063718147915776)
  frame.arrow = arrow
  local oldGradeLabel = frame:CreateChildWidget("label", "oldGradeLabel", 0, true)
  oldGradeLabel:SetAutoResize(true)
  oldGradeLabel:SetHeight(FONT_SIZE.LARGE)
  oldGradeLabel.style:SetShadow(true)
  oldGradeLabel.style:SetFontSize(FONT_SIZE.LARGE)
  oldGradeLabel:AddAnchor("RIGHT", arrow, "LEFT", -2, 0)
  local newGradeLabel = frame:CreateChildWidget("label", "newGradeLabel", 0, true)
  newGradeLabel:SetAutoResize(true)
  newGradeLabel:SetHeight(FONT_SIZE.LARGE)
  newGradeLabel.style:SetShadow(true)
  newGradeLabel.style:SetFontSize(FONT_SIZE.LARGE)
  newGradeLabel:AddAnchor("LEFT", arrow, "RIGHT", 4, 0)
  local content = frame:CreateChildWidget("textbox", "content", 0, true)
  content:SetHeight(FONT_SIZE.XLARGE)
  content.style:SetFontSize(FONT_SIZE.XLARGE)
  content.style:SetShadow(true)
  content:AddAnchor("TOP", arrow, "BOTTOM", 0, MARGIN.WINDOW_SIDE / 3)
  local function SetArrowTexture(resultCode)
    if resultCode == IEBCT_ENCHANT_SUCCESS or resultCode == IEBCT_EVOVING then
      frame.arrow:SetTextureInfo("single_arrow")
    elseif resultCode == IGER_GREAT_SUCCESS then
      frame.arrow:SetTextureInfo("double_arrow")
    end
  end
  local OnHide = function(self)
    self:ReleaseHandler("OnUpdate")
  end
  frame:SetHandler("OnHide", OnHide)
  local OnEndFadeOut = function(self)
    StartNextImgEvent()
  end
  frame:SetHandler("OnEndFadeOut", OnEndFadeOut)
  local yellowColor = F_COLOR.GetColor("soft_yellow", true)
  local skyColor = F_COLOR.GetColor("skyblue", true)
  function frame:SetResult(characterName, resultCode, itemLink, oldGrade, newGrade)
    local itemInfo = X2Item:InfoFromLink(itemLink)
    local oldGradeColor = X2Item:GradeColor(oldGrade)
    oldGradeColor = F_COLOR.Hex2Dec(oldGradeColor)
    local oldGradeName = X2Item:GradeName(oldGrade)
    oldGradeName = string.format("[%s]", oldGradeName)
    local newGradeColor = F_COLOR.Hex2Dec(X2Item:GradeColor(newGrade))
    local newGradeColorStr = F_COLOR.SetHexFormatToGradeColor(X2Item:GradeColor(newGrade))
    local newGradeName = X2Item:GradeName(newGrade)
    newGradeName = string.format("[%s]", newGradeName)
    F_COLOR.ApplyTextureColor(self.itemBg, newGradeColor)
    F_COLOR.ApplyTextureColor(self.arrow, newGradeColor)
    F_COLOR.ApplyTextColor(self.oldGradeLabel, oldGradeColor)
    F_COLOR.ApplyTextColor(self.newGradeLabel, newGradeColor)
    F_COLOR.ApplyTextColor(self.itemName, newGradeColor)
    itemInfo.itemGrade = newGrade
    self.itemIcon:SetInfo(itemInfo)
    self.oldGradeLabel:SetText(oldGradeName)
    self.newGradeLabel:SetText(newGradeName)
    self.itemName:SetText(itemInfo.name)
    SetArrowTexture(resultCode)
    local text = ""
    if resultCode == IEBCT_ENCHANT_SUCCESS then
      text = locale.physicalEnchant.broadcast_success_alarm(yellowColor, characterName, skyColor)
    elseif resultCode == IEBCT_ENCHANT_GREATE_SUCCESS then
      text = locale.physicalEnchant.broadcast_great_success_alarm(yellowColor, characterName, skyColor)
    elseif resultCode == IEBCT_EVOVING then
      text = locale.physicalEnchant.broadcast_evolving_alarm(yellowColor, characterName, skyColor, newGradeColorStr, newGradeName)
    end
    self.content:SetTextAutoWidth(1000, text, 10)
    local showTime = 0
    local function OnUpdate(self, dt)
      showTime = dt + showTime
      if showTime >= 3500 then
        self:Show(false, 1000)
        self:ReleaseHandler("OnUpdate")
      end
    end
    self:SetHandler("OnUpdate", OnUpdate)
  end
  function frame:SetScaleResult(characterName, resultCode, itemLink, oldScale, newScale)
    local itemInfo = X2Item:InfoFromLink(itemLink)
    local gradeColor = F_COLOR.Hex2Dec(X2Item:GradeColor(itemInfo.itemGrade))
    F_COLOR.ApplyTextureColor(self.itemBg, gradeColor)
    F_COLOR.ApplyTextureColor(self.arrow, gradeColor)
    F_COLOR.ApplyTextColor(self.oldGradeLabel, gradeColor)
    F_COLOR.ApplyTextColor(self.newGradeLabel, gradeColor)
    F_COLOR.ApplyTextColor(self.itemName, gradeColor)
    self.itemIcon:SetInfo(itemInfo)
    self.oldGradeLabel:SetText(oldScale)
    self.newGradeLabel:SetText(newScale)
    self.itemName:SetText(itemInfo.name)
    SetArrowTexture(resultCode)
    local text = ""
    if resultCode == IEBCT_ENCHANT_SUCCESS then
      text = locale.physicalEnchant.broadcast_scale_success_alarm(yellowColor, characterName, skyColor)
    elseif resultCode == IEBCT_ENCHANT_GREATE_SUCCESS then
      text = locale.physicalEnchant.broadcast_scale_great_success_alarm(yellowColor, characterName, skyColor)
    end
    self.content:SetTextAutoWidth(1000, text, 10)
    local showTime = 0
    local function OnUpdate(self, dt)
      showTime = dt + showTime
      if showTime >= 3500 then
        self:Show(false, 1000)
        self:ReleaseHandler("OnUpdate")
      end
    end
    self:SetHandler("OnUpdate", OnUpdate)
  end
  return frame
end
local gradeEnchantBroadcastAlarm = CreateGradeEnchantBroadcastAlarmMessage("gradeEnchantBroadcastAlarm", "UIParent")
function ShowGradeEnchantBroadcastAlarmMessage(characterName, resultCode, itemLink, oldEnchantValue, newEnchantValue)
  if characterName == X2Unit:UnitName("player") then
    return false
  end
  gradeEnchantBroadcastAlarm:Show(true, 500)
  gradeEnchantBroadcastAlarm:SetResult(characterName, resultCode, itemLink, oldEnchantValue, newEnchantValue)
  gradeEnchantBroadcastAlarm:Raise()
  return true
end
function ShowScaleEnchantBroadcastAlarmMessage(characterName, resultCode, itemLink, oldEnchantValue, newEnchantValue)
  if characterName == X2Unit:UnitName("player") then
    return false
  end
  gradeEnchantBroadcastAlarm:Show(true, 500)
  gradeEnchantBroadcastAlarm:SetScaleResult(characterName, resultCode, itemLink, oldEnchantValue, newEnchantValue)
  gradeEnchantBroadcastAlarm:Raise()
  return true
end
