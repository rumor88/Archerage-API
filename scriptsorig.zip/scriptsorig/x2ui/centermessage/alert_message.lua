function formatSkillMessage(code, param, skillId)
  if code == "URK_EQUIP_RANGED" then
    if param == "0" then
      return X2Locale:LocalizeUiText(CHAT_SYSTEM_TEXT, "skill_urk_equip_ranged")
    elseif param == "1" then
      return X2Locale:LocalizeUiText(CHAT_SYSTEM_TEXT, "skill_urk_equip_instrument")
    elseif param == "2" then
      return X2Locale:LocalizeUiText(CHAT_SYSTEM_TEXT, "skill_urk_cannot_use_with_non_combat_instument")
    elseif param == "3" then
      return X2Locale:LocalizeUiText(CHAT_SYSTEM_TEXT, "skill_urk_equip_shot_gun")
    end
  elseif code == "URK_LESS_ACTABILITY_POINT" then
    return X2Locale:LocalizeUiText(CHAT_SYSTEM_TEXT, string.format("skill_%s", string.lower(code)), param or "", skillId or "")
  end
  return X2Locale:LocalizeUiText(CHAT_SYSTEM_TEXT, string.format("skill_%s", string.lower(code)), param or "")
end
function CreateSystemAlertWindow(id, parent)
  local chatWindow = UIParent:CreateWidget("message", id, parent)
  chatWindow.style:SetSnap(true)
  chatWindow.style:SetShadow(true)
  chatWindow.style:SetColorByKey("scarlet_red")
  chatWindow:SetTimeVisible(2)
  chatWindow:SetMaxLines(CENTER_MSG_MAX_LINE.SYS_ALERT)
  return chatWindow
end
systemAlertWindow = CreateSystemAlertWindow("systemAlertWindow", systemLayerParent)
systemAlertWindow:SetExtent(UIParent:GetScreenWidth(), 50)
systemAlertWindow:AddAnchor("TOP", "UIParent", "TOP", 0, 180)
systemAlertWindow.style:SetFontSize(FONT_SIZE.XLARGE)
systemAlertWindow.style:SetColorByKey("red")
systemAlertWindow:Show(true)
systemAlertWindow:EnablePick(false)
