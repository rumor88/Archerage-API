if X2Util:GetGameProvider() == XLGAMES_TH then
  function centerMessageLocale:GetEnchantResultItemStr(gradeStr, nameStr)
    return string.format([[
%s
%s]], gradeStr, nameStr)
  end
end
