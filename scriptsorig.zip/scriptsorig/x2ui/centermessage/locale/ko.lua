if centerMessageLocale == nil then
  centerMessageLocale = {}
end
centerMessageLocale.killEffect = {
  resource = {
    {
      texture = TEXTURE_PATH.KILL_EFFECT_FIRST_KILL,
      key = "first",
      helmetKey = "helmet"
    },
    {
      texture = TEXTURE_PATH.KILL_EFFECT_FROM_SECOND_TO_FOURTH_KILL,
      key = "double",
      helmetKey = "double_helmet"
    },
    {
      texture = TEXTURE_PATH.KILL_EFFECT_FROM_SECOND_TO_FOURTH_KILL,
      key = "triple",
      helmetKey = "triple_helmet"
    },
    {
      texture = TEXTURE_PATH.KILL_EFFECT_FROM_SECOND_TO_FOURTH_KILL,
      key = "fourth",
      helmetKey = "fourth_helmet"
    },
    {
      texture = TEXTURE_PATH.KILL_EFFECT_FIFTH_KILL,
      key = "fifth",
      helmetKey = "helmet"
    },
    {
      texture = TEXTURE_PATH.KILL_EFFECT_WAR_OF_GOD,
      key = "dominating",
      helmetKey = "helmet"
    }
  },
  firstKilBloodlHelmetCoords = "blood"
}
function centerMessageLocale:GetEnchantResultItemStr(gradeStr, nameStr)
  return string.format("%s %s", gradeStr, nameStr)
end
