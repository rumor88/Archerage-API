if X2Util:GetGameProvider() == MAILRU then
  function centerMessageLocale:GetEnchantResultItemStr(gradeStr, nameStr)
    return string.format([[
%s
%s]], gradeStr, nameStr)
  end
end
