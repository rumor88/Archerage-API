if X2Util:GetGameProvider() == KAKAONA and X2Locale:GetLocale() == "fr" then
  centerMessageLocale.killEffect.resource[10] = {}
  centerMessageLocale.killEffect.resource[10].texture = TEXTURE_PATH.KILL_EFFECT_WAR_OF_GOD
  centerMessageLocale.killEffect.resource[10].key = "legendary"
  centerMessageLocale.killEffect.resource[15] = {}
  centerMessageLocale.killEffect.resource[15].helmetKey = centerMessageLocale.killEffect.resource[6].helmetKey
  centerMessageLocale.killEffect.resource[15].texture = TEXTURE_PATH.KILL_EFFECT_WAR_OF_GOD
  centerMessageLocale.killEffect.resource[15].key = "destruction"
  centerMessageLocale.killEffect.resource[15].helmetKey = centerMessageLocale.killEffect.resource[6].helmetKey
  function centerMessageLocale:GetEnchantResultItemStr(gradeStr, nameStr)
    return string.format([[
%s
%s]], gradeStr, nameStr)
  end
end
