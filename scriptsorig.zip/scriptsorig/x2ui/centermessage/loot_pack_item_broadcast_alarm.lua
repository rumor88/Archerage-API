local CreateLootPackItemBroadcastAlarmMessage = function(id, parent)
  local frame = CreateEmptyWindow(id, parent)
  frame:SetExtent(946, 180)
  frame:AddAnchor("TOP", parent, 0, 60)
  frame:SetUILayer("system")
  frame:EnablePick(false)
  local bg = frame:CreateDrawable(TEXTURE_PATH.ALARM_DECO, "bg", "background")
  bg:AddAnchor("BOTTOM", frame, 0, 0)
  local arrow = W_ICON.CreateArrowIcon(frame)
  arrow:AddAnchor("BOTTOM", bg, "TOP", 0, MARGIN.WINDOW_SIDE / 2)
  frame.arrow = arrow
  local useStatusBg = frame:CreateDrawable(TEXTURE_PATH.ALARM_DECO, "icon_bg", "artwork")
  useStatusBg:AddAnchor("LEFT", arrow, -97, -MARGIN.WINDOW_SIDE / 2)
  frame.useStatusBg = useStatusBg
  local resultStatusBg = frame:CreateDrawable(TEXTURE_PATH.ALARM_DECO, "result_status_bg", "artwork")
  resultStatusBg:AddAnchor("RIGHT", arrow, 97, -MARGIN.WINDOW_SIDE / 2)
  frame.resultStatusBg = resultStatusBg
  local useItemBg = frame:CreateDrawable(TEXTURE_PATH.GRADE_ENCHANT_BROADCAST_ALARM, "bg", "artwork")
  useItemBg:AddAnchor("LEFT", useStatusBg, 30, 0)
  frame.useItemBg = useItemBg
  local resultItemBg = frame:CreateDrawable(TEXTURE_PATH.GRADE_ENCHANT_BROADCAST_ALARM, "bg", "artwork")
  resultItemBg:AddAnchor("LEFT", resultStatusBg, 39, 0)
  frame.resultItemBg = resultItemBg
  local useItemIcon = CreateIconButton("useItemIcon", frame)
  useItemIcon:EnablePick(false)
  useItemIcon:AddAnchor("CENTER", useItemBg, -2, 0)
  frame.useItemIcon = useItemIcon
  local resultItemIcon = CreateIconButton("resultItemIcon", frame)
  resultItemIcon:EnablePick(false)
  resultItemIcon:AddAnchor("CENTER", resultItemBg, -2, 0)
  frame.resultItemIcon = resultItemIcon
  local useItemName = frame:CreateChildWidget("label", "useItemName", 0, true)
  useItemName:SetAutoResize(true)
  useItemName:SetHeight(FONT_SIZE.LARGE)
  useItemName.style:SetShadow(true)
  useItemName.style:SetFontSize(FONT_SIZE.LARGE)
  useItemName:AddAnchor("RIGHT", useItemIcon, "BOTTOM", 35, MARGIN.WINDOW_SIDE / 4609434218613702656)
  frame.useItemName = useItemName
  local resultItemName = frame:CreateChildWidget("label", "resultItemName", 0, true)
  resultItemName:SetAutoResize(true)
  resultItemName:SetHeight(FONT_SIZE.LARGE)
  resultItemName.style:SetShadow(true)
  resultItemName.style:SetFontSize(FONT_SIZE.LARGE)
  resultItemName:AddAnchor("LEFT", resultItemIcon, "BOTTOM", -35, MARGIN.WINDOW_SIDE / 4609434218613702656)
  frame.resultItemName = resultItemName
  local content = frame:CreateChildWidget("textbox", "content", 0, true)
  content:SetHeight(FONT_SIZE.XLARGE)
  content.style:SetFontSize(FONT_SIZE.XLARGE)
  content.style:SetShadow(true)
  content:AddAnchor("TOP", arrow, "BOTTOM", 0, MARGIN.WINDOW_SIDE * 4610334938539176755)
  frame.content = content
  local OnHide = function(self)
    self:ReleaseHandler("OnUpdate")
  end
  frame:SetHandler("OnHide", OnHide)
  local OnEndFadeOut = function(self)
    StartNextImgEvent()
  end
  frame:SetHandler("OnEndFadeOut", OnEndFadeOut)
  function frame:SetResult(characterName, sourceName, useItemLink, resultItemLink)
    local useItemInfo = X2Item:InfoFromLink(useItemLink)
    local resultItemInfo = X2Item:InfoFromLink(resultItemLink)
    local newGradeColor = X2Item:GradeColor(resultItemInfo.itemGrade)
    newGradeColor = F_COLOR.Hex2Dec(newGradeColor)
    if useItemInfo then
      self.useItemIcon:Show(true)
      self.useItemName:Show(true)
      self.useItemBg:Show(true)
      self.useStatusBg:Show(true)
      self.arrow:Show(true)
      self.resultStatusBg:RemoveAllAnchors()
      self.resultStatusBg:AddAnchor("RIGHT", arrow, 97, -MARGIN.WINDOW_SIDE / 2)
      self.resultItemName:RemoveAllAnchors()
      self.resultItemName:AddAnchor("LEFT", resultItemIcon, "BOTTOM", -35, MARGIN.WINDOW_SIDE / 4609434218613702656)
      local oldGradeColor = X2Item:GradeColor(useItemInfo.itemGrade)
      oldGradeColor = F_COLOR.Hex2Dec(oldGradeColor)
      F_COLOR.ApplyTextureColor(self.useItemBg, oldGradeColor)
      F_COLOR.ApplyTextColor(self.useItemName, oldGradeColor)
      self.useItemIcon:SetInfo(useItemInfo)
      self.useItemName:SetText(useItemInfo.name)
      F_COLOR.ApplyTextureColor(self.arrow, newGradeColor)
    else
      self.useItemIcon:Show(false)
      self.useItemName:Show(false)
      self.useItemBg:Show(false)
      self.useStatusBg:Show(false)
      self.arrow:Show(false)
      self.resultStatusBg:RemoveAllAnchors()
      self.resultStatusBg:AddAnchor("CENTER", arrow, 0, -MARGIN.WINDOW_SIDE / 2)
      self.resultItemName:RemoveAllAnchors()
      self.resultItemName:AddAnchor("TOP", resultItemIcon, "BOTTOM", 0, MARGIN.WINDOW_SIDE / 4)
    end
    F_COLOR.ApplyTextureColor(self.resultItemBg, newGradeColor)
    F_COLOR.ApplyTextColor(self.resultItemName, newGradeColor)
    self.resultItemIcon:SetInfo(resultItemInfo)
    self.resultItemName:SetText(resultItemInfo.name)
    local text = ""
    if sourceName ~= "" and sourceName ~= nil then
      text = X2Locale:LocalizeUiText(COMMON_TEXT, "broadcast_look_pack_item_alarm_with_source", F_COLOR.GetColor("soft_yellow", true), characterName, sourceName, F_COLOR.GetColor("skyblue", true))
    else
      text = X2Locale:LocalizeUiText(COMMON_TEXT, "broadcast_look_pack_item_alarm", F_COLOR.GetColor("soft_yellow", true), characterName, F_COLOR.GetColor("skyblue", true))
    end
    self.content:SetTextAutoWidth(1000, text, 10)
    self.content:SetHeight(self.content:GetTextHeight())
    local showTime = 0
    local function OnUpdate(self, dt)
      showTime = dt + showTime
      if showTime >= 3500 then
        self:Show(false, 1000)
        self:ReleaseHandler("OnUpdate")
      end
    end
    self:SetHandler("OnUpdate", OnUpdate)
  end
  return frame
end
lootPackItemBroadcastAlarm = CreateLootPackItemBroadcastAlarmMessage("lootPackItemBroadcastAlarm", "UIParent")
function ShowLootPackItemBroadcastAlarmMessage(characterName, sourceName, useItemLink, resultItemLink)
  lootPackItemBroadcastAlarm:Show(true, 500)
  lootPackItemBroadcastAlarm:SetResult(characterName, sourceName, useItemLink, resultItemLink)
  lootPackItemBroadcastAlarm:Raise()
  return true
end
