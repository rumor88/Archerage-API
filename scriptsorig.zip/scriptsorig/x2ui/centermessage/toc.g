﻿## author : mook
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## centermessage

locale/ko.lua
locale/ru.lua
locale/en_us.lua
locale/de.lua
locale/fr.lua
locale/th.lua

common.lua

alert_message.lua

additem_view.lua
additem.lua

notify_message.lua
quest_notify_message.lua
raid_command_message.lua
subzone_message.lua
effect_message.lua

siege_system_alarm_view.lua
siege_system_alarm.lua

equip_slot_reinforce_message.lua
honorpointwar_message.lua
notice_message.lua
kill_effect.lua
enchant_etc_alarm.lua
enchant_grade_alarm.lua
enchant_grade_broadcast_alarm.lua
## nation_message.lua
day_event_alarm.lua
tower_defense_msg.lua
achievement_complete_msg.lua
ranking_msg.lua
learn_ability.lua
zone_state_alarm.lua
hero_message.lua
expedition_level_up_msg.lua
expedition_accept_message.lua
expedition_reject_message.lua
loot_pack_item_broadcast_alarm.lua
family_level_up_msg.lua
craft_order_msg.lua
indun_round_msg.lua
faction_relation_message.lua
instance_difficult_msg.lua

center_message_manager.lua
