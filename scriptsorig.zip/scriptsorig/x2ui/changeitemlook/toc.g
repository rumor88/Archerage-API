﻿## author : prodg
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## changeitemlook

changeitemlook_view.lua
changeitemlook.lua