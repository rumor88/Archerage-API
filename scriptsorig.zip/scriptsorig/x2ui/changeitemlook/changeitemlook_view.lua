local ITEM_WIDGET_WIDTH = 190
local ITEM_WIDGET_HEIGHT = 160
local function CreateItemIconWidget(id, parent, str)
  local widget = parent:CreateChildWidget("emptywidget", id, 0, true)
  local title = widget:CreateChildWidget("label", "title", 0, true)
  title:SetText(str)
  title:AddAnchor("TOP", widget, 0, MARGIN.WINDOW_SIDE / 4609434218613702656)
  title:SetExtent(ITEM_WIDGET_WIDTH, FONT_SIZE.LARGE)
  title.style:SetFontSize(FONT_SIZE.LARGE)
  title.style:SetColorByKey("title")
  local item = CreateIconButton(string.format("%s.item", id), widget)
  item:SetExtent(ICON_SIZE.XLARGE, ICON_SIZE.XLARGE)
  item:AddAnchor("TOP", title, "BOTTOM", 0, MARGIN.WINDOW_SIDE / 4608533498688228557)
  item:RegisterForClicks("RightButton")
  widget.item = item
  local name = widget:CreateChildWidget("textbox", "name", 0, true)
  name:SetExtent(ITEM_WIDGET_WIDTH - MARGIN.WINDOW_SIDE, FONT_SIZE.MIDDLE)
  name:AddAnchor("TOP", item, "BOTTOM", 0, MARGIN.WINDOW_SIDE / 2)
  return widget
end
local CreateMaterialsWidget = function(id, parent)
  local widget = parent:CreateChildWidget("emptywidget", id, 0, true)
  local title = widget:CreateChildWidget("label", "title", 0, true)
  title:SetText(GetUIText(COMMON_TEXT, "material_item"))
  title:SetHeight(FONT_SIZE.LARGE)
  title:AddAnchor("TOPLEFT", widget, 0, 0)
  title:AddAnchor("TOPRIGHT", widget, 0, 0)
  title.style:SetFontSize(FONT_SIZE.LARGE)
  title.style:SetColorByKey("title")
  widget.items = {}
  for i = 1, 5 do
    local item = CreateIconButton(string.format("%s.item%d", id, i), widget)
    item:SetExtent(ICON_SIZE.XLARGE, ICON_SIZE.XLARGE)
    if i == 1 then
      item:AddAnchor("TOPLEFT", title, "BOTTOMLEFT", 0, 10)
    else
      item:AddAnchor("LEFT", widget.items[i - 1], "RIGHT", 12, 0)
    end
    widget.items[i] = item
  end
  local feeFrame = W_MODULE:Create("feeFrame", widget, W_MODULE.TYPES.VALUE_BOX)
  feeFrame:Show(false)
  feeFrame:AddAnchor("BOTTOM", widget, 0, 0)
  return widget
end
function CreateChangeItemLookWnd(id, parent)
  local widget = parent:CreateChildWidget("emptywidget", "changeItemLook", 0, true)
  widget:AddAnchor("TOPLEFT", parent.tab, 0, 27)
  widget:AddAnchor("BOTTOMRIGHT", parent.tab, 0, 0)
  widget.code = id
  local height = 525
  local baseItem = CreateItemIconWidget("baseItem", widget, locale.lookConverter.baseItem)
  baseItem:SetExtent(ITEM_WIDGET_WIDTH, ITEM_WIDGET_HEIGHT)
  baseItem:AddAnchor("TOPLEFT", widget, 0, MARGIN.WINDOW_TITLE)
  local bg = CreateContentBackground(baseItem, "TYPE10", "brown")
  bg:AddAnchor("TOPLEFT", baseItem, 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", baseItem, 0, 0)
  local lookItem = CreateItemIconWidget("lookItem", widget, locale.lookConverter.lookItem)
  lookItem:SetExtent(ITEM_WIDGET_WIDTH, ITEM_WIDGET_HEIGHT)
  lookItem:AddAnchor("TOPRIGHT", widget, 0, MARGIN.WINDOW_TITLE)
  local bg = CreateContentBackground(lookItem, "TYPE10", "blue")
  bg:AddAnchor("TOPLEFT", lookItem, 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", lookItem, 0, 0)
  local plusDeco = widget:CreateDrawable(TEXTURE_PATH.LOOK_CHANGED, "plus_deco", "overlay")
  plusDeco:AddAnchor("LEFT", baseItem, "RIGHT", -MARGIN.WINDOW_SIDE * 4607632778762754458, -MARGIN.WINDOW_SIDE / 2)
  local newItem = CreateItemIconWidget("newItem", widget, locale.lookConverter.newItem)
  newItem:SetExtent(ITEM_WIDGET_WIDTH, ITEM_WIDGET_HEIGHT / 4608983858650965606)
  newItem:AddAnchor("TOP", widget, 0, MARGIN.WINDOW_TITLE + ITEM_WIDGET_HEIGHT)
  newItem.title.style:SetFont(FONT_PATH.SUB, FONT_SIZE.XLARGE)
  newItem.title.style:SetColorByKey("medium_brown")
  newItem.item:RemoveAllAnchors()
  newItem.item:AddAnchor("TOP", newItem.title, "BOTTOM", 0, MARGIN.WINDOW_SIDE / 2)
  local deco_left = newItem:CreateDrawable(TEXTURE_PATH.LOOK_CHANGED, "pattern_left", "overlay")
  deco_left:AddAnchor("RIGHT", newItem.item, "LEFT", -MARGIN.WINDOW_SIDE / 4, -MARGIN.WINDOW_SIDE / 4609434218613702656)
  local deco_right = newItem:CreateDrawable(TEXTURE_PATH.LOOK_CHANGED, "pattern_right", "overlay")
  deco_right:AddAnchor("LEFT", newItem.item, "RIGHT", MARGIN.WINDOW_SIDE / 4, -MARGIN.WINDOW_SIDE / 4609434218613702656)
  local line = CreateLine(widget, "TYPE1", "overlay")
  line:SetWidth(400)
  line:AddAnchor("TOP", newItem, "BOTTOM", 0, MARGIN.WINDOW_SIDE / 2)
  local materials = CreateMaterialsWidget("materials", widget)
  materials:SetExtent(300, ITEM_WIDGET_HEIGHT / 4609434218613702656)
  materials:AddAnchor("TOP", newItem, "BOTTOM", 0, MARGIN.WINDOW_SIDE * 4608083138725491507)
  local infos = {
    leftButtonStr = locale.lookConverter.convert,
    rightButtonStr = GetCommonText("cancel")
  }
  CreateWindowDefaultTextButtonSet(widget, infos, parent)
  widget.leftButton:Enable(false)
  local warning = widget:CreateChildWidget("textbox", "warning", 0, true)
  warning:SetWidth(widget:GetWidth() - MARGIN.WINDOW_SIDE * 2)
  warning:SetText(locale.lookConverter.warning)
  warning:SetHeight(warning:GetTextHeight())
  warning:AddAnchor("TOP", materials, "BOTTOM", 0, MARGIN.WINDOW_SIDE / 4609434218613702656)
  warning.style:SetColorByKey("red")
  widget:SetHeight(height + warning:GetHeight() + MARGIN.WINDOW_SIDE)
  return widget
end
function CreateExtractItemLookWnd(id, parent)
  local widget = parent:CreateChildWidget("emptywidget", "ExtractItemLook", 0, true)
  widget:AddAnchor("TOPLEFT", parent.tab, 0, 27)
  widget:AddAnchor("BOTTOMRIGHT", parent.tab, 0, 0)
  widget.code = id
  local height = 525
  local newItem = CreateItemIconWidget("newItem", widget, locale.lookConverter.newItem)
  newItem:SetExtent(ITEM_WIDGET_WIDTH, ITEM_WIDGET_HEIGHT / 4608983858650965606)
  newItem:AddAnchor("TOP", widget, 0, MARGIN.WINDOW_TITLE / 2)
  newItem.title.style:SetFont(FONT_PATH.SUB, FONT_SIZE.XLARGE)
  newItem.title.style:SetColorByKey("medium_brown")
  newItem.item:RemoveAllAnchors()
  newItem.item:AddAnchor("TOP", newItem.title, "BOTTOM", 0, MARGIN.WINDOW_SIDE / 2)
  local deco_left = newItem:CreateDrawable(TEXTURE_PATH.LOOK_CHANGED, "deco_left", "overlay")
  deco_left:AddAnchor("RIGHT", newItem.item, "LEFT", -MARGIN.WINDOW_SIDE / 4, MARGIN.WINDOW_SIDE / 4)
  local deco_right = newItem:CreateDrawable(TEXTURE_PATH.LOOK_CHANGED, "deco_right", "overlay")
  deco_right:AddAnchor("LEFT", newItem.item, "RIGHT", MARGIN.WINDOW_SIDE / 4, MARGIN.WINDOW_SIDE / 4)
  local baseItem = CreateItemIconWidget("baseItem", widget, locale.lookConverter.baseItem)
  baseItem:SetExtent(ITEM_WIDGET_WIDTH, ITEM_WIDGET_HEIGHT)
  baseItem:AddAnchor("TOPLEFT", widget, 0, MARGIN.WINDOW_TITLE / 2 + newItem:GetHeight() + MARGIN.WINDOW_SIDE / 2)
  local bg = CreateContentBackground(baseItem, "TYPE10", "brown")
  bg:AddAnchor("TOPLEFT", baseItem, 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", baseItem, 0, 0)
  local lookItem = CreateItemIconWidget("lookItem", widget, locale.lookConverter.lookItem)
  lookItem:SetExtent(ITEM_WIDGET_WIDTH, ITEM_WIDGET_HEIGHT)
  lookItem:AddAnchor("TOPRIGHT", widget, 0, MARGIN.WINDOW_TITLE / 2 + newItem:GetHeight() + MARGIN.WINDOW_SIDE / 2)
  local bg = CreateContentBackground(lookItem, "TYPE10", "blue")
  bg:AddAnchor("TOPLEFT", lookItem, 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", lookItem, 0, 0)
  local line = CreateLine(widget, "TYPE1", "overlay")
  line:SetWidth(400)
  line:AddAnchor("TOP", newItem, 0, MARGIN.WINDOW_TITLE / 2 + newItem:GetHeight() + MARGIN.WINDOW_SIDE / 2 + baseItem:GetHeight())
  local materials = CreateMaterialsWidget("materials", widget)
  materials:SetExtent(300, ITEM_WIDGET_HEIGHT / 4609434218613702656)
  materials:AddAnchor("TOP", newItem, 0, MARGIN.WINDOW_TITLE / 2 + newItem:GetHeight() + MARGIN.WINDOW_SIDE / 2 + baseItem:GetHeight() + MARGIN.WINDOW_SIDE / 4609434218613702656)
  local infos = {
    leftButtonStr = locale.lookConverter.convert,
    rightButtonStr = GetCommonText("cancel")
  }
  CreateWindowDefaultTextButtonSet(widget, infos, parent)
  widget.leftButton:Enable(false)
  local warning = widget:CreateChildWidget("textbox", "warning", 0, true)
  warning:SetWidth(widget:GetWidth() - MARGIN.WINDOW_SIDE * 2)
  warning:SetText(GetCommonText("lookRevert_desc"))
  warning:SetHeight(warning:GetTextHeight())
  warning:AddAnchor("TOP", materials, "BOTTOM", 0, MARGIN.WINDOW_SIDE / 4609434218613702656)
  warning.style:SetColorByKey("red")
  widget:SetHeight(height + warning:GetHeight() + MARGIN.WINDOW_SIDE)
  return widget
end
local CreateItemLookContent = function(parent, tabCodes, interactionNum)
  local content
  content1 = CreateChangeItemLookWnd("TAB_INDEX_CHANGEITEMLOOK", parent)
  content2 = CreateExtractItemLookWnd("TAB_INDEX_EXTRACTITEMLOOK", parent)
  content2:Show(false)
  SetChangeItemLookEventFunction(content1, interactionNum)
  SetChangeItemLookEventFunction(content2, interactionNum)
  return content
end
local featureSet = X2Player:GetFeatureSet()
function SetViewOfChangeItemLookWindow(id, parent, interactionNum)
  local frame = CreateWindow(id, parent, "look_convert")
  frame:SetExtent(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_430), 666)
  frame:SetTitle(GetUIText(WINDOW_TITLE_TEXT, "look_convert"))
  frame:AddAnchor("CENTER", "UIParent", 0, 0)
  local TAB_MENU_TEXT = {
    locale.lookConverter.convert,
    GetUIText(COMMON_TEXT, "extract")
  }
  local TAB_INDEX = {
    "TAB_INDEX_CHANGEITEMLOOK",
    "TAB_INDEX_EXTRACTITEMLOOK"
  }
  local tab = W_TAB.CreateTab("tab", frame)
  tab:AddTabs(TAB_MENU_TEXT)
  if featureSet.itemlookExtract then
    tab.unselectedButton[2]:Show(true)
  else
    tab.selectedButton[2]:Show(false)
    tab.unselectedButton[2]:Show(false)
  end
  frame.contents = CreateItemLookContent(frame, "TAB_INDEX_CHANGEITEMLOOK", interactionNum)
  function tab:OnTabChangedProc(selected)
    if selected == 1 then
      self:GetParent().ExtractItemLook:Show(false)
      self:GetParent().ExtractItemLook:Clear()
      self:GetParent().changeItemLook:Show(true)
      self:GetParent().changeItemLook:ShowProc()
    elseif selected == 2 then
      self:GetParent().changeItemLook:Show(false)
      self:GetParent().changeItemLook:Clear()
      self:GetParent().ExtractItemLook:Show(true)
      self:GetParent().ExtractItemLook:ShowProc()
    end
  end
  return frame
end
