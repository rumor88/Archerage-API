local DrawLineByColumn = function(index, column, useDefaultColor)
  if index == 1 then
    return
  end
  if useDefaultColor == nil then
    useDefaultColor = true
  end
  local line = column:CreateDrawable(TEXTURE_PATH.DEFAULT, "line_column", "overlay")
  line:AddAnchor("LEFT", column, 0, line:GetHeight() / 2 + 5)
  if useDefaultColor then
    line:SetTextureColor("default")
  end
end
local DrawUnderlineForColumn = function(listCtrl, columHeight, useDefaultColor)
  local underline = CreateLine(listCtrl, "TYPE1", "overlay")
  underline:AddAnchor("TOPLEFT", listCtrl, 0, columHeight)
  underline:AddAnchor("TOPRIGHT", listCtrl, 0, columHeight)
  if useDefaultColor then
    underline:SetTextureColor("default")
  end
end
local DrawUnderlineForRow = function(index, row)
  if index == 1 then
    return
  end
  local line = CreateLine(row, "TYPE1", "overlay")
  line:AddAnchor("TOPLEFT", row, -30, 0)
  line:AddAnchor("TOPRIGHT", row, 30, 0)
  line:SetVisible(false)
  return line
end
W_LISTCTRL = {
  SORT_TYPE = {ASCENDING = 1, DESCENDING = 2},
  SPECIAL_COLUMN = {KEY = 1, SHARED_DATA = 2},
  LAYOUT_ATTRIBUTE = {
    COLUMN_HEIGHT = "columnHeight",
    BG = {KEY = "bgKey", COLOR_KEY = "bgColorKey"},
    COLUMN_BG = {
      KEY = "columnBgKey",
      COLOR_KEY = "columnBgColorKey"
    },
    SCROLL_ANCHOR_OFFSET = "scrollAnchorOffset",
    FIRST_COLUMN_BG_KEY = "firstColumnBgKey",
    FIRST_COLUMN_BG_COLOR_KEY = "firstColumnBgColorKey",
    DRAW_LINE_BY_COLUMN_FUNC = "drawLineByColumnFunc",
    COLUMN_LINES_DEFAULT_COLOR = "lineByColumnDefaultColor",
    DRAW_UNDERLINE_FOR_COLUMN_FUNC = "drawUnderlineForColumnFunc",
    DRAW_UNDERLINE_FOR_ROW = "drawUnderlineForRow"
  },
  LAYOUT_PRESET_TYPE = {
    DEFAULT = "default",
    DEFAULT_WHITE = "default_white",
    DEFAULT_HAS_LOW_LINE = "default_has_low_line",
    HIDE_COLUMN = "hide_column",
    HAS_BG = "has_bg"
  },
  OVER_CLICK_IMG_SET_TYPE = {
    DEFAULT = "default",
    SERVER_SELECT = "server_select",
    ACHIEVEMENT = "achievement",
    ENTRANCE = "entrance"
  }
}
W_LISTCTRL.LAYOUT_PRESET_INFO = {
  [W_LISTCTRL.LAYOUT_PRESET_TYPE.DEFAULT] = {
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.COLUMN_HEIGHT] = 35,
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.DRAW_LINE_BY_COLUMN_FUNC] = DrawLineByColumn,
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.DRAW_UNDERLINE_FOR_COLUMN_FUNC] = DrawUnderlineForColumn,
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.COLUMN_LINES_DEFAULT_COLOR] = true
  },
  [W_LISTCTRL.LAYOUT_PRESET_TYPE.DEFAULT_WHITE] = {
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.COLUMN_HEIGHT] = 35,
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.DRAW_LINE_BY_COLUMN_FUNC] = DrawLineByColumn,
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.DRAW_UNDERLINE_FOR_COLUMN_FUNC] = DrawUnderlineForColumn,
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.COLUMN_LINES_DEFAULT_COLOR] = false
  },
  [W_LISTCTRL.LAYOUT_PRESET_TYPE.DEFAULT_HAS_LOW_LINE] = {
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.COLUMN_HEIGHT] = 35,
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.DRAW_LINE_BY_COLUMN_FUNC] = DrawLineByColumn,
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.DRAW_UNDERLINE_FOR_COLUMN_FUNC] = DrawUnderlineForColumn,
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.COLUMN_LINES_DEFAULT_COLOR] = true,
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.DRAW_UNDERLINE_FOR_ROW] = DrawUnderlineForRow
  },
  [W_LISTCTRL.LAYOUT_PRESET_TYPE.HAS_BG] = {
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.COLUMN_HEIGHT] = 32,
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.BG] = {KEY = "type02_new", COLOR_KEY = "default"},
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.COLUMN_BG] = {
      KEY = "type02_new_half",
      COLOR_KEY = "default"
    },
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.SCROLL_ANCHOR_OFFSET] = function(columnHeight)
      return {
        -4,
        columnHeight + 5,
        -4,
        -7
      }
    end,
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.FIRST_COLUMN_BG_KEY] = "type02_new_half_crop",
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.FIRST_COLUMN_BG_COLOR_KEY] = "default"
  },
  [W_LISTCTRL.LAYOUT_PRESET_TYPE.HIDE_COLUMN] = {
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.COLUMN_HEIGHT] = 0,
    [W_LISTCTRL.LAYOUT_ATTRIBUTE.SCROLL_ANCHOR_OFFSET] = function(columnHeight)
      return {
        0,
        columnHeight,
        0,
        0
      }
    end
  }
}
