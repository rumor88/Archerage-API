function W_CTRL.CreateListCtrlNew(id, parent, layoutPreset, needToWrappingFunc)
  local frame = parent:CreateChildWidget("emptywidget", id, 0, true)
  local listCtrl = frame:CreateChildWidgetByType(UOT_LIST_CTRL, "listCtrl", 0, true)
  listCtrl:AddAnchor("TOPLEFT", frame, 0, 0)
  listCtrl:AddAnchor("BOTTOMRIGHT", frame, 0, 0)
  local datas = {}
  local useSharedData = false
  local selectedDataInfo = {index = 0, key = nil}
  local LAYOUT_ATTRIBUTE = W_LISTCTRL.LAYOUT_ATTRIBUTE
  local LAYOUT_PRESET_INFO = W_LISTCTRL.LAYOUT_PRESET_INFO
  local settedPresetType, firstColumnBg
  function frame:SetLayout(type)
    if type == nil then
      type = W_LISTCTRL.LAYOUT_PRESET_TYPE.DEFAULT
    end
    local info = LAYOUT_PRESET_INFO[type]
    if info == nil then
      return
    end
    if settedpresetType ~= nil then
      return
    end
    settedPresetType = type
    local columnHeight = info[LAYOUT_ATTRIBUTE.COLUMN_HEIGHT] or 0
    listCtrl:SetHeaderColumnHeight(columnHeight)
    local bgInfo = info[LAYOUT_ATTRIBUTE.BG]
    if bgInfo ~= nil then
      local bgKey = bgInfo.KEY
      if bgKey ~= nil then
        local bg = frame:CreateDrawable(TEXTURE_PATH.DEFAULT, bgKey, "background")
        bg:AddAnchor("TOPLEFT", frame, 0, 0)
        bg:AddAnchor("BOTTOMRIGHT", frame, 0, 0)
        frame.bg = bg
        local colorKey = bgInfo.COLOR_KEY
        if colorKey ~= nil then
          bg:SetTextureColor(colorKey)
        end
      end
    end
    local columnBgInfo = info[LAYOUT_ATTRIBUTE.COLUMN_BG]
    if columnBgInfo ~= nil then
      local columnBgKey = columnBgInfo.KEY
      if columnBgKey ~= nil then
        local columnBg = frame:CreateDrawable(TEXTURE_PATH.DEFAULT, columnBgKey, "background")
        columnBg:AddAnchor("TOPLEFT", frame, 0, 0)
        columnBg:AddAnchor("TOPRIGHT", frame, 0, 0)
        columnBg:SetHeight(columnHeight)
        frame.columnBg = columnBg
        local colorKey = columnBgInfo.COLOR_KEY
        if colorKey ~= nil then
          columnBg:SetTextureColor(colorKey)
        end
      end
    end
    local firstColumnBgKey = info[LAYOUT_ATTRIBUTE.FIRST_COLUMN_BG_KEY]
    if firstColumnBgKey ~= nil then
      firstColumnBg = frame:CreateDrawable(TEXTURE_PATH.DEFAULT, firstColumnBgKey, "background")
      firstColumnBg:AddAnchor("TOPLEFT", frame, 0, columnHeight or 1)
      firstColumnBg:AddAnchor("BOTTOMLEFT", frame, 0, -3)
      local colorKey = info[LAYOUT_ATTRIBUTE.FIRST_COLUMN_BG_COLOR_KEY]
      if colorKey ~= nil then
        firstColumnBg:SetTextureColor(colorKey)
      end
    end
    local underlineFunc = info[LAYOUT_ATTRIBUTE.DRAW_UNDERLINE_FOR_COLUMN_FUNC]
    if underlineFunc ~= nil then
      local underline = underlineFunc(listCtrl, columnHeight, info[LAYOUT_ATTRIBUTE.COLUMN_LINES_DEFAULT_COLOR])
    end
  end
  frame:SetLayout(layoutPreset)
  function frame:GetBackground(key)
    if key == LAYOUT_ATTRIBUTE.BG then
      return frame.bg
    elseif key == LAYOUT_ATTRIBUTE.COLUMN_BG then
      return frame.columnBg
    end
  end
  local funcTarget = needToWrappingFunc and parent or frame
  local overClickImgSet = {
    [W_LISTCTRL.OVER_CLICK_IMG_SET_TYPE.DEFAULT] = function(listCtrl)
      local overedImage = listCtrl:CreateOveredImage()
      overedImage:SetTexture(TEXTURE_PATH.TAB_LIST)
      overedImage:SetTextureInfo("enchant_info_bg", "listctrl_overed_default")
      local selectedImage = listCtrl:CreateSelectedImage()
      selectedImage:SetTexture(TEXTURE_PATH.TAB_LIST)
      selectedImage:SetTextureInfo("enchant_info_bg", "listctrl_selected_default")
    end,
    [W_LISTCTRL.OVER_CLICK_IMG_SET_TYPE.ACHIEVEMENT] = function(listCtrl)
      local overedImage = listCtrl:CreateOveredImage()
      overedImage:SetTexture(TEXTURE_PATH.DEFAULT)
      overedImage:SetTextureInfo("slot_ov")
      local selectedImage = listCtrl:CreateSelectedImage()
      selectedImage:SetTexture(TEXTURE_PATH.DEFAULT)
      selectedImage:SetTextureInfo("slot_ov")
    end,
    [W_LISTCTRL.OVER_CLICK_IMG_SET_TYPE.SERVER_SELECT] = function(listCtrl)
      local overedImage = listCtrl:CreateOveredImage()
      overedImage:SetTexture(TEXTURE_PATH.DEFAULT_NEW)
      overedImage:SetTextureInfo("common_ov", "default")
      local selectedImage = listCtrl:CreateSelectedImage()
      selectedImage:SetTexture(TEXTURE_PATH.DEFAULT_NEW)
      selectedImage:SetTextureInfo("bg", "common_selected")
    end,
    [W_LISTCTRL.OVER_CLICK_IMG_SET_TYPE.ENTRANCE] = function(listCtrl)
      local overedImage = listCtrl:CreateOveredImage()
      overedImage:SetTexture(TEXTURE_PATH.BATTLEFIELD_COMMON_LIST_BUTTON)
      overedImage:SetTextureInfo("frame_ov")
      local selectedImage = listCtrl:CreateSelectedImage()
      selectedImage:SetTexture(TEXTURE_PATH.BATTLEFIELD_COMMON_LIST_BUTTON)
      selectedImage:SetTextureInfo("frame_on")
    end
  }
  function funcTarget:UseOverClickTexture(setType)
    if setType == nil then
      setType = W_LISTCTRL.OVER_CLICK_IMG_SET_TYPE.DEFAULT
    end
    local func = overClickImgSet[setType]
    if func == nil then
      return
    end
    func(listCtrl)
  end
  function funcTarget:UseSortMark()
    local ascendingSortMark = self:CreateDrawable(TEXTURE_PATH.TAB_LIST, "list_sort_mark_asc", "overlay")
    ascendingSortMark:SetVisible(false)
    self.ascendingSortMark = ascendingSortMark
    local descendingSortMark = self:CreateDrawable(TEXTURE_PATH.TAB_LIST, "list_sort_mark_des", "overlay")
    descendingSortMark:SetVisible(false)
    self.descendingSortMark = descendingSortMark
  end
  function funcTarget:ShowSortMark(columnIndex, sortingType)
    local column = self:GetColumn(columnIndex)
    if column == nil then
      return
    end
    if sortingType ~= W_LISTCTRL.ASCENDING and sortingType ~= W_LISTCTRL.DESCENDING then
      return
    end
    local columnStrLen = column.style:GetTextWidth(column:GetText())
    local offset = columnStrLen / 2 + 7
    local isAsending = sortingType == W_LISTCTRL.ASCENDING
    local showMark = isAsending and self.ascendingSortMark or self.descendingSortMark
    local hideMark = isAsending and self.descendingSortMark or self.ascendingSortMark
    showMark:RemoveAllAnchors()
    showMark:AddAnchor("RIGHT", column, 5, 2)
    showMark:SetVisible(true)
    hideMark:SetVisible(false)
  end
  function funcTarget:HideSortMark()
    self.ascendingSortMark:SetVisible(false)
    self.descendingSortMark:SetVisible(false)
  end
  function funcTarget:SetUseDoubleClick(use)
    listCtrl:SetUseDoubleClick(use)
  end
  function funcTarget:EnableColumn(index, enable)
    local column = self:GetColumn(index)
    if column == nil then
      return
    end
    column:Enable(enable)
  end
  function frame:DeleteAllDatas()
    datas = {}
    useSharedData = false
    listCtrl:DeleteAllDatas()
    listCtrl:ClearSelection()
    for i = 1, funcTarget:GetRowCount() do
      local row = funcTarget:GetRow(i)
      if row ~= nil and row.underline ~= nil then
        row.underline:SetVisible(false)
      end
    end
    funcTarget:Refresh()
  end
  function funcTarget:ClearSelection()
    listCtrl:ClearSelection()
  end
  function funcTarget:SetOveredImageOffset(left, top, right, bottom)
    listCtrl:SetOveredImageOffset(left, top, right, bottom)
  end
  function funcTarget:SetSelectedImageOffset(left, top, right, bottom)
    listCtrl:SetSelectedImageOffset(left, top, right, bottom)
  end
  function funcTarget:Select(index, triggerEvent)
    listCtrl:Select(index, triggerEvent)
  end
  function funcTarget:SelectByDataKey(dataKey)
    for i = 1, #datas do
      if dataKey == datas[i][W_LISTCTRL.SPECIAL_COLUMN.KEY] then
        local selectedIndex = frame:GetViewIndex(i)
        if selectedIndex ~= self:GetSelectedIdx() then
          self:Select(selectedIndex - 1)
        else
          if self.OnSelChangedProc ~= nil then
            self:OnSelChangedProc(self:GetViewIndex(i), false)
          end
          selectedDataInfo = {index = i, key = dataKey}
        end
      end
    end
  end
  local function OnSelChanged(self, selIdx, doubleClick)
    if funcTarget.OnSelChangedProc ~= nil then
      funcTarget:OnSelChangedProc(selIdx, doubleClick)
    end
  end
  listCtrl:SetHandler("OnSelChanged", OnSelChanged)
  function funcTarget:GetColumn(index)
    if #listCtrl.column == 0 then
      return
    end
    return listCtrl.column[index]
  end
  function funcTarget:GetColumnCount()
    if listCtrl.column == nil then
      return 0
    end
    return #listCtrl.column
  end
  function funcTarget:GetRow(index)
    if #listCtrl.items == 0 then
      return
    end
    return listCtrl.items[index]
  end
  function funcTarget:GetRowCount()
    if listCtrl.items == nil then
      return 0
    end
    return #listCtrl.items
  end
  function funcTarget:GetSubItem(rowIndex, columnIndex)
    local row = self:GetRow(rowIndex)
    if row == nil then
      return
    end
    return row.subItems[columnIndex]
  end
  function funcTarget:GetSubItemCount()
    local row = self:GetRow(1)
    if row == nil then
      return
    end
    return #row.subItems
  end
  function funcTarget:GetSelectedIdx()
    return listCtrl:GetSelectedIdx()
  end
  function funcTarget:GetData(dataIndex)
    if dataIndex == nil or dataIndex == 0 then
      return
    end
    return datas[dataIndex]
  end
  function funcTarget:GetDataPartially(dataIndex, columnIndex)
    local data = self:GetData(dataIndex)
    if data == nil then
      return
    end
    if self:GetUseDataShared() then
      return data[W_LISTCTRL.SPECIAL_COLUMN.SHARED_DATA]
    else
      return data[W_LISTCTRL.SPECIAL_COLUMN.KEY + columnIndex]
    end
  end
  function funcTarget:GetDataKey(dataIndex)
    if dataIndex == nil or dataIndex == 0 then
      return
    end
    return datas[dataIndex][W_LISTCTRL.SPECIAL_COLUMN.KEY]
  end
  function funcTarget:GetDataCount()
    return #datas
  end
  function funcTarget:GetUseDataShared()
    return useSharedData
  end
  function frame:GetViewIndex(dataIndex)
    return dataIndex
  end
  function frame:GetDataKeyByViewIndex(index)
    if index == nil then
      return
    end
    return datas[index]
  end
  function funcTarget:InsertColumn(name, width, type, layoutFunc, dataSetFunc)
    listCtrl:InsertColumn(width, type)
    local index = #listCtrl.column
    local column = listCtrl.column[index]
    column.layoutFunc = layoutFunc
    column.dataSetFunc = dataSetFunc
    column:SetText(name)
    if firstColumnBg ~= nil and index == 1 then
      firstColumnBg:SetWidth(width)
    end
    column.style:SetShadow(false)
    column.style:SetFontSize(FONT_SIZE.LARGE)
    SetButtonFontColor(column, GetButtonDefaultFontColor())
    if settedPresetType ~= nil then
      local info = LAYOUT_PRESET_INFO[settedPresetType]
      if info ~= nil then
        local drawLineFunc = info[LAYOUT_ATTRIBUTE.DRAW_LINE_BY_COLUMN_FUNC]
        if drawLineFunc ~= nil then
          drawLineFunc(index, column, info[LAYOUT_ATTRIBUTE.COLUMN_LINES_DEFAULT_COLOR])
        end
      end
    end
  end
  local DefaultListItemSetting = function(item)
    if item.SetInset == nil or item.style == nil then
      return
    end
    item.style:SetColorByKey("default")
    item.style:SetEllipsis(true)
  end
  function funcTarget:InsertRows(count, useEventWindow)
    listCtrl:InsertRows(count, useEventWindow)
    local rowCount = #listCtrl.items
    for i = 1, rowCount do
      local row = listCtrl.items[i]
      for j = 1, #listCtrl.column do
        local column = listCtrl.column[j]
        if column.layoutFunc ~= nil then
          column.layoutFunc(row.subItems[j], row, listCtrl)
        else
          DefaultListItemSetting(row.subItems[j])
        end
      end
      local info = LAYOUT_PRESET_INFO[settedPresetType]
      if info ~= nil then
        local drawUnderlineFunc = info[LAYOUT_ATTRIBUTE.DRAW_UNDERLINE_FOR_ROW]
        if drawUnderlineFunc ~= nil then
          local underline = drawUnderlineFunc(i, row)
          row.underline = underline
        end
      end
    end
  end
  local function InsertData(key, data, shared, index)
    local newData = {}
    local findedDataIndex = 0
    for i = 1, #datas do
      newData = datas[i]
      if newData[W_LISTCTRL.SPECIAL_COLUMN.KEY] == key then
        findedDataIndex = i
        break
      end
    end
    if findedDataIndex == 0 then
      newData = {}
      newData[W_LISTCTRL.SPECIAL_COLUMN.KEY] = key
      datas[#datas + 1] = newData
    end
    if #datas <= funcTarget:GetRowCount() then
      listCtrl:InsertData(#datas, 1, "")
    end
    if shared then
      newData[W_LISTCTRL.SPECIAL_COLUMN.SHARED_DATA] = data
    else
      newData[W_LISTCTRL.SPECIAL_COLUMN.KEY + index] = data
    end
  end
  function frame:InsertData(key, columnIndex, data)
    InsertData(key, data, false, columnIndex)
  end
  function frame:InsertSharedData(key, data)
    InsertData(key, data, true)
    useSharedData = true
  end
  function frame:Refresh()
    local rowCount = self:GetRowCount()
    local colCount = self:GetColumnCount()
    if rowCount == 0 or colCount == 0 then
      return
    end
    for i = 1, rowCount do
      local datas = datas[i]
      for j = 1, colCount do
        local subItem = self:GetSubItem(i, j)
        local column = self:GetColumn(j)
        local dataSetFunc = column.dataSetFunc
        if datas ~= nil then
          local data = self:GetDataPartially(i, j)
          if dataSetFunc ~= nil then
            dataSetFunc(subItem, data)
          else
            subItem:SetText(data ~= nil and tostring(data) or "")
          end
        elseif dataSetFunc ~= nil then
          dataSetFunc(subItem, nil)
        else
          subItem:SetText("")
        end
      end
    end
  end
  return frame
end
