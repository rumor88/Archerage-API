if locale == nil then
  locale = {}
end
local t = function(category, key)
  return X2Locale:LocalizeUiText(category, key)
end
if locale.unknown == nil then
  locale.unknown = t(MONEY_TEXT, "unknown")
end
local function tMoney(key)
  return t(MONEY_TEXT, key)
end
local function tLogin(key)
  return t(LOGIN_TEXT, key)
end
locale.money = {
  money = tMoney("money"),
  current = tMoney("current"),
  copper = X2Locale:LocalizeUiText(MONEY_TEXT, "copper_name"),
  silver = X2Locale:LocalizeUiText(MONEY_TEXT, "silver_name"),
  gold = X2Locale:LocalizeUiText(MONEY_TEXT, "gold_name"),
  honor = X2Locale:LocalizeUiText(COMMON_TEXT, "honor_point"),
  dishonor = X2Locale:LocalizeUiText(MONEY_TEXT, "dishonor_name"),
  living_point = X2Locale:LocalizeUiText(COMMON_TEXT, "living_point"),
  gain_leadership_point = X2Locale:LocalizeUiText(MONEY_TEXT, "gain_leadership_point"),
  contribution_point = X2Locale:LocalizeUiText(MONEY_TEXT, "contribution_point"),
  noMoney = X2Locale:LocalizeUiText(MONEY_TEXT, "no_money"),
  sold_out = X2Locale:LocalizeUiText(MONEY_TEXT, "sold_out"),
  no_have_money = X2Locale:LocalizeUiText(MONEY_TEXT, "no_have_money"),
  askChargeAAPoint = X2Locale:LocalizeUiText(MONEY_TEXT, "ask_charge_aa_point"),
  autoUseAAPoint = X2Locale:LocalizeUiText(MONEY_TEXT, "auto_use_aa_point")
}
locale.escape = {
  title = X2Locale:LocalizeUiText(COMMON_TEXT, "escape_title"),
  content = function(a)
    return X2Locale:LocalizeUiText(COMMON_TEXT, "escape_content", tostring(a))
  end
}
locale.questContext = {
  tabText = {
    X2Locale:LocalizeUiText(QUEST_TEXT, "tabText_progress"),
    X2Locale:LocalizeUiText(QUEST_TEXT, "tabText_mainQuest")
  },
  replay = X2Locale:LocalizeUiText(QUEST_TEXT, "replay"),
  questComplete = X2Locale:LocalizeUiText(QUEST_INTERACTION_TEXT, "complete_quest"),
  list = X2Locale:LocalizeUiText(COMMON_TEXT, "quest_contexts"),
  ok = X2Locale:LocalizeUiText(QUEST_TEXT, "ok"),
  no = X2Locale:LocalizeUiText(QUEST_TEXT, "no"),
  Get_gainExp = function(a)
    return X2Locale:LocalizeUiText(QUEST_TEXT, "gain_exp", a)
  end,
  completeMessage = X2Locale:LocalizeUiText(QUEST_TEXT, "complete_msg"),
  letItDoneMessage = X2Locale:LocalizeUiText(QUEST_TEXT, "letitdone_msg"),
  overDoneMessage = X2Locale:LocalizeUiText(QUEST_TEXT, "overdone_msg"),
  complete = X2Locale:LocalizeUiText(QUEST_TEXT, "complete"),
  cancel = X2Locale:LocalizeUiText(QUEST_TEXT, "cancel"),
  letItDone = X2Locale:LocalizeUiText(QUEST_TEXT, "letitdone"),
  overDone = X2Locale:LocalizeUiText(QUEST_TEXT, "overdone"),
  compensation = X2Locale:LocalizeUiText(QUEST_TEXT, "compensation"),
  selectiveCompensation = X2Locale:LocalizeUiText(QUEST_TEXT, "selective_compensation"),
  selectItem = X2Locale:LocalizeUiText(QUEST_TEXT, "select_item"),
  rewardAnd = X2Locale:LocalizeUiText(QUEST_TEXT, "reward_and"),
  rewardMoney = X2Locale:LocalizeUiText(QUEST_TEXT, "reward_money"),
  livingPoint = X2Locale:LocalizeUiText(COMMON_TEXT, "living_point"),
  rewardDisHonor = X2Locale:LocalizeUiText(QUEST_TEXT, "reward_dishonor"),
  questCount = X2Locale:LocalizeUiText(QUEST_TEXT, "quest_count"),
  selectAllQuests = X2Locale:LocalizeUiText(QUEST_TEXT, "select_all_quests"),
  selectAllQuestsTip = X2Locale:LocalizeUiText(QUEST_TEXT, "select_all_quests_tip"),
  takeReward = X2Locale:LocalizeUiText(QUEST_TEXT, "take_reward"),
  hiddenQuest = X2Locale:LocalizeUiText(QUEST_TEXT, "hidden_quest"),
  rewardSelect = X2Locale:LocalizeUiText(QUEST_TEXT, "rewardSelect"),
  rewardTake = X2Locale:LocalizeUiText(QUEST_TEXT, "rewardTake"),
  rewardAAPoint = X2Locale:LocalizeUiText(MONEY_TEXT, "aa_point"),
  abandonQuest = X2Locale:LocalizeUiText(QUEST_TEXT, "abandonQuest"),
  mySelf = X2Locale:LocalizeUiText(QUEST_TEXT, "my_self"),
  invalid_reward = X2Locale:LocalizeUiText(QUEST_TEXT, "invalid_reward"),
  Get_category = function(a)
    return X2Locale:LocalizeUiText(QUEST_TEXT, "category", F_TEXT.IStr(a))
  end,
  errors = {
    X2Locale:LocalizeUiText(QUEST_ERROR, "already_have"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "invalid_quest"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "player_not_found"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "invalid_character"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "cant_supply_quest_item"),
    function(questDetail, isCommon)
      if isCommon == true then
        return X2Locale:LocalizeUiText(QUEST_ERROR, "maybe_common_quest_list_full")
      end
      local questDetailStr = X2Locale:LocalizeUiText(COMMON_TEXT, string.format("quest_detail_%s", questDetail))
      if questDetailStr == nil then
        return "invalid quest"
      end
      return X2Locale:LocalizeUiText(QUEST_ERROR, "maybe_quest_list_full", questDetailStr, questDetailStr)
    end,
    X2Locale:LocalizeUiText(QUEST_ERROR, "invalid_npc_or_quest"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "invalid_request_for_npc"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "unit_requirement_check"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "invalid_reward_selection"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "cant_supply_rewards"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "invalid_quest_status"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "remove_quest_item_fail"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "invalid_quest_objective"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "invalid_quest_objective_index"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "wrong_answer_for_player_choice"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "precedent_objective_is_not_completed"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "invalid_npc"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "invalid_doodad"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "too_far_away_to_interact_with"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "update_failed"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "not_progressing"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "bag_full"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "item_required"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "level_not_match"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "gained_item_is_not_match"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "already_completed"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "backpack_occupied"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "cant_supply_money"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "cant_accept_by_fatigue"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "daily_limit"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "no_mate_item_in_the_bag"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "need_to_mate_summon"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "not_enough_mate_level"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "mate_equipments_are_not_empty"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "player_trade"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "not_running_game_schedule_quest"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "cannot_while_teleport"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "blocked_quest"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "chronicle_info_need"),
    X2Locale:LocalizeUiText(QUEST_ERROR, "weekly_limit")
  },
  openMap = X2Locale:LocalizeUiText(QUEST_TEXT, "open_map"),
  quest = X2Locale:LocalizeUiText(QUEST_TEXT, "quest"),
  next = X2Locale:LocalizeUiText(QUEST_TEXT, "quest_talk_next"),
  prev = X2Locale:LocalizeUiText(COMMON_TEXT, "prev"),
  selectiveObj = X2Locale:LocalizeUiText(QUEST_TEXT, "only_one_object_message"),
  aggroObj = X2Locale:LocalizeUiText(QUEST_TEXT, "aggro_obj_desc"),
  groupObj = X2Locale:LocalizeUiText(QUEST_TEXT, "group_obj_desc"),
  scoreCount = X2Locale:LocalizeUiText(QUEST_TEXT, "scoreCount"),
  doing = X2Locale:LocalizeUiText(QUEST_TEXT, "doing")
}
locale.login = {
  login = tLogin("login"),
  id = tLogin("id"),
  password = tLogin("password"),
  connectExit = tLogin("connectExit"),
  loginTip = tLogin("loginTip"),
  staff = tLogin("developer"),
  returnBtn = tLogin("back_to_login"),
  btn_otp = tLogin("btn_otp"),
  title_otp = tLogin("title_otp"),
  error_title_otp = tLogin("error_title_otp"),
  GetErrorContentOtp = function(maxTry)
    return X2Locale:LocalizeUiText(LOGIN_TEXT, "error_content_otp", tostring(maxTry))
  end,
  btn_pc_cert = tLogin("btn_pc_cert"),
  title_pc_cert = tLogin("title_pc_cert"),
  error_title_pc_cert = tLogin("error_title_pc_cert"),
  error_title_secure_card = tLogin("error_title_secure_card"),
  GetErrorContentPcCert = function(maxTry)
    return X2Locale:LocalizeUiText(LOGIN_TEXT, "error_content_pc_cert", tostring(maxTry))
  end,
  GetErrorContentRemainCount = function(failCount, maxTry)
    return X2Locale:LocalizeUiText(LOGIN_TEXT, "error_content_cert_count", tostring(failCount), tostring(maxTry))
  end,
  GetContentArsWithTimeOut = function(remainTime)
    return X2Locale:LocalizeUiText(LOGIN_TEXT, "content_ars_with_timeout", tostring(remainTime))
  end,
  GetContentArs = function()
    return X2Locale:LocalizeUiText(LOGIN_TEXT, "content_ars")
  end,
  certing = tLogin("certing"),
  join = X2Locale:LocalizeUiText(LOGIN_TEXT, "join"),
  findId = X2Locale:LocalizeUiText(LOGIN_TEXT, "find_id"),
  findPassword = X2Locale:LocalizeUiText(LOGIN_TEXT, "find_password")
}
locale.server = {
  enter = X2Locale:LocalizeUiText(SERVER_TEXT, "enter"),
  name = X2Locale:LocalizeUiText(SERVER_TEXT, "name"),
  nameIndependent = X2Locale:LocalizeUiText(SERVER_TEXT, "name_independent"),
  state = X2Locale:LocalizeUiText(SERVER_TEXT, "state"),
  popLow = X2Locale:LocalizeUiText(SERVER_TEXT, "popLow"),
  popMiddle = X2Locale:LocalizeUiText(SERVER_TEXT, "popMiddle"),
  popHigh = X2Locale:LocalizeUiText(SERVER_TEXT, "popHigh"),
  cantUse = X2Locale:LocalizeUiText(SERVER_TEXT, "cantUse"),
  checking = X2Locale:LocalizeUiText(SERVER_TEXT, "checking"),
  paramOrder = function(a)
    return X2Locale:LocalizeUiText(SERVER_TEXT, "paramOrder", tostring(a))
  end,
  paramCountOfPersons = function(a)
    return X2Locale:LocalizeUiText(SERVER_TEXT, "paramCountOfPersons", tostring(a))
  end,
  totalWaitingPersons = X2Locale:LocalizeUiText(SERVER_TEXT, "totalWaitingPersons"),
  timeAboveOneHour = X2Locale:LocalizeUiText(SERVER_TEXT, "timeAboveOneHour"),
  GetGuideText = function(a)
    return X2Locale:LocalizeUiText(SERVER_TEXT, "GetGuideText", tostring(a))
  end,
  max_character_count_change = function(maxPerWorld, maxPerAccount)
    return X2Locale:LocalizeUiText(SERVER_TEXT, "max_character_count_change", tostring(maxPerWorld), tostring(maxPerAccount))
  end,
  max_character_count_warning = function(maxPerWorld, maxPerAccount, maxExpandable)
    if maxExpandable > 0 then
      return X2Locale:LocalizeUiText(SERVER_TEXT, "max_character_count_warning2", tostring(maxPerAccount), tostring(maxPerWorld), tostring(maxPerAccount + maxExpandable))
    elseif maxPerWorld == maxPerAccount then
      return X2Locale:LocalizeUiText(SERVER_TEXT, "max_character_count_warning3", tostring(maxPerWorld))
    else
      return X2Locale:LocalizeUiText(SERVER_TEXT, "max_character_count_warning", tostring(maxPerWorld), tostring(maxPerAccount))
    end
  end,
  pre_select_character_warning = X2Locale:LocalizeUiText(SERVER_TEXT, "pre_select_character_warning"),
  nuian_start_region = X2Locale:LocalizeUiText(SERVER_TEXT, "nuian_start_region"),
  elf_start_region = X2Locale:LocalizeUiText(SERVER_TEXT, "elf_start_region"),
  ferre_start_region = X2Locale:LocalizeUiText(SERVER_TEXT, "ferre_start_region"),
  hariharan_start_region = X2Locale:LocalizeUiText(SERVER_TEXT, "hariharan_start_region"),
  race_congestion_low = X2Locale:LocalizeUiText(SERVER_TEXT, "race_congestion_low"),
  race_congestion_middle = X2Locale:LocalizeUiText(SERVER_TEXT, "race_congestion_middle"),
  race_congestion_high = X2Locale:LocalizeUiText(SERVER_TEXT, "race_congestion_high"),
  refresh = X2Locale:LocalizeUiText(SERVER_TEXT, "refresh"),
  refresh_diable = X2Locale:LocalizeUiText(SERVER_TEXT, "refresh_diable"),
  pre_select_cant_create = X2Locale:LocalizeUiText(SERVER_TEXT, "pre_select_cant_create"),
  serverIntegrationWarning = X2Locale:LocalizeUiText(COMMON_TEXT, "serverIntegrationWarning"),
  serverIntegrationNotice = X2Locale:LocalizeUiText(COMMON_TEXT, "serverIntegrationNotice"),
  integration = X2Locale:LocalizeUiText(COMMON_TEXT, "integration"),
  newWorld = X2Locale:LocalizeUiText(COMMON_TEXT, "newWorld"),
  integrationWarning = X2Locale:LocalizeUiText(COMMON_TEXT, "serverIntegrationWarning2"),
  integrationWorldList = {
    X2Locale:LocalizeUiText(COMMON_TEXT, "integrationWorldList1"),
    X2Locale:LocalizeUiText(COMMON_TEXT, "integrationWorldList2")
  },
  integratedWorld = {
    X2Locale:LocalizeUiText(COMMON_TEXT, "integratedWorld1"),
    X2Locale:LocalizeUiText(COMMON_TEXT, "integratedWorld2")
  },
  newWorldNotice = X2Locale:LocalizeUiText(COMMON_TEXT, "newWorldNotice")
}
locale.characterSelect = {
  invalidIndex = X2Locale:LocalizeUiText(CHARACTER_SELECT_TEXT, "invalide_faction_index"),
  unknownFactionInfo = X2Locale:LocalizeUiText(CHARACTER_SELECT_TEXT, "unknown_faction"),
  max_character_count_warning = X2Locale:LocalizeUiText(CHARACTER_SELECT_TEXT, "max_character_count_warning"),
  max_character_count_warning2 = X2Locale:LocalizeUiText(CHARACTER_SELECT_TEXT, "max_character_count_warning2"),
  character_count_not_match = X2Locale:LocalizeUiText(CHARACTER_SELECT_TEXT, "character_count_not_match"),
  waiting_remainTime_text = function(remain)
    return X2Locale:LocalizeUiText(COMMON_TEXT, "waiting_remainTime_text", tostring(remain))
  end,
  waiting_remainTime_calculating_text = X2Locale:LocalizeUiText(COMMON_TEXT, "waiting_remainTime_calculating_text"),
  character_name_force_changed = X2Locale:LocalizeUiText(COMMON_TEXT, "character_name_force_changed")
}
locale.loginCrowded = {
  tip = {
    X2Locale:LocalizeUiText(LOGIN_CROWDED_TEXT, "smooth"),
    X2Locale:LocalizeUiText(LOGIN_CROWDED_TEXT, "crowed"),
    X2Locale:LocalizeUiText(LOGIN_CROWDED_TEXT, "race_balance_unable"),
    X2Locale:LocalizeUiText(LOGIN_CROWDED_TEXT, "race_balance_unable")
  }
}
locale.tutorial = {
  title = X2Locale:LocalizeUiText(TUTORIAL_TEXT, "title"),
  looting = X2Locale:LocalizeUiText(TUTORIAL_TEXT, "looting"),
  mount = X2Locale:LocalizeUiText(TUTORIAL_TEXT, "mount"),
  dead = X2Locale:LocalizeUiText(TUTORIAL_TEXT, "dead"),
  acceptFirstQuest = X2Locale:LocalizeUiText(TUTORIAL_TEXT, "accept_first_quest"),
  acceptFirstItemQuest = X2Locale:LocalizeUiText(TUTORIAL_TEXT, "accept_first_item_quest"),
  skill_train = X2Locale:LocalizeUiText(TUTORIAL_TEXT, "skill_train"),
  event_return_point = X2Locale:LocalizeUiText(TUTORIAL_TEXT, "event_return_point"),
  uiAvi = X2Locale:LocalizeUiText(TUTORIAL_TEXT, "ui_avi"),
  GetReturnPointMsg = function(a)
    return X2Locale:LocalizeUiText(TUTORIAL_TEXT, "return_point_msg", a)
  end,
  updateBag = {
    gain_item = X2Locale:LocalizeUiText(TUTORIAL_TEXT, "bag_gain_item"),
    summonMate = X2Locale:LocalizeUiText(TUTORIAL_TEXT, "bag_summon_mate"),
    weaponOrArmor = X2Locale:LocalizeUiText(TUTORIAL_TEXT, "bag_weapon_or_armor")
  },
  openBag = {
    summonMate = X2Locale:LocalizeUiText(TUTORIAL_TEXT, "open_bag_summon_mate"),
    weaponOrArmor = X2Locale:LocalizeUiText(TUTORIAL_TEXT, "open_bag_weapon_or_armor")
  }
}
locale.trade = {
  myStuff = X2Locale:LocalizeUiText(TRADE_TEXT, "my_stuff"),
  money = X2Locale:LocalizeUiText(TRADE_TEXT, "money"),
  cancel = X2Locale:LocalizeUiText(TRADE_TEXT, "cancel"),
  ok = X2Locale:LocalizeUiText(TRADE_TEXT, "ok"),
  lock = X2Locale:LocalizeUiText(TRADE_TEXT, "lock"),
  unlock = X2Locale:LocalizeUiText(TRADE_TEXT, "unlock"),
  canceled = X2Locale:LocalizeUiText(TRADE_TEXT, "canceled"),
  registedItem = X2Locale:LocalizeUiText(TRADE_TEXT, "registed_item"),
  tradeOk = X2Locale:LocalizeUiText(TRADE_TEXT, "trade_ok"),
  tradeOtherLocked = X2Locale:LocalizeUiText(TRADE_TEXT, "trade_other_locked"),
  tradeOtherLockCanceled = X2Locale:LocalizeUiText(TRADE_TEXT, "trade_other_lock_canceled"),
  tradeOtherOk = X2Locale:LocalizeUiText(TRADE_TEXT, "trade_other_ok"),
  tradeAccomplishd = X2Locale:LocalizeUiText(TRADE_TEXT, "trade_accomplishd"),
  lockedMsg = X2Locale:LocalizeUiText(TRADE_TEXT, "trade_confirm"),
  otherLockedMsg = X2Locale:LocalizeUiText(TRADE_TEXT, "trade_other_confirm"),
  unlockedMsg = X2Locale:LocalizeUiText(TRADE_TEXT, "trade_cancel_confirm")
}
locale.comercialMail = {
  goodsCategory = X2Locale:LocalizeUiText(MAIL_TEXT, "goods_category"),
  goodsTitle = X2Locale:LocalizeUiText(MAIL_TEXT, "goods_title"),
  goodsRemain = X2Locale:LocalizeUiText(MAIL_TEXT, "goods_remain"),
  guide = X2Locale:LocalizeUiText(MAIL_TEXT, "comercial_mail_guide")
}
locale.mail = {
  readMail = X2Locale:LocalizeUiText(MAIL_TEXT, "read_mail"),
  readSentMail = X2Locale:LocalizeUiText(MAIL_TEXT, "read_sent_mail"),
  sender = X2Locale:LocalizeUiText(MAIL_TEXT, "sender"),
  receiver = X2Locale:LocalizeUiText(MAIL_TEXT, "receiver"),
  title = X2Locale:LocalizeUiText(MAIL_TEXT, "title"),
  attachRecv = X2Locale:LocalizeUiText(MAIL_TEXT, "attach_recv"),
  moneyRece = X2Locale:LocalizeUiText(MAIL_TEXT, "money_rece"),
  normalMail = X2Locale:LocalizeUiText(MAIL_TEXT, "normal_mail"),
  expressMail = X2Locale:LocalizeUiText(MAIL_TEXT, "express_mail"),
  send = X2Locale:LocalizeUiText(MAIL_TEXT, "send"),
  attachment = X2Locale:LocalizeUiText(MAIL_TEXT, "attachment"),
  reply = X2Locale:LocalizeUiText(MAIL_TEXT, "reply"),
  GetUnreadMail = function(count)
    return X2Locale:LocalizeUiText(MAIL_TEXT, "unread_mail", tostring(count))
  end,
  haveAttachItem = X2Locale:LocalizeUiText(MAIL_TEXT, "have_attach_item"),
  deletedCharacter = X2Locale:LocalizeUiText(MAIL_TEXT, "deleted_character"),
  generalDelivery = function(a)
    return X2Locale:LocalizeUiText(MAIL_TEXT, "general_delivery", a)
  end,
  expressDelivery = function(a)
    return X2Locale:LocalizeUiText(MAIL_TEXT, "express_delivery", a)
  end,
  bidMoney = X2Locale:LocalizeUiText(MAIL_TEXT, "bid_money"),
  charge = X2Locale:LocalizeUiText(MAIL_TEXT, "charge"),
  profit = X2Locale:LocalizeUiText(MAIL_TEXT, "profit"),
  notExistReadMail = X2Locale:LocalizeUiText(MAIL_TEXT, "not_exist_read_mail"),
  allReadMailIncludeAttach = X2Locale:LocalizeUiText(MAIL_TEXT, "all_read_mail_include_attach"),
  alarmAllReadMailDelected = X2Locale:LocalizeUiText(MAIL_TEXT, "alarm_all_read_mail_delected"),
  bargainingMoney = X2Locale:LocalizeUiText(MAIL_TEXT, "bargaining_money"),
  interest = X2Locale:LocalizeUiText(MAIL_TEXT, "interest"),
  totalSellBackpackMoney = X2Locale:LocalizeUiText(MAIL_TEXT, "total_sell_backpack_money"),
  sellBackpackTip = X2Locale:LocalizeUiText(MAIL_TEXT, "sell_backpack_tip"),
  housePrice = X2Locale:LocalizeUiText(MAIL_TEXT, "house_price"),
  unboundButler = {
    sender = function()
      return GetCommonText("butler")
    end,
    title = function()
      return GetUIText(MAIL_TEXT, "unbind_butler_mail_title")
    end,
    body = function()
      return GetUIText(MAIL_TEXT, "unbind_butler_mail_body")
    end
  },
  butlerHarvest = {
    sender = function()
      return GetCommonText("butler")
    end,
    title = function()
      return GetUIText(MAIL_TEXT, "butler_harvest_mail_title")
    end,
    body = function(itemType, requestedAmount, withBonus)
      local withBonusMessage = ""
      if withBonus then
        withBonusMessage = GetUIText(MAIL_TEXT, "butler_harvest_bonuse_mail_body")
      end
      local itemName = X2Item:Name(itemType) or "Unknown Item"
      return X2Locale:LocalizeUiText(MAIL_TEXT, "butler_harvest_mail_body", itemName, tostring(requestedAmount), withBonusMessage)
    end
  },
  expeditionOwnerChangeAutomatically = {
    sender = function()
      return X2Locale:LocalizeUiText(MAP_TEXT, "M_NPC_STORE_EXPEDITION")
    end,
    title = function(isFormerOnwer)
      return isFormerOnwer == true and X2Locale:LocalizeUiText(MAIL_TEXT, "mail_title_nofication_of_fire_expedition_owner_automatically") or X2Locale:LocalizeUiText(MAIL_TEXT, "mail_title_nofication_of_new_expedition_owner_automatically")
    end,
    body = function(isFormerOnwer)
      return isFormerOnwer == true and X2Locale:LocalizeUiText(MAIL_TEXT, "mail_body_nofication_of_fire_expedition_owner_automatically") or X2Locale:LocalizeUiText(MAIL_TEXT, "mail_body_nofication_of_new_expedition_owner_automatically")
    end
  },
  houseSellCancel = {
    title = function(zoneId, houseName)
      local info = {
        title = X2Locale:LocalizeUiText(MAIL_TEXT, "title_house_sell_cancel"),
        sender = X2Locale:LocalizeUiText(MAIL_TEXT, "house_tax_sender", X2Dominion:GetZoneGroupName(zoneId))
      }
      return info
    end,
    body = function(houseName, itemType, count)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "body_house_sell_cancel", tostring(houseName))
    end
  },
  houseSold = {
    title = function(buyerName, houseName)
      local info = {
        title = X2Locale:LocalizeUiText(MAIL_TEXT, "title_house_sold"),
        sender = buyerName
      }
      return info
    end,
    body = function(buyerName, houseName, price, tax, taxRate)
      local strTable = {
        buyerName = buyerName,
        houseName = houseName,
        price = price,
        tax = tax,
        taxRate = taxRate
      }
      return strTable
    end
  },
  houseBought = {
    title = function(zoneId, houseName)
      local info = {
        title = X2Locale:LocalizeUiText(MAIL_TEXT, "title_house_bought"),
        sender = X2Locale:LocalizeUiText(MAIL_TEXT, "house_tax_sender", X2Dominion:GetZoneGroupName(zoneId))
      }
      return info
    end,
    body = function(sellerName, houseName, price)
      local strTable = {
        sellerName = sellerName,
        houseName = houseName,
        price = price
      }
      return strTable
    end
  },
  houseTax = {
    sender = function(zoneName)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "house_tax_sender", zoneName)
    end,
    title = function(zoneName)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "house_tax_title", zoneName)
    end,
    defaultWaring = X2Locale:LocalizeUiText(MAIL_TEXT, "house_tax_default_waring"),
    body = function(name, p1, p2, due, basicTax, dominionTaxRate, heavyTaxHouseCount, weeks, charge, isHeavyTaxHouse, normalTaxHouseCount, hostileTaxRate, taxType, monopolyTaxRate)
      local bodyInfo = {}
      bodyInfo.name = name
      bodyInfo.tax_period_start = p1
      bodyInfo.tax_period_end = p2
      bodyInfo.pay_period = due
      bodyInfo.basic_tax = basicTax
      bodyInfo.dominion_tax_rate = dominionTaxRate
      bodyInfo.heavyTaxHouseCount = heavyTaxHouseCount
      bodyInfo.unpaid_count = weeks
      bodyInfo.total_tax = charge
      bodyInfo.isHeavyTaxHouse = isHeavyTaxHouse
      bodyInfo.normalTaxHouseCount = normalTaxHouseCount
      bodyInfo.hostile_tax_rate = hostileTaxRate
      bodyInfo.tax_type = taxType == nil and HOUSING_TAX_SEAL or taxType
      bodyInfo.monopoly_tax_rate = monopolyTaxRate
      return bodyInfo
    end
  },
  houseRebuild = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = X2Locale:LocalizeUiText(COMMON_TEXT, "rebuilding_mail_title"),
    body = function(deposit, existingHousingName, rebuilngHousingName)
      local bodyInfo = {}
      bodyInfo.deposit = deposit
      bodyInfo.existingHousingName = existingHousingName
      bodyInfo.rebuilngHousingName = rebuilngHousingName
      return bodyInfo
    end
  },
  taxInKindReceipt = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "balance_receipt_sender"),
    title = function(zoneName, isNation)
      if isNation == true then
        return X2Locale:LocalizeUiText(COMMON_TEXT, "tax_in_kind_balance_nation_receipt_title", zoneName)
      else
        return X2Locale:LocalizeUiText(COMMON_TEXT, "tax_in_kind_balance_receipt_title", zoneName)
      end
    end,
    body = function(zoneName, isNation)
      if isNation == true then
        return X2Locale:LocalizeUiText(COMMON_TEXT, "tax_in_kind_balance_nation_receipt_body", zoneName)
      else
        return X2Locale:LocalizeUiText(COMMON_TEXT, "tax_in_kind_balance_receipt_body", zoneName)
      end
    end
  },
  balanceReceiptBody = {
    period = function(zoneName, startPeriod, endPeriod)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "balance_receipt_body_period", zoneName, startPeriod, endPeriod)
    end
  },
  taxRateChange = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "tax_rate_change_sender"),
    titleName = X2Locale:LocalizeUiText(MAIL_TEXT, "tax_rate_change_title_name"),
    taxtations = X2Locale:LocalizeUiText(MAIL_TEXT, "tax_rate_change_taxtations"),
    title = function(zoneName)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "tax_rate_change_title", zoneName)
    end,
    body = function(oldTaxRate, newTaxRate)
      local bodyInfo = {}
      bodyInfo.old_tax_rate = oldTaxRate
      bodyInfo.new_tax_rate = newTaxRate
      return bodyInfo
    end
  },
  taxRateChangeBody = {
    content = function(zoneName)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "tax_rate_change_body_content", zoneName)
    end
  },
  auctionOffCancel = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "auctioneer"),
    title = function(a, b)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "auction_cancel_title", a, tostring(b))
    end,
    body = function(a, b)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "auction_cancel_body", a, tostring(b))
    end
  },
  auctionOffSuccess = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "auctioneer"),
    title = function(a, b)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "auction_success_title", a, tostring(b))
    end,
    body = function(a, b, c, d, e, f, g, h, i, j)
      local offSuccessInfo = {
        itemName = a,
        count = X2Locale:LocalizeUiText(COMMON_TEXT, "amount", tostring(b)),
        money = c,
        bidMoney = d,
        charge = e,
        deposit = f,
        advantage = g,
        chargePers = h,
        duration = i,
        serviceKind = j
      }
      return offSuccessInfo
    end
  },
  auctionOffFail = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "auctioneer"),
    title = function(a, b)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "auction_fail_title", a, tostring(b))
    end,
    body = function(a, b)
      local offFailInfo = {
        bodyTitle = X2Locale:LocalizeUiText(MAIL_TEXT, "auction_fail_body", a, tostring(b))
      }
      return offFailInfo
    end
  },
  auctionBidWin = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "auctioneer"),
    title = function(a, b)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "bid_win_title", a, tostring(b))
    end,
    body = function(a, b, c)
      local offBidWinInfo = {
        bodyTitle = X2Locale:LocalizeUiText(MAIL_TEXT, "bid_win_body", a, tostring(b)),
        money = c
      }
      return offBidWinInfo
    end
  },
  auctionBidFail = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "auctioneer"),
    title = function(a)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "bid_fail_title", a)
    end,
    body = function(a)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "bid_fail_body", a)
    end
  },
  auctionDepositRatioDiff = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "auctioneer"),
    body = function(itemType, itemCount, goldStr, silverStr, copperStr)
      local name = X2Item:Name(itemType) or "Unknown Item"
      return X2Locale:LocalizeUiText(MAIL_TEXT, "auction_deposit_ratio_diff_body", name, tostring(itemCount), goldStr, silverStr, copperStr)
    end
  },
  auctionDepositLimitDiff = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "auctioneer"),
    body = function(itemType, itemCount, goldStr, silverStr, copperStr)
      local name = X2Item:Name(itemType) or "Unknown Item"
      return X2Locale:LocalizeUiText(MAIL_TEXT, "auction_deposit_limit_diff_body", name, tostring(itemCount), goldStr, silverStr, copperStr)
    end
  },
  auctionOffCancelNew = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "auctioneer"),
    title = function(a, b)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "auction_cancel_title", X2Item:Name(tonumber(a)) or a, tostring(b))
    end,
    body = function(a, b)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "auction_cancel_body", X2Item:Name(tonumber(a)) or a, tostring(b))
    end
  },
  auctionOffSuccessNew = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "auctioneer"),
    title = function(a, b)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "auction_success_title", X2Item:Name(tonumber(a)) or a, tostring(b))
    end,
    body = function(a, b, c, d, e, f, g, h, i, j)
      local offSuccessInfo = {
        itemName = X2Item:Name(tonumber(a)) or a,
        count = X2Locale:LocalizeUiText(COMMON_TEXT, "amount", tostring(b)),
        money = c,
        bidMoney = d,
        charge = e,
        deposit = f,
        advantage = g,
        chargePers = h,
        duration = i,
        serviceKind = j
      }
      return offSuccessInfo
    end
  },
  auctionOffFailNew = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "auctioneer"),
    title = function(a, b)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "auction_fail_title", X2Item:Name(tonumber(a)) or a, tostring(b))
    end,
    body = function(a, b)
      local offFailInfo = {
        bodyTitle = X2Locale:LocalizeUiText(MAIL_TEXT, "auction_fail_body", X2Item:Name(tonumber(a)) or a, tostring(b))
      }
      return offFailInfo
    end
  },
  auctionBidWinNew = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "auctioneer"),
    title = function(a, b)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "bid_win_title", X2Item:Name(tonumber(a)) or a, tostring(b))
    end,
    body = function(a, b, c)
      local offBidWinInfo = {
        bodyTitle = X2Locale:LocalizeUiText(MAIL_TEXT, "bid_win_body", X2Item:Name(tonumber(a)) or a, tostring(b)),
        money = c
      }
      return offBidWinInfo
    end
  },
  auctionBidFailNew = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "auctioneer"),
    title = function(a)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "bid_fail_title", X2Item:Name(tonumber(a)) or a)
    end,
    body = function(a)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "bid_fail_body", X2Item:Name(tonumber(a)) or a)
    end
  },
  craftOrderCancel = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "craft_order_manager"),
    title = function(craftType)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "craft_order_cancel_title")
    end,
    body = function(craftType)
      local pInfo = X2Craft:GetCraftProductInfo(craftType)[1]
      return X2Locale:LocalizeUiText(MAIL_TEXT, "craft_order_cancel_body", pInfo.item_name)
    end
  },
  craftOrderExpired = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "craft_order_manager"),
    title = function(craftType)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "craft_order_cancel_title")
    end,
    body = function(craftType)
      local pInfo = X2Craft:GetCraftProductInfo(craftType)[1]
      return X2Locale:LocalizeUiText(MAIL_TEXT, "craft_order_expired_body", pInfo.item_name)
    end
  },
  craftOrderModified = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "craft_order_manager"),
    title = function(craftType)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "craft_order_cancel_title")
    end,
    body = function(craftType)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "craft_order_modified_body")
    end
  },
  craftOrderHandle = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "craft_order_manager"),
    title = function(craftType)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "craft_order_complete_title")
    end,
    body = function(craftType)
      local pInfo = X2Craft:GetCraftProductInfo(craftType)[1]
      return X2Locale:LocalizeUiText(MAIL_TEXT, "craft_order_complete_body", pInfo.item_name)
    end
  },
  craftOrderFee = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "craft_order_manager"),
    title = function(craftType)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "craft_order_process_title")
    end,
    body = function(craftType)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "craft_order_process_body")
    end
  },
  questReward = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "achievement_reward"),
    title = function(questName)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "quest_title", questName)
    end,
    body = function(questName)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "quest_body", questName)
    end
  },
  questRewardNew = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "achievement_reward"),
    title = function(questType)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "quest_title", X2Quest:GetQuestName(tonumber(questType)))
    end,
    body = function(questType)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "quest_body", X2Quest:GetQuestName(tonumber(questType)))
    end
  },
  expeditionQuestReward = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "expedition_quest_reward_mail_sender"),
    title = function()
      return X2Locale:LocalizeUiText(COMMON_TEXT, "expedition_quest_reward_mail_title")
    end,
    body = function(questName)
      return X2Locale:LocalizeUiText(COMMON_TEXT, "expedition_quest_reward_mail_body", questName)
    end
  },
  expeditionQuestRewardNew = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "expedition_quest_reward_mail_sender"),
    title = function()
      return X2Locale:LocalizeUiText(COMMON_TEXT, "expedition_quest_reward_mail_title")
    end,
    body = function(questType)
      return X2Locale:LocalizeUiText(COMMON_TEXT, "expedition_quest_reward_mail_body", X2Quest:GetQuestName(tonumber(questType)))
    end
  },
  sellBackpack = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "sell_backpack"),
    title = function(a)
      if a == nil then
        return X2Locale:LocalizeUiText(MAIL_TEXT, "sell_backpack_title")
      elseif a == 0 then
        return X2Locale:LocalizeUiText(COMMON_TEXT, "mail_sell_backpack_title_crafter")
      elseif a == 1 then
        return X2Locale:LocalizeUiText(COMMON_TEXT, "mail_sell_backpack_title_seller")
      elseif a == 2 then
        return X2Locale:LocalizeUiText(MAIL_TEXT, "sell_backpack_title")
      elseif a == 3 then
        return X2Locale:LocalizeUiText(COMMON_TEXT, "sell_tradegood_title")
      end
    end,
    body = function(a, b, c, d, e, extraRatio, actualGain, receiverCase, coinType, crafterCoinCount, sellerCoinCount, revenueSanction, extraRatioKind, tradegood, interest, freshness, specialtyMerchantRatio, sellerRatio)
      if e == nil then
        e = 0
      end
      if c == nil then
        d = b
        b = 0
        c = 0
      end
      if sellerCoinCount == nil then
        sellerCoinCount = crafterCoinCount
        crafterCoinCount = coinType
        coinType = receiverCase
        receiverCase = actualGain
        actualGain = extraRatio
        extraRatio = 0
      end
      if extraRatioKind == nil then
        extraRatioKind = extraRatio > 0 and 1 or 0
      end
      if tradegood == nil then
        tradegood = 0
      end
      if interest == nil then
        interest = 5
      end
      if freshness == nil then
        freshness = 0
      end
      if specialtyMerchantRatio == nil then
        specialtyMerchantRatio = 0
      end
      local strTable = {
        itemName = X2Locale:LocalizeUiText(MAIL_TEXT, "sell_backpack_item_name", a),
        ratio = b,
        earlyMoney = string.format("|m%d;", c),
        totalMoney = string.format("|m%d;", d),
        bargain = e,
        bargainingMoney = string.format("|m%d;", e),
        actualGain = string.format("|m%d", actualGain),
        receiverCase = receiverCase,
        coinType = coinType,
        crafterCoinCount = crafterCoinCount,
        sellerCoinCount = sellerCoinCount,
        extraRatio = extraRatio,
        revenueSanction = revenueSanction,
        extraRatioKind = extraRatioKind,
        tradegood = tradegood,
        interest = interest,
        freshness = freshness,
        specialtyMerchantRatio = specialtyMerchantRatio,
        sellerRatio = sellerRatio
      }
      return strTable
    end
  },
  sellBackpackNew = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "sell_backpack"),
    title = function(a)
      if a == nil then
        return X2Locale:LocalizeUiText(MAIL_TEXT, "sell_backpack_title")
      elseif a == 0 then
        return X2Locale:LocalizeUiText(COMMON_TEXT, "mail_sell_backpack_title_crafter")
      elseif a == 1 then
        return X2Locale:LocalizeUiText(COMMON_TEXT, "mail_sell_backpack_title_seller")
      elseif a == 2 then
        return X2Locale:LocalizeUiText(MAIL_TEXT, "sell_backpack_title")
      elseif a == 3 then
        return X2Locale:LocalizeUiText(COMMON_TEXT, "sell_tradegood_title")
      end
    end,
    body = function(soldItemType, b, c, d, e, extraRatio, actualGain, receiverCase, coinType, crafterCoinCount, sellerCoinCount, revenueSanction, extraRatioKind, tradegood, interest, freshness, specialtyMerchantRatio, sellerRatio)
      if e == nil then
        e = 0
      end
      if c == nil then
        d = b
        b = 0
        c = 0
      end
      if sellerCoinCount == nil then
        sellerCoinCount = crafterCoinCount
        crafterCoinCount = coinType
        coinType = receiverCase
        receiverCase = actualGain
        actualGain = extraRatio
        extraRatio = 0
      end
      if extraRatioKind == nil then
        extraRatioKind = extraRatio > 0 and 1 or 0
      end
      if tradegood == nil then
        tradegood = 0
      end
      if interest == nil then
        interest = 5
      end
      if freshness == nil then
        freshness = 0
      end
      if specialtyMerchantRatio == nil then
        specialtyMerchantRatio = 0
      end
      local strTable = {
        itemName = X2Locale:LocalizeUiText(MAIL_TEXT, "sell_backpack_item_name", X2Item:Name(tonumber(soldItemType)) or ""),
        ratio = b,
        earlyMoney = string.format("|m%d;", c),
        totalMoney = string.format("|m%d;", d),
        bargain = e,
        bargainingMoney = string.format("|m%d;", e),
        actualGain = string.format("|m%d", actualGain),
        receiverCase = receiverCase,
        coinType = coinType,
        crafterCoinCount = crafterCoinCount,
        sellerCoinCount = sellerCoinCount,
        extraRatio = extraRatio,
        revenueSanction = revenueSanction,
        extraRatioKind = extraRatioKind,
        tradegood = tradegood,
        interest = interest,
        freshness = freshness,
        specialtyMerchantRatio = specialtyMerchantRatio,
        sellerRatio = sellerRatio
      }
      return strTable
    end
  },
  houseDemolish = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = X2Locale:LocalizeUiText(MAIL_TEXT, "house_demolish_title"),
    body = X2Locale:LocalizeUiText(MAIL_TEXT, "house_demolish_body")
  },
  houseDemolishIntegration = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = X2Locale:LocalizeUiText(MAIL_TEXT, "house_demolish_title"),
    body = X2Locale:LocalizeUiText(MAIL_TEXT, "house_demolish_body")
  },
  houseDemolishExpedition = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = X2Locale:LocalizeUiText(MAIL_TEXT, "house_demolish_title"),
    body = X2Locale:LocalizeUiText(MAIL_TEXT, "house_demolish_expedition_body")
  },
  houseDemolishReward = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = X2Locale:LocalizeUiText(MAIL_TEXT, "house_demolish_title"),
    body = X2Locale:LocalizeUiText(MAIL_TEXT, "house_demolish_body")
  },
  restoreItem = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = X2Locale:LocalizeUiText(MAIL_TEXT, "restore_item_title"),
    body = X2Locale:LocalizeUiText(MAIL_TEXT, "restore_item_body")
  },
  craftTerminate = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = X2Locale:LocalizeUiText(MAIL_TEXT, "craft_terminate_title"),
    body = X2Locale:LocalizeUiText(MAIL_TEXT, "craft_terminate_body")
  },
  chargePay = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = X2Locale:LocalizeUiText(MAIL_TEXT, "charge_pay_title"),
    body = X2Locale:LocalizeUiText(MAIL_TEXT, "charge_pay_body")
  },
  shipyardExpire = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "shipyard_sender"),
    title = X2Locale:LocalizeUiText(MAIL_TEXT, "shipyard_title"),
    body = X2Locale:LocalizeUiText(MAIL_TEXT, "shipyard_body")
  },
  juryReward = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "jury_reward_sender"),
    title = function(a)
      local num = tonumber(a)
      if num == 10 or num == 100 then
        return X2Locale:LocalizeUiText(MAIL_TEXT, "jury_title", a)
      else
        return X2Locale:LocalizeUiText(MAIL_TEXT, "jury_title2")
      end
    end,
    body = function(a)
      local num = tonumber(a)
      if num == 10 or num == 100 then
        return X2Locale:LocalizeUiText(MAIL_TEXT, "jury_body", a)
      else
        return X2Locale:LocalizeUiText(MAIL_TEXT, "jury_body2")
      end
    end
  },
  arrestorReward = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "jury_reward_sender"),
    title = X2Locale:LocalizeUiText(MAIL_TEXT, "arrestor_reward_title"),
    body = X2Locale:LocalizeUiText(MAIL_TEXT, "arrestor_reward_body")
  },
  reporterReward = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "jury_reward_sender"),
    title = X2Locale:LocalizeUiText(MAIL_TEXT, "bot_report_reward_title"),
    body = function(botName)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "bot_report_reward_body", botName)
    end
  },
  questMail = {
    sender = "__QUEST__",
    title = function(a)
      return a
    end,
    body = function(a)
      return a
    end
  },
  inGameShop = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = function(a)
      return a
    end,
    body = function(...)
      if #arg == 1 then
        itemName = arg[1]
        return X2Locale:LocalizeUiText(MAIL_TEXT, "ingameshop_express_mail")
      else
        present = arg[1]
        who = arg[2]
        itemName = arg[3]
        priceType = arg[4]
        local infos = {}
        infos.priceType = priceType
        if present then
          infos.content = X2Locale:LocalizeUiText(MAIL_TEXT, "ingameshop_body_present", who)
        else
          infos.content = ""
        end
        return infos
      end
    end,
    fromInGameShop = true
  },
  scheduleItem = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = function(a)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "schedule_item_title", a)
    end,
    body = function(a, b)
      if b ~= nil then
        if b == SIMT_SCHEDULE_ITEM_NORMAL_MAIL then
          return X2Locale:LocalizeUiText(MAIL_TEXT, "schedule_item_body", a)
        else
          return a
        end
      else
        return X2Locale:LocalizeUiText(MAIL_TEXT, "schedule_item_body", a)
      end
    end
  },
  achievement = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = function(a)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "achievement_item_title", a)
    end,
    body = function(a, b)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "achievement_item_body", a, b)
    end
  },
  achievementNew = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = function(a)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "achievement_item_title", X2Achievement:GetAchievementName(tonumber(a)))
    end,
    body = function(a)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "achievement_item_body", X2Achievement:GetAchievementName(tonumber(a)))
    end
  },
  todayAssignment = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = function(a)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "today_assignment_item_title", a)
    end,
    body = function(a)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "today_assignment_item_body", a)
    end
  },
  rankReward = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = function(a)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "rank_reward_title", a)
    end,
    body = function(a, b, c, d)
      local divisionGroup = c
      if divisionGroup == "global" then
        divisionGroup = X2Locale:LocalizeUiText(COMMON_TEXT, "ranking_division_global")
      else
        divisionGroup = X2World:GetCurrentWorldName()
      end
      return X2Locale:LocalizeUiText(MAIL_TEXT, "rank_reward_body", a, b, divisionGroup, d)
    end
  },
  rankingReward = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = function(a)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "rank_reward_title", X2Locale:LocalizeUiText(COMMON_TEXT, a))
    end,
    body = function(a, b, c, d, e)
      local tabName = X2Locale:LocalizeUiText(COMMON_TEXT, a)
      local rankingName = X2Locale:LocalizeUiText(COMMON_TEXT, b)
      local grade = X2Locale:LocalizeUiText(ITEM_GRADE, c)
      local divisionGroup = d
      if divisionGroup == "global" then
        divisionGroup = X2Locale:LocalizeUiText(COMMON_TEXT, "ranking_division_global")
      else
        divisionGroup = X2World:GetCurrentWorldName()
      end
      local rank = e
      return X2Locale:LocalizeUiText(COMMON_TEXT, "ranking_reward_body", tabName, rankingName, grade, divisionGroup, rank)
    end
  },
  mobilizationOrderItem = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = X2Locale:LocalizeUiText(COMMON_TEXT, "mobilization_order_title"),
    body = X2Locale:LocalizeUiText(COMMON_TEXT, "mobilization_order_body")
  },
  siegeGameRewardWinItem = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_game_reward_win_title"),
    body = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_game_reward_win_body")
  },
  siegeGameRewardLoseItem = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_game_reward_lose_title"),
    body = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_game_reward_lose_body")
  },
  heroCandidateAlarm = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "hero_election_manager"),
    title = X2Locale:LocalizeUiText(COMMON_TEXT, "hero_election_candidate_mail_title"),
    body = function(msg, periodStart, periodEnd)
      local bodyInfo = {}
      bodyInfo.msg = tostring(msg)
      bodyInfo.periodStart = periodStart
      bodyInfo.periodEnd = periodEnd
      return bodyInfo
    end
  },
  heroElectionItem = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "hero_election_manager"),
    title = X2Locale:LocalizeUiText(COMMON_TEXT, "hero_election_win_mail_title"),
    body = function(msg, periodStart, periodEnd)
      local bodyInfo = {}
      bodyInfo.msg = tostring(msg)
      bodyInfo.periodStart = periodStart
      bodyInfo.periodEnd = periodEnd
      return bodyInfo
    end
  },
  heroBonusItem = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "hero_election_manager"),
    title = X2Locale:LocalizeUiText(COMMON_TEXT, "hero_bonus_mail_title"),
    body = function(msg, periodStart, periodEnd)
      local bodyInfo = {}
      bodyInfo.msg = tostring(msg)
      bodyInfo.periodStart = periodStart
      bodyInfo.periodEnd = periodEnd
      return bodyInfo
    end
  },
  accountAttendance = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = function(a, b)
      return X2Locale:LocalizeUiText(COMMON_TEXT, "account_attendance_reward_mail_title", a, b)
    end,
    body = function()
      return X2Locale:LocalizeUiText(COMMON_TEXT, "account_attendance_reward_mail_body")
    end
  },
  itemGradeEnchantFailBreakReward = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = function(brokenItemTypeStr)
      local name = X2Item:Name(tonumber(brokenItemTypeStr)) or "Unknown Item"
      return X2Locale:LocalizeUiText(COMMON_TEXT, "item_grade_enchant_fail_break_reward_mail_title", name)
    end,
    body = function(brokenItemTypeStr, rewardItemTypeStr, rewardItemGradeStr, rewardItemCountStr)
      local brokenItemName = X2Item:Name(tonumber(brokenItemTypeStr)) or "Unknown Item"
      local rewardItemName = X2Item:Name(tonumber(rewardItemTypeStr)) or "Unknown Item"
      return X2Locale:LocalizeUiText(COMMON_TEXT, "item_grade_enchant_fail_break_reward_mail_body", brokenItemName, rewardItemName, rewardItemCountStr)
    end
  },
  itemSmeltingResultItemMail = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = function(resultItemType)
      local name = X2Item:Name(tonumber(resultItemType)) or "Unknown Item"
      return X2Locale:LocalizeUiText(COMMON_TEXT, "item_smelting_result_item_mail_title", name)
    end,
    body = function(targetItemTypeStr, resultItemTypeStr, resultItemGradeStr, resultItemCountStr)
      local targetItemName = X2Item:Name(tonumber(targetItemTypeStr)) or "Unknown Item"
      local resultItemName = X2Item:Name(tonumber(resultItemTypeStr)) or "Unknown Item"
      return X2Locale:LocalizeUiText(COMMON_TEXT, "item_smelting_result_item_mail_body", targetItemName, resultItemName, resultItemCountStr)
    end
  },
  expeditionWar = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = X2Locale:LocalizeUiText(COMMON_TEXT, "refund_war_deposit_title"),
    body = X2Locale:LocalizeUiText(COMMON_TEXT, "refund_war_deposit")
  },
  expeditionImmigrationReject = {
    title = function(titleText)
      return titleText
    end,
    sender = function(senderText)
      return senderText
    end,
    body = function(nationName)
      local bodyInfo = {}
      bodyInfo.nationName = nationName
      return bodyInfo
    end
  },
  residentBalance = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "resident_balance_sender"),
    title = function(zoneName)
      return X2Locale:LocalizeUiText(COMMON_TEXT, "resident_balance_receipt_title", zoneName)
    end,
    body = function(zoneGroup, totalServicePoint, myServicePoint, totalCharge, chargeRate, myDividend, extortionAll, extortionMember, currency, heroTax, ranking)
      local bodyInfo = {}
      bodyInfo.zoneGroupType = zoneGroup
      bodyInfo.totalServicePoint = totalServicePoint
      bodyInfo.myServicePoint = myServicePoint
      bodyInfo.totalCharge = totalCharge
      bodyInfo.chargeRate = chargeRate
      bodyInfo.myDividend = myDividend
      bodyInfo.extortionAll = extortionAll
      bodyInfo.extortionMember = extortionMember
      bodyInfo.currency = currency
      bodyInfo.heroTax = heroTax
      bodyInfo.ranking = ranking
      return bodyInfo
    end
  },
  balanceReceipt = {
    sender = X2Locale:LocalizeUiText(MAIL_TEXT, "balance_receipt_sender"),
    title = function(zoneName)
      return X2Locale:LocalizeUiText(MAIL_TEXT, "balance_receipt_title", zoneName)
    end
  },
  battleFieldReward = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "battle_field_sender"),
    title = X2Locale:LocalizeUiText(COMMON_TEXT, "battle_field_title"),
    body = function(battleFieldName, state, rank)
      local stateStr = X2Locale:LocalizeUiText(COMMON_TEXT, state)
      return X2Locale:LocalizeUiText(COMMON_TEXT, "battle_field_body", battleFieldName, stateStr, rank)
    end
  },
  battleFieldRewardNew = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "battle_field_sender"),
    title = X2Locale:LocalizeUiText(COMMON_TEXT, "battle_field_title"),
    body = function(battleFieldType, state, rank)
      local stateStr = X2Locale:LocalizeUiText(COMMON_TEXT, state)
      local battleFieldName = X2BattleField:GetInstanceName(tonumber(battleFieldType)) or "Unknown"
      return X2Locale:LocalizeUiText(COMMON_TEXT, "battle_field_body", battleFieldName, stateStr, rank)
    end
  },
  bestRatingReward = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "best_rating_reward_mail_sender"),
    title = X2Locale:LocalizeUiText(COMMON_TEXT, "best_rating_reward_mail_title"),
    body = function(battleFieldName, oldRating, newRating)
      return X2Locale:LocalizeUiText(COMMON_TEXT, "best_rating_reward_mail_body", battleFieldName, oldRating, newRating)
    end
  },
  bestRatingRewardNew = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "best_rating_reward_mail_sender"),
    title = X2Locale:LocalizeUiText(COMMON_TEXT, "best_rating_reward_mail_title"),
    body = function(battleFieldType, oldRating, newRating)
      local battleFieldName = X2BattleField:GetInstanceName(tonumber(battleFieldType)) or "Unknown"
      return X2Locale:LocalizeUiText(COMMON_TEXT, "best_rating_reward_mail_body", battleFieldName, oldRating, newRating)
    end
  },
  dyeingReward = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = function()
      return X2Locale:LocalizeUiText(COMMON_TEXT, "dyeing_reward_title")
    end,
    body = function(itemType)
      return X2Locale:LocalizeUiText(COMMON_TEXT, "dyeing_reward_content", X2Item:Name(itemType))
    end
  },
  dyeingAddedReward = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = function(titleStr)
      return titleStr
    end,
    body = function(itemType)
      return X2Locale:LocalizeUiText(COMMON_TEXT, "dyeing_reward_content", X2Item:Name(itemType))
    end
  },
  indunRoundReward = {
    sender = function(instanceId, mailKind)
      local instanceType = tonumber(instanceId)
      local mailType = tonumber(mailKind)
      local info = X2BattleField:GetInstanceRewardMailInfo(instanceType, mailType)
      if info ~= nil and info.mailSender ~= nil and info.mailSender ~= "" then
        return info.mailSender
      end
      return X2Locale:LocalizeUiText(COMMON_TEXT, "indun_round_reward_mail_sender")
    end,
    title = function(instanceId, mailKind)
      local instanceType = tonumber(instanceId)
      local mailType = tonumber(mailKind)
      local info = X2BattleField:GetInstanceRewardMailInfo(instanceType, mailType)
      if info ~= nil and info.mailTitle ~= nil and info.mailTitle ~= "" then
        return info.mailTitle
      end
      return X2Locale:LocalizeUiText(COMMON_TEXT, "indun_round_reward_mail_title")
    end,
    body = function(instanceId, mailKind)
      local instanceType = tonumber(instanceId)
      local mailType = tonumber(mailKind)
      local info = X2BattleField:GetInstanceRewardMailInfo(instanceType, mailType)
      if info ~= nil and info.mailBody ~= nil and info.mailBody ~= "" then
        return info.mailBody
      end
      return X2Locale:LocalizeUiText(COMMON_TEXT, "indun_round_reward_mail_content")
    end
  },
  factionKickInactive = {
    sender = X2Util:ApplyUIMacroString(X2Locale:LocalizeUiText(MAIL_TEXT, "faction_kick_inactive_sender")),
    title = X2Locale:LocalizeUiText(MAIL_TEXT, "faction_kick_inactive_title"),
    body = X2Util:ApplyUIMacroString(X2Locale:LocalizeUiText(MAIL_TEXT, "faction_kick_inactive_body", tostring(X2Faction:GetFactionKickInactiveDay())))
  },
  returnHariharaRequest = {
    sender = X2Util:ApplyUIMacroString(X2Locale:LocalizeUiText(MAIL_TEXT, "hari_faction_change_sender")),
    title = X2Locale:LocalizeUiText(MAIL_TEXT, "hari_faction_change_title"),
    body = X2Locale:LocalizeUiText(MAIL_TEXT, "hari_faction_change_body")
  },
  returnNuiaRequest = {
    sender = X2Util:ApplyUIMacroString(X2Locale:LocalizeUiText(MAIL_TEXT, "nuia_faction_change_sender")),
    title = X2Locale:LocalizeUiText(MAIL_TEXT, "nuia_faction_change_title"),
    body = X2Locale:LocalizeUiText(MAIL_TEXT, "nuia_faction_change_body")
  },
  surveyFormReward = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = X2Locale:LocalizeUiText(COMMON_TEXT, "survey_form_reward_title"),
    body = function(survey_form_title)
      return X2Locale:LocalizeUiText(COMMON_TEXT, "survey_form_reward_body", survey_form_title)
    end
  },
  visualRaceMail = {
    sender = X2Locale:LocalizeUiText(COMMON_TEXT, "archeage"),
    title = X2Locale:LocalizeUiText(COMMON_TEXT, "visual_race_beautyshop_sender_title"),
    body = X2Locale:LocalizeUiText(COMMON_TEXT, "visual_race_beautyshop_sender_body")
  }
}
locale.mail.balanceReceipt.body = locale.mail.residentBalance.body
locale.raid = {
  option = X2Locale:LocalizeUiText(RAID_TEXT, "option"),
  title = X2Locale:LocalizeUiText(RAID_TEXT, "raid_title"),
  dismissRaid = X2Locale:LocalizeUiText(RAID_TEXT, "dismiss_raid"),
  leaveRaid = X2Locale:LocalizeUiText(RAID_TEXT, "leave_raid"),
  party = X2Locale:LocalizeUiText(RAID_TEXT, "party"),
  leaderTip = X2Locale:LocalizeUiText(RAID_TEXT, "raid_owner"),
  subleaderTip = X2Locale:LocalizeUiText(RAID_TEXT, "raid_officer"),
  lootingTip = X2Locale:LocalizeUiText(RAID_TEXT, "looting_manager"),
  dismissed = X2Locale:LocalizeUiText(RAID_TEXT, "dismiss_raid_message"),
  setMode = X2Locale:LocalizeUiText(RAID_TEXT, "set_raid_viewmode"),
  normalMode = X2Locale:LocalizeUiText(RAID_TEXT, "show_bigger"),
  simpleMode = X2Locale:LocalizeUiText(RAID_TEXT, "show_smaller"),
  setArray = X2Locale:LocalizeUiText(RAID_TEXT, "set_raid_ui_show"),
  partyVisibleToRaid = X2Locale:LocalizeUiText(RAID_TEXT, "show_party_info"),
  invisibleRaidFrame = X2Locale:LocalizeUiText(RAID_TEXT, "show_raid_info"),
  setInvitation = X2Locale:LocalizeUiText(RAID_TEXT, "set_invite"),
  refuseInvitation = X2Locale:LocalizeUiText(RAID_TEXT, "reject_area_invite"),
  setMyRole = X2Locale:LocalizeUiText(RAID_TEXT, "set_my_role")
}
locale.siegeRaid = {
  registerDlgTitle = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_register_dlg_title"),
  registerDlgDesc = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_register_dlg_desc"),
  notVolunteerPeriod = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_volunteer_not_period"),
  registerWindowTitle = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_register_window_title"),
  dominionsTitle = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_register_dominions_title"),
  registersTitle = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_register_registers_title"),
  registersEmptyDesc = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_register_registers_empty_desc"),
  prepareSiegeZone = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_register_prepare_siege_zone"),
  reserveState = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_register_reserve_state"),
  scheduleText = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_register_schedule_text"),
  scheduleTooltip = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_register_schedule_tooltip"),
  registerBtn = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_register_btn"),
  unregisterBtn = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_unregister_btn"),
  registerReserve = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_register_reserve"),
  heroGrade = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_hero_grade"),
  suggestionsDesc = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_suggestions_desc"),
  appointWindowTitle = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_appoint_window_title"),
  title = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_team"),
  owner = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_team_owner"),
  officer = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_team_officer"),
  appointOfficer = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_team_officer_appoint"),
  leaveTeam = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_team_leave"),
  leaveTeamError = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_team_leave_error"),
  kickedMsg = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_team_kicked"),
  inviteRejectMsg = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_team_invite_reject"),
  supportSiegeRaidTeamReadySiege = X2Locale:LocalizeUiText(COMMON_TEXT, "support_siege_raid_team_ready_siege"),
  alreadyCreateSiegeRaidTeamReadySiege = X2Locale:LocalizeUiText(COMMON_TEXT, "alreay_create_siege_raid_team_ready_siege")
}
locale.team = {
  leaveTeamError = X2Locale:LocalizeUiText(TEAM_TEXT, "leave_team_error"),
  dismiss = function()
    if X2Team:IsRaidTeam() == true then
      if X2Team:IsJointTeam() == true then
        return X2Locale:LocalizeUiText(COMMON_TEXT, "raid_joint_dismiss_btn")
      else
        return locale.raid.dismissRaid
      end
    else
      return X2Locale:LocalizeUiText(TEAM_TEXT, "dimiss_party")
    end
  end,
  leave = function()
    if X2Team:IsRaidTeam() == true then
      if X2Team:IsSiegeRaidTeam() == true then
        return locale.siegeRaid.leaveTeam
      else
        return locale.raid.leaveRaid
      end
    else
      return X2Locale:LocalizeUiText(TEAM_TEXT, "leave_party")
    end
  end,
  leaderTip = function()
    if X2Team:IsRaidTeam() == true then
      return locale.raid.leaderTip
    else
      return X2Locale:LocalizeUiText(TEAM_TEXT, "team_owner")
    end
  end,
  subleaderTip = locale.raid.subleaderTip,
  lootingTip = X2Locale:LocalizeUiText(TEAM_TEXT, "looting_manager"),
  setOfficer = X2Locale:LocalizeUiText(TEAM_TEXT, "set_raid_officer"),
  setlootingOfficer = X2Locale:LocalizeUiText(TEAM_TEXT, "set_looting_manager"),
  createPartyMessage = X2Locale:LocalizeUiText(TEAM_TEXT, "create_party_message"),
  createRaidMessage = X2Locale:LocalizeUiText(TEAM_TEXT, "create_raid_message"),
  joinPartyMessage = X2Locale:LocalizeUiText(TEAM_TEXT, "join_party_message"),
  joinRaidMessage = X2Locale:LocalizeUiText(TEAM_TEXT, "join_raid_message"),
  rejectPartyInviteMessage = X2Locale:LocalizeUiText(TEAM_TEXT, "reject_party_invite_message"),
  rejectRaidInviteMessage = X2Locale:LocalizeUiText(TEAM_TEXT, "reject_raid_invite_message"),
  kickPartyMessage = X2Locale:LocalizeUiText(TEAM_TEXT, "kick_party_message"),
  kickRaidMessage = X2Locale:LocalizeUiText(TEAM_TEXT, "kick_raid_message"),
  dismissPartyMessage = X2Locale:LocalizeUiText(TEAM_TEXT, "dismiss_party_message"),
  leavePartyMessage = X2Locale:LocalizeUiText(TEAM_TEXT, "leave_party_message"),
  leaveRaidMessage = X2Locale:LocalizeUiText(TEAM_TEXT, "leave_raid_message")
}
locale.team.msgFunc = {}
function locale.team.msgFunc.joined_by_self(isParty, jointOrder, a, roleType)
  if isParty == true then
    if a == myName then
      return locale.team.createPartyMessage
    end
    return X2Locale:LocalizeUiText(TEAM_TEXT, "whose_join_party", a)
  else
    if a == myName then
      if roleType ~= nil and roleType == "siege_raid" then
        return X2Locale:LocalizeUiText(COMMON_TEXT, "create_siege_raid_message")
      else
        return locale.team.createRaidMessage
      end
    end
    if roleType ~= nil and roleType == "siege_raid" then
      return X2Locale:LocalizeUiText(COMMON_TEXT, "whose_join_siege_raid", a)
    else
      return X2Locale:LocalizeUiText(TEAM_TEXT, "whose_join_raid", a)
    end
  end
end
function locale.team.msgFunc.joined(isParty, jointOrder, a, roleType)
  local myTeamOrder = X2Team:GetMyTeamJointOrder()
  if myTeamOrder ~= jointOrder then
    return nil
  end
  if isParty then
    if a == nil then
      return locale.team.joinPartyMessage
    end
    return X2Locale:LocalizeUiText(TEAM_TEXT, "who_join_party", a)
  else
    if a == nil then
      if roleType ~= nil and roleType == "siege_raid" then
        return X2Locale:LocalizeUiText(COMMON_TEXT, "join_siege_raid_message")
      else
        return locale.team.joinRaidMessage
      end
    end
    if roleType ~= nil and roleType == "siege_raid" then
      return X2Locale:LocalizeUiText(COMMON_TEXT, "who_join_siege_raid", a)
    else
      return X2Locale:LocalizeUiText(TEAM_TEXT, "who_join_raid", a)
    end
  end
end
function locale.team.msgFunc.kicked_by_self(isParty, jointOrder, a, roleType)
  if isParty then
    return locale.team.kickPartyMessage
  elseif roleType ~= nil and roleType == "siege_raid" then
    return X2Locale:LocalizeUiText(COMMON_TEXT, "kick_siege_raid_message")
  else
    return locale.team.kickRaidMessage
  end
end
function locale.team.msgFunc.kicked(isParty, jointOrder, a, roleType)
  local myTeamOrder = X2Team:GetMyTeamJointOrder()
  if myTeamOrder ~= jointOrder then
    return nil
  end
  if isParty then
    return X2Locale:LocalizeUiText(TEAM_TEXT, "who_kick_party", a)
  elseif roleType ~= nil and roleType == "siege_raid" then
    return X2Locale:LocalizeUiText(COMMON_TEXT, "who_kick_siege_raid", a)
  else
    return X2Locale:LocalizeUiText(TEAM_TEXT, "who_kick_raid", a)
  end
end
function locale.team.msgFunc.dismissed(isParty, jointOrder, a, roleType)
  if isParty then
    return locale.team.dismissPartyMessage
  elseif roleType ~= nil and roleType == "siege_raid" then
    return X2Locale:LocalizeUiText(COMMON_TEXT, "dismiss_siege_raid_message")
  else
    return locale.raid.dismissed
  end
end
function locale.team.msgFunc.invitation_rejected_by_self(isParty, jointOrder, a, roleType)
  if isParty then
    return locale.team.rejectPartyInviteMessage
  elseif roleType ~= nil and roleType == "siege_raid" then
    return X2Locale:LocalizeUiText(COMMON_TEXT, "reject_siege_raid_invite_message", a)
  else
    return locale.team.rejectRaidInviteMessage
  end
end
function locale.team.msgFunc.invitation_rejected(isParty, jointOrder, a, roleType)
  local myTeamOrder = X2Team:GetMyTeamJointOrder()
  if myTeamOrder ~= jointOrder then
    return nil
  end
  if isParty then
    return X2Locale:LocalizeUiText(TEAM_TEXT, "who_reject_party", a)
  elseif roleType ~= nil and roleType == "siege_raid" then
    return X2Locale:LocalizeUiText(COMMON_TEXT, "who_reject_siege_raid", a)
  else
    return X2Locale:LocalizeUiText(TEAM_TEXT, "who_reject_raid", a)
  end
end
function locale.team.msgFunc.leaved_by_self(isParty, jointOrder)
  if isParty then
    return locale.team.leavePartyMessage
  else
    return locale.team.leaveRaidMessage
  end
end
function locale.team.msgFunc.leaved(isParty, jointOrder, a)
  local myTeamOrder = X2Team:GetMyTeamJointOrder()
  if myTeamOrder ~= jointOrder then
    return nil
  end
  if isParty then
    return X2Locale:LocalizeUiText(TEAM_TEXT, "who_leave_party", a)
  else
    return X2Locale:LocalizeUiText(TEAM_TEXT, "who_leave_raid", a)
  end
end
function locale.team.msgFunc.owner_changed(isParty, jointOrder, a)
  if isParty then
    return X2Locale:LocalizeUiText(TEAM_TEXT, "who_party_owner", a)
  elseif X2Team:IsJointTeam() then
    if X2Team:IsJointLeader() == (jointOrder == X2Team:GetMyTeamJointOrder()) then
      return GetCommonText("raid_joint_be_owner", a)
    else
      return GetCommonText("raid_joint_be_officer", a)
    end
  else
    return X2Locale:LocalizeUiText(TEAM_TEXT, "who_raid_owner", a)
  end
end
function locale.team.msgFunc.officer_changed(isParty, jointOrder, a, roleType)
  if roleType ~= nil and roleType == "siege_raid" then
    return X2Locale:LocalizeUiText(COMMON_TEXT, "appoint_siege_raid_officer", a)
  end
end
locale.banPlayer = {
  banNoitfyMessage = X2Locale:LocalizeUiText(COMMON_TEXT, "ban_player_notify"),
  banNoitfyMessage = X2Locale:LocalizeUiText(COMMON_TEXT, "ban_already_trying"),
  banNoitfyMessage = X2Locale:LocalizeUiText(COMMON_TEXT, "ban_not_yet_cooltime")
}
locale.banPlayer.msgFunc = {}
function locale.banPlayer.msgFunc.success(a)
  return X2Locale:LocalizeUiText(COMMON_TEXT, "ban_player_success", a)
end
function locale.banPlayer.msgFunc.fail(a)
  return X2Locale:LocalizeUiText(COMMON_TEXT, "ban_player_failed", a)
end
locale.role = {
  tanker = X2Locale:LocalizeUiText(RAID_TEXT, "raid_role_tanker"),
  healer = X2Locale:LocalizeUiText(RAID_TEXT, "raid_role_healer"),
  dealer = X2Locale:LocalizeUiText(RAID_TEXT, "raid_role_dealer"),
  ranged_dealer = X2Locale:LocalizeUiText(RAID_TEXT, "raid_role_ranged_dealer"),
  norole = X2Locale:LocalizeUiText(RAID_TEXT, "raid_role_none")
}
locale.squad = {
  invite = X2Locale:LocalizeUiText(COMMON_TEXT, "squad_invite"),
  expel = X2Locale:LocalizeUiText(COMMON_TEXT, "squad_expel"),
  delegate = X2Locale:LocalizeUiText(COMMON_TEXT, "squad_delegate"),
  leave = X2Locale:LocalizeUiText(COMMON_TEXT, "squad_leave")
}
locale.slave = {
  title = X2Locale:LocalizeUiText(SLAVE_TEXT, "slave_info_title"),
  kind = X2Locale:LocalizeUiText(SLAVE_TEXT, "slave_kind"),
  class = X2Locale:LocalizeUiText(SLAVE_TEXT, "slave_class"),
  move_speed = X2Locale:LocalizeUiText(SLAVE_TEXT, "slave_move_speed"),
  turn_speed = X2Locale:LocalizeUiText(SLAVE_TEXT, "slave_turn_speed"),
  titleGear = X2Locale:LocalizeUiText(SLAVE_TEXT, "title_gear"),
  titleBrake = X2Locale:LocalizeUiText(SLAVE_TEXT, "title_brake"),
  titleTractionCtrl = X2Locale:LocalizeUiText(SLAVE_TEXT, "title_traction_ctrl"),
  on = X2Locale:LocalizeUiText(SLAVE_TEXT, "on"),
  off = X2Locale:LocalizeUiText(SLAVE_TEXT, "off"),
  gearValue = {
    X2Locale:LocalizeUiText(SLAVE_TEXT, "backward_movement"),
    X2Locale:LocalizeUiText(SLAVE_TEXT, "neutral_movement")
  },
  gearGrade = {
    X2Locale:LocalizeUiText(SLAVE_TEXT, "gear_1"),
    X2Locale:LocalizeUiText(SLAVE_TEXT, "gear_2"),
    X2Locale:LocalizeUiText(SLAVE_TEXT, "gear_3")
  }
}
locale.pet = {
  toggle = {
    follow = X2Locale:LocalizeUiText(PET_TEXT, "toggle_follow"),
    stop = X2Locale:LocalizeUiText(PET_TEXT, "toggle_stop"),
    getOn = X2Locale:LocalizeUiText(PET_TEXT, "toggle_get_on"),
    getOff = X2Locale:LocalizeUiText(PET_TEXT, "toggle_get_off")
  },
  command = {
    follow = X2Locale:LocalizeUiText(PET_TEXT, "command_follow"),
    stop = X2Locale:LocalizeUiText(PET_TEXT, "command_stop"),
    mount = X2Locale:LocalizeUiText(PET_TEXT, "command_mount"),
    unmount = X2Locale:LocalizeUiText(PET_TEXT, "command_unmount"),
    openEquip = X2Locale:LocalizeUiText(PET_TEXT, "command_open_equip"),
    closeEquip = X2Locale:LocalizeUiText(PET_TEXT, "command_close_equip"),
    passengerGetOff = X2Locale:LocalizeUiText(PET_TEXT, "command_passenger_get_off"),
    cya = X2Locale:LocalizeUiText(PET_TEXT, "command_cya"),
    attack = X2Locale:LocalizeUiText(COMMON_TEXT, "command_attack"),
    guides = {
      follow = X2Locale:LocalizeUiText(PET_TEXT, "command_guides_follow"),
      mount = X2Locale:LocalizeUiText(PET_TEXT, "command_guides_mount"),
      openEquip = X2Locale:LocalizeUiText(PET_TEXT, "command_guides_open_equip"),
      passengerGetOff = X2Locale:LocalizeUiText(PET_TEXT, "command_guides_passenger_get_off"),
      cya = X2Locale:LocalizeUiText(PET_TEXT, "command_guides_cya"),
      attack = X2Locale:LocalizeUiText(COMMON_TEXT, "command_guides_attack")
    }
  },
  helmet = X2Locale:LocalizeUiText(PET_TEXT, "helmet"),
  armor = X2Locale:LocalizeUiText(PET_TEXT, "armor"),
  saddle = X2Locale:LocalizeUiText(PET_TEXT, "saddle"),
  shoes = X2Locale:LocalizeUiText(PET_TEXT, "shoes"),
  info = {
    title = X2Locale:LocalizeUiText(PET_TEXT, "equip_title")
  },
  state = {
    guides = {
      aggressive = X2Locale:LocalizeUiText(PET_TEXT, "state_aggressive"),
      protective = X2Locale:LocalizeUiText(PET_TEXT, "state_protective"),
      passive = X2Locale:LocalizeUiText(PET_TEXT, "state_passive"),
      stand = X2Locale:LocalizeUiText(PET_TEXT, "state_stand")
    }
  },
  action = {
    cannotSetAutoUse1 = X2Locale:LocalizeUiText(PET_TEXT, "autoskill_message1"),
    cannotSetAutoUse2 = X2Locale:LocalizeUiText(PET_TEXT, "autoskill_message2")
  },
  unsummon_mate_equip = X2Locale:LocalizeUiText(PET_TEXT, "unsummon_mate_equip"),
  item_not_equip_for_pet = X2Locale:LocalizeUiText(PET_TEXT, "item_not_equip_for_pet"),
  unsummon_slave_equip = X2Locale:LocalizeUiText(SLAVE_TEXT, "unsummon_slave_equip"),
  item_not_equip_for_slave = X2Locale:LocalizeUiText(SLAVE_TEXT, "item_not_equip_for_slave"),
  GetLevelText = function(a)
    return X2Locale:LocalizeUiText(PET_TEXT, "level", F_TEXT.IStr(a))
  end
}
locale.unitFrame = {
  combatTip = X2Locale:LocalizeUiText(UNIT_FRAME_TEXT, "combat_tip"),
  pvpTip = X2Locale:LocalizeUiText(UNIT_FRAME_TEXT, "pvp_tip"),
  partyLeaderTip = X2Locale:LocalizeUiText(UNIT_FRAME_TEXT, "party_leader_tip"),
  eliteNpc = X2Locale:LocalizeUiText(UNIT_FRAME_TEXT, "elite_npc"),
  transfer = X2Locale:LocalizeUiText(UNIT_FRAME_TEXT, "transfer"),
  mate = X2Locale:LocalizeUiText(UNIT_FRAME_TEXT, "mate"),
  housing = X2Locale:LocalizeUiText(UNIT_FRAME_TEXT, "housing"),
  potal = X2Locale:LocalizeUiText(UNIT_FRAME_TEXT, "potal"),
  stack = X2Locale:LocalizeUiText(UNIT_FRAME_TEXT, "stack"),
  noneOwner = X2Locale:LocalizeUiText(UNIT_FRAME_TEXT, "none_owner"),
  offline = X2Locale:LocalizeUiText(UNIT_FRAME_TEXT, "offline"),
  overHeadMarker = X2Locale:LocalizeUiText(UNIT_FRAME_TEXT, "over_head_marker"),
  removeAll = X2Locale:LocalizeUiText(UNIT_FRAME_TEXT, "remove_all"),
  pvp_honor_point = X2Locale:LocalizeUiText(UNIT_FRAME_TEXT, "pvp_honor_point"),
  pvp_kill_point = X2Locale:LocalizeUiText(UNIT_FRAME_TEXT, "pvp_kill_point"),
  visualRaceState = X2Locale:LocalizeUiText(COMMON_TEXT, "visual_race_state")
}
locale.duel = {
  challenge = X2Locale:LocalizeUiText(DUEL_TEXT, "challenge_duel"),
  challenge_party = X2Locale:LocalizeUiText(DUEL_TEXT, "challenge_party_duel")
}
locale.menu = {}
locale.menu.option = X2Locale:LocalizeUiText(OPTION_TEXT, "menu_option")
locale.menu.hotkey = X2Locale:LocalizeUiText(OPTION_TEXT, "menu_hotkey")
locale.menu.selectCharacter = X2Locale:LocalizeUiText(OPTION_TEXT, "select_character")
locale.menu.selectWorld = X2Locale:LocalizeUiText(OPTION_TEXT, "select_world")
locale.menu.exit = X2Locale:LocalizeUiText(OPTION_TEXT, "menu_exit")
locale.menu.set_option = X2Locale:LocalizeUiText(OPTION_TEXT, "set_option")
locale.menu.apply = X2Locale:LocalizeUiText(COMMON_TEXT, "apply")
locale.menu.default = X2Locale:LocalizeUiText(OPTION_TEXT, "default")
locale.menu.option = X2Locale:LocalizeUiText(OPTION_TEXT, "option")
locale.menu.optionwindow = {
  resetUI = X2Locale:LocalizeUiText(OPTION_TEXT, "option_window_reset_ui"),
  resetKeyBinding = X2Locale:LocalizeUiText(OPTION_TEXT, "option_window_reset_key_binding"),
  restartTip = X2Locale:LocalizeUiText(OPTION_TEXT, "restart_tip")
}
locale.optionWindow = {}
locale.optionWindow.screen = {
  title = X2Locale:LocalizeUiText(OPTION_TEXT, "group_title_screen"),
  menuText = {
    X2Locale:LocalizeUiText(OPTION_TEXT, "option_item_screen"),
    X2Locale:LocalizeUiText(OPTION_TEXT, "option_item_screen_quality")
  }
}
locale.optionWindow.sound = {
  title = X2Locale:LocalizeUiText(OPTION_TEXT, "option_sound_title"),
  setDefault = X2Locale:LocalizeUiText(OPTION_TEXT, "option_set_default")
}
locale.optionWindow.interface = {
  title = X2Locale:LocalizeUiText(OPTION_TEXT, "group_title_game"),
  SetDegree = function(value)
    return X2Locale:LocalizeUiText(OPTION_TEXT, "degree", tostring(value))
  end,
  menuText = {
    X2Locale:LocalizeUiText(OPTION_TEXT, "option_interface_nametag"),
    X2Locale:LocalizeUiText(OPTION_TEXT, "option_interface_game_info"),
    X2Locale:LocalizeUiText(OPTION_TEXT, "option_interface_function"),
    X2Locale:LocalizeUiText(OPTION_TEXT, "option_interface_ui_short_cut"),
    X2Locale:LocalizeUiText(OPTION_TEXT, "option_interface_addon")
  }
}
locale.optionWindow.key = {
  title = X2Locale:LocalizeUiText(OPTION_TEXT, "menu_hotkey"),
  menuText = {
    X2Locale:LocalizeUiText(OPTION_TEXT, "option_hotkey_menu_char_ctrl"),
    X2Locale:LocalizeUiText(OPTION_TEXT, "option_hotkey_menu_vehicle_ctrl"),
    X2Locale:LocalizeUiText(OPTION_TEXT, "option_hotkey_menu_game_control"),
    X2Locale:LocalizeUiText(OPTION_TEXT, "option_hotkey_menu_cam_ctrl"),
    X2Locale:LocalizeUiText(OPTION_TEXT, "option_hotkey_menu_ui_call"),
    X2Locale:LocalizeUiText(OPTION_TEXT, "option_hotkey_menu_short_cut"),
    X2Locale:LocalizeUiText(OPTION_TEXT, "option_hotkey_menu_addtion")
  }
}
locale.auction = {
  guideText = X2Locale:LocalizeUiText(AUCTION_TEXT, "input_item_name"),
  myselfBid = X2Locale:LocalizeUiText(AUCTION_TEXT, "myself_bid"),
  otherPeopleBid = X2Locale:LocalizeUiText(AUCTION_TEXT, "other_people_bid"),
  myPutupGoods = X2Locale:LocalizeUiText(AUCTION_TEXT, "my_putup_goods"),
  bidState = X2Locale:LocalizeUiText(AUCTION_TEXT, "bid_state"),
  myBiddingPrice = X2Locale:LocalizeUiText(AUCTION_TEXT, "my_bidding_price"),
  currentBidPrice = X2Locale:LocalizeUiText(AUCTION_TEXT, "current_bid_price"),
  bundlePrice = X2Locale:LocalizeUiText(COMMON_TEXT, "bundle_price"),
  startPrice = X2Locale:LocalizeUiText(AUCTION_TEXT, "start_price"),
  directPrice = X2Locale:LocalizeUiText(AUCTION_TEXT, "direct_price"),
  directPriceTooltip = X2Locale:LocalizeUiText(AUCTION_TEXT, "direct_price_tooltip"),
  bidPriceTooltip = X2Locale:LocalizeUiText(AUCTION_TEXT, "bid_price_tooltip"),
  lowDirectPrice = X2Locale:LocalizeUiText(AUCTION_TEXT, "lowDirectPrice"),
  lowestEachPrice = X2Locale:LocalizeUiText(AUCTION_TEXT, "lowestEachPrice"),
  putupPrice = X2Locale:LocalizeUiText(AUCTION_TEXT, "putupPrice"),
  lowDirectPrice = X2Locale:LocalizeUiText(AUCTION_TEXT, "lowDirectPrice"),
  searching = X2Locale:LocalizeUiText(AUCTION_TEXT, "searching"),
  no_lowest_price = X2Locale:LocalizeUiText(AUCTION_TEXT, "no_lowest_price"),
  biddingTime = X2Locale:LocalizeUiText(AUCTION_TEXT, "bidding_time"),
  myPutupCount = X2Locale:LocalizeUiText(AUCTION_TEXT, "my_putup_count"),
  bidSuccesfullyCommission = X2Locale:LocalizeUiText(AUCTION_TEXT, "bid_succesfully_commission"),
  bid = X2Locale:LocalizeUiText(AUCTION_TEXT, "bid"),
  bid_money = X2Locale:LocalizeUiText(AUCTION_TEXT, "bid_money"),
  putup = X2Locale:LocalizeUiText(AUCTION_TEXT, "putup"),
  bidHistory = X2Locale:LocalizeUiText(AUCTION_TEXT, "bid_history"),
  notBid = X2Locale:LocalizeUiText(AUCTION_TEXT, "not_bid"),
  bidding = X2Locale:LocalizeUiText(AUCTION_TEXT, "bidding"),
  name = X2Locale:LocalizeUiText(AUCTION_TEXT, "name"),
  type = X2Locale:LocalizeUiText(AUCTION_TEXT, "type"),
  bidPrice = X2Locale:LocalizeUiText(AUCTION_TEXT, "bid_price"),
  selfBidPrice = X2Locale:LocalizeUiText(AUCTION_TEXT, "self_bid_price"),
  directBid = X2Locale:LocalizeUiText(AUCTION_TEXT, "direct_bid"),
  directForbidden = X2Locale:LocalizeUiText(AUCTION_TEXT, "direct_forbidden"),
  under_time = X2Locale:LocalizeUiText(AUCTION_TEXT, "under_time"),
  putupItem = X2Locale:LocalizeUiText(AUCTION_TEXT, "putup_item"),
  itemCondition = X2Locale:LocalizeUiText(AUCTION_TEXT, "item_condition"),
  cancelBid = X2Locale:LocalizeUiText(AUCTION_TEXT, "cancel_bid"),
  searchConditionInit = X2Locale:LocalizeUiText(AUCTION_TEXT, "search_condition_init"),
  levelRange = X2Locale:LocalizeUiText(AUCTION_TEXT, "level_range"),
  itemGrade = X2Locale:LocalizeUiText(AUCTION_TEXT, "item_grade"),
  matchWord = X2Locale:LocalizeUiText(AUCTION_TEXT, "match_word"),
  level = X2Locale:LocalizeUiText(AUCTION_TEXT, "level"),
  refreshTooltip = X2Locale:LocalizeUiText(AUCTION_TEXT, "refresh_tooltip"),
  putupMsg = function(a)
    return X2Locale:LocalizeUiText(AUCTION_TEXT, "putup_message", a)
  end,
  cancelMsg = function(a)
    return X2Locale:LocalizeUiText(AUCTION_TEXT, "cancel_message", a)
  end,
  biddedMsg = function(a, b)
    return X2Locale:LocalizeUiText(AUCTION_TEXT, "bidded_message", a, b)
  end,
  boughtMsg = function(a, b)
    return X2Locale:LocalizeUiText(AUCTION_TEXT, "bought_message", a, b)
  end,
  biddenMsg = function(a, b)
    return X2Locale:LocalizeUiText(AUCTION_TEXT, "bidden_message", a, b)
  end,
  boughtBySomeoneMsg = function(a, b)
    return X2Locale:LocalizeUiText(AUCTION_TEXT, "bought_by_someone_message", a, b)
  end,
  levelTooLowMsg = function(a, b)
    return X2Locale:LocalizeUiText(AUCTION_TEXT, a, b)
  end,
  first_search_guide = X2Locale:LocalizeUiText(AUCTION_TEXT, "first_search_guide"),
  none_search_result = X2Locale:LocalizeUiText(AUCTION_TEXT, "none_search_result"),
  bidPartition = X2Locale:LocalizeUiText(AUCTION_TEXT, "bid_partition"),
  sellPartition = X2Locale:LocalizeUiText(AUCTION_TEXT, "sell_partition"),
  sellMinStackCount = X2Locale:LocalizeUiText(AUCTION_TEXT, "sell_min_stack_count"),
  bidMinStack = X2Locale:LocalizeUiText(AUCTION_TEXT, "auction_bid_min_stack"),
  bidMaxStack = X2Locale:LocalizeUiText(AUCTION_TEXT, "auction_bid_max_stack"),
  heirLevelSearchTooltip = X2Locale:LocalizeUiText(AUCTION_TEXT, "heir_level_search_tooltip"),
  minStackCount = function(countStr)
    return X2Locale:LocalizeUiText(AUCTION_TEXT, "min_stack_bid_count", countStr)
  end,
  minStackPrice = X2Locale:LocalizeUiText(AUCTION_TEXT, "min_stack_price"),
  depositTooltipTitle = X2Locale:LocalizeUiText(AUCTION_TEXT, "deposit_tooltip_title"),
  depositTooltipRateByTime = function(putupTime, depositRatio)
    return X2Locale:LocalizeUiText(AUCTION_TEXT, "deposit_tooltip_rate_by_time", putupTime, depositRatio)
  end,
  depositTooltipInfo = function(depositRateStr, maxDepositStr)
    local text = X2Locale:LocalizeUiText(AUCTION_TEXT, "deposit_tooltip_info")
    for i = 1, #depositRateStr do
      text = F_TEXT.SetEnterString(text, depositRateStr[i])
    end
    text = F_TEXT.SetEnterString(text, maxDepositStr)
    return text
  end,
  chargeTooltipTitle = function(text)
    return X2Locale:LocalizeUiText(AUCTION_TEXT, "charge_tooltip_title", text)
  end,
  chargeTooltipInfo = X2Locale:LocalizeUiText(AUCTION_TEXT, "charge_tooltip_info"),
  chargeTooltipTitleExplan = function(text)
    return X2Locale:LocalizeUiText(AUCTION_TEXT, "charge_tooltip_title_explan", text)
  end,
  chargeTooltipTitleNormal = X2Locale:LocalizeUiText(AUCTION_TEXT, "charge_tooltip_title_normal"),
  chargeTooltipTitleItemCharge = function(text)
    return X2Locale:LocalizeUiText(AUCTION_TEXT, "charge_tooltip_title_item_charge", text)
  end
}
locale.messageBoxBtnText = {
  ok = X2Locale:LocalizeUiText(COMMON_TEXT, "ok"),
  cancel = X2Locale:LocalizeUiText(MSG_BOX_BTN_TEXT, "cancel")
}
locale.messageBox = {
  default = {
    title = "unknown",
    body = nil,
    needsParams = false,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  error_disconnected = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_disconnected"),
    body = X2Locale:LocalizeUiText(MSG_BOX_BODY_TEXT, "error_disconnected"),
    needsParams = false,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  error_initial_ability = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_initial_ability"),
    body = X2Locale:LocalizeUiText(MSG_BOX_BODY_TEXT, "error_initial_ability"),
    needsParams = false,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  error_char_name_mismatch = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_char_name_mismatch"),
    body = X2Locale:LocalizeUiText(MSG_BOX_BODY_TEXT, "error_char_name_mismatch"),
    needsParams = false,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  error_character_expedition_owner = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_character_delete_failed"),
    body = X2Locale:LocalizeUiText(ERROR_MSG, "EXPEDITION_OWNER_CANNOT_DELETE"),
    needsParams = false,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  error_character_faction_owner = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_character_delete_failed"),
    body = X2Locale:LocalizeUiText(ERROR_MSG, "FACTION_OWNER_CANNOT_DELETE"),
    needsParams = false,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  cannot_delete_char_while_on_play = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_character_delete_failed"),
    body = X2Locale:LocalizeUiText(ERROR_MSG, "CANNOT_DELETE_CHAR_WHILE_ON_PLAY"),
    needsParams = false,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  cannot_delete_char_while_penalty = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_character_delete_failed"),
    body = X2Locale:LocalizeUiText(ERROR_MSG, "CANNOT_DELETE_CHAR_WHILE_PENALTY"),
    needsParams = false,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  cannot_delete_char_while_bot_suspected = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_character_delete_failed"),
    body = X2Locale:LocalizeUiText(ERROR_MSG, "CANNOT_DELETE_CHAR_WHILE_BOT_SUSPECTED"),
    needsParams = false,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  cannot_delete_has_comercial_mail_item = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_character_delete_failed"),
    body = X2Locale:LocalizeUiText(ERROR_MSG, "CANNOT_DELETE_HAS_COMERCIAL_MAIL_ITEM"),
    needsParams = false,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  error_already_requested_character_delete = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_already_requested_character_delete"),
    body = X2Locale:LocalizeUiText(MSG_BOX_BODY_TEXT, "error_already_requested_character_delete"),
    needsParams = false,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  error_already_requested_character_transfer = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_character_delete_failed"),
    body = X2Locale:LocalizeUiText(ERROR_MSG, "CH_TRANSFER_CANNOT_DELETE_CHARACTER"),
    needsParams = false,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  error_character_delete_failed = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_character_delete_failed"),
    body = X2Locale:LocalizeUiText(MSG_BOX_BODY_TEXT, "error_character_delete_failed"),
    needsParams = false,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  error_cancel_character_delete_failed = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_cancel_character_delete_failed"),
    body = X2Locale:LocalizeUiText(MSG_BOX_BODY_TEXT, "error_cancel_character_delete_failed"),
    needsParams = false,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  error_character_expedition = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_character_delete_failed"),
    body = X2Locale:LocalizeUiText(ERROR_MSG, "CHARACTER_DELETE_EXPEDITION_JOINED"),
    needsParams = false,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  error_character_connection_restrict = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_character_connection_restrict"),
    body = X2Locale:LocalizeUiText(MSG_BOX_BODY_TEXT, "error_character_connection_restrict"),
    needsParams = false,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  error_to_connect_world = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_to_connect_world"),
    body = X2Locale:LocalizeUiText(MSG_BOX_BODY_TEXT, "error_to_connect_world")
  },
  instant_game_bad_level = {
    title = X2Locale:LocalizeUiText(COMMON_TEXT, "instance_entrance_title"),
    body = function(battle_ground, level_min)
      return X2Locale:LocalizeUiText(MSG_BOX_BODY_TEXT, "instant_game_bad_level", battle_ground, tostring(level_min))
    end,
    needsParams = true,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  error_message = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_message"),
    body = function(msgKey, ...)
      return X2Locale:LocalizeUiText(ERROR_MSG, msgKey, ...)
    end,
    needsParams = true,
    buttons = {
      nil,
      locale.messageBoxBtnText.ok
    }
  },
  ask_leave_intro_world = {
    title = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "ask_leave_intro_world"),
    body = X2Locale:LocalizeUiText(MSG_BOX_BODY_TEXT, "ask_leave_intro_world"),
    needsParams = false,
    buttons = {
      locale.messageBoxBtnText.ok,
      locale.messageBoxBtnText.cancel
    }
  }
}
locale.util = {
  GetRecoveredExpString = function(expValue)
    return X2Locale:LocalizeUiText(UTIL_TEXT, "recovered_exp_str", F_TEXT.SetCommaFormat(expValue))
  end,
  speed_unit = X2Locale:LocalizeUiText(UTIL_TEXT, "speed_unit"),
  rotation_unit = X2Locale:LocalizeUiText(UTIL_TEXT, "rotation_unit")
}
locale.tooltip = {
  none = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "none"),
  wearLevel = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "wear_level"),
  attackPower = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "attack_power"),
  attackSpeed = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "attack_speed"),
  attackSecond = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "attack_second"),
  useSkill = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "use_skill"),
  noDescription = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "no_description"),
  equiped = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equiped"),
  magicAttackPower = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "magic_attackpower"),
  healPower = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "heal_power"),
  magicResistance = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "magic_resistance"),
  defencePower = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "defence_power"),
  durability = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "durability"),
  index = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "index"),
  second = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "second"),
  minute = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "minute"),
  hour = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "hour"),
  day = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "day"),
  now = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "now"),
  rangeSelf = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "range_self"),
  crafting_amount = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "crafting_amount"),
  stack = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "stack"),
  leftTime = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "left_time"),
  inc = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "inc"),
  dec = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "dec"),
  addEffect = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "add_effect"),
  sellYes = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "sell_yes"),
  sellNo = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "sell_no"),
  hp = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "hp"),
  mp = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "mp"),
  soul_bound = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "soul_bound"),
  soulbound_pickup = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "soulbound_pickup"),
  soulbound_equip = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "soulbound_equip"),
  soulbound_unpack = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "soulbound_unpack"),
  cost = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "cost"),
  use_effect = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "use_effect"),
  proc = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "proc"),
  equip_effect = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_effect"),
  player = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "player"),
  portal = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "portal"),
  set = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "set"),
  set_effect = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "set_effect"),
  owner = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "owner"),
  nobody = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "nobody"),
  magicItem = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "magicItem"),
  crafter = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "crafter"),
  craftedWorld = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "craftedWorld"),
  level_requirement = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "level_req"),
  pet_level_requirement = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "pet_level_requirement"),
  level_limit = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "level_limit"),
  pet_level_limit = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "pet_level_limit"),
  item_flag_cannot_equip = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "item_flag_cannot_equip"),
  GetFirstLvRequirements = function(a, b)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "first_level_requirements", a, F_TEXT.IStr(b))
  end,
  GetNextLvRequirements = function(a, b)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "next_level_requirements", a, F_TEXT.IStr(b))
  end,
  GetLearnPtRequirements = function(a, b)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "learn_point_requirements", a, F_TEXT.IStr(b))
  end,
  GetHeirLearnPtRequirements = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "learn_heir_level_requirements", F_TEXT.IStr(a))
  end,
  GetCastTime = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "cast_time", string.format("%.1f", a))
  end,
  GetCooldown = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "cooldown", a)
  end,
  GetRange = function(a, b)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "range", F_TEXT.IStr(a), F_TEXT.IStr(b))
  end,
  GetSkillLevel = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "skill_level", F_TEXT.IStr(a))
  end,
  GetFirstLearnLevel = function(a, b)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "first_learn_level", a, F_TEXT.IStr(b))
  end,
  GetNextLearnLevel = function(a, b)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "next_learn_level", a, F_TEXT.IStr(b))
  end,
  GetPetSkillLearnLevel = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "pet_skill_learn_level", F_TEXT.IStr(a))
  end,
  GetTargetAreaRadius = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "target_area_radius", F_TEXT.IStr(a))
  end,
  GetItemExpireRemainTime = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "item_expire_remain_time", a)
  end,
  GetItemLifespanTime = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "item_lifespan_time", a)
  end,
  itemTimeExpired = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "item_time_expired"),
  unbind = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "unbind"),
  showSlaveInfo = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "showSlaveInfo"),
  reqEnchantCondition = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "reqEnchantCondition"),
  reqEnchantSlot = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "reqEnchantSlot", a)
  end,
  reqEnchantItem = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "reqEnchantItem", a)
  end,
  reqEnchantLevelOver = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "reqEnchantLevelOver", a)
  end,
  reqEnchantGradeOver = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "reqEnchantGradeOver", a)
  end,
  rechargeItem = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "rechargeItem"),
  chargeTimeRemained = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "chargeTimeRemained", a)
  end,
  chargeLifetime = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "chargeLifetime", a)
  end,
  expireChargeLifetime = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "expireChargeLifetime"),
  length = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "length", a)
  end,
  weight = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "weight", a)
  end,
  catchedDate = function(a)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "catchedDate", a)
  end,
  actabilityRequirement = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "actabilityRequirement"),
  sellPrice = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "sellPrice"),
  freeLooting = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "freeLooting"),
  ConvenienceButton = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "convenience_button"),
  enchantable = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "enchantable"),
  lookItem = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "lookItem"),
  socketInfo = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "socketInfo"),
  progressCount = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "progressCount"),
  movePosition = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "movePosition"),
  movePositionInfo = function(a, b)
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "movePositionInfo", a, b)
  end,
  leadership = X2Locale:LocalizeUiText(COMMON_TEXT, "leadership_point"),
  default = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "default")
}
locale.tooltip.attack = {
  X2Locale:LocalizeUiText(TOOLTIP_TEXT, "attack_type_piercing"),
  X2Locale:LocalizeUiText(TOOLTIP_TEXT, "attack_type_cut"),
  X2Locale:LocalizeUiText(TOOLTIP_TEXT, "attack_type_blow")
}
locale.tooltip.attackStrength = {
  X2Locale:LocalizeUiText(TOOLTIP_TEXT, "attack_strength_strong"),
  X2Locale:LocalizeUiText(TOOLTIP_TEXT, "attack_strength_normal"),
  X2Locale:LocalizeUiText(TOOLTIP_TEXT, "attack_strength_weak")
}
FORMAT_FILTER = {
  YEAR = 64,
  MONTH = 32,
  DAY = 16,
  HOUR = 8,
  MINUTE = 4,
  SECOND = 2
}
DEFAULT_FORMAT_FILTER = FORMAT_FILTER.YEAR + FORMAT_FILTER.MONTH + FORMAT_FILTER.DAY + FORMAT_FILTER.HOUR + FORMAT_FILTER.MINUTE
locale.time = {
  GetDateFormatFromSec = function(sec)
    local dt = {
      second = sec % 60,
      minute = math.floor(sec / 60) % 60,
      hour = math.floor(sec / 3600) % 24,
      day = math.floor(sec / 86400),
      month = 0,
      year = 0
    }
    return dt
  end,
  GetDate = function(year, month, day, hour, minute, second, filter)
    return baselibLocale.GetDate(year, month, day, hour, minute, second, filter)
  end,
  IsEmptyDateFormat = function(df)
    if df.year == 0 and df.month == 0 and df.day == 0 and df.hour == 0 and df.minute == 0 and df.second == 0 then
      return true
    end
    return false
  end,
  GetDateToDateFormat = function(df, filter)
    local func = locale.time.GetDate
    return func(df.year, df.month, df.day, df.hour, df.minute, df.second, filter)
  end,
  GetDateToSimpleDateFormat = function(df)
    local func = baselibLocale.GetSimpleDate
    return func(df.year, df.month, df.day, df.hour, df.minute, df.second)
  end,
  GetRemainDate = function(year, month, day, hour, minute, second, filter)
    filter = filter or DEFAULT_FORMAT_FILTER
    local function Get(value, msg, key)
      if value <= 0 then
        return ""
      end
      if X2Helper:BitwiseAnd(filter, key) == 0 then
        return ""
      end
      return X2Locale:LocalizeUiText(PERIOD_TIME_TEXT, msg, tostring(value))
    end
    if year == 0 and month == 0 and day == 0 and hour == 0 and minute == 0 and X2Helper:BitwiseAnd(filter, FORMAT_FILTER.SECOND) == 0 then
      return X2Locale:LocalizeUiText(PERIOD_TIME_TEXT, "less_one_minute")
    end
    local str = string.format("%s%s%s", Get(year, "year", FORMAT_FILTER.YEAR), Get(month, "month", FORMAT_FILTER.MONTH), Get(day, "day", FORMAT_FILTER.DAY))
    local hourStr = Get(hour, "hour", FORMAT_FILTER.HOUR)
    if 0 < string.len(hourStr) then
      str = string.format("%s%s%s", str, 0 < string.len(str) and " " or "", hourStr)
    end
    local minuteStr = Get(minute, "minute", FORMAT_FILTER.MINUTE)
    if 0 < string.len(minuteStr) then
      str = string.format("%s%s%s", str, 0 < string.len(str) and " " or "", minuteStr)
    end
    local secondStr = Get(second, "second", FORMAT_FILTER.SECOND)
    if 0 < string.len(secondStr) then
      str = string.format("%s%s%s", str, 0 < string.len(str) and " " or "", secondStr)
    end
    return str
  end,
  GetRemainDateToDateFormat = function(df, filter)
    local func = locale.time.GetRemainDate
    return func(df.year, df.month, df.day, df.hour, df.minute, df.second, filter)
  end,
  GetPeriodToMinutesSecondFormat = function(df, filter)
    local minuteString = X2Locale:LocalizeUiText(PERIOD_TIME_TEXT, "minute", tostring(df.minute))
    local secondString = X2Locale:LocalizeUiText(PERIOD_TIME_TEXT, "second", tostring(df.second))
    return string.format("%s %s", minuteString, secondString)
  end,
  day = function(day)
    return X2Locale:LocalizeUiText(DATE_TIME_TEXT, "day", day)
  end,
  days = function(days)
    return X2Locale:LocalizeUiText(DATE_TIME_TEXT, "days", days)
  end,
  CreateDF = function(year, month, day, hour, minute, second)
    local df = {}
    df.year = year
    df.month = month
    df.day = day
    df.hour = hour
    df.minute = minute
    df.second = second
    return df
  end
}
locale.dominion = {
  siege_period_auction = X2Locale:LocalizeUiText(DOMINION, "siege_period_peace_title"),
  siege_period_declare = X2Locale:LocalizeUiText(DOMINION, "siege_period_declare_title"),
  siege_period_ready_to_siege = X2Locale:LocalizeUiText(DOMINION, "siege_period_warmup_title"),
  siege_period_warmup = X2Locale:LocalizeUiText(DOMINION, "siege_period_warmup_title"),
  siege_period_siege = X2Locale:LocalizeUiText(DOMINION, "siege_period_siege_title"),
  siege_period_peace = X2Locale:LocalizeUiText(DOMINION, "siege_period_peace_title"),
  defense = X2Locale:LocalizeUiText(DOMINION, "defense"),
  siege_warfare = X2Locale:LocalizeUiText(DOMINION, "siege_warfare"),
  spaceVs = X2Locale:LocalizeUiText(DOMINION, "space_vs"),
  unknown = X2Locale:LocalizeUiText(DOMINION, "unknown"),
  mercenary = X2Locale:LocalizeUiText(DOMINION, "mercenary"),
  castleOwner = X2Locale:LocalizeUiText(DOMINION, "castle_owner"),
  requestExpedition = X2Locale:LocalizeUiText(DOMINION, "request_expedition"),
  siege_war_info = X2Locale:LocalizeUiText(DOMINION, "siege_war_info"),
  siege_info = X2Locale:LocalizeUiText(DOMINION, "siege_info"),
  notExistSiegeInfo = X2Locale:LocalizeUiText(DOMINION, "not_exist_siege_info"),
  GetReinforcementsArrived = function(name)
    return X2Locale:LocalizeUiText(DOMINION, "reinforcements_arrived", name)
  end,
  GetGuardTowerStatusMsg = function(status)
    return X2Locale:LocalizeUiText(DOMINION, status)
  end,
  GetEngravingStatusMsg = function(status, name, factionName)
    return X2Locale:LocalizeUiText(DOMINION, status, factionName, tostring(name))
  end,
  engravingSucceed = function(name, zoneGroupName)
    if name == nil or name == "" then
      return X2Locale:LocalizeUiText(DOMINION, "siege_alert_engraving_succeeded_none_target")
    else
      return X2Locale:LocalizeUiText(DOMINION, "siege_alert_engraving_succeeded", zoneGroupName, tostring(name))
    end
  end,
  GetDeclareActionStatusMsg = function(action, offenseName, zoneGroupName)
    local key = string.format("action_%s", action)
    return X2Locale:LocalizeUiText(DOMINION, key, offenseName, zoneGroupName)
  end,
  GetMsg = function(msg, zoneGroupName, expeditionName)
    return X2Locale:LocalizeUiText(DOMINION, msg, zoneGroupName, expeditionName)
  end,
  GetSiegeMsg = function(msg, zoneGroupName, remainTime)
    if remainTime == nil then
      return X2Locale:LocalizeUiText(DOMINION, msg, zoneGroupName)
    else
      return X2Locale:LocalizeUiText(DOMINION, msg, zoneGroupName, remainTime)
    end
  end,
  GetSiegeMsgInProgress = function(periodName, zoneGroupName)
    local key = string.format("%s_in_progress", periodName)
    return X2Locale:LocalizeUiText(DOMINION, key, zoneGroupName)
  end,
  GetSiegeIconTooltip = function(zoneGroupName, defenseName, remainTime)
    return string.format([[
%s/%s
%s]], zoneGroupName, defenseName, remainTime)
  end,
  GetSiegeMsgForAlarm = function(periodName, zoneGroupName, onEvent)
    local key
    if onEvent == true then
      key = string.format("%s_start", periodName)
    else
      key = string.format("%s_in_progress_for_alarm", periodName)
    end
    return X2Locale:LocalizeUiText(DOMINION, key, zoneGroupName)
  end,
  GetSiegeWin = function(winner)
    return X2Locale:LocalizeUiText(DOMINION, "siege_win", winner)
  end,
  GetSiegeLose = function(loser)
    return X2Locale:LocalizeUiText(DOMINION, "siege_lose", loser)
  end
}
locale.kindName = {
  human = X2Locale:LocalizeUiText(UNIT_KIND_TEXT, "human"),
  devil = X2Locale:LocalizeUiText(UNIT_KIND_TEXT, "devil"),
  beast = X2Locale:LocalizeUiText(UNIT_KIND_TEXT, "beast"),
  spirit = X2Locale:LocalizeUiText(UNIT_KIND_TEXT, "spirit"),
  dragon = X2Locale:LocalizeUiText(UNIT_KIND_TEXT, "dragon"),
  undead = X2Locale:LocalizeUiText(UNIT_KIND_TEXT, "undead"),
  horse = X2Locale:LocalizeUiText(UNIT_KIND_TEXT, "horse"),
  fantastic = X2Locale:LocalizeUiText(UNIT_KIND_TEXT, "fantastic"),
  machine = X2Locale:LocalizeUiText(UNIT_KIND_TEXT, "machine"),
  ship = X2Locale:LocalizeUiText(UNIT_KIND_TEXT, "ship"),
  carriage = X2Locale:LocalizeUiText(UNIT_KIND_TEXT, "carriage"),
  siege_weapon = X2Locale:LocalizeUiText(UNIT_KIND_TEXT, "siege_weapon"),
  unknown = X2Locale:LocalizeUiText(UNIT_KIND_TEXT, "unknown")
}
locale.gradeName = {
  normal = X2Locale:LocalizeUiText(UNIT_GRADE_TEXT, "normal"),
  elite = X2Locale:LocalizeUiText(UNIT_GRADE_TEXT, "elite"),
  boss_a = X2Locale:LocalizeUiText(UNIT_GRADE_TEXT, "boss_a"),
  boss_b = X2Locale:LocalizeUiText(UNIT_GRADE_TEXT, "boss_b"),
  boss_c = X2Locale:LocalizeUiText(UNIT_GRADE_TEXT, "boss_c"),
  weak = X2Locale:LocalizeUiText(UNIT_GRADE_TEXT, "weak"),
  strong = X2Locale:LocalizeUiText(UNIT_GRADE_TEXT, "strong"),
  boss_s = X2Locale:LocalizeUiText(UNIT_GRADE_TEXT, "boss_s")
}
locale.character = {}
locale.character.subtitleInfoTooltip = {
  melee_dmg = X2Locale:LocalizeUiText(CHARACTER_SUBTITLE_INFO_TOOLTIP_TEXT, "melee_dmg"),
  ranged_dmg = X2Locale:LocalizeUiText(CHARACTER_SUBTITLE_INFO_TOOLTIP_TEXT, "ranged_dmg")
}
function locale.attribute(attribute)
  if IsAttackSpeedAttributes(attribute) then
    return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "attack_speed")
  elseif attribute == "exp" then
    return X2Locale:LocalizeUiText(COMMON_TEXT, "exp")
  end
  return X2Locale:LocalizeUiText(ATTRIBUTE_TEXT, attribute) or ""
end
locale.bmmileage = {
  bmmileage_archelife = X2Locale:LocalizeUiText(ATTRIBUTE_TEXT, "bmmileage_archelife"),
  bmmileage_free = X2Locale:LocalizeUiText(ATTRIBUTE_TEXT, "bmmileage_free"),
  bmmileage_pcbang = X2Locale:LocalizeUiText(ATTRIBUTE_TEXT, "bmmileage_pcbang"),
  bmmileage = X2Locale:LocalizeUiText(ATTRIBUTE_TEXT, "bmmileage")
}
function locale.playTimeNotice(playTime)
  return X2Locale:LocalizeUiText(COMMON_TEXT, "play_time_notice", tostring(playTime))
end
locale.raceText = {
  X2Locale:LocalizeUiText(RACE_TEXT, "nuian"),
  "\237\142\152\236\150\180\235\166\172",
  X2Locale:LocalizeUiText(RACE_TEXT, "dwarf"),
  X2Locale:LocalizeUiText(RACE_TEXT, "elf"),
  X2Locale:LocalizeUiText(RACE_TEXT, "hariharan"),
  X2Locale:LocalizeUiText(RACE_TEXT, "ferre"),
  "\235\166\172\237\132\180\235\147\156",
  X2Locale:LocalizeUiText(RACE_TEXT, "warborn"),
  "\235\139\164\235\163\168"
}
locale.gender = {}
locale.gender.male = X2Locale:LocalizeUiText(GENDER_TEXT, "male")
locale.gender.female = X2Locale:LocalizeUiText(GENDER_TEXT, "female")
locale.common = {
  warning = X2Locale:LocalizeUiText(COMMON_TEXT, "warning"),
  ok = X2Locale:LocalizeUiText(COMMON_TEXT, "ok"),
  cancel = X2Locale:LocalizeUiText(COMMON_TEXT, "cancel"),
  change = X2Locale:LocalizeUiText(COMMON_TEXT, "change"),
  crime = X2Locale:LocalizeUiText(COMMON_TEXT, "crime"),
  GetAmount = function(ammount)
    return X2Locale:LocalizeUiText(COMMON_TEXT, "amount", tostring(ammount))
  end,
  accumulate = function(area, kind, point)
    return X2Locale:LocalizeUiText(COMMON_TEXT, "x_sum_y_points", area, kind, tostring(point))
  end,
  input_name_guide = X2Locale:LocalizeUiText(COMMON_TEXT, "input_name_guide"),
  reload = X2Locale:LocalizeUiText(COMMON_TEXT, "reload"),
  option = X2Locale:LocalizeUiText(COMMON_TEXT, "option"),
  period = X2Locale:LocalizeUiText(COMMON_TEXT, "period"),
  name = X2Locale:LocalizeUiText(INSTANT_GAME_TEXT, "name"),
  from_to = function(from, to)
    return X2Locale:LocalizeUiText(COMMON_TEXT, "from_to", tostring(from), tostring(to))
  end,
  combat = X2Locale:LocalizeUiText(COMMON_TEXT, "combat"),
  buy = X2Locale:LocalizeUiText(COMMON_TEXT, "buy"),
  present = X2Locale:LocalizeUiText(COMMON_TEXT, "gift")
}
locale.mileage = {
  gived_max_warning = X2Locale:LocalizeUiText(INFOBAR_MENU_TIP_TEXT, "bmmileage_free_nontarget_end_tip"),
  none_give_term = function(a, b)
    return X2Locale:LocalizeUiText(INFOBAR_MENU_TIP_TEXT, "bmmileage_none_give_term", tostring(a), tostring(b))
  end,
  none_give_term_give_max = function(a, b, c, d)
    return X2Locale:LocalizeUiText(INFOBAR_MENU_TIP_TEXT, "bmmileage_none_give_term_give_max", tostring(a), tostring(b), tostring(c), tostring(d))
  end,
  have_give_term_give_max = function(a, b, c, d)
    return X2Locale:LocalizeUiText(INFOBAR_MENU_TIP_TEXT, "bmmileage_have_give_term_give_max", tostring(a), tostring(b), tostring(c), tostring(d))
  end,
  gived_max = function(a, b, c, d)
    return X2Locale:LocalizeUiText(INFOBAR_MENU_TIP_TEXT, "bmmileage_gived_max", tostring(a), tostring(b), tostring(c), tostring(d))
  end,
  none_give_max = function(a, b, c)
    return X2Locale:LocalizeUiText(INFOBAR_MENU_TIP_TEXT, "bmmileage_none_give_max", tostring(a), tostring(b), tostring(c))
  end
}
function locale.common.abilityNameWithStr(abilName)
  if abilName == nil or abilName == "invalid ability" then
    return nil
  end
  return X2Locale:LocalizeUiText(ABILITY_CATEGORY_TEXT, abilName)
end
function locale.common.abilityNameWithId(abilId)
  return locale.common.abilityNameWithStr(X2Ability:GetAbilityStr(abilId))
end
locale.common.equipSlotType = {}
locale.common.equipSlotType.offhand = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "offhand")
locale.common.equipSlotType["1handed"] = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "1handed")
locale.common.equipSlotType["2handed"] = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "2handed")
locale.common.equipSlotType.instrument = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "instrument")
locale.common.equipSlotType.ranged = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "ranged")
locale.common.equipSlotType.mainhand = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "mainhand")
locale.common.equipSlotType.head = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "head")
locale.common.equipSlotType.neck = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "neck")
locale.common.equipSlotType.chest = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "chest")
locale.common.equipSlotType.waist = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "waist")
locale.common.equipSlotType.legs = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "legs")
locale.common.equipSlotType.hands = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "hands")
locale.common.equipSlotType.feet = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "feet")
locale.common.equipSlotType.arms = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "arms")
locale.common.equipSlotType.back = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "back")
locale.common.equipSlotType.ear = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "ear")
locale.common.equipSlotType.finger = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "finger")
locale.common.equipSlotType.underweartop = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "underweartop")
locale.common.equipSlotType.underwearbottom = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "underwearbottom")
locale.common.equipSlotType.shield = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "shield")
locale.common.equipSlotType.backpack = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "backpack")
locale.common.equipSlotType.cosplay = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "cosplay")
locale.common.equipSlotType.underpants = X2Locale:LocalizeUiText(EQUIP_SLOT_TYPE_TEXT, "underpants")
locale.common.equipSlotType.allEquip = X2Locale:LocalizeUiText(COMMON_TEXT, "allEquip")
locale.common.heirSkills = {
  X2Locale:LocalizeUiText(COMMON_TEXT, "heir_skill_fire"),
  X2Locale:LocalizeUiText(COMMON_TEXT, "heir_skill_life"),
  X2Locale:LocalizeUiText(COMMON_TEXT, "heir_skill_earthquake"),
  X2Locale:LocalizeUiText(COMMON_TEXT, "heir_skill_rock"),
  X2Locale:LocalizeUiText(COMMON_TEXT, "heir_skill_wave"),
  X2Locale:LocalizeUiText(COMMON_TEXT, "heir_skill_fog"),
  X2Locale:LocalizeUiText(COMMON_TEXT, "heir_skill_squall"),
  X2Locale:LocalizeUiText(COMMON_TEXT, "heir_skill_lightning")
}
locale.characterCreate = {
  getTendencyInfo = function(str)
    return X2Locale:LocalizeUiText(CHARACTER_CREATE_TEXT, str)
  end,
  abilityDescWithStr = function(abilName)
    if abilName == nil or abilName == "invalid ability" then
      return nil
    end
    return X2Locale:LocalizeUiText(ABILITY_CATEGORY_DESCRIPTION_TEXT, abilName)
  end,
  abilityDescWithId = function(abilId)
    return locale.characterCreate.abilityDescWithStr(X2Ability:GetAbilityStr(abilId))
  end
}
locale.party = {}
locale.party.leaved = nil
locale.party.leaderPopupLeaders = {
  X2Locale:LocalizeUiText(PARTY_TEXT, "leader_popup_leader_drop"),
  X2Locale:LocalizeUiText(PARTY_TEXT, "leader_popup_leader_loot_rule")
}
locale.party.leaderPopupMembers = {
  X2Locale:LocalizeUiText(PARTY_TEXT, "leader_popup_member_kick_out"),
  X2Locale:LocalizeUiText(PARTY_TEXT, "leader_popup_member_delegate")
}
locale.party.memberPopups = {
  X2Locale:LocalizeUiText(PARTY_TEXT, "member_popup_drop")
}
locale.party.lootRule = {}
locale.party.lootRule.popups = {
  X2Locale:LocalizeUiText(PARTY_TEXT, "loot_rule_popup_free"),
  X2Locale:LocalizeUiText(PARTY_TEXT, "loot_rule_popup_sequence"),
  X2Locale:LocalizeUiText(PARTY_TEXT, "loot_rule_popup_in_charge")
}
locale.party.lootRule.dropdownBase = X2Locale:LocalizeUiText(PARTY_TEXT, "loot_rule_select_in_charge")
locale.lootMethodFunc = {}
locale.lootMethodFunc.msgFunc = {}
function locale.lootMethodFunc.msgFunc.free()
  return X2Locale:LocalizeUiText(LOOT_METHOD_TEXT, "free")
end
function locale.lootMethodFunc.msgFunc.sequence()
  return X2Locale:LocalizeUiText(LOOT_METHOD_TEXT, "sequence")
end
function locale.lootMethodFunc.msgFunc.inCharge(a)
  return X2Locale:LocalizeUiText(LOOT_METHOD_TEXT, "in_charge", a)
end
locale.lootPopupText = {
  diceDistribute = X2Locale:LocalizeUiText(LOOT_TEXT, "popup_dice_distribute"),
  bindOnPickup = X2Locale:LocalizeUiText(LOOT_TEXT, "popup_bop"),
  notUseDiceRule = X2Locale:LocalizeUiText(LOOT_TEXT, "popup_not_use_dice_rule"),
  notUseBindOnPickup = X2Locale:LocalizeUiText(LOOT_TEXT, "popup_not_use_bop"),
  useBindOnPickup_Dice = X2Locale:LocalizeUiText(LOOT_TEXT, "popup_use_bop_dice"),
  GetMoreThenGrade = function(a)
    return X2Locale:LocalizeUiText(LOOT_TEXT, "more_then", a)
  end,
  GetDoubleTitle = function(a, b)
    return X2Locale:LocalizeUiText(LOOT_TEXT, "popup_double_title", a, b)
  end
}
locale.diceBidRule = {}
locale.diceBidRule.popups = {
  X2Locale:LocalizeUiText(LOOT_TEXT, "bid_rule_default"),
  X2Locale:LocalizeUiText(LOOT_TEXT, "bid_rule_auto_accept"),
  X2Locale:LocalizeUiText(LOOT_TEXT, "bid_rule_auto_giveup")
}
locale.diceBidRule.popupTitle = X2Locale:LocalizeUiText(LOOT_TEXT, "bid_rule")
locale.diceBidRule.checkBoxTooltip = X2Locale:LocalizeUiText(LOOT_TEXT, "bid_rule_auto_checkBoxTooltip")
locale.appellation = {
  title = X2Locale:LocalizeUiText(COMMON_TEXT, "appellation_title"),
  unable = X2Locale:LocalizeUiText(COMMON_TEXT, "appellation_unable"),
  have_not_appellation = X2Locale:LocalizeUiText(COMMON_TEXT, "appellation_have_not_appellation")
}
locale.chatChannel = {
  race = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_normal_group1_alliance"),
  chat_trade = X2Locale:LocalizeUiText(CHAT_CHANNEL_TEXT, "chat_trade")
}
locale.chatSystem = {
  GetQuest = function(a)
    return X2Locale:LocalizeUiText(CHAT_SYSTEM_TEXT, "msg_quest", a)
  end,
  get_quest_start_item = X2Locale:LocalizeUiText(CHAT_SYSTEM_TEXT, "get_quest_start_item"),
  get_use_item_in_active_quest = X2Locale:LocalizeUiText(CHAT_SYSTEM_TEXT, "get_use_item_in_active_quest"),
  get_quest_item = X2Locale:LocalizeUiText(CHAT_SYSTEM_TEXT, "get_quest_item"),
  get_item = X2Locale:LocalizeUiText(CHAT_SYSTEM_TEXT, "get_item"),
  GetGainBmMileage = function(a, b)
    return X2Locale:LocalizeUiText(CHAT_SYSTEM_TEXT, "msg_gain_bmmileage", F_TEXT.SetCommaFormat(a), F_TEXT.SetCommaFormat(b))
  end,
  GetUseBmMileage = function(a, b)
    return X2Locale:LocalizeUiText(CHAT_SYSTEM_TEXT, "msg_use_bmmileage", F_TEXT.SetCommaFormat(a), F_TEXT.SetCommaFormat(b))
  end
}
locale.chatCombatLog = {
  config = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "config"),
  check_all = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "check_all"),
  hit = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "hit"),
  critical = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "critical"),
  miss = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "miss"),
  dodge = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "dodge"),
  block = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "block"),
  parry = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "parry"),
  immune = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "immune"),
  resist = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "resist"),
  piercing = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "piercing"),
  slashing = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "slashing"),
  blunting = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "blunting"),
  drowning = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "drowning"),
  falling = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "falling"),
  collision = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "collision"),
  collision_front = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "collision_front"),
  collision_side = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "collision_side"),
  collision_rear = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "collision_rear"),
  collision_bottom = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "collision_bottom"),
  health = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "health"),
  mana = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "mana"),
  unknown = X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "unknown"),
  GetMeleeLogFormat = function(a, b, c, d, e)
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "melee_log_format", a, b, c, d, e)
  end,
  GetReduced = function(a)
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "reduced", F_TEXT.IStr(a))
  end,
  GetMeleeMissed = function(a, b)
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "melee_missed", a, b)
  end,
  GetSpellLogFormat = function(a, b, c, d, e, f)
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "spell_log_format", a, b, c, d, e, f)
  end,
  GetSpellMissed = function(a, b, c)
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "spell_missed", a, b, c)
  end,
  GetSpellHealed = function(a, b, c, d)
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "spell_healed", a, b, c, d)
  end,
  GetSpellEnergize = function(a, b, c, d)
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "spell_energize", a, b, c, d)
  end,
  GetSpellCastStart = function(a, b)
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "spell_cast_start", a, b)
  end,
  GetSpellCastSuccess = function(a, b)
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "spell_cast_success", a, b)
  end,
  GetSpellCastFailed = function(a, b)
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "spell_cast_failed", a, b)
  end,
  GetSpellAuraAppliedBuff = function(a, b)
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "spell_aura_applied_buff", a, b)
  end,
  GetSpellAuraAppliedDebuff = function(a, b)
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "spell_aura_applied_debuff", a, b)
  end,
  GetSpellAuraRemovedBuff = function(a, b)
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "spell_aura_removed_buff", a, b)
  end,
  GetSpellAuraRemovedDebuff = function(a, b)
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "spell_aura_removed_debuff", a, b)
  end,
  GetEnvironmentalDamage = function(a, b, c)
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "environmental_damage", a, b, c)
  end
}
locale.chat = {
  FORCE_ATTACK_ON = X2Locale:LocalizeUiText(CHAT_FORCE_ATTACK_TEXT, "force_attack_on"),
  FORCE_ATTACK_OFF = X2Locale:LocalizeUiText(CHAT_FORCE_ATTACK_TEXT, "force_attack_off"),
  create = X2Locale:LocalizeUiText(CHAT_CREATE_TAB_TEXT, "create"),
  change = X2Locale:LocalizeUiText(CHAT_CREATE_TAB_TEXT, "change"),
  eraseTabContent = X2Locale:LocalizeUiText(CHAT_CREATE_TAB_TEXT, "erase_tab_content"),
  removeTab = X2Locale:LocalizeUiText(CHAT_CREATE_TAB_TEXT, "remove_tab"),
  lockTab = X2Locale:LocalizeUiText(CHAT_CREATE_TAB_TEXT, "lock_tab"),
  unlockTab = X2Locale:LocalizeUiText(CHAT_CREATE_TAB_TEXT, "unlock_tab")
}
locale.chatFiltering = {
  title = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_title"),
  texts = {
    [CMF_SAY] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_normal_group1_common"),
    [CMF_ZONE] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_normal_group1_shout"),
    [CMF_WHISPER] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_normal_group1_whisper"),
    [CMF_TRADE] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_normal_group1_trade"),
    [CMF_PARTY] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_normal_group1_party"),
    [CMF_FIND_PARTY] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_normal_group1_search_party"),
    [CMF_RAID] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_normal_group1_raid"),
    [CMF_EXPEDITION] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_normal_group1_expedition"),
    [CMF_FAMILY] = X2Locale:LocalizeUiText(COMMON_TEXT, "family"),
    [CMF_TRIAL] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_normal_group1_trial"),
    [CMF_FACTION] = X2Locale:LocalizeUiText(CHARACTER_SUBTITLE_TEXT, "faction"),
    [CMF_RACE] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_normal_group1_alliance"),
    [CMF_SQUAD] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_normal_group1_squad"),
    [CMF_OTHER_CONTINENT] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_other_continent"),
    [CMF_ALL_SERVER] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_all_server"),
    [CMF_NOTICE] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_normal_group1_notice"),
    [CMF_SYSTEM] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_normal_group1_system"),
    [CMF_QUEST_INFO] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_alarm_group6_submenu3"),
    [CMF_CHANNEL_INFO] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_alarm_group6_submenu4"),
    [CMF_CONNECT_ALERT] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_connect_alert"),
    [CMF_CONNECT_FRIEND] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_connect_friend"),
    [CMF_CONNECT_FAMILY] = X2Locale:LocalizeUiText(COMMON_TEXT, "family"),
    [CMF_CONNECT_EXPEDITION] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_normal_group1_expedition"),
    [CMF_ADDED_ITEM_GROUP] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_alarm_group3_item_info"),
    [CMF_ADDED_ITEM_SELF] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_alarm_group3_submenu1"),
    [CMF_ADDED_ITEM_TEAM] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_alarm_group3_submenu2"),
    [CMF_LOOT_METHOD_CHANGED] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_alarm_group4_submenu1"),
    [CMF_ACQ_CONSUME_GROUP] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_alarm_group4_get_consume_info"),
    [CMF_SELF_MONEY_CHANGED] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_alarm_group4_submenu2"),
    [CMF_SELF_HONOR_POINT_CHANGED] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_alarm_group4_submenu3"),
    [CMF_SELF_LIVING_POINT_CHANGED] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_alarm_group4_submenu4"),
    [CMF_PARTY_AND_RAID_INFO] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_alarm_group5_team_info"),
    [CMF_DOMINION_AND_SIEGE_INFO] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_alarm_group5_camp_info"),
    [CMF_TRADE_STORE_MSG] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_alarm_group5_trade_info"),
    [CMF_ETC_GROUP] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_alarm_group6_etc"),
    [CMF_EMOTIOIN_EXPRESS] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_alarm_group5_expression_info"),
    [CMF_SELF_SKILL_INFO] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_alarm_group1_skill_info"),
    [CMF_COMBAT_SRC_GROUP] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_combat_group1_submenu1"),
    [CMF_COMBAT_DST_GROUP] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_combat_group2_submenu2"),
    [CMF_COMBAT_MELEE_GROUP] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_combat_group3_default_attack"),
    [CMF_COMBAT_MELEE_DAMAGE] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_combat_group3_submenu1"),
    [CMF_COMBAT_MELEE_MISSED] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_combat_group3_submenu2"),
    [CMF_COMBAT_SPELL_GROUP] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_combat_group4_skill"),
    [CMF_COMBAT_SPELL_DAMAGE] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_combat_group4_submenu1"),
    [CMF_COMBAT_SPELL_MISSED] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_combat_group4_submenu2"),
    [CMF_COMBAT_SPELL_HEALED] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_combat_group4_submenu3"),
    [CMF_COMBAT_SPELL_ENERGIZE] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_combat_group4_submenu4"),
    [CMF_COMBAT_SPELL_AURA] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_combat_group5_buff"),
    [CMF_COMBAT_ENVIRONMENTAL_DMANAGE] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_combat_group5_around_damage"),
    [CMF_COMBAT_DEAD] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_combat_group5_death"),
    [CMF_KO] = X2Locale:LocalizeUiText(COMMON_TEXT, "ko_kr"),
    [CMF_EN_US] = X2Locale:LocalizeUiText(COMMON_TEXT, "en_us"),
    [CMF_ZH_CN] = X2Locale:LocalizeUiText(COMMON_TEXT, "zh_cn"),
    [CMF_JA] = X2Locale:LocalizeUiText(COMMON_TEXT, "ja_jp"),
    [CMF_RU] = X2Locale:LocalizeUiText(COMMON_TEXT, "ru_ru"),
    [CMF_ZH_TW] = X2Locale:LocalizeUiText(COMMON_TEXT, "zh_tw"),
    [CMF_DE] = X2Locale:LocalizeUiText(COMMON_TEXT, "de_de"),
    [CMF_FR] = X2Locale:LocalizeUiText(COMMON_TEXT, "fr_fr"),
    [CMF_TH] = X2Locale:LocalizeUiText(COMMON_TEXT, "th_th"),
    [CMF_IND] = X2Locale:LocalizeUiText(COMMON_TEXT, "id_id"),
    [CMF_EN_SG] = X2Locale:LocalizeUiText(COMMON_TEXT, "en_sg"),
    [CMF_LOCALE_SERVER] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_normal_group1_locale_server")
  },
  tip = {
    [CMF_OTHER_CONTINENT] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_tip_other_continent"),
    [CMF_ALL_SERVER] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_tip_all_server"),
    [CMF_COMBAT_ENVIRONMENTAL_DMANAGE] = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_tip_death")
  },
  enemy_combat = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_enemy_combat"),
  friend_combat = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_friend_combat"),
  setAlphaMode = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_set_alpah_mode"),
  mouseOverActive = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_mouse_over_active"),
  alwaysActive = X2Locale:LocalizeUiText(CHAT_FILTERING, "chat_always_active")
}
locale.graveyard = {
  title = X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "title"),
  dead_msg = X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "dead"),
  revive = X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "revive"),
  revive_battle_field = X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "revive_battle_field"),
  revive_siege = X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "revive_siege"),
  revive_indun = X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "revive_indun"),
  graceRevive = X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "grace_revive"),
  dead_wnd_msg = X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "dead_wnd_msg"),
  dead_battle_field_wnd_msg = X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "dead_battle_field_wnd_msg"),
  dead_siege_wnd_msg = X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "dead_siege_wnd_msg"),
  dead_indun_wnd_msg = X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "dead_indun_wnd_msg"),
  GetResurrectionWaitingMsg = function(a)
    return X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "resurrection_waiting_msg", a)
  end,
  GetLostExp = function(a)
    return X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "lost_exp", tostring(a))
  end,
  GetDurabilityLossRatio = function(a)
    return X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "durability_loss_ratio", tostring(a))
  end,
  notDecreaseExp = X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "not_decrease_exp"),
  GetDeathMessage = function(name)
    if name == X2Unit:UnitName("player") then
      return locale.graveyard.dead_msg
    end
    return X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "death_message", name)
  end,
  expRecoverGuide = X2Locale:LocalizeUiText(GRAVE_YARD_TEXT, "exp_recover_guide")
}
locale.levelChanged = {
  GetLevelText = function(a)
    return X2Locale:LocalizeUiText(LEVEL_CHANGED_TEXT, "level", F_TEXT.IStr(a))
  end
}
locale.inven = {
  bagTitle = X2Locale:LocalizeUiText(INFOBAR_MENU_TEXT, "bag"),
  addTabDesc = X2Locale:LocalizeUiText(INVEN_TEXT, "addTabDesc"),
  allTab = X2Locale:LocalizeUiText(COMMON_TEXT, "all"),
  expandBag = X2Locale:LocalizeUiText(INVEN_TEXT, "expandSlot"),
  expandCoffer = X2Locale:LocalizeUiText(INVEN_TEXT, "expandCoffer"),
  addGroup = X2Locale:LocalizeUiText(INVEN_TEXT, "addGroup"),
  editGroup = X2Locale:LocalizeUiText(INVEN_TEXT, "editGroup"),
  removeGroup = X2Locale:LocalizeUiText(INVEN_TEXT, "removeGroup"),
  sort = X2Locale:LocalizeUiText(INVEN_TEXT, "sort"),
  paying_drawing = X2Locale:LocalizeUiText(INVEN_TEXT, "paying_drawing"),
  inputAmount = X2Locale:LocalizeUiText(INVEN_TEXT, "inputAmount"),
  deposit = X2Locale:LocalizeUiText(INVEN_TEXT, "deposit"),
  withdraw = X2Locale:LocalizeUiText(INVEN_TEXT, "withdraw")
}
locale.clock = {
  currentTime = X2Locale:LocalizeUiText(MAP_TEXT, "clock"),
  protectRegion = X2Locale:LocalizeUiText(MAP_TEXT, "protect_region"),
  neutralityRegion = X2Locale:LocalizeUiText(MAP_TEXT, "neutrality_region"),
  unknown_region = X2Locale:LocalizeUiText(MAP_TEXT, "unknown_region"),
  roadmapSize = X2Locale:LocalizeUiText(MAP_TEXT, "roadmap_size"),
  roadmapOption = X2Locale:LocalizeUiText(MAP_TEXT, "roadmap_option"),
  visibleRodemap = X2Locale:LocalizeUiText(MAP_TEXT, "visible_rodemap"),
  visibleRoadmapIcon = X2Locale:LocalizeUiText(MAP_TEXT, "visible_roadmap_icon"),
  roadmapSize_tooltip = X2Locale:LocalizeUiText(MAP_TEXT, "roadmap_size_tooltip"),
  road_map_size = {
    X2Locale:LocalizeUiText(MAP_TEXT, "road_map_size_small"),
    X2Locale:LocalizeUiText(MAP_TEXT, "road_map_size_middle"),
    X2Locale:LocalizeUiText(MAP_TEXT, "road_map_size_big")
  }
}
locale.commonFarm = {
  title = X2Locale:LocalizeUiText(FARM_TEXT, "title"),
  item = X2Locale:LocalizeUiText(FARM_TEXT, "item"),
  time = X2Locale:LocalizeUiText(FARM_TEXT, "time"),
  area = X2Locale:LocalizeUiText(FARM_TEXT, "area"),
  map = X2Locale:LocalizeUiText(FARM_TEXT, "map"),
  growUp = X2Locale:LocalizeUiText(FARM_TEXT, "grow_up"),
  endanger = X2Locale:LocalizeUiText(FARM_TEXT, "endanger"),
  protectWaring = function(a)
    return X2Locale:LocalizeUiText(FARM_TEXT, "protect_waring", tostring(a))
  end,
  ableCount = function(a)
    return X2Locale:LocalizeUiText(FARM_TEXT, "able_count", tostring(a))
  end,
  itemList = X2Locale:LocalizeUiText(FARM_TEXT, "farm_item_list")
}
locale.map = {
  title = X2Locale:LocalizeUiText(MAP_TEXT, "title"),
  checkQuset = X2Locale:LocalizeUiText(MAP_TEXT, "checkQuset"),
  visibleNpc = X2Locale:LocalizeUiText(MAP_TEXT, "visibleNpc"),
  guide = X2Locale:LocalizeUiText(MAP_TEXT, "guide"),
  w_gweonid_forest = X2Locale:LocalizeUiText(MAP_TEXT, "w_gweonid_forest"),
  w_garangdol_plains = X2Locale:LocalizeUiText(MAP_TEXT, "w_garangdol_plains"),
  w_marianople = X2Locale:LocalizeUiText(MAP_TEXT, "w_marianople"),
  cbsuh_nonpc = X2Locale:LocalizeUiText(MAP_TEXT, "cbsuh_nonpc"),
  peace_tax_tip = X2Locale:LocalizeUiText(MAP_TEXT, "peace_tax_tip"),
  allIcon = X2Locale:LocalizeUiText(COMMON_TEXT, "all"),
  NpcAllIcon = {
    X2Locale:LocalizeUiText(MAP_TEXT, "NpcAllIcon")
  },
  DoodadAllIcon = {
    X2Locale:LocalizeUiText(MAP_TEXT, "DoodadAllIcon")
  },
  filterBtn = X2Locale:LocalizeUiText(MAP_TEXT, "filterBtnTooltip"),
  pingBtn = X2Locale:LocalizeUiText(MAP_TEXT, "pingBtnTooltip"),
  expandBtn = X2Locale:LocalizeUiText(MAP_TEXT, "expandBtnTooltip"),
  lookMyPosition = X2Locale:LocalizeUiText(MAP_TEXT, "lookMyPosition"),
  pingPosition = X2Locale:LocalizeUiText(MAP_TEXT, "pingPosition"),
  changeMapScale = X2Locale:LocalizeUiText(MAP_TEXT, "changeMapScale"),
  showIcon = X2Locale:LocalizeUiText(MAP_TEXT, "showIcon"),
  pingMenu = {
    X2Locale:LocalizeUiText(MAP_TEXT, "delete")
  },
  slaveKind = function(str)
    return X2Locale:LocalizeUiText(SLAVE_KIND, str)
  end,
  shipyard = X2Locale:LocalizeUiText(HOUSING_TEXT, "material_shipyard"),
  telescopeOwner = function(str)
    return X2Locale:LocalizeUiText(MAP_TEXT, "telescopeOwner", tostring(str))
  end,
  telescopeExpedition = function(str)
    return X2Locale:LocalizeUiText(MAP_TEXT, "telescopeExpedition", tostring(str))
  end,
  telescopeBuff = X2Locale:LocalizeUiText(MAP_TEXT, "telescopeBuff", tostring(X2Locale:LocalizeUiText(MAP_TEXT, "protectedBuff"))),
  makeLongitudeStr = function(info, color1, color2)
    local str = string.format("%s%s%d\194\176%s%d' %d\"", color1, info.longitude, info.deg_long, color2, info.min_long, info.sec_long)
    return str
  end,
  makeLatitudeStr = function(info, color1, color2)
    local str = string.format("%s%s%d\194\176%s%d' %d\"", color1, info.latitude, info.deg_lat, color2, info.min_lat, info.sec_lat)
    return str
  end
}
locale.skill = {
  titleText = X2Locale:LocalizeUiText(SKILL_TEXT, "titleText"),
  skillInfoTitle = X2Locale:LocalizeUiText(SKILL_TEXT, "skill_info_title"),
  skill_notify_title = X2Locale:LocalizeUiText(SKILL_TEXT, "skill_notify_title"),
  openSkillWindow = X2Locale:LocalizeUiText(SKILL_TEXT, "open_skill_ui"),
  attackSkill = X2Locale:LocalizeUiText(SKILL_TEXT, "category_attack"),
  generalSkill = X2Locale:LocalizeUiText(SKILL_TEXT, "category_general"),
  jobRaceSkill = X2Locale:LocalizeUiText(SKILL_TEXT, "category_job_race"),
  continue = X2Locale:LocalizeUiText(SKILL_TEXT, "category_buff"),
  generalButtonText = X2Locale:LocalizeUiText(SKILL_TEXT, "generalButtonText"),
  actabilityButtonText = X2Locale:LocalizeUiText(SKILL_TEXT, "actabilityButtonText"),
  resetButoonExplain = X2Locale:LocalizeUiText(SKILL_TEXT, "resetButoonExplain"),
  skillPointText = X2Locale:LocalizeUiText(SKILL_TEXT, "useable_skill_point"),
  GetJobText = function(job)
    return X2Locale:LocalizeUiText(SKILL_TEXT, "job_display", tostring(job))
  end,
  GetSkillChangedText = function(a)
    return X2Locale:LocalizeUiText(SKILL_TEXT, "skill_changed", tostring(a))
  end,
  GetAbilityRequirementText = function(level)
    return X2Locale:LocalizeUiText(SKILL_TEXT, "ability_requirement", tostring(level))
  end,
  GetNewSkillPointText = function(point)
    return X2Locale:LocalizeUiText(SKILL_TEXT, "new_skill_point", tostring(point))
  end,
  newAbilityActivatable = X2Locale:LocalizeUiText(SKILL_TEXT, "new_ability_activatable"),
  actability = {
    ableExpertMaxCount = X2Locale:LocalizeUiText(SKILL_TEXT, "ableExpertMaxCount"),
    sampleTip = function(name, count, isMaster)
      if isMaster then
        return X2Locale:LocalizeUiText(SKILL_TEXT, "sample_tip_master", name, tostring(count))
      else
        return X2Locale:LocalizeUiText(SKILL_TEXT, "sample_tip_under_master", name, tostring(count))
      end
    end
  }
}
locale.castingBar = {
  success = X2Locale:LocalizeUiText(CASTING_BAR_TEXT, "success"),
  stop = X2Locale:LocalizeUiText(CASTING_BAR_TEXT, "stop"),
  breath = X2Locale:LocalizeUiText(CASTING_BAR_TEXT, "breath")
}
locale.store = {
  item = X2Locale:LocalizeUiText(STORE_TEXT, "item"),
  defence = X2Locale:LocalizeUiText(STORE_TEXT, "defence"),
  sellTotalMoney = X2Locale:LocalizeUiText(STORE_TEXT, "sellTotalMoney"),
  buyTotalMoney = X2Locale:LocalizeUiText(COMMON_TEXT, "purchase_cost"),
  shoppingBasket = X2Locale:LocalizeUiText(STORE_TEXT, "shoppingBasket"),
  clearShoppingBasket = X2Locale:LocalizeUiText(STORE_TEXT, "clearShoppingBasket"),
  sell = X2Locale:LocalizeUiText(STORE_TEXT, "sell"),
  sellAll = X2Locale:LocalizeUiText(STORE_TEXT, "sellAll"),
  reBuyList = X2Locale:LocalizeUiText(STORE_TEXT, "reBuyList"),
  preview = X2Locale:LocalizeUiText(STORE_TEXT, "preview"),
  wearItem = X2Locale:LocalizeUiText(STORE_TEXT, "wearItem"),
  noSlot = X2Locale:LocalizeUiText(STORE_TEXT, "noSlot"),
  registedItem = X2Locale:LocalizeUiText(STORE_TEXT, "registedItem"),
  cantSell = X2Locale:LocalizeUiText(STORE_TEXT, "cantSell"),
  cartNoSlot = X2Locale:LocalizeUiText(STORE_TEXT, "cartNoSlot"),
  sellNoSlot = X2Locale:LocalizeUiText(STORE_TEXT, "sellNoSlot"),
  noBuyList = X2Locale:LocalizeUiText(STORE_TEXT, "noBuyList"),
  sellmsg = X2Locale:LocalizeUiText(STORE_TEXT, "sellmsg"),
  sellmsg_stack = function(a, b)
    return string.format("%s %sx%s", X2Locale:LocalizeUiText(STORE_TEXT, "sellmsg"), a, F_TEXT.SetCommaFormat(b))
  end,
  buymsg = X2Locale:LocalizeUiText(STORE_TEXT, "buymsg"),
  disableSell = X2Locale:LocalizeUiText(STORE_TEXT, "disableSell"),
  disableSellInLivingStore = X2Locale:LocalizeUiText(STORE_TEXT, "disableSellInLivingStore"),
  spendCoinMsg = X2Locale:LocalizeUiText(STORE_TEXT, "spend_coin_msg"),
  emptyCartListMsg = X2Locale:LocalizeUiText(ERROR_MSG, "CART_EMPTY"),
  emptySellListMsg = X2Locale:LocalizeUiText(ERROR_MSG, "SELL_CART_EMPTY"),
  buy_left_money = X2Locale:LocalizeUiText(COMMON_TEXT, "balance_after_purchase"),
  sell_left_money = X2Locale:LocalizeUiText(STORE_TEXT, "sell_left_money"),
  drain_tip = X2Locale:LocalizeUiText(STORE_TEXT, "drain_tip"),
  blockItemSell = function(a)
    return X2Locale:LocalizeUiText(ERROR_MSG, "BLOCK_ITEM_SELL", a)
  end,
  buyFailedMerchantGoodLimitPurchase = function(a, b, period)
    if period == MPT_DALIY then
      return X2Locale:LocalizeUiText(COMMON_TEXT, "buy_failed_merchant_good_limit_purchase_daliy", a, b)
    elseif period == MPT_WEEKLY then
      return X2Locale:LocalizeUiText(COMMON_TEXT, "buy_failed_merchant_good_limit_purchase_weekly", a, b)
    elseif period == MPT_MONTHLY then
      return X2Locale:LocalizeUiText(COMMON_TEXT, "buy_failed_merchant_good_limit_purchase_monthly", a, b)
    end
    return ""
  end,
  cartList = function(a, b)
    return X2Locale:LocalizeUiText(COMMON_TEXT, "cart_list", tostring(a), tostring(b))
  end,
  reaminBuyCount = function(a, b)
    return X2Locale:LocalizeUiText(STORE_TEXT, "remain_buy_count", tostring(a), tostring(b))
  end
}
locale.store_specialty = {
  prices = X2Locale:LocalizeUiText(STORE_TEXT, "prices")
}
locale.portal = {
  title = X2Locale:LocalizeUiText(PORTAL_TEXT, "portal_list"),
  returnPlace = X2Locale:LocalizeUiText(PORTAL_TEXT, "return_place"),
  cantRemovePlace = X2Locale:LocalizeUiText(PORTAL_TEXT, "cant_remove_place"),
  invalidZoneMsg = X2Locale:LocalizeUiText(PORTAL_TEXT, "invalidZoneMsg"),
  memo = X2Locale:LocalizeUiText(PORTAL_TEXT, "title"),
  save = X2Locale:LocalizeUiText(PORTAL_TEXT, "save"),
  itemDescUnused = X2Locale:LocalizeUiText(PORTAL_TEXT, "itemDescUnused"),
  itemDescUsed = X2Locale:LocalizeUiText(PORTAL_TEXT, "itemDescUsed"),
  titleNaviDoodad = X2Locale:LocalizeUiText(PORTAL_TEXT, "titleNaviDoodad"),
  naming = X2Locale:LocalizeUiText(PORTAL_TEXT, "naming"),
  delete_portal = X2Locale:LocalizeUiText(PORTAL_TEXT, "delete_portal"),
  location_name = X2Locale:LocalizeUiText(PORTAL_TEXT, "register_name"),
  zone_name = X2Locale:LocalizeUiText(PORTAL_TEXT, "zone_name"),
  world_name = X2Locale:LocalizeUiText(PORTAL_TEXT, "world_name"),
  map_location = X2Locale:LocalizeUiText(PORTAL_TEXT, "map_location"),
  showMap = X2Locale:LocalizeUiText(PORTAL_TEXT, "show_map"),
  ask_delete = function(a)
    return X2Locale:LocalizeUiText(MSG_BOX_BODY_TEXT, "ask_delete_portal", a)
  end,
  menu = {
    X2Locale:LocalizeUiText(PORTAL_TEXT, "menu1"),
    X2Locale:LocalizeUiText(PORTAL_TEXT, "menu2"),
    X2Locale:LocalizeUiText(COMMON_TEXT, "favorite"),
    X2Locale:LocalizeUiText(COMMON_TEXT, "portal_indun")
  },
  indun_name = X2Locale:LocalizeUiText(COMMON_TEXT, "portal_indun_name"),
  enter_condition = X2Locale:LocalizeUiText(COMMON_TEXT, "portal_indun_entrance_condition"),
  player_count = X2Locale:LocalizeUiText(COMMON_TEXT, "portal_indun_player_count"),
  daily_use = X2Locale:LocalizeUiText(COMMON_TEXT, "portal_indun_daily_use"),
  location = X2Locale:LocalizeUiText(COMMON_TEXT, "portal_indun_location")
}
locale.stabler = {
  title = X2Locale:LocalizeUiText(STABLER_TEXT, "title"),
  needPet = X2Locale:LocalizeUiText(STABLER_TEXT, "needPet"),
  cost = X2Locale:LocalizeUiText(STABLER_TEXT, "cost")
}
locale.housing = {
  materialWindow = {
    shipyard = X2Locale:LocalizeUiText(HOUSING_TEXT, "material_shipyard")
  },
  payState = {
    unpaid = X2Locale:LocalizeUiText(HOUSING_TEXT, "pay_state_unpaid"),
    full = X2Locale:LocalizeUiText(HOUSING_TEXT, "pay_state_full"),
    overdue = X2Locale:LocalizeUiText(HOUSING_TEXT, "pay_state_overdue")
  },
  checkPayment = X2Locale:LocalizeUiText(HOUSING_TEXT, "check_payment"),
  untilTerm = X2Locale:LocalizeUiText(HOUSING_TEXT, "until_term"),
  constructionWindow = {
    progressStep = X2Locale:LocalizeUiText(HOUSING_TEXT, "progress_step")
  },
  buildWindow = {
    title = X2Locale:LocalizeUiText(HOUSING_TEXT, "build_title"),
    buildInfo = X2Locale:LocalizeUiText(HOUSING_TEXT, "build_buildInfo"),
    heavyTax = X2Locale:LocalizeUiText(HOUSING_TEXT, "build_heavyTax"),
    heavyTaxDesc = X2Locale:LocalizeUiText(HOUSING_TEXT, "build_heavyTaxDesc"),
    materialLabel = X2Locale:LocalizeUiText(HOUSING_TEXT, "build_materialLabel"),
    taxPaymentDesc = X2Locale:LocalizeUiText(HOUSING_TEXT, "build_taxPaymentDesc")
  },
  faction = X2Locale:LocalizeUiText(HOUSING_TEXT, "faction"),
  paymentTax = X2Locale:LocalizeUiText(HOUSING_TEXT, "payment_tax"),
  dueDateForPayment = X2Locale:LocalizeUiText(HOUSING_TEXT, "due_date"),
  demolishDate = X2Locale:LocalizeUiText(HOUSING_TEXT, "demolish_date"),
  left = X2Locale:LocalizeUiText(HOUSING_TEXT, "left"),
  tax_warning = X2Locale:LocalizeUiText(HOUSING_TEXT, "tax_warning"),
  taxExemptionWarning = X2Locale:LocalizeUiText(HOUSING_TEXT, "tax_exemption_warning"),
  consumeLabor = function(a)
    return X2Locale:LocalizeUiText(HOUSING_TEXT, "consume_labor", F_TEXT.IStr(a))
  end,
  incompleted_warning = X2Locale:LocalizeUiText(HOUSING_TEXT, "incompleted_warning"),
  maintainWindow = {
    heavyTaxExemption = X2Locale:LocalizeUiText(HOUSING_TEXT, "maintain_heavy_tax_exemption")
  },
  permissions = {
    {
      text = X2Locale:LocalizeUiText(HOUSING_PERMISSIONS_TEXT, "house_permissions_0"),
      value = HOUSE_ALLOW_OWNER,
      tooltip = X2Locale:LocalizeUiText(HOUSING_TEXT, "closed_condition_tip")
    },
    {
      text = X2Locale:LocalizeUiText(COMMON_TEXT, "family"),
      value = HOUSE_ALLOW_FAMILY
    },
    {
      text = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "expedition"),
      value = HOUSE_ALLOW_EXPEDITION
    },
    {
      text = X2Locale:LocalizeUiText(HOUSING_PERMISSIONS_TEXT, "house_permissions_4"),
      value = HOUSE_ALLOW_FAMILY_AND_EXPEDITION
    },
    {
      text = X2Locale:LocalizeUiText(HOUSING_PERMISSIONS_TEXT, "house_permissions_5"),
      value = HOUSE_ALLOW_ALLIANCE
    },
    {
      text = X2Locale:LocalizeUiText(HOUSING_PERMISSIONS_TEXT, "house_permissions_2"),
      value = HOUSE_ALLOW_ALL
    }
  },
  demolish = {
    title = X2Locale:LocalizeUiText(HOUSING_TEXT, "demolish_title")
  },
  informationWindow = {
    owner = X2Locale:LocalizeUiText(HOUSING_TEXT, "owner"),
    invicibleDuration = X2Locale:LocalizeUiText(HOUSING_TEXT, "invicibleDuration"),
    demolishDuration = X2Locale:LocalizeUiText(HOUSING_TEXT, "demolishDuration"),
    demolishDurationTooltip = X2Locale:LocalizeUiText(HOUSING_TEXT, "demolish_duration_tooltip")
  },
  msg_house_change_name = X2Locale:LocalizeUiText(HOUSING_TEXT, "msg_house_change_name")
}
locale.territory = {
  peaceMoney = X2Locale:LocalizeUiText(TERRITORY_TEXT, "peace_money"),
  taxRate = X2Locale:LocalizeUiText(TERRITORY_TEXT, "tax_rate"),
  taxItemTip = function(color, itemName)
    return X2Locale:LocalizeUiText(COMMON_TEXT, "guide_icon_tooltip_tax_item", color, itemName)
  end
}
locale.craft = {
  highRankItem = X2Locale:LocalizeUiText(CRAFT_TEXT, "high_rank_item"),
  craftItem = X2Locale:LocalizeUiText(CRAFT_TEXT, "craft_item"),
  requireMastery = X2Locale:LocalizeUiText(CRAFT_TEXT, "require_mastery"),
  showAll = X2Locale:LocalizeUiText(CRAFT_TEXT, "show_all"),
  cancel = X2Locale:LocalizeUiText(QUEST_INTERACTION_TEXT, "craft_cancel"),
  craftBook = X2Locale:LocalizeUiText(WINDOW_TITLE_TEXT, "craft_book"),
  allMake = X2Locale:LocalizeUiText(CRAFT_TEXT, "allMake"),
  craftInfo = X2Locale:LocalizeUiText(CRAFT_TEXT, "craftInfo"),
  itemList = X2Locale:LocalizeUiText(CRAFT_TEXT, "itemList"),
  defaultLaborPowerUsed = X2Locale:LocalizeUiText(CRAFT_TEXT, "defaultLaborPowerUsed"),
  craftSuccessRate = X2Locale:LocalizeUiText(CRAFT_TEXT, "craftSuccessRate"),
  recommendLevel = X2Locale:LocalizeUiText(CRAFT_TEXT, "recommendLevel")
}
locale.skillTrainingMsg = {
  skill_init_msg_4 = function(point)
    return X2Locale:LocalizeUiText(SKILL_TRAINING_MSG_TEXT, "skill_init_msg_4", tostring(point))
  end,
  consume_heir_points = function(point)
    return X2Locale:LocalizeUiText(SKILL_TRAINING_MSG_TEXT, "consume_heir_points", tostring(point))
  end
}
locale.combat = {
  critical = X2Locale:LocalizeUiText(COMBAT_TEXT, "critical"),
  miss = X2Locale:LocalizeUiText(COMBAT_TEXT, "miss"),
  dodge = X2Locale:LocalizeUiText(COMBAT_TEXT, "dodge"),
  block = X2Locale:LocalizeUiText(COMBAT_TEXT, "block"),
  parry = X2Locale:LocalizeUiText(COMBAT_TEXT, "parry"),
  immune = X2Locale:LocalizeUiText(COMBAT_TEXT, "immune"),
  resist = X2Locale:LocalizeUiText(COMBAT_TEXT, "resist"),
  spell_aura_removed = X2Locale:LocalizeUiText(COMBAT_TEXT, "spell_aura_removed"),
  combat_text_synergy = X2Locale:LocalizeUiText(COMBAT_TEXT, "combat_text_synergy"),
  combat_text_synergy_damage = X2Locale:LocalizeUiText(COMBAT_TEXT, "combat_text_synergy_damage"),
  player_enter_combat = X2Locale:LocalizeUiText(COMBAT_TEXT, "player_enter_combat"),
  player_leave_combat = X2Locale:LocalizeUiText(COMBAT_TEXT, "player_leave_combat")
}
locale.physicalEnchant = {
  broadcast_success_alarm = function(a, b, c)
    return X2Locale:LocalizeUiText(PHYSICAL_ENCHANT_TEXT, "broadcast_success_alarm", a, b, c)
  end,
  broadcast_great_success_alarm = function(a, b, c)
    return X2Locale:LocalizeUiText(PHYSICAL_ENCHANT_TEXT, "broadcast_great_success_alarm", a, b, c)
  end,
  broadcast_scale_success_alarm = function(a, b, c)
    return X2Locale:LocalizeUiText(PHYSICAL_ENCHANT_TEXT, "broadcast_enchant_scale_success", a, b, c)
  end,
  broadcast_scale_great_success_alarm = function(a, b, c)
    return X2Locale:LocalizeUiText(PHYSICAL_ENCHANT_TEXT, "broadcast_enchant_scale_great_success", a, b, c)
  end,
  broadcast_evolving_alarm = function(a, b, c, d, e)
    return string.format("%s.", X2Locale:LocalizeUiText(PHYSICAL_ENCHANT_TEXT, "broadcast_evolving_alarm", a, b, c, d, e))
  end
}
locale.faction = {
  name = X2Locale:LocalizeUiText(FACTION_TEXT, "name"),
  master = X2Locale:LocalizeUiText(FACTION_TEXT, "master"),
  my_influence = X2Locale:LocalizeUiText(FACTION_TEXT, "my_influence"),
  detail = X2Locale:LocalizeUiText(FACTION_TEXT, "detail"),
  show_detail = X2Locale:LocalizeUiText(FACTION_TEXT, "show_detail"),
  friendship = X2Locale:LocalizeUiText(FACTION_TEXT, "friendship"),
  my_post = X2Locale:LocalizeUiText(FACTION_TEXT, "my_post"),
  personnel = X2Locale:LocalizeUiText(FACTION_TEXT, "personnel"),
  level = X2Locale:LocalizeUiText(FACTION_TEXT, "level"),
  area = X2Locale:LocalizeUiText(FACTION_TEXT, "area"),
  viscount = X2Locale:LocalizeUiText(FACTION_TEXT, "viscount"),
  relation_proposed_war = function(proposer, subject)
    return X2Locale:LocalizeUiText(FACTION_TEXT, "relation_proposed_war", proposer, subject)
  end,
  relation_proposed_peace = function(proposer, subject)
    return X2Locale:LocalizeUiText(FACTION_TEXT, "relation_proposed_peace", proposer, subject)
  end,
  relation_accepted_war = function(proposer, subject)
    return X2Locale:LocalizeUiText(FACTION_TEXT, "relation_accepted_war", proposer, subject)
  end,
  relation_accepted_peace = function(proposer, subject)
    return X2Locale:LocalizeUiText(FACTION_TEXT, "relation_accepted_peace", proposer, subject)
  end,
  relation_declined_war = function(proposer, subject)
    return X2Locale:LocalizeUiText(FACTION_TEXT, "relation_declined_war", proposer, subject)
  end,
  relation_declined_peace = function(proposer, subject)
    return X2Locale:LocalizeUiText(FACTION_TEXT, "relation_declined_peace", proposer, subject)
  end,
  relation_cancelled_war = function(proposer, subject)
    return X2Locale:LocalizeUiText(FACTION_TEXT, "relation_cancelled_war", proposer, subject)
  end,
  relation_cancelled_peace = function(proposer, subject)
    return X2Locale:LocalizeUiText(FACTION_TEXT, "relation_cancelled_peace", proposer, subject)
  end,
  relation_expired_war = function(proposer, subject)
    return X2Locale:LocalizeUiText(FACTION_TEXT, "relation_expired_war", proposer, subject)
  end,
  relation_expired_peace = function(proposer, subject)
    return X2Locale:LocalizeUiText(FACTION_TEXT, "relation_expired_peace", proposer, subject)
  end,
  GetAmount = function(a)
    return X2Locale:LocalizeUiText(COMMON_TEXT, "amount", F_TEXT.IStr(a))
  end
}
locale.community = {
  race = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "race"),
  friend = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "friend"),
  family = X2Locale:LocalizeUiText(COMMON_TEXT, "family"),
  town = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "town"),
  relationship = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "relationship"),
  expedition = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "expedition"),
  faction = X2Locale:LocalizeUiText(COMMON_TEXT, "faction"),
  id = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "id"),
  position = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "position"),
  job = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "job"),
  guild_name = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "guild_name"),
  post = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "post"),
  invite = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "invite"),
  couple_invite = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "couple_invite"),
  child_invite = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "child_invite"),
  leave = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "leave"),
  kick = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "kick"),
  dismission = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "dismission"),
  divorce = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "divorce"),
  upgrade = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "upgrade"),
  degrade = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "degrade"),
  grade_owner = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "grade_owner"),
  grade_officer = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "grade_officer"),
  grade_assistant = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "grade_assistant"),
  grade_normal = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "grade_normal"),
  family_noname = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "family_noname"),
  unblock = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "unblock")
}
locale.relationship = {
  tabText = {
    X2Locale:LocalizeUiText(COMMUNITY_TEXT, "tab_first_text"),
    X2Locale:LocalizeUiText(COMMON_TEXT, "tab_waiting_friend"),
    X2Locale:LocalizeUiText(COMMUNITY_TEXT, "tab_second_text")
  },
  onlineMember = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "online_member"),
  blockMember = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "block_member"),
  GetOnlineAcquaintanceText = function(a)
    return X2Locale:LocalizeUiText(COMMUNITY_TEXT, "online_acquaintance", a)
  end
}
locale.family = {
  title_syntax = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "title_syntax"),
  member_added = function(owner, member, role)
    return X2Locale:LocalizeUiText(COMMUNITY_TEXT, "member_added", owner, member, role)
  end,
  member_left = function(member)
    return X2Locale:LocalizeUiText(COMMUNITY_TEXT, "member_left", member)
  end,
  member_kicked = function(member)
    return X2Locale:LocalizeUiText(COMMUNITY_TEXT, "member_kicked", member)
  end,
  member_desc = function(owner, member, role)
    return X2Locale:LocalizeUiText(COMMUNITY_TEXT, "member_desc", owner, member, role)
  end,
  owner_desc = function(owner)
    return X2Locale:LocalizeUiText(COMMUNITY_TEXT, "owner_desc", owner)
  end,
  owner_changed = function(owner)
    return X2Locale:LocalizeUiText(COMMUNITY_TEXT, "owner_changed", owner)
  end,
  name = X2Locale:LocalizeUiText(FACTION_TEXT, "name"),
  title = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "title"),
  add_family = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "ask_family_invite"),
  family_leader = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "family_leader"),
  owner_title = function(owner, title)
    return X2Locale:LocalizeUiText(COMMUNITY_TEXT, "owner_title", owner, title)
  end,
  kick_member = X2Locale:LocalizeUiText(COMMON_TEXT, "family_kick"),
  change_owner = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "change_family_leader"),
  removed = X2Locale:LocalizeUiText(ERROR_MSG, "FAMILY_REMOVED"),
  tooltip_text = function(owner, title)
    return X2Locale:LocalizeUiText(COMMUNITY_TEXT, "community_desc", owner, title)
  end,
  onlineMember = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "online_family"),
  changeTitle = X2Locale:LocalizeUiText(COMMON_TEXT, "change_name_family_title"),
  leave_family = X2Locale:LocalizeUiText(COMMON_TEXT, "family_leave")
}
locale.friend = {
  title = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "title"),
  addFriend = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "add_friend"),
  showOffMember = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "show_off_member"),
  playJournal = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "play_journal"),
  deleteFriend = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "delete_friend")
}
locale.block = {
  add = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "add_ignore"),
  block = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "block")
}
locale.expedition = {
  creationFailTitle = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "creation_fail_title"),
  creationFailMsg = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "creation_fail_msg"),
  onlineMember = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "online_member"),
  partyPlay = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "party_play"),
  viewOffMember = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "view_off_member"),
  inviteRaid = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "ask_raidteam_invite"),
  inviteParty = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "ask_party_invite"),
  invite = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "ask_expedition_invite"),
  changeName = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "change_name"),
  changeRole = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "change_role"),
  delegate = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "delegate"),
  inviteMember = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "invite_member"),
  expel = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "expel"),
  promote = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "promote"),
  dismiss = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "dismiss"),
  managerGF = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "managerGF"),
  gfBankView = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "gfBankView"),
  gfBankDeposit = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "gfBankDeposit"),
  gfBankFetch = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "gfBankFetch"),
  managerContribution = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "managerContribution"),
  leave = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "ask_leave_expedition"),
  apply = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "policy_apply"),
  useInstance = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "use_instance"),
  before_year = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "before_year"),
  before_month = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "before_month"),
  before_day = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "before_day"),
  before_hour = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "before_hour"),
  before_min = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "before_min"),
  less_min = X2Locale:LocalizeUiText(EXPEDITION_TEXT, "less_min"),
  role_name = {
    X2Locale:LocalizeUiText(EXPEDITION_TEXT, "role_name_0"),
    X2Locale:LocalizeUiText(EXPEDITION_TEXT, "role_name_1"),
    X2Locale:LocalizeUiText(EXPEDITION_TEXT, "role_name_2"),
    X2Locale:LocalizeUiText(EXPEDITION_TEXT, "role_name_3"),
    X2Locale:LocalizeUiText(EXPEDITION_TEXT, "role_name_255")
  }
}
locale.grammar = {
  textAnd = X2Locale:LocalizeUiText(UTIL_TEXT, "grammar_text_and")
}
locale.continent = {
  west = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "west"),
  east = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "east"),
  origin = X2Locale:LocalizeUiText(COMMUNITY_TEXT, "origin")
}
locale.changeName = {
  korean = X2Locale:LocalizeUiText(COMMON_TEXT, "korean"),
  english = X2Locale:LocalizeUiText(COMMON_TEXT, "english"),
  limit_alphabet = function(a, b)
    return X2Locale:LocalizeUiText(COMMON_TEXT, "limit_alphabet", a, b)
  end,
  limit_multi_lang_alphabet = function(a, b, c, d, e, f)
    return X2Locale:LocalizeUiText(COMMON_TEXT, "limit_multi_lang_alphabet", a, b, c, d, e, f)
  end,
  allow_mixcase = X2Locale:LocalizeUiText(COMMON_TEXT, "allow_mixcase"),
  allow_space = X2Locale:LocalizeUiText(COMMON_TEXT, "allow_space"),
  allow_space_limit = function(a)
    return X2Locale:LocalizeUiText(COMMON_TEXT, "allow_space_limit", a)
  end,
  allow_special_character = X2Locale:LocalizeUiText(COMMON_TEXT, "allow_special_character")
}
locale.web = {
  cast_title = X2Locale:LocalizeUiText(WEB_TEXT, "cast_title"),
  cast_transfer_doing = X2Locale:LocalizeUiText(WEB_TEXT, "cast_transfer_doing"),
  cast_transfer_succeeded = X2Locale:LocalizeUiText(WEB_TEXT, "cast_transfer_succeeded"),
  cast_transfer_failed = X2Locale:LocalizeUiText(WEB_TEXT, "cast_transfer_failed"),
  diary_transfer_doing = X2Locale:LocalizeUiText(WEB_TEXT, "diary_transfer_doing"),
  diary_transfer_succeeded = X2Locale:LocalizeUiText(WEB_TEXT, "diary_transfer_succeeded"),
  diary_transfer_failed = X2Locale:LocalizeUiText(WEB_TEXT, "diary_transfer_failed")
}
locale.icon_shape_button_tooltip = {
  portal_delete = X2Locale:LocalizeUiText(PORTAL_TEXT, "portal_delete"),
  portal_spawn = X2Locale:LocalizeUiText(PORTAL_TEXT, "spawn_Portal"),
  inviteRaid = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "ask_raidteam_invite"),
  raid_option = X2Locale:LocalizeUiText(RAID_TEXT, "raid_option"),
  changeToRaid = X2Locale:LocalizeUiText(RAID_TEXT, "convert_raid"),
  range_invite = X2Locale:LocalizeUiText(RAID_TEXT, "area_invite")
}
locale.trial = {
  wait_jury_tip = function(a)
    return X2Locale:LocalizeUiText(TRIAL_TEXT, "wait_jury_tip", tostring(a))
  end,
  count = X2Locale:LocalizeUiText(TRIAL_TEXT, "crime_count"),
  crimeRecordTitle = X2Locale:LocalizeUiText(TRIAL_TEXT, "crime_record_title"),
  crimeRecordOk = X2Locale:LocalizeUiText(TRIAL_TEXT, "crime_record_ok"),
  crimeRecordType = X2Locale:LocalizeUiText(TRIAL_TEXT, "crime_record_type"),
  crimeRecordVictim = X2Locale:LocalizeUiText(TRIAL_TEXT, "crime_record_victim"),
  crimeRecordMemo = X2Locale:LocalizeUiText(TRIAL_TEXT, "crime_record_memo"),
  crimeRecordReportedBy = X2Locale:LocalizeUiText(TRIAL_TEXT, "crime_record_reported_by"),
  crimeReportByDoodad = function(doodad)
    return X2Locale:LocalizeUiText(TRIAL_TEXT, "crime_reported_by_doodad", doodad)
  end,
  crimeReport = X2Locale:LocalizeUiText(TRIAL_TEXT, "crime_report"),
  crimeRecordGuideText = X2Locale:LocalizeUiText(TRIAL_TEXT, "crime_record_guide_text"),
  crimeTypeAssault = X2Locale:LocalizeUiText(TRIAL_TEXT, "crime_type_assault"),
  crimeTypeMurder = X2Locale:LocalizeUiText(TRIAL_TEXT, "crime_type_murder"),
  crimeTypeTheft = X2Locale:LocalizeUiText(TRIAL_TEXT, "crime_type_theft"),
  crimeTypeEtc = X2Locale:LocalizeUiText(TRIAL_TEXT, "crime_type_etc"),
  waitTrialTitle = X2Locale:LocalizeUiText(TRIAL_TEXT, "wait_trial_title"),
  waitJury = function(waitTime, count, total)
    return X2Locale:LocalizeUiText(TRIAL_TEXT, "wait_jury", F_COLOR.GetColor("red", true), tostring(waitTime), F_COLOR.GetColor("black", true), tostring(count), tostring(total))
  end,
  waitTrial = function(waitTime, order)
    return X2Locale:LocalizeUiText(TRIAL_TEXT, "wait_trial", F_COLOR.GetColor("red", true), tostring(waitTime), F_COLOR.GetColor("black", true), tostring(order))
  end,
  waitCancelTrial = X2Locale:LocalizeUiText(TRIAL_TEXT, "wait_cancel_trial"),
  verdictTitle = X2Locale:LocalizeUiText(TRIAL_TEXT, "verdict_title"),
  verdictGuilyTitle = X2Locale:LocalizeUiText(COMMON_TEXT, "verdict_guily_title"),
  verdictNotGuilty = X2Locale:LocalizeUiText(TRIAL_TEXT, "verdict_not_guilty"),
  verdictGuilty = function(minutes)
    return X2Locale:LocalizeUiText(TRIAL_TEXT, "verdict_guilty", tostring(minutes))
  end,
  verdictWarning = X2Locale:LocalizeUiText(TRIAL_TEXT, "verdict_warning"),
  theft_tip = function(skill_name, name)
    return X2Locale:LocalizeUiText(TRIAL_TEXT, "theft_tip", tostring(skill_name), tostring(name))
  end,
  rulingTitle = X2Locale:LocalizeUiText(TRIAL_TEXT, "ruling_title"),
  rulingInProgress = X2Locale:LocalizeUiText(TRIAL_TEXT, "ruling_in_progress"),
  rulingResult = X2Locale:LocalizeUiText(TRIAL_TEXT, "ruling_result"),
  rulingStatus = function(count, total)
    return X2Locale:LocalizeUiText(TRIAL_TEXT, "ruling_status", tostring(count), tostring(total))
  end,
  rulingResultNotGuilty = X2Locale:LocalizeUiText(TRIAL_TEXT, "ruling_result_not_guilty"),
  audienceJoined = function(name)
    return X2Locale:LocalizeUiText(TRIAL_TEXT, "audience_joined", name)
  end,
  audienceLeft = function(name)
    return X2Locale:LocalizeUiText(TRIAL_TEXT, "audience_left", name)
  end,
  crimePointStr = X2Locale:LocalizeUiText(TRIAL_TEXT, "crime_point_str"),
  arrestHistory = X2Locale:LocalizeUiText(TRIAL_TEXT, "arrest_history"),
  trialChoice = function(acceptTrial, acceptGuilty)
    return X2Locale:LocalizeUiText(TRIAL_TEXT, "trial_choice", acceptTrial, acceptGuilty)
  end,
  rulingHistory = X2Locale:LocalizeUiText(TRIAL_TEXT, "ruling_history"),
  rulingChoice = function(guilty, notGuilty)
    return X2Locale:LocalizeUiText(TRIAL_TEXT, "ruling_choice", guilty, notGuilty)
  end,
  jailTotal = X2Locale:LocalizeUiText(TRIAL_TEXT, "jail_total"),
  jailMinutes = function(minutes)
    return X2Locale:LocalizeUiText(TRIAL_TEXT, "jail_minutes", minutes)
  end,
  totalRecords = X2Locale:LocalizeUiText(TRIAL_TEXT, "total_records"),
  stateMessage = {
    function(maxWaitTime)
      return X2Locale:LocalizeUiText(TRIAL_TEXT, "state_message_1")
    end,
    function(maxWaitTime)
      return X2Locale:LocalizeUiText(TRIAL_TEXT, "state_message_2")
    end,
    function(maxWaitTime)
      return X2Locale:LocalizeUiText(TRIAL_TEXT, "state_message_3", maxWaitTime)
    end,
    function(maxWaitTime)
      return X2Locale:LocalizeUiText(TRIAL_TEXT, "state_message_4", maxWaitTime)
    end,
    function(maxWaitTime)
      return X2Locale:LocalizeUiText(TRIAL_TEXT, "state_message_5", maxWaitTime)
    end,
    function(maxWaitTime)
      return X2Locale:LocalizeUiText(TRIAL_TEXT, "state_message_6", maxWaitTime)
    end,
    function(maxWaitTime)
      return X2Locale:LocalizeUiText(TRIAL_TEXT, "state_message_7")
    end,
    function(maxWaitTime)
      return X2Locale:LocalizeUiText(TRIAL_TEXT, "state_message_8")
    end,
    function(maxWaitTime)
      return X2Locale:LocalizeUiText(TRIAL_TEXT, "state_message_9")
    end
  },
  remainTime = function(str)
    return X2Locale:LocalizeUiText(TRIAL_TEXT, "remain_time", str)
  end,
  remainCount = function(num1, num2)
    return X2Locale:LocalizeUiText(TRIAL_TEXT, "remain_count", num1, num2)
  end,
  canceled = X2Locale:LocalizeUiText(TRIAL_TEXT, "canceled"),
  botSuspectReported = function(source, target)
    return X2Locale:LocalizeUiText(TRIAL_TEXT, "bot_reported", source, target)
  end,
  reportTitle = X2Locale:LocalizeUiText(TRIAL_TEXT, "report_title"),
  reportTime = X2Locale:LocalizeUiText(TRIAL_TEXT, "report_time")
}
locale.honorPointWar = {
  changeState = function(name, state)
    return X2Locale:LocalizeUiText(HONOR_POINT_WAR_TEXT, "change_state", name, state)
  end,
  endWar = function(name)
    return X2Locale:LocalizeUiText(HONOR_POINT_WAR_TEXT, "end_war", name)
  end,
  leaveWarArea = function(state)
    return X2Locale:LocalizeUiText(HONOR_POINT_WAR_TEXT, "leave_war_area", state)
  end,
  enterWarArea = function(state)
    return X2Locale:LocalizeUiText(HONOR_POINT_WAR_TEXT, "enter_war_area", state)
  end,
  getHonorPoint = function(point)
    return X2Locale:LocalizeUiText(HONOR_POINT_WAR_TEXT, "get_honor_point", point)
  end,
  loseHonorPoint = function(point)
    return X2Locale:LocalizeUiText(HONOR_POINT_WAR_TEXT, "lose_honor_point", point)
  end,
  appliedDebuff = X2Locale:LocalizeUiText(HONOR_POINT_WAR_TEXT, "applied_debuff"),
  removedDebuff = X2Locale:LocalizeUiText(HONOR_POINT_WAR_TEXT, "removed_debuff"),
  stateTooltip = X2Locale:LocalizeUiText(HONOR_POINT_WAR_TEXT, "state_tooltip"),
  statePeaceTooltip = X2Locale:LocalizeUiText(HONOR_POINT_WAR_TEXT, "state_peace_tooltip")
}
locale.inGameShop = {
  putToCart = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "putToCart"),
  needFriendName = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "needFriendName"),
  price = X2Locale:LocalizeUiText(COMMON_TEXT, "price"),
  remain = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "remain"),
  startDate = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "startDate"),
  endDate = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "endDate"),
  chargeAAPoint = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "chargeAAPoint"),
  unknownName = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "unknownName"),
  GetRequiredQuest = function(questName)
    return X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "getRequiredQuest", questName)
  end,
  cart = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "cart"),
  deleteTitle = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "deleteTitle"),
  nameTitle = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "nameTitle"),
  cantPresent = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "cantPresent"),
  package = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "package"),
  resultTitle = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "resultTitle"),
  successPresent = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "successPresent"),
  failPresent = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "failPresent"),
  successBuy = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "successBuy"),
  failBuy = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "failBuy"),
  resultPutToCart = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "resultPutToCart"),
  putToCartFullError = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "putToCartFullError"),
  putToCartNormalError = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "putToCartNormalError"),
  cashError = X2Locale:LocalizeUiText(ERROR_MSG, "INGAME_SHOP_NOT_ENOUGH_AA_CASH"),
  friendNameError = X2Locale:LocalizeUiText(ERROR_MSG, "INGAME_SHOP_FIND_CHARACTER_NAME_FAIL"),
  soldOutError = X2Locale:LocalizeUiText(ERROR_MSG, "INGAME_SHOP_SOLD_OUT"),
  expiredDateError2 = X2Locale:LocalizeUiText(ERROR_MSG, "INGAME_SHOP_EXPIRED_SELL_BY_DATE"),
  normalError = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "normalError"),
  countPerAccoutError = X2Locale:LocalizeUiText(ERROR_MSG, "INGAME_SHOP_BUY_NO_DUPLICATE_ITEM"),
  sameAccountError = X2Locale:LocalizeUiText(ERROR_MSG, "INGAME_SHOP_FIND_CHARACTER_SAME_ACCOUNT"),
  limitedTotalPriceError = X2Locale:LocalizeUiText(ERROR_MSG, "INGAME_SHOP_LIMITED_BUY_FOR_TOTAL_PRICE"),
  bmMileageError = X2Locale:LocalizeUiText(ERROR_MSG, "INGAME_SHOP_NOT_ENOUGH_BM_MILEAGE"),
  invalidAccountError = X2Locale:LocalizeUiText(ERROR_MSG, "INGAME_SHOP_BUY_FAIL_INVALID_ACCOUNT"),
  deletedCharacterError = X2Locale:LocalizeUiText(ERROR_MSG, "INGAME_SHOP_CHRACTER_DELETE_REQUESTED"),
  transferCharacterError = X2Locale:LocalizeUiText(ERROR_MSG, "INGAME_SHOP_CHRACTER_TRANSFER_REQUESTED"),
  useAACoinForGiftError = X2Locale:LocalizeUiText(ERROR_MSG, "INGAME_SHOP_CANNOT_USE_AACOIN_FOR_GIFT"),
  goldError = X2Locale:LocalizeUiText(ERROR_MSG, "INGAME_SHOP_NOT_ENOUGH_GOLD"),
  noticePresentGood = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "noticePresentGood"),
  noticeBuyGood = function(receiveWay)
    return X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "noticeBuyGood", receiveWay)
  end,
  eventDateTitle = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "eventDateTitle"),
  alwaysBuy = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "alwaysBuy"),
  GetBuyPerAccount = function(a)
    return X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "buyPerAccount", tostring(a))
  end,
  GetBuyPerCharacter = function(a)
    return X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "buyPerCharacter", tostring(a))
  end,
  GetBuyPerDay = function(a)
    return X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "buyPerDay", tostring(a))
  end,
  bonusNotice = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "bonusNotice"),
  myCash = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "myCash"),
  myAAPoint = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "myAAPoint"),
  GetMainMenuName = function(index)
    return X2Locale:LocalizeUiText(INGAMESHOP_TEXT, string.format("main_menu_%d", index))
  end,
  GetSubMenuName = function(mainIndex, subIndex)
    return X2Locale:LocalizeUiText(INGAMESHOP_TEXT, string.format("sub_menu_%d_%d", mainIndex, subIndex))
  end,
  GetChangeRatioText = function(cashText, pointText)
    return X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "getChangeRatioText", cashText, pointText)
  end,
  nowCheckTime = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "nowCheckTime"),
  nowCheckTimeTitle = X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_message"),
  enterBeautyShop = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "enterBeautyShop"),
  genderTransfer = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "genderTransfer"),
  cartButtonTooltip = X2Locale:LocalizeUiText(INGAMESHOP_TEXT, "cartButtonTooltip")
}
locale.battlefield = {
  immediatelyExit = X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "immediately_exit"),
  cancelEntrance = X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "cancel_entrance"),
  waiting = X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "waiting"),
  readyTime = function(mm, ss)
    return string.format(X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "ready_time"), mm, ss)
  end,
  playTime = X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "play_time"),
  playTimeDetail = function(a, b)
    return X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "play_time_detail", tostring(a), tostring(b))
  end,
  shop = X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "battle_field_shop"),
  winCondition = {
    title = X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "win_codition_title"),
    scoreAttainment = function(a)
      return X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "codition_score_attainment", tostring(a))
    end,
    killCountAttainment = function(a)
      return X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "condition_score_attainment", tostring(a))
    end,
    roundWinCountAttainment = function(a)
      return X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "condition_round_win_count_attainment", tostring(a))
    end,
    targetDestruction = X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "condition_target_destruction"),
    timeoverScopeRank = function(a)
      return X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "condition_timeover_score_rank", tostring(a))
    end,
    scoreSuperiority = X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "condition_score_superiority"),
    tip = X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "condition_tip")
  },
  alarmEndReason = {
    timeover = X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "end_time_over"),
    killCount = function(a, b)
      return X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "end_kill_enemy", tostring(a), tostring(b))
    end,
    roundWinCount = function(a, b)
      return X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "end_round_win_count", tostring(a), tostring(b))
    end,
    killCorpsHead = function(a)
      return X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "end_destroy_target", tostring(a))
    end
  },
  scoreboardEndReason = {
    X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "scoreboard_end_reason_time_over"),
    function(a, b)
      return X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "scoreboard_end_reason_kill_enemy", tostring(a), tostring(b))
    end,
    function(a)
      return X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "scoreboard_end_reason_destroy_target", tostring(a))
    end
  },
  scoreboard = {
    kill = X2Locale:LocalizeUiText(INSTANT_GAME_TEXT, "kill"),
    death = X2Locale:LocalizeUiText(INSTANT_GAME_TEXT, "death"),
    score = X2Locale:LocalizeUiText(INSTANT_GAME_TEXT, "score"),
    destruction = X2Locale:LocalizeUiText(INSTANT_GAME_TEXT, "destruction"),
    elimination = X2Locale:LocalizeUiText(INSTANT_GAME_TEXT, "elimination")
  }
}
locale.composition = {
  noteKorean = {
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "syllable_names_c_2"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "syllable_names_d_2"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "syllable_names_e_2"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "syllable_names_f_2"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "syllable_names_g_2"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "syllable_names_a_2"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "syllable_names_b_2")
  },
  noteEnglish = {
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "syllable_names_c_1"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "syllable_names_d_1"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "syllable_names_e_1"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "syllable_names_f_1"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "syllable_names_g_1"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "syllable_names_a_1"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "syllable_names_b_1")
  },
  title = {
    syllableNames = X2Locale:LocalizeUiText(COMPOSITION_TEXT, "title_syllableNames"),
    noteLength = X2Locale:LocalizeUiText(COMPOSITION_TEXT, "title_note_length"),
    restLength = X2Locale:LocalizeUiText(COMPOSITION_TEXT, "title_rest_length"),
    etc = X2Locale:LocalizeUiText(COMPOSITION_TEXT, "title_etc"),
    example = X2Locale:LocalizeUiText(COMPOSITION_TEXT, "title_example")
  },
  inputGuide = {
    syllableNames = X2Locale:LocalizeUiText(COMPOSITION_TEXT, "input_guide_syllable_names"),
    noteLength = X2Locale:LocalizeUiText(COMPOSITION_TEXT, "input_guide_note_length"),
    restLength = X2Locale:LocalizeUiText(COMPOSITION_TEXT, "input_guide_rest_length")
  },
  notes = {
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "whole_note"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "half_note"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "quarter_note"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "eighth_note"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "sixteenth_note"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "thirty_second_note"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "sixty_fourth_note"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "dotted_note")
  },
  values = {
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "one"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "two"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "four"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "eight"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "sixteen"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "thirty_two"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "sixty_four"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "dot")
  },
  rests = {
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "whole_rest"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "half_rest"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "quarter_rest"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "eighth_rest"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "sixteenth_rest"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "thirty_second_rest"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "sixty_fourth_rest"),
    X2Locale:LocalizeUiText(COMPOSITION_TEXT, "dotted_rest")
  },
  syllableNames = X2Locale:LocalizeUiText(COMPOSITION_TEXT, "syllableNames"),
  method = X2Locale:LocalizeUiText(COMPOSITION_TEXT, "method"),
  score = X2Locale:LocalizeUiText(COMPOSITION_TEXT, "score"),
  actability = X2Locale:LocalizeUiText(COMPOSITION_TEXT, "actability"),
  musicSample = X2Locale:LocalizeUiText(COMPOSITION_TEXT, "music_sample"),
  saveMusic = X2Locale:LocalizeUiText(COMPOSITION_TEXT, "save_music"),
  actability_tip = X2Locale:LocalizeUiText(COMPOSITION_TEXT, "actability_tip")
}
locale.customSaveLoad = {
  customSave = X2Locale:LocalizeUiText(COMMON_TEXT, "create_name_custom"),
  customSaveMsg = function(a)
    return X2Locale:LocalizeUiText(CUSTOMIZING_TEXT, "custom_save_msg", a)
  end,
  customLoad = X2Locale:LocalizeUiText(CUSTOMIZING_TEXT, "custom_load"),
  customLoadOk = X2Locale:LocalizeUiText(CUSTOMIZING_TEXT, "custom_load_ok"),
  customLoadOkMsg = function(a)
    return X2Locale:LocalizeUiText(CUSTOMIZING_TEXT, "custom_load_ok_msg", a)
  end,
  customLoadOkContent = X2Locale:LocalizeUiText(CUSTOMIZING_TEXT, "custom_load_ok_content"),
  customOverWrite = X2Locale:LocalizeUiText(CUSTOMIZING_TEXT, "custom_over_write"),
  customOverWriteContent = function(a)
    return X2Locale:LocalizeUiText(CUSTOMIZING_TEXT, "custom_over_write_content", a)
  end,
  customDelete = X2Locale:LocalizeUiText(CUSTOMIZING_TEXT, "custom_delete"),
  customDeleteContent = function(a)
    return X2Locale:LocalizeUiText(CUSTOMIZING_TEXT, "custom_delete_content", a)
  end,
  customDeleteMsg = function(a)
    return X2Locale:LocalizeUiText(CUSTOMIZING_TEXT, "custom_delete_msg", a)
  end,
  customSelectMsg = X2Locale:LocalizeUiText(CUSTOMIZING_TEXT, "custom_select_msg"),
  customNoNameMsg = X2Locale:LocalizeUiText(CUSTOMIZING_TEXT, "custom_no_name_msg"),
  customNoPath = X2Locale:LocalizeUiText(CUSTOMIZING_TEXT, "custom_no_path"),
  customNoFile = X2Locale:LocalizeUiText(CUSTOMIZING_TEXT, "custom_no_file"),
  customInvalidData = X2Locale:LocalizeUiText(CUSTOMIZING_TEXT, "custom_invalid_data")
}
locale.nationMgr = {
  dominion = X2Locale:LocalizeUiText(NATION_TEXT, "dominion"),
  nationRelation = X2Locale:LocalizeUiText(NATION_TEXT, "nation_relation"),
  siegeRaidTeam = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_team"),
  king = X2Locale:LocalizeUiText(NATION_TEXT, "king"),
  dominionList = X2Locale:LocalizeUiText(NATION_TEXT, "dominion_list"),
  nativeDominion = X2Locale:LocalizeUiText(NATION_TEXT, "native_dominion"),
  selectedDominion = X2Locale:LocalizeUiText(NATION_TEXT, "selected_dominion"),
  friendlyNation = X2Locale:LocalizeUiText(NATION_TEXT, "friendly_nation"),
  hostileNation = X2Locale:LocalizeUiText(NATION_TEXT, "hostile_nation"),
  noOwner = X2Locale:LocalizeUiText(NATION_TEXT, "no_owner"),
  now = X2Locale:LocalizeUiText(NATION_TEXT, "now"),
  joinApproval = X2Locale:LocalizeUiText(NATION_TEXT, "join_approval"),
  joinRejected = X2Locale:LocalizeUiText(NATION_TEXT, "join_rejected"),
  noDominionList = X2Locale:LocalizeUiText(NATION_TEXT, "no_dominion_list"),
  remain_period = X2Locale:LocalizeUiText(NATION_TEXT, "remain_period"),
  siegeRaidCommander = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_team_commander"),
  siegeRaidTeamMemberCount = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_team_member"),
  siegeRaidSponser = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_team_sponsor"),
  siegeRaidZone = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_zone"),
  siegeRaidState = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_state"),
  siegeRaidSchedule = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_period"),
  siegeRaidHeroList = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_team_hero_list"),
  siegeRaidTeamMemberList = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_team_member_list"),
  siegeRaidTeamApplicant = X2Locale:LocalizeUiText(COMMON_TEXT, "siege_raid_team_apply")
}
locale.secondPassword = {
  secondPassword = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "second_password"),
  createTitle = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "create_title"),
  modifyTitle = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "modify_title"),
  clearTitle = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "clear_title"),
  content = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "content"),
  passwordTip = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "password_tip"),
  passwordGuide = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "password_guide"),
  passwordConfirm = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "password_confirm"),
  securityTip = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "security_tip"),
  verificationTitle = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "verification_title"),
  verificationContent = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "verification_content"),
  reinputCount = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "reinput_count"),
  clearContent = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "clear_content"),
  usable = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "usable"),
  unusable = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "unusable"),
  accordance = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "accordance"),
  discordance = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "discordance"),
  setting_success = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "setting_success"),
  setting_fail = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "setting_fail"),
  change_success = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "change_success"),
  change_fail = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "change_fail"),
  change_same_fail = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "change_same_fail"),
  clear_success = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "clear_success"),
  clear_fail = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "clear_fail"),
  confirmation_success = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "confirmation_success"),
  lock_state_played = function(a)
    return X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "lock_state_played", tostring(a))
  end,
  curPassword = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "cur_password"),
  newPassword = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "new_password"),
  newPasswordConfirm = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "new_password_confirm"),
  passwordShort = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "password_short"),
  recommendSecondPasswordTitle = X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "recommendSecondPasswordTitle")
}
locale.lookConverter = {
  material = X2Locale:LocalizeUiText(ITEM_LOOK_CONVERT_TEXT, "material"),
  convertFee = X2Locale:LocalizeUiText(ITEM_LOOK_CONVERT_TEXT, "convertFee"),
  baseItem = X2Locale:LocalizeUiText(ITEM_LOOK_CONVERT_TEXT, "baseItem"),
  lookItem = X2Locale:LocalizeUiText(ITEM_LOOK_CONVERT_TEXT, "lookItem"),
  newItem = X2Locale:LocalizeUiText(ITEM_LOOK_CONVERT_TEXT, "newItem"),
  convert = X2Locale:LocalizeUiText(ITEM_LOOK_CONVERT_TEXT, "convert"),
  cancel = X2Locale:LocalizeUiText(ITEM_LOOK_CONVERT_TEXT, "cancel"),
  baseItemTooltip = function(color)
    return X2Locale:LocalizeUiText(ITEM_LOOK_CONVERT_TEXT, "baseItemTooltip", color)
  end,
  lookItemTooltip = function(color)
    return X2Locale:LocalizeUiText(ITEM_LOOK_CONVERT_TEXT, "lookItemTooltip", color)
  end,
  extractBaseItemTooltip = function(color)
    return X2Locale:LocalizeUiText(ITEM_LOOK_CONVERT_TEXT, "extractBaseItemTooltip", color)
  end,
  extractLookItemTooltip = function(color)
    return X2Locale:LocalizeUiText(ITEM_LOOK_CONVERT_TEXT, "extractLookItemTooltip", color)
  end,
  successNotice = function(str)
    return X2Locale:LocalizeUiText(ITEM_LOOK_CONVERT_TEXT, "successNotice", str)
  end,
  warning = X2Locale:LocalizeUiText(ITEM_LOOK_CONVERT_TEXT, "look_convert_warning")
}
locale.ranking = {
  title = X2Locale:LocalizeUiText(RANKING_TEXT, "ranking"),
  reward = X2Locale:LocalizeUiText(RANKING_TEXT, "reward"),
  preseasonRank = X2Locale:LocalizeUiText(COMMON_TEXT, "preseason_ranking"),
  curRecord = X2Locale:LocalizeUiText(RANKING_TEXT, "my_cur_record"),
  record = X2Locale:LocalizeUiText(COMMON_TEXT, "my_rank_record"),
  rank = X2Locale:LocalizeUiText(RANKING_TEXT, "rank"),
  placing = X2Locale:LocalizeUiText(RANKING_TEXT, "placing"),
  recordTime = X2Locale:LocalizeUiText(RANKING_TEXT, "record_time"),
  updateTip = function(a)
    return X2Locale:LocalizeUiText(RANKING_TEXT, "update_tip", tostring(a))
  end,
  rewardProvisionDay = function(a, b)
    local key = "reward_provision_day"
    if b == RK_EXPEDITION_INSTANCE_RATING then
      key = "reward_expedition_instance"
    end
    return X2Locale:LocalizeUiText(RANKING_TEXT, key, tostring(a))
  end,
  battlefieldScoreTipTitle = X2Locale:LocalizeUiText(RANKING_TEXT, "battlefield_score_tip_title"),
  battlefieldScoreTipBody = X2Locale:LocalizeUiText(RANKING_TEXT, "battlefield_score_tip_body")
}
locale.premium = {
  grade = function(gradeText)
    return X2Locale:LocalizeUiText(PREMIUM_TEXT, "grade", gradeText)
  end,
  premium_buy = X2Locale:LocalizeUiText(PREMIUM_TEXT, "premium_buy"),
  benefit = X2Locale:LocalizeUiText(PREMIUM_TEXT, "benefit"),
  premium_apply_effect = X2Locale:LocalizeUiText(PREMIUM_TEXT, "premium_apply_effect"),
  my_premium_point = X2Locale:LocalizeUiText(PREMIUM_TEXT, "my_premium_point"),
  cash_buy = X2Locale:LocalizeUiText(PREMIUM_TEXT, "cash_buy"),
  premium_kind = X2Locale:LocalizeUiText(PREMIUM_TEXT, "premium_kind"),
  premium_grade_num = function(point)
    return X2Locale:LocalizeUiText(PREMIUM_TEXT, "premium_grade_num", point)
  end,
  bonus = X2Locale:LocalizeUiText(PREMIUM_TEXT, "bonus"),
  real_money = function(money)
    return X2Locale:LocalizeUiText(PREMIUM_TEXT, "real_money", money)
  end,
  goods = X2Locale:LocalizeUiText(PREMIUM_TEXT, "goods")
}
locale.sensitiveOperation = {
  remain_time = function(remainTime)
    return X2Locale:LocalizeUiText(PROTECT_SENSITIVE_OPERATION_TEXT, "remain_time", remainTime)
  end,
  title = X2Locale:LocalizeUiText(PROTECT_SENSITIVE_OPERATION_TEXT, "title"),
  content = X2Locale:LocalizeUiText(PROTECT_SENSITIVE_OPERATION_TEXT, "content"),
  successContent = X2Locale:LocalizeUiText(PROTECT_SENSITIVE_OPERATION_TEXT, "sensitive_operation_verify_success")
}
locale.moneyTooltip = {
  aapoint = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "aapoint_tooltip"),
  money = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "money_tooltip")
}
locale.systemHotKeyErrorMessage = X2Locale:LocalizeUiText(ERROR_MSG, "CAN_NOT_USE_SYSTEM_HOT_KEY")
locale.reportBadUser = {
  title = X2Locale:LocalizeUiText(COMMON_TEXT, "report_bad_user"),
  target = X2Locale:LocalizeUiText(COMMON_TEXT, "report_target"),
  reportReason = X2Locale:LocalizeUiText(COMMON_TEXT, "report_reason"),
  reportTime = X2Locale:LocalizeUiText(COMMON_TEXT, "report_time"),
  reportTypeBot = X2Locale:LocalizeUiText(COMMON_TEXT, "report_type_bot"),
  reportTypeMail = X2Locale:LocalizeUiText(COMMON_TEXT, "report_type_bad_mail"),
  reportTypeChat = X2Locale:LocalizeUiText(COMMON_TEXT, "report_type_bad_chat"),
  reportTypeEtc = X2Locale:LocalizeUiText(TRIAL_TEXT, "crime_type_etc"),
  reportTypeAbusing = X2Locale:LocalizeUiText(COMMON_TEXT, "report_type_abusing"),
  reportTypeBadCharacterName = X2Locale:LocalizeUiText(COMMON_TEXT, "report_type_bad_character_name"),
  reportTypeExpeditionName = X2Locale:LocalizeUiText(COMMON_TEXT, "report_type_bad_expedition_name"),
  reportRecords = X2Locale:LocalizeUiText(COMMON_TEXT, "report_records"),
  writeReport = X2Locale:LocalizeUiText(COMMON_TEXT, "write_report_reason"),
  askReport = X2Locale:LocalizeUiText(COMMON_TEXT, "ask_report_bad_user")
}
locale.forceAttack = {
  toolTip = function(protectPvp)
    if protectPvp then
      return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "builtin_toggle_force_attack_by_protect_pvp_tooltip", tostring(X2Player:GetProtectPvpLevel() + 1))
    else
      return X2Locale:LocalizeUiText(TOOLTIP_TEXT, "builtin_toggle_force_attack_tooltip")
    end
  end
}
function locale.GetAchievementKindString(kind)
  return baselibLocale.achievementKindString[kind] == nil and X2Locale:LocalizeUiText(MAP_TEXT, "unknown") or baselibLocale.achievementKindString[kind].text
end
function locale:GetNameErrorForCharacter(key)
  local stringDatas = {
    error_forbid_char_creation = X2Locale:LocalizeUiText(LOGIN_CROWDED_TEXT, "no_create_race"),
    error_char_name_duplicate = X2Locale:LocalizeUiText(MSG_BOX_BODY_TEXT, "error_char_name_duplicate"),
    error_char_name_forbidden = X2Locale:LocalizeUiText(MSG_BOX_BODY_TEXT, "error_char_name_forbidden"),
    error_char_name_pending = X2Locale:LocalizeUiText(MSG_BOX_BODY_TEXT, "error_char_name_pending"),
    error_char_continent_block = X2Locale:LocalizeUiText(MSG_BOX_BODY_TEXT, "error_char_continent_block")
  }
  if stringDatas[key] == nil then
    return X2Locale:LocalizeUiText(MSG_BOX_BODY_TEXT, "error_char_name_forbidden")
  end
  return stringDatas[key]
end
