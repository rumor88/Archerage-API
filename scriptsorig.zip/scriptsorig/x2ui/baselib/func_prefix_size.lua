F_PREFIX_SIZE = {}
ICON_SIZE_18 = 1
ICON_SIZE_24 = 2
ICON_SIZE_30 = 3
ICON_SIZE_35 = 4
ICON_SIZE_42 = 5
ICON_SIZE_44 = 6
ICON_SIZE_48 = 7
ICON_SIZE_50 = 8
ICON_SIZE_52 = 9
ICON_SIZE_58 = 10
ICON_SIZE_40 = 11
local iconButtonSizes = {
  [ICON_SIZE_18] = 18,
  [ICON_SIZE_24] = 24,
  [ICON_SIZE_30] = 30,
  [ICON_SIZE_35] = 35,
  [ICON_SIZE_40] = 40,
  [ICON_SIZE_42] = 42,
  [ICON_SIZE_44] = 44,
  [ICON_SIZE_48] = 48,
  [ICON_SIZE_50] = 50,
  [ICON_SIZE_52] = 52,
  [ICON_SIZE_58] = 58
}
ICON_SIZE = {
  SOCKET = 18,
  BUFF = 24,
  SET_ITEM = 24,
  APPELLAITON = 30,
  AUCTION = 35,
  DEFAULT = 42,
  LARGE = 48,
  XLARGE = 50,
  SLAVE = 52
}
function F_PREFIX_SIZE:GetIconButtonSize(index)
  return iconButtonSizes[index]
end
WINDOW_WIDTH_300 = 1
WINDOW_WIDTH_350 = 2
WINDOW_WIDTH_430 = 3
WINDOW_WIDTH_450 = 4
WINDOW_WIDTH_510 = 5
WINDOW_WIDTH_600 = 6
WINDOW_WIDTH_680 = 7
WINDOW_WIDTH_800 = 8
WINDOW_WIDTH_900 = 9
WINDOW_WIDTH_1200 = 10
local windowWidths = {
  [WINDOW_WIDTH_300] = 300,
  [WINDOW_WIDTH_350] = 350,
  [WINDOW_WIDTH_430] = 430,
  [WINDOW_WIDTH_450] = 450,
  [WINDOW_WIDTH_510] = 510,
  [WINDOW_WIDTH_600] = 600,
  [WINDOW_WIDTH_680] = 680,
  [WINDOW_WIDTH_800] = 800,
  [WINDOW_WIDTH_900] = 900,
  [WINDOW_WIDTH_1200] = 1200
}
function F_PREFIX_SIZE:GetWindowWidth(index)
  return windowWidths[index]
end
function F_PREFIX_SIZE:GetWindowWidthForCombos()
  local widthTables = {}
  for i = 1, #windowWidths do
    local data = {
      text = tostring(windowWidths[i]),
      value = windowWidths[i]
    }
    table.insert(widthTables, data)
  end
  return widthTables
end
function F_PREFIX_SIZE:GetDefaultIconGap()
  return 5
end
