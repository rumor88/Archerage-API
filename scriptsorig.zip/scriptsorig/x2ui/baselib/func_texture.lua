F_TEXTURE = {}
function CreateTooltipDrawable(widget)
  local bg = widget:CreateDrawable(TEXTURE_PATH.HUD, "tooltip_bg", "background")
  bg:AddAnchor("TOPLEFT", widget, 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", widget, 0, 0)
  widget.bg = bg
end
function DrawEffectActionBarBackground(actionBar)
  local bg = actionBar:CreateEffectDrawableByKey(TEXTURE_PATH.HUD, "effect_action_bar_bg", "background")
  bg:SetVisible(false)
  bg:AddAnchor("TOPLEFT", actionBar, 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", actionBar, 0, 0)
  bg:SetRepeatCount(1)
  actionBar.bg = bg
  actionBar.isvisibleBg = false
  function actionBar:OnEnterEffectSetting()
    self.bg:SetEffectPriority(1, "alpha", 4602678819172646912, 4602678819172646912)
    self.bg:SetEffectInitialColor(1, 1, 1, 1, 0)
    self.bg:SetEffectFinalColor(1, 1, 1, 1, 4600877379321698714)
    self.bg:SetStartEffect(true)
    self.isvisibleBg = true
  end
  function actionBar:OnLeaveEffectSetting()
    self.bg:SetEffectPriority(1, "alpha", 4599075939470750515, 4599075939470750515)
    self.bg:SetEffectInitialColor(1, 1, 1, 1, 4600877379321698714)
    self.bg:SetEffectFinalColor(1, 1, 1, 1, 0)
    self.bg:SetStartEffect(true)
    self.isvisibleBg = false
  end
end
function CreateLine(widget, styleType, layer)
  if layer == nil then
    layer = "background"
  end
  local styleTable = {
    TYPE1 = function(widget, layer)
      local line = widget:CreateDrawable(TEXTURE_PATH.DEFAULT, "line_01", layer)
      line:SetTextureColor("default")
      return line
    end,
    TYPE2 = function(widget, layer)
      local line = widget:CreateDrawable(TEXTURE_PATH.DEFAULT, "tab_line_left", layer)
      line:SetTextureColor("default")
      local line2 = widget:CreateDrawable(TEXTURE_PATH.DEFAULT, "tab_line_right", layer)
      line2:SetTextureColor("default")
      return line, line2
    end,
    TYPE5 = function(widget, layer)
      local line = widget:CreateDrawable(TEXTURE_PATH.DEFAULT, "tab_line_left", layer)
      line:SetTextureColor("dark_blue")
      local line2 = widget:CreateDrawable(TEXTURE_PATH.DEFAULT, "tab_line_right", layer)
      line2:SetTextureColor("dark_blue")
      return line, line2
    end,
    TYPE6 = function(widget, layer)
      local line = widget:CreateDrawable(TEXTURE_PATH.DEFAULT, "line_01", layer)
      line:SetTextureColor("dark_blue_20")
      return line
    end,
    TYPE8 = function(widget, layer)
      local line = widget:CreateDrawable(TEXTURE_PATH.DEFAULT, "line_achievement", layer)
      line:SetTextureColor("deepblue_15")
      return line
    end
  }
  return styleTable[styleType](widget, layer)
end
function DrawTargetLine(widget)
  local line = widget:CreateDrawable(TEXTURE_PATH.DEFAULT, "line_01", "overlay")
  line:SetTextureColor("default")
  line:SetExtent(0, 3)
  line:AddAnchor("TOPLEFT", widget, "BOTTOMLEFT", 0, 8)
  line:AddAnchor("TOPRIGHT", widget, "BOTTOMRIGHT", 0, 8)
  widget.line = line
end
function CreateContentBackground(widget, styleType, color, layer)
  if layer == nil then
    layer = "background"
  end
  local styleTable = {
    TYPE1 = function(widget, layer)
      local bg = widget:CreateDrawable(TEXTURE_PATH.DEFAULT, "type_01", layer)
      bg:SetTextureColor(color)
      return bg
    end,
    TYPE2 = function(widget, layer)
      local bg = widget:CreateDrawable(TEXTURE_PATH.DEFAULT, "type02_new", layer)
      bg:SetTextureColor(color)
      return bg
    end,
    TYPE3 = function(widget, layer)
      local bg = widget:CreateDrawable(TEXTURE_PATH.DEFAULT, "type_03", layer)
      bg:SetTextureColor(color)
      return bg
    end,
    TYPE5 = function(widget, layer)
      local bg = widget:CreateDrawable(TEXTURE_PATH.DEFAULT, "type_05", layer)
      bg:SetTextureColor(color)
      return bg
    end,
    TYPE6 = function(widget, layer)
      local bg = widget:CreateDrawable(TEXTURE_PATH.DEFAULT, "type_06", layer)
      bg:SetTextureColor(color)
      return bg
    end,
    TYPE7 = function(widget, layer)
      local bg = widget:CreateDrawable(TEXTURE_PATH.SUBZONE_SYSTEM, "type_07", layer)
      bg:SetTextureColor(color)
      return bg
    end,
    TYPE8 = function(widget, layer)
      local bg = widget:CreateDrawable(TEXTURE_PATH.ALARM_BG, "type_08", layer)
      bg:SetTextureColor(color)
      return bg
    end,
    TYPE10 = function(widget, layer)
      local bg = widget:CreateDrawable(TEXTURE_PATH.DEFAULT, "type_10", layer)
      bg:SetTextureColor(color)
      return bg
    end,
    TYPE11 = function(widget, layer)
      local bg = widget:CreateDrawable(TEXTURE_PATH.DEFAULT, "common_bg", layer)
      bg:SetTextureColor(color)
      return bg
    end,
    TYPE12 = function(widget, layer)
      local bg = widget:CreateDrawable(TEXTURE_PATH.DEFAULT, "type_12", layer)
      bg:SetTextureColor(color)
      return bg
    end,
    TYPE13 = function(widget, layer)
      local bg = widget:CreateDrawable(TEXTURE_PATH.PAPER_DECO, "type_13", layer)
      return bg
    end
  }
  return styleTable[styleType](widget, layer)
end
function CreateLoadingTextureSet(widget, color)
  if color == nil then
    color = "default"
  end
  local modalLoadingWindow = widget:CreateChildWidget("emptywidget", "modalLoadingWindow", 0, true)
  local bg = modalLoadingWindow:CreateDrawable(TEXTURE_PATH.DEFAULT, "modal_bg", "overlay")
  bg:SetTextureColor(color)
  bg:AddAnchor("TOPLEFT", modalLoadingWindow, 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", modalLoadingWindow, 0, 0)
  local effect = modalLoadingWindow:CreateEffectDrawableByKey("ui/tutorials/loading.dds", "loading", "overlay")
  effect:SetVisible(false)
  effect:AddAnchor("CENTER", modalLoadingWindow, 0, 0)
  effect:SetRepeatCount(0)
  effect:SetEffectPriority(1, "rotate", 4609434218613702656, 4609434218613702656)
  effect:SetEffectRotate(1, 0, 360)
  modalLoadingWindow.effect = effect
  function widget:WaitPage(isShow)
    self.modalLoadingWindow:Show(isShow)
    self.modalLoadingWindow.effect:SetStartEffect(isShow)
    self.modalLoadingWindow:Raise()
  end
  function widget:WaitPageCont(isShow)
    local isVisible = self.modalLoadingWindow:IsVisible()
    self.modalLoadingWindow:Show(isShow)
    if isVisible ~= isShow then
      self.modalLoadingWindow.effect:SetStartEffect(isShow)
    end
    self.modalLoadingWindow:Raise()
  end
  return modalLoadingWindow
end
function F_TEXTURE.CreateCheckIcon(target)
  local checkImg = target:CreateDrawable(TEXTURE_PATH.DEFAULT, "common_v", "overlay")
  checkImg:SetTextureColor("green")
  return checkImg
end
local HIGHLIGHT_FIELD = {
  BOX = "box",
  CHECK = "check",
  PATH = "path",
  KEY = "key",
  ANCHOR_VALUE = "anchor_value"
}
local highlightInfo = {
  blue = {
    [HIGHLIGHT_FIELD.BOX] = {
      [HIGHLIGHT_FIELD.PATH] = TEXTURE_PATH.DEFAULT,
      [HIGHLIGHT_FIELD.KEY] = "icon_selected",
      [HIGHLIGHT_FIELD.ANCHOR_VALUE] = 8
    }
  },
  green = {
    [HIGHLIGHT_FIELD.BOX] = {
      [HIGHLIGHT_FIELD.PATH] = TEXTURE_PATH.APPELLATION_STAMP_APPLIED,
      [HIGHLIGHT_FIELD.KEY] = "icon_apply",
      [HIGHLIGHT_FIELD.ANCHOR_VALUE] = 8
    },
    [HIGHLIGHT_FIELD.CHECK] = F_TEXTURE.CreateCheckIcon
  },
  ucc = {
    [HIGHLIGHT_FIELD.BOX] = {
      [HIGHLIGHT_FIELD.PATH] = TEXTURE_PATH.UCC,
      [HIGHLIGHT_FIELD.KEY] = "ucc_item_on",
      [HIGHLIGHT_FIELD.ANCHOR_VALUE] = 0
    }
  }
}
function F_TEXTURE.CreateIconHighlight(target, styleType)
  local info = highlightInfo[styleType]
  if info == nil then
    return
  end
  local curStyle = styleType
  local boxImg
  local boxInfo = info[HIGHLIGHT_FIELD.BOX]
  if boxInfo then
    local anchorValue = boxInfo[HIGHLIGHT_FIELD.ANCHOR_VALUE]
    boxImg = target:CreateDrawable(boxInfo[HIGHLIGHT_FIELD.PATH], boxInfo[HIGHLIGHT_FIELD.KEY], "overlay")
    boxImg:Show(false)
    boxImg:AddAnchor("TOPLEFT", target, -anchorValue, -anchorValue)
    boxImg:AddAnchor("BOTTOMRIGHT", target, anchorValue, anchorValue)
  end
  local checkImg
  local function CreateCheckImg(info)
    local checkCreater = info[HIGHLIGHT_FIELD.CHECK]
    if checkCreater ~= nil and type(checkCreater) == "function" and checkImg == nil then
      checkImg = checkCreater(target)
      checkImg:AddAnchor("BOTTOMRIGHT", target, 0, 0)
    end
  end
  CreateCheckImg(info)
  function target:ChangeIconHighlight(styleType)
    local info = highlightInfo[styleType]
    if info == nil then
      return
    end
    local boxInfo = info[HIGHLIGHT_FIELD.BOX]
    if boxInfo and boxImg ~= nil then
      boxImg:SetTexture(boxInfo[HIGHLIGHT_FIELD.PATH])
      boxImg:SetTextureInfo(boxInfo[HIGHLIGHT_FIELD.KEY])
      local anchorValue = boxInfo[HIGHLIGHT_FIELD.ANCHOR_VALUE]
      boxImg:AddAnchor("TOPLEFT", target, -anchorValue, -anchorValue)
      boxImg:AddAnchor("BOTTOMRIGHT", target, anchorValue, anchorValue)
    end
    CreateCheckImg(info)
    if checkImg ~= nil then
      checkImg:SetVisible(info[HIGHLIGHT_FIELD.CHECK] ~= nil)
    end
    curStyle = styleType
  end
  function target:SetVisibleCheck(visible)
    local info = highlightInfo[curStyle]
    if info == nil then
      return
    end
    if checkImg ~= nil then
      visible = visible and (info[HIGHLIGHT_FIELD.CHECK] ~= nil and true or false)
      checkImg:SetVisible(visible)
    end
  end
  return boxImg, checkImg
end
function F_TEXTURE.CreateAlertReasonSection(id, parent, anchorTarget)
  local reason = parent:CreateChildWidget("emptywidget", id, 0, true)
  reason:Show(false)
  reason:AddAnchor("TOPLEFT", anchorTarget, 0, 0)
  reason:AddAnchor("BOTTOMRIGHT", anchorTarget, 0, 0)
  local bg = reason:CreateDrawable(TEXTURE_PATH.DEFAULT, "type02_new", "background")
  bg:SetTextureColor("brown_5")
  bg:AddAnchor("TOPLEFT", reason, 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", reason, 0, 0)
  local msg = reason:CreateChildWidget("textbox", "msg", 0, false)
  msg:AddAnchor("LEFT", reason, 10, 0)
  msg:AddAnchor("RIGHT", reason, -10, 0)
  msg.style:SetAlign(ALIGN_CENTER)
  msg.style:SetShadow(true)
  msg.style:SetFontSize(FONT_SIZE.LARGE)
  msg:SetAutoResize(true)
  function reason:SetReason(show, reasonStr)
    if not show then
      self:Show(false)
      return
    end
    msg:SetText(reasonStr)
    self:Show(true)
  end
  return reason
end
