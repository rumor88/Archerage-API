if X2Debug:GetDevMode() then
  do
    local chectTextureWidget, keySelectWidget
    local TEXTURE_KEY = "textureKey"
    local COLOR_KEY = "colorKey"
    local function CreateKeySelectView()
      local screenHeight = UIParent:GetScreenHeight()
      local windowWidth = F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_350)
      local window = CreateWindow("checkTexture", "UIParent")
      window.titleBar:HideCloseButton()
      window:SetCloseOnEscape(false)
      window:ApplyUIScale(false)
      window:SetExtent(windowWidth, screenHeight)
      window:AddAnchor("TOPRIGHT", "UIParent", "TOPRIGHT", 0, 0)
      window:Show(true)
      local openBtn = window:CreateChildWidget("button", "openBtn", 0, true)
      openBtn:AddAnchor("TOPRIGHT", window.titleBar, "BOTTOMRIGHT", 0, 0)
      openBtn:SetText("Open")
      openBtn:SetStyle("text_default")
      function openBtn:OnClick()
        openBtn:Enable(false)
        UIParent:CheckTextureToolFileOpen()
        openBtn:Enable(true)
      end
      openBtn:SetHandler("OnClick", openBtn.OnClick)
      local edit = W_CTRL.CreateEdit("edit", window)
      edit:SetExtent(windowWidth - openBtn:GetWidth(), FONT_SIZE.MIDDLE + 15)
      edit:AddAnchor("RIGHT", openBtn, "LEFT", 0, 0)
      edit.style:SetColorByKey("black")
      edit:SetEnglish(true)
      edit:SetGuideText("Search Key")
      edit.nextSearchLabelIndex = 1
      function edit:SelectKey()
        local input = edit:GetText()
        if input == nil or input == "" then
          return
        end
        local contentWidget = window.scrollWnd.content
        if contentWidget.dataLabels == nil then
          return
        end
        for i = edit.nextSearchLabelIndex, #contentWidget.dataLabels do
          if contentWidget.dataLabels[i]:IsVisible() and contentWidget.dataLabels[i].kind == TEXTURE_KEY then
            local start, _ = string.find(contentWidget.dataLabels[i].rawData.textureKey, input)
            if start ~= nil then
              edit.nextSearchLabelIndex = i + 1
              contentWidget.dataLabels[i]:OnClick("enterKey")
              return
            end
          end
        end
        edit.nextSearchLabelIndex = 1
      end
      edit:SetHandler("OnEnterPressed", edit.SelectKey)
      function edit:TextChanged()
        edit.nextSearchLabelIndex = 1
      end
      edit:SetHandler("OnTextChanged", edit.TextChanged)
      local scrollWnd = CreateScrollWindow(window, "scrollWnd", 0)
      scrollWnd:AddAnchor("TOPLEFT", edit, "BOTTOMLEFT", 0, 0)
      scrollWnd:AddAnchor("BOTTOMRIGHT", window, "BOTTOMRIGHT", 0, 0)
      scrollWnd:Show(true)
      function window:SelectLabelWidget(textureKey)
        local contentWidget = window.scrollWnd.content
        for i = 1, #contentWidget.dataLabels do
          if contentWidget.dataLabels[i]:IsVisible() and contentWidget.dataLabels[i]:GetText() == textureKey then
            contentWidget.dataLabels[i]:OnClick(nil)
          end
        end
      end
      function window:FillData(data)
        edit:SetText("", true)
        if window.selectedDataLabel ~= nil then
          window.selectedDataLabel.bg:SetVisible(false)
        end
        window.selectedDataLabel = nil
        window.scrollWnd:ResetScroll(0)
        local visibleCount = 0
        local contentWidget = window.scrollWnd.content
        for i = 1, #data do
          local dataLabel
          if contentWidget.dataLabels ~= nil and contentWidget.dataLabels[i] ~= nil then
            dataLabel = contentWidget.dataLabels[i]
          else
            dataLabel = contentWidget:CreateChildWidget("label", "dataLabels", i, true)
            dataLabel.style:SetAlign(ALIGN_LEFT)
            dataLabel.style:SetFontSize(FONT_SIZE.SMALL)
            dataLabel.style:SetColorByKey("black")
            dataLabel:SetExtent(windowWidth - 10, FONT_SIZE.SMALL)
            if i == 1 then
              dataLabel:AddAnchor("TOPLEFT", contentWidget, "TOPLEFT", 5, 0)
            else
              dataLabel:AddAnchor("TOPLEFT", contentWidget.dataLabels[i - 1], "BOTTOMLEFT", 0, 0)
            end
            dataLabel.bg = dataLabel:CreateColorDrawableByKey("texture_check_window_data_label", "background")
            dataLabel.bg:AddAnchor("TOPLEFT", dataLabel, "TOPLEFT", 0, 0)
            dataLabel.bg:AddAnchor("BOTTOMRIGHT", dataLabel, "BOTTOMRIGHT", 0, 0)
            dataLabel.bg:SetVisible(false)
            function dataLabel:OnClick(buttonString)
              if buttonString ~= nil and chectTextureWidget ~= nil then
                chectTextureWidget:SelectTextureWidget(dataLabel.rawData.textureKey, dataLabel.rawData.color)
              end
              if (buttonString == nil or buttonString == "enterKey") and window.scrollWnd:IsEnabled() then
                window.scrollWnd:SetValue((i - 1) * contentWidget.dataLabels[i]:GetHeight())
              end
              if window.selectedDataLabel ~= nil then
                window.selectedDataLabel.bg:SetVisible(false)
              end
              window.selectedDataLabel = dataLabel
              if window.selectedDataLabel ~= nil then
                window.selectedDataLabel.bg:SetVisible(true)
              end
            end
            dataLabel:SetHandler("OnClick", dataLabel.OnClick)
          end
          dataLabel:SetText(data[i].text)
          dataLabel.kind = data[i].kind
          dataLabel.rawData = data[i].rawData
          dataLabel:Show(true)
          visibleCount = visibleCount + 1
        end
        window.scrollWnd:ResetScroll(visibleCount * FONT_SIZE.SMALL)
        if contentWidget.dataLabels ~= nil then
          for i = visibleCount + 1, #contentWidget.dataLabels do
            contentWidget.dataLabels[i].kind = nil
            contentWidget.dataLabels[i].rawData = nil
            contentWidget.dataLabels[i]:Show(false)
          end
        end
      end
      return window
    end
    local MakeTooltip = function(textureKey, info)
      local tooltipText = textureKey
      local coords = info.coords
      tooltipText = F_TEXT.SetEnterString(tooltipText, string.format("coords (%.2f, %.2f, %.2f, %.2f)", coords[1], coords[2], coords[3], coords[4]))
      local extent = info.extent
      tooltipText = F_TEXT.SetEnterString(tooltipText, string.format("extent (%.2f, %.2f)", extent[1], extent[2]))
      local inset = info.inset
      tooltipText = F_TEXT.SetEnterString(tooltipText, string.format("inset (%.2f, %.2f, %.2f, %.2f)", inset[1], inset[2], inset[3], inset[4]))
      if info.colors ~= nil then
        tooltipText = F_TEXT.SetEnterString(tooltipText, "colors")
        for key, color in pairs(info.colors) do
          tooltipText = F_TEXT.SetEnterString(tooltipText, string.format("-- %s (%.2f, %.2f, %.2f, %.2f)", key, color[1], color[2], color[3], color[4]))
        end
      end
      return tooltipText
    end
    local function OnCheckTexture(texturePath)
      local alreadyShow = chectTextureWidget ~= nil
      if chectTextureWidget ~= nil then
        chectTextureWidget:Show(false)
        chectTextureWidget = nil
      end
      if texturePath == "" and alreadyShow then
        if keySelectWidget ~= nil then
          keySelectWidget:Show(false)
        end
        UIParent:DevLog("[CHECK UI TEXTURE] return OnCheckTxture function")
        return
      end
      local screenWidth = UIParent:GetScreenWidth()
      local screenHeight = UIParent:GetScreenHeight()
      local w = UIParent:CreateWidget("emptywidget", string.format("checkBase[%s]", tostring(os.clock())), "UIParent")
      w:EnableHidingIsRemove(true)
      w:ApplyUIScale(false)
      w:SetExtent(screenWidth, screenHeight)
      w:AddAnchor("TOPLEFT", "UIParent", "TOPLEFT", 0, 0)
      w:Show(true)
      local data = UIParent:GetTextureKeyData(texturePath)
      local bg = w:CreateColorDrawableByKey("texture_check_window_bg", "background")
      bg:AddAnchor("TOPLEFT", w, "TOPLEFT", 0, 0)
      bg:AddAnchor("BOTTOMRIGHT", w, "BOTTOMRIGHT", 0, 0)
      local textureRect = w:CreateChildWidget("emptywidget", "textureRect", 0, true)
      textureRect:EnableDrag(true)
      bg = textureRect:CreateColorDrawableByKey("texture_check_window_rect", "background")
      bg:AddAnchor("TOPLEFT", textureRect, "TOPLEFT", 0, 0)
      bg:AddAnchor("BOTTOMRIGHT", textureRect, "BOTTOMRIGHT", 0, 0)
      textureRect:AddAnchor("TOPLEFT", w, "TOPLEFT", 10, 10)
      if data ~= nil and data.width ~= nil then
        textureRect:SetExtent(data.width, data.height)
      else
        textureRect:SetExtent(0, 0)
      end
      local function OnDragStart()
        textureRect:StartMoving()
      end
      textureRect:SetHandler("OnDragStart", OnDragStart)
      local function OnDragStop()
        textureRect:StopMovingOrSizing()
      end
      textureRect:SetHandler("OnDragStop", OnDragStop)
      local tooltipTextBox = w:CreateChildWidget("textbox", "tooltipTextBox", 0, true)
      bg = tooltipTextBox:CreateColorDrawableByKey("texture_check_window_tooltip_bg", "background")
      bg:AddAnchor("TOPLEFT", tooltipTextBox, "TOPLEFT", 0, 0)
      bg:AddAnchor("BOTTOMRIGHT", tooltipTextBox, "BOTTOMRIGHT", 0, 0)
      tooltipTextBox:EnableFocus(false)
      tooltipTextBox:EnablePick(false)
      tooltipTextBox.style:SetColorByKey("check_texture_tooltip")
      tooltipTextBox.style:SetAlign(ALIGN_TOP_LEFT)
      tooltipTextBox:SetInset(4, 4, 4, 4)
      tooltipTextBox:Show(false)
      local selectViewData = {}
      if data ~= nil and data.keys ~= nil then
        for i = 1, #data.keys do
          local info = UIParent:GetTextureData(texturePath, data.keys[i])
          local child = textureRect:CreateChildWidget("emptywidget", "child", i, true)
          child.textureKey = data.keys[i]
          child:Show(true)
          local scaleX = data.width / screenHeight
          local scaleY = data.height / screenHeight
          if scaleY < 1 then
            scaleX = 1
            scaleY = 1
          end
          local coords = info.coords
          child:SetExtent(coords[3] / scaleX, coords[4] / scaleY)
          child:AddAnchor("TOPLEFT", textureRect, "TOPLEFT", coords[1] / scaleX, coords[2] / scaleY)
          local drawable = child:CreateDrawable(texturePath, data.keys[i], "background")
          drawable:AddAnchor("TOPLEFT", child, "TOPLEFT", 0, 0)
          drawable:AddAnchor("BOTTOMRIGHT", child, "BOTTOMRIGHT", 0, 0)
          child.tooltipText = MakeTooltip(data.keys[i], info)
          child.drawable = drawable
          function child:OnEnter()
            child:SetDrawBorder(true, 0, 0, 1, 1)
            local screenWidth = UIParent:GetScreenWidth()
            local screenHeight = UIParent:GetScreenHeight()
            tooltipTextBox:RemoveAllAnchors()
            tooltipTextBox:SetExtent(screenWidth, screenHeight)
            tooltipTextBox:SetText(child.tooltipText)
            local tooltipWidth, tooltipHeight = tooltipTextBox:GetLongestLineWidth() + 8, tooltipTextBox:GetTextHeight() + 8
            tooltipTextBox:SetExtent(tooltipWidth, tooltipHeight)
            local x, y = child:GetOffset()
            local w, h = child:GetExtent()
            local bottomRightX = x + w
            local bottomRightY = y + h
            local sourceAnchorX = "LEFT"
            if tooltipWidth > screenWidth - bottomRightX then
              sourceAnchorX = "RIGHT"
            end
            local sourceAnchorY = "TOP"
            if tooltipHeight > screenHeight - bottomRightY then
              sourceAnchorY = "BOTTOM"
            end
            tooltipTextBox:AddAnchor(string.format("%s%s", sourceAnchorY, sourceAnchorX), child, "BOTTOMRIGHT", 0, 0)
            tooltipTextBox:Raise()
            tooltipTextBox:Show(true)
          end
          child:SetHandler("OnEnter", child.OnEnter)
          function child:OnLeave()
            if w.selectedTextureWidget == child then
              w.selectedTextureWidget:SetDrawBorder(true, 1, 0, 0, 1)
            else
              child:SetDrawBorder(false, 0, 0, 1, 1)
            end
            tooltipTextBox:Show(false)
          end
          child:SetHandler("OnLeave", child.OnLeave)
          function child:OnClick(buttonString)
            if buttonString ~= nil and keySelectWidget ~= nil then
              keySelectWidget:SelectLabelWidget(child.textureKey)
            end
            if w.selectedTextureWidget ~= nil then
              w.selectedTextureWidget:SetDrawBorder(false, 1, 0, 0, 1)
            end
            w.selectedTextureWidget = w.textureRect.child[i]
            if w.selectedTextureWidget ~= nil then
              w.selectedTextureWidget:SetDrawBorder(true, 1, 0, 0, 1)
            end
          end
          child:SetHandler("OnClick", child.OnClick)
          selectViewData[#selectViewData + 1] = {
            text = data.keys[i],
            kind = TEXTURE_KEY,
            rawData = {
              textureKey = data.keys[i],
              color = {
                1,
                1,
                1,
                1
              }
            }
          }
          if info.colors ~= nil then
            for key, color in pairs(info.colors) do
              local text = F_TEXT.SetEnterString(string.format("-- %s (%.2f, %.2f, %.2f, %.2f)", key, color[1], color[2], color[3], color[4]), "")
              selectViewData[#selectViewData + 1] = {
                text = text,
                kind = COLOR_KEY,
                rawData = {
                  textureKey = data.keys[i],
                  color = color
                }
              }
            end
          end
        end
      end
      function w:SelectTextureWidget(textureKey, color)
        for i = 1, #w.textureRect.child do
          if w.textureRect.child[i].textureKey == textureKey then
            F_COLOR.ApplyTextureColor(w.textureRect.child[i].drawable, color)
            w.textureRect.child[i]:OnClick(nil)
          end
        end
      end
      chectTextureWidget = w
      if keySelectWidget == nil then
        keySelectWidget = CreateKeySelectView()
      end
      keySelectWidget:Show(true)
      keySelectWidget:FillData(selectViewData)
      keySelectWidget:Raise()
    end
    UIParent:SetEventHandler("CHECK_TEXTURE", OnCheckTexture)
  end
end
