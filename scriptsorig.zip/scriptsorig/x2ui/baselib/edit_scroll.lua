function CreateEditScroll(parent, ownId)
  local frame = CreateScrollWindow(parent, ownId, 0)
  local offset = 10
  local bottomOffset = 5
  local bg = frame:CreateDrawable(TEXTURE_PATH.DEFAULT, "editbox_df", "background")
  bg:AddAnchor("TOPLEFT", frame, -offset, -offset)
  bg:AddAnchor("BOTTOMRIGHT", frame, bottomOffset, bottomOffset)
  frame.scrollInset = 0
  function frame:SetScrollInset(inset)
    frame.scrollInset = inset
  end
  local editbox = W_CTRL.CreateMultiLineEdit("editbox", frame.content)
  editbox:AddAnchor("TOPLEFT", frame.content, 0, 0)
  editbox:AddAnchor("TOPRIGHT", frame.content, 0, 0)
  editbox:SetHeight(2300)
  editbox:SetInset(0, 0, 10, 0)
  editbox.bg:SetVisible(false)
  frame.editbox = editbox
  local function OnTextChanged()
    if frame.OnTextChangedProc ~= nil then
      frame.OnTextChangedProc()
    end
    frame:ResetScroll(editbox:GetTextHeight() + 10)
  end
  editbox:SetHandler("OnTextChanged", OnTextChanged)
  local function OnCursorMovedScoreEdit()
    local min, max = frame.scroll.vs:GetMinMaxValues()
    local cursor = editbox:GetCursorPosY() / UIParent:GetUIScale()
    if cursor >= frame:GetHeight() + frame.scroll.vs:GetValue() - 23 then
      local vs = cursor - frame:GetHeight() + 23
      if max < vs then
        frame:ResetScroll(vs + frame:GetHeight())
      end
      frame:SetValue(vs)
    elseif cursor - 1 < frame.scroll.vs:GetValue() then
      frame:SetValue(cursor)
    end
  end
  editbox:SetHandler("OnCursorMoved", OnCursorMovedScoreEdit)
  return frame
end
