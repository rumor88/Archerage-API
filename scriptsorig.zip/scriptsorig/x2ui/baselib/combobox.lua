local SetViewOfSliderList = function(id, parent)
  local window = UIParent:CreateWidget("window", id, parent)
  window:Show(false)
  local list = W_CTRL.CreateList("list", window)
  list:AddAnchor("TOPLEFT", window, 0, 0)
  list:AddAnchor("BOTTOMRIGHT", window, -15, 0)
  list:SetInset(5, 7, 5, 7)
  list:SetStyle(nil)
  list.bg:RemoveAllAnchors()
  list.bg:AddAnchor("TOPLEFT", window, 0, 0)
  list.bg:AddAnchor("BOTTOMRIGHT", window, 0, 0)
  window.list = list
  local scroll = W_CTRL.CreateScroll("scroll", window)
  scroll:AddAnchor("TOPRIGHT", window, -4, 8)
  scroll:AddAnchor("BOTTOMRIGHT", window, -4, -8)
  window.scroll = scroll
  return window
end
local function CreateSliderList(id, parent)
  local window = SetViewOfSliderList(id, parent)
  local list = window.list
  local scroll = window.scroll
  local function OnSliderChanged(self, arg)
    list:SetTop(arg)
  end
  scroll.vs:SetHandler("OnSliderChanged", OnSliderChanged)
  function list:OnSelChanged()
    widget:SetText(list:GetSelectedText())
    list:Show(false)
  end
  return window
end
local function CreateDropdown()
  local dropdown = CreateSliderList("dropDownSliderList", "UIParent")
  dropdown:SetMinMaxValues(0, 0)
  local OnHide = function(self)
    self.OnSelChanged = nil
    self:SetHeight(0)
    self:ClearItem()
    self.scroll:Show(false)
  end
  dropdown:SetHandler("OnHide", OnHide)
  function dropdown:Hide(target)
    self:Show(false)
    target:DetachWidget()
  end
  return dropdown
end
local DEFAULT_DROPDOWN_LAYER = "normal"
local commonDropdown = CreateDropdown()
commonDropdown:SetUILayer(DEFAULT_DROPDOWN_LAYER)
commonDropdown:SetCloseOnEscape(true)
ADDON:RegisterContentWidget(UIC_DROPDOWN_LIST, commonDropdown)
function W_CTRL.CreateAutocomplete(id, parent)
  local comboBox = parent:CreateChildWidget("combobox", id, 0, true)
  comboBox:SetExtent(DEFAULT_SIZE.DIALOG_CONTENT_WIDTH, DEFAULT_SIZE.COMBOBOX_HEIGHT)
  comboBox:SetEditable(true)
  comboBox.parent = parent
  local selector = comboBox.selector
  local dropdown = comboBox.dropdown
  InitEdit(selector)
  function comboBox:CreateGuideText(msg, align, inset)
    selector:SetGuideText(msg)
    if inset ~= nil then
      selector:SetGuideTextInset(inset)
    end
    selector.guideTextStyle:SetColorByKey("guide_text_in_editbox")
    if align == nil then
      align = ALIGN_LEFT
    end
    selector.guideTextStyle:SetAlign(align)
  end
  InitList(dropdown)
  local bg = dropdown:CreateDrawable(TEXTURE_PATH.DEFAULT, "editbox_df", "background")
  bg:AddAnchor("TOPLEFT", dropdown, 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", dropdown, 0, 0)
  dropdown.bg = bg
  function comboBox:HideDropdown()
    dropdown:Show(false)
    selector:ClearFocus()
  end
  function comboBox:Reset()
    selector:SetText("")
  end
  function comboBox:LinkText(str)
    comboBox:PauseAutocomplete(true)
    selector:SetText(str)
    if str == selector:GetText() then
      comboBox:PauseAutocomplete(false)
    end
  end
  return comboBox
end
function W_CTRL.CreateComboBox(id, parent)
  local comboBox = parent:CreateChildWidget("combobox", id, 0, true)
  comboBox:SetExtent(DEFAULT_SIZE.DIALOG_CONTENT_WIDTH, DEFAULT_SIZE.COMBOBOX_HEIGHT)
  comboBox:SetEditable(false)
  comboBox.parent = parent
  local selectorBtn = comboBox.selectorBtn
  local toggle = comboBox.toggle
  local dropdown = comboBox.dropdown
  local upBtn = dropdown.upBtn
  local downBtn = dropdown.downBtn
  local vslider = dropdown.vslider
  local thumb = dropdown.vslider.thumb
  ButtonInit(selectorBtn)
  selectorBtn:SetInset(7, 1, 21, 0)
  selectorBtn.style:SetAlign(ALIGN_LEFT)
  selectorBtn:Show(true)
  local selectorBg = selectorBtn:CreateDrawable(TEXTURE_PATH.DEFAULT, "editbox_df", "background")
  selectorBg:AddAnchor("TOPLEFT", selectorBtn, 0, 0)
  selectorBg:AddAnchor("BOTTOMRIGHT", selectorBtn, 0, 0)
  selectorBtn.bg = selectorBg
  toggle:AddAnchor("RIGHT", selectorBtn, -2, 2)
  toggle:SetStyle("grid_folder_down_arrow")
  toggle:Show(true)
  InitList(dropdown)
  dropdown:SetInset(5, 5, 20, 5)
  local dropdownBg = dropdown:CreateDrawable(TEXTURE_PATH.DEFAULT, "editbox_df", "background")
  dropdownBg:AddAnchor("TOPLEFT", dropdown, 0, 0)
  dropdownBg:AddAnchor("BOTTOMRIGHT", dropdown, 0, 0)
  dropdown.bg = dropdownBg
  local offsetX = -4
  local offSetY = 8
  upBtn:AddAnchor("TOPRIGHT", dropdown, offsetX, offSetY)
  ApplyButtonSkin(upBtn, BUTTON_BASIC.SLIDER_UP)
  downBtn:AddAnchor("BOTTOMRIGHT", dropdown, offsetX, -offSetY)
  ApplyButtonSkin(downBtn, BUTTON_BASIC.SLIDER_DOWN)
  thumb:EnableDrag(true)
  ApplyButtonSkin(thumb, BUTTON_BASIC.SLIDER_VERTICAL_THUMB)
  vslider:SetMinThumbLength(50)
  local scrollBg = dropdown:CreateDrawable(TEXTURE_PATH.SCROLL, "scroll_frame_bg", "background")
  scrollBg:SetTextureColor("default")
  scrollBg:AddAnchor("TOPLEFT", vslider, 2, -9)
  scrollBg:AddAnchor("BOTTOMRIGHT", vslider, -3, 9)
  local function OnEnableChanged(self, enabled)
    local key = enabled and "editbox_df" or "editbox_dis"
    selectorBg:SetTextureInfo(key)
  end
  comboBox:SetHandler("OnEnableChanged", OnEnableChanged)
  local buttonMoveStep = 1
  local wheelMoveStep = 1
  local selectedIndex = 0
  local prevSelectedIndex = 0
  local guideStr = ""
  local guideTextAlwaysShow = false
  local maxItemCount = 0
  local curItemCount = 0
  local dropdownInfo
  local visibleItemCount = 0
  function comboBox:Clear()
    buttonMoveStep = 1
    wheelMoveStep = 1
    selectedIndex = 0
    prevSelectedIndex = 0
    guideStr = ""
    guideTextAlwaysShow = false
    maxItemCount = 0
    dropdownInfo = nil
    curItemCount = 0
    comboBox:SetEnable(false, true)
    selectorBtn:SetText("")
    dropdown:ClearItem()
  end
  local function HideDropdown()
    dropdown:Show(false)
    ShowSliderBar(false)
  end
  local function ShowDropdown(show)
    dropdown:Show(show)
  end
  local function ShowSliderBar(showScroll)
    upBtn:Show(showScroll)
    downBtn:Show(showScroll)
    thumb:Show(showScroll)
    vslider:Show(showScroll)
    scrollBg:Show(showScroll)
  end
  function comboBox:SetEnable(enable)
    comboBox:Enable(enable, true)
    if enable then
      selectorBtn.bg:SetTextureColor("default")
      comboBox:SetAlpha(1)
    else
      selectorBtn.bg:SetTextureColor("disable")
      comboBox:SetAlpha(4604480259023595110)
    end
  end
  function comboBox:SetGuideText(str, alwaysShow)
    guideStr = str
    if selectedIndex == 0 then
      selectorBtn:SetText(guideStr)
    end
    guideTextAlwaysShow = alwaysShow
  end
  local function SetItemDropdown(count)
    comboBox:SetDropdownVisibleLimit(count)
    local left, top, right, bottom = dropdown:GetInset()
    dropdown:SetExtent(selectorBtn:GetWidth(), count * dropdown:GetHeight() + top + bottom)
    local showScroll = false
    if count < maxItemCount then
      showScroll = true
      vslider:SetValue(0, false)
      vslider:SetMinMaxValues(0, dropdown:GetMaxTop())
    end
    ShowSliderBar(showScroll)
  end
  function comboBox:AppendItems(info, defaultSelectFirstItem, uneEnableSort)
    if info == nil then
      return
    end
    if type(info) ~= "table" then
      return
    end
    if #info == 0 then
      return
    end
    dropdownInfo = info
    maxItemCount = #info
    if visibleItemCount ~= 0 and visibleItemCount < maxItemCount then
      curItemCount = visibleItemCount
    else
      curItemCount = maxItemCount
    end
    dropdown:ClearItem()
    if useEnableSort == true then
      table.sort(info, function(a, b)
        return a.enable ~= false and b.enable == false
      end)
    end
    for i = 1, #dropdownInfo do
      dropdown:AppendItemByTable(dropdownInfo[i])
    end
    local enableCount = 0
    for i, v in ipairs(dropdownInfo) do
      if v.enable == nil or v.enable ~= nil and v.enable ~= false then
        enableCount = enableCount + 1
      end
    end
    SetItemDropdown(curItemCount)
    comboBox:SetEnable(enableCount > 0, true)
    if defaultSelectFirstItem ~= false then
      comboBox:Select(1)
    end
  end
  function comboBox:GetSelectedIndex()
    return selectedIndex
  end
  function comboBox:GetPrevSelectedIndex()
    return prevSelectedIndex
  end
  function comboBox:GetSelectedInfo()
    if dropdownInfo == nil then
      return
    end
    if selectedIndex == 0 or #dropdownInfo < selectedIndex then
      return
    end
    return dropdownInfo[selectedIndex]
  end
  function comboBox:GetIndexByValue(value)
    if dropdownInfo == nil then
      return 0
    end
    for i = 1, #dropdownInfo do
      if dropdownInfo[i].value == value then
        return i
      end
    end
    return 0
  end
  function comboBox:IsSelected()
    return selctedIndex ~= 0
  end
  function comboBox:ShowDropdownTooltip(show)
    showDropdownTooltip = show
  end
  function comboBox:SetVisibleItemCount(count)
    visibleItemCount = count
  end
  function comboBox:Select(index, callProc)
    if index == 0 then
      return
    end
    if dropdownInfo == nil then
      return
    end
    if index > #dropdownInfo then
      return
    end
    if callProc == nil then
      callProc = true
    end
    prevSelectedIndex = selectedIndex
    selectedIndex = index
    local str = ""
    local color = F_COLOR.GetColor("default")
    if guideTextAlwaysShow then
      str = guideStr
    else
      str = dropdownInfo[index].text
      if dropdownInfo[index].useColor then
        color = dropdownInfo[index].color
      end
    end
    selectorBtn:SetText(str)
    SetButtonFontOneColor(selectorBtn, color)
    if callProc and self.SelectedProc ~= nil then
      self:SelectedProc(selectedIndex)
    end
    dropdown:Select(index - 1, false)
  end
  function comboBox:SelectByValue(value, callProc)
    if value == nil then
      return
    end
    if dropdownInfo == nil then
      return
    end
    if callProc == nil then
      callProc = true
    end
    local index = 0
    for i, v in ipairs(dropdownInfo) do
      if v.value == value then
        index = i
        break
      end
    end
    self:Select(index, callProc)
  end
  function comboBox:SetEllipsis(isEllipsis, attachParam)
    selectorBtn.style:SetEllipsis(isEllipsis)
    dropdown.itemStyle:SetEllipsis(isEllipsis)
    if isEllipsis then
      F_TEXT.ApplyAutoEllipsisTooltipText(selectorBtn)
    end
  end
  function comboBox:OnContentUpdated(action, idx, val)
    if action ~= "ChangedValue" then
      return
    end
    self:Select(idx)
  end
  comboBox:SetHandler("OnContentUpdated", comboBox.OnContentUpdated)
  function OnSliderChanged(self, arg)
    dropdown:SetTop(arg)
  end
  vslider:SetHandler("OnSliderChanged", OnSliderChanged)
  function upBtn:OnClick()
    vslider:Up(buttonMoveStep)
  end
  upBtn:SetHandler("OnClick", upBtn.OnClick)
  function downBtn:OnClick()
    vslider:Down(buttonMoveStep)
  end
  downBtn:SetHandler("OnClick", downBtn.OnClick)
  function OnWheelUp()
    vslider:Up(wheelMoveStep)
  end
  dropdown:SetHandler("OnWheelUp", OnWheelUp)
  function OnWheelDown()
    vslider:Down(wheelMoveStep)
  end
  dropdown:SetHandler("OnWheelDown", OnWheelDown)
  function comboBox:OnTooltip(text, posX, posY, off)
    if off then
      HideTooltips()
      return
    end
    SetTooltipOnPos(text, self, posX, posY)
  end
  dropdown:SetHandler("OnTooltip", comboBox.OnTooltip)
  comboBox:Clear()
  return comboBox
end
