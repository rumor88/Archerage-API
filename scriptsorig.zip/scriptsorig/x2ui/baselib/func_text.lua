function F_TEXT.ConvertAbbreviatedBindingText(text)
  text = string.upper(text)
  for k, v in pairs(baselibLocale.bindingKeyModifierName) do
    text = string.gsub(text, k, v)
  end
  local offset = 0
  for k, v in pairs(baselibLocale.bindingKeyModifierName) do
    local l, r = string.find(text, v)
    if r ~= nil then
      offset = math.max(offset, r)
    end
  end
  local key = string.sub(text, -(string.len(text) - offset))
  local converted = baselibLocale.bindingKeyName[key]
  if converted ~= nil then
    text = string.gsub(text, key, converted)
  end
  return text
end
function F_TEXT.ApplyAutoEllipsisTooltipText(widget, diff)
  widget.style:SetEllipsis(true)
  local function OnEnter(self)
    local text = self:GetText()
    if text == nil or text == "" then
      return
    end
    local effecitveWidth, _ = self:GetEffectiveExtent()
    local widgetWidth = effecitveWidth - (diff or 0)
    if widgetWidth > self.style:GetTextWidth(text, false) then
      return
    end
    SetTooltip(text, self)
  end
  widget:SetHandler("OnEnter", OnEnter)
end
function F_TEXT.GetLimitInfoText(namePolicy)
  local strLimitLength = locale.changeName.limit_multi_lang_alphabet(locale.changeName.korean, tostring(namePolicy.local_min), tostring(namePolicy.local_max), locale.changeName.english, tostring(namePolicy.eng_min), tostring(namePolicy.eng_max))
  local strAllowOption
  if namePolicy.is_allow_mix_case == true then
    strAllowOption = locale.changeName.allow_mixcase
  end
  local MergeString = function(a, b)
    if a == nil then
      return b
    else
      return string.format("%s, %s", a, b)
    end
  end
  if namePolicy.is_allow_space == true then
    if namePolicy.limit_space_cnt == 0 then
      MergeString(strAllowOption, locale.changeName.allow_space)
    else
      MergeString(strAllowOption, locale.changeName.allow_space_limit(tostring(namePolicy.limit_space_cnt)))
    end
  end
  if namePolicy.is_allow_special_letter == true then
    MergeString(strAllowOption, locale.changeName.allow_special_character)
  end
  if strAllowOption ~= nil then
    return F_TEXT.SetEnterString(strLimitLength, string.format("(%s)", strAllowOption))
  else
    return strLimitLength
  end
end
function GetCommonText(key, a, b, c)
  return F_TEXT.GetCommonText(key, a, b, c)
end
function GetUIText(category, key, ...)
  return F_TEXT.GetUIText(category, key, ...)
end
