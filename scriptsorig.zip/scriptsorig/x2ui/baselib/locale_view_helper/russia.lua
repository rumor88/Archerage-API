if X2Util:GetGameProvider() == MAILRU then
  UIParent:SetUseInsertComma(false)
  localeView.systemConfig = {
    buttonOffsetX = {
      -107,
      8,
      107
    }
  }
  localeView.questContextList.systemChatBubbleDecoFormat = "%s"
end
