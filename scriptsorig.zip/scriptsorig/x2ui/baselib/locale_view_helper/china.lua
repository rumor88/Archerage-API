if X2Util:GetGameProvider() == TENCENT then
  localeView.useWebContent = false
  localeView.localGmCommand = 2
end
