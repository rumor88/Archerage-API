if X2Util:GetGameProvider() == GAMEON then
  localeView.useWebContent = true
  localeView.fpsInfoAnchor = {-295, 6}
end
