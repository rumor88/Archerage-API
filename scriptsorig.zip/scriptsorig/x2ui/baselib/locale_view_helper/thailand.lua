if X2Util:GetGameProvider() == XLGAMES_TH then
  UIParent:SetUseInsertComma(false)
  localeView.localGmCommand = 2
  localeView.systemConfig = {
    buttonOffsetX = {
      -107,
      8,
      107
    }
  }
  localeView.questContextList.systemChatBubbleDecoFormat = "%s"
end
