if localeView == nil then
  localeView = {}
end
localeView.useWebContent = true
localeView.localGmCommand = 1
localeView.fpsInfoAnchor = {-238, 6}
localeView.questContextList = {systemChatBubbleDecoFormat = "[%s]"}
