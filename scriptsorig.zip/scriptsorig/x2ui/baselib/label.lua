function W_CTRL.CreateLabel(id, parent)
  parent = parent or "UIParent"
  local label = UIParent:CreateWidget("label", id, parent)
  label.style:SetAlign(ALIGN_LEFT)
  label.style:SetSnap(true)
  label.style:SetColorByKey("default")
  return label
end
