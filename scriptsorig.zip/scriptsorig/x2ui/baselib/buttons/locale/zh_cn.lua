if X2Util:GetGameProvider() == KAKAONA and X2Locale:GetLocale() == "zh_cn" then
  BUTTON_CONTENTS.CUTSCENE_PLAY = {
    drawableType = "drawable",
    path = BUTTON_TEXTURE_PATH.CUTSCENE_PLAY,
    coordsKey = "btn_cutscene"
  }
end
