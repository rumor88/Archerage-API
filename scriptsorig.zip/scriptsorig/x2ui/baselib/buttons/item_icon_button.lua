local SetViewOfIconButton = function(id, parent, buttonType)
  local button
  if buttonType == "inventory" or buttonType == "constant" then
    button = UIParent:CreateWidget("slot", id, parent)
    button:ChangeIconLayer("background")
  else
    button = parent:CreateChildWidget("button", id, 0, true)
  end
  local back = button:CreateNinePartDrawable(TEXTURE_PATH.HUD, "background")
  button.back = back
  local icon = button:CreateIconDrawable("background")
  icon:AddAnchor("TOPLEFT", button, 1, 1)
  icon:AddAnchor("BOTTOMRIGHT", button, -1, -1)
  button.icon = icon
  local overImage = button:CreateDrawable(TEXTURE_PATH.HUD, "icon_button_ov", "overlay")
  overImage:AddAnchor("TOPLEFT", button, 1, 1)
  overImage:AddAnchor("BOTTOMRIGHT", button, -1, -1)
  button:SetHighlightBackground(overImage)
  function button:IsBuffType()
    return buttonType == "buff" or buttonType == "debuff"
  end
  if not button:IsBuffType() then
    local size = F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_42)
    button:SetExtent(size, size)
    F_SLOT.ApplySlotSkin(button, back, SLOT_STYLE.BAG_DEFAULT)
    W_ICON.CreateDestroyIcon(button)
    W_ICON.CreateOverlayStateImg(button)
    W_ICON.CreateDyeingIcon(button)
    W_ICON.CreateLimitLevel(button)
    W_ICON.CreateLookIcon(button)
    W_ICON.CreateOpenPaperItemIcon(button)
    W_ICON.CreateLifeTimeIcon(button)
    W_ICON.CreatePackIcon(button)
    W_ICON.CreateDisableEnchantItemIcon(button)
    W_ICON.CreateLockIcon(button)
    W_ICON.CreateStack(button)
    W_ICON.CreateChainIcon(button)
    W_ICON.CreateExpeditionRoleIcon(button)
  else
    local size = F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_30)
    button:SetExtent(size, size)
    local deco = button:CreateDrawable(TEXTURE_PATH.HUD, "buff_deco", "overlay")
    if buttonType == "buff" then
      F_SLOT.ApplySlotSkin(button, back, SLOT_STYLE.BUFF)
      deco:SetTextureInfo("buff_deco", "default")
      deco:AddAnchor("BOTTOM", button, 0, 0)
    else
      F_SLOT.ApplySlotSkin(button, back, SLOT_STYLE.DEBUFF)
      deco:SetTextureInfo("debuff_deco", "default")
      deco:AddAnchor("TOP", button, 0, 0)
    end
  end
  local boxImg, checkImg
  function button:CreateHighlightedImg(type)
    if boxImg ~= nil then
      return
    end
    boxImg = F_TEXTURE.CreateIconHighlight(self, type)
  end
  function button:ShowHighlightedImg(show)
    if boxImg ~= nil then
      boxImg:Show(show)
    end
    self:SetVisibleCheck(show)
  end
  return button
end
function CreateIconButton(id, parent, buttonType)
  local button = SetViewOfIconButton(id, parent, buttonType)
  button.forceVisible = false
  function button:SetForceVisible(visible)
    button.forceVisible = visible
  end
  function button:GetForceVisible()
    return button.forceVisible
  end
  function button:GetInfo()
    return self.info
  end
  function button:SetVisibleIconBack(visible)
    self.back:SetVisible(visible)
  end
  local SetItemIcons = function(button, iconPath, overIcon, gradeIcon, sideEffect)
    itemIconParam = {}
    button.icon:ClearAllTextures()
    if iconPath ~= nil then
      button.icon:AddTexture(iconPath)
    end
    if overIcon ~= nil then
      button.icon:AddTexture(overIcon)
    end
    if gradeIcon ~= nil then
      button.icon:AddTexture(gradeIcon)
    end
    if baselibLocale.itemSideEffect == true then
      local sideEffectVisible = false
      if iconPath ~= nil and sideEffect ~= nil and sideEffect == true then
        sideEffectVisible = true
        if button.sideEffect == nil then
          button.sideEffect = W_ICON.DrawItemSideEffectBackground(button)
        end
      end
      if button.sideEffect ~= nil then
        button:Anim_Item_Side_effect(sideEffectVisible)
      end
    end
    if not button:IsBuffType() then
      if button:GetForceVisible() == false and iconPath == nil then
        button.back:SetColor(1, 1, 1, 4599075939470750515)
      else
        button.back:SetColor(1, 1, 1, 1)
      end
    end
  end
  function button:SetItemIcon(itemType, itemGrade, info)
    if itemType == nil or itemGrade == nil then
      SetItemIcons(self)
      return
    end
    local sideEffect = X2Item:GetItemSideEffect(itemType)
    if info ~= nil and info.icon ~= nil and info.gradeIcon ~= nil then
      SetItemIcons(self, info.icon, info.overIcon, info.gradeIcon, sideEffect)
    else
      local iconInfo = X2Item:GetItemIconSet(itemType, itemGrade)
      if iconInfo == nil then
        return
      end
      SetItemIcons(self, iconInfo.icon, iconInfo.overIcon, iconInfo.gradeIcon, sideEffect)
    end
  end
  function button:SetIconDirectly(directIconInfo)
    SetItemIcons(self, directIconInfo.icon, directIconInfo.overIcon, directIconInfo.gradeIcon, false)
  end
  function button:SetInfo(info)
    self.info = info
    if info == nil then
      self:Init()
      return
    end
    if self:IsBuffType() then
      SetItemIcons(self, info.path or info.iconPath)
    elseif buttonType == "ucc" then
      SetItemIcons(self, info.path or info.iconPath)
      self:SetTooltip(nil)
    elseif buttonType == "stamp" or buttonType == "faction" then
      SetItemIcons(self, info.path or info.iconPath)
      self:SetLimitLevelManualHandling(info)
      self:SetLifeTimeIcon(info)
      if not info.showTooltip then
        self:SetTooltip(nil)
      end
    elseif buttonType == "textureWithCoords" then
      button.icon:AddTextureWithInfo(info.texturePath, info.coords)
      self:SetTooltip(nil)
      self.tooltipText = info.tooltipText
    else
      local itype = info.itemType
      if info.lookType ~= nil and info.lookType ~= 0 then
        itype = info.lookType
      end
      if itype == 0 then
        self:Init()
        return
      end
      if buttonType == "constant" then
        self:EstablishItem(itype, info.itemGrade)
      end
      self:SetItemIcon(itype, info.itemGrade, info)
      if math.floor(self:GetWidth()) <= F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_24) then
        return
      end
      self:SetDyeingInfo(info)
      self:SetLockInfo(info)
      self:SetPackInfo(info)
      self:SetDestroyInfo(info)
      self:SetLookIcon(info)
      self:SetLifeTimeIcon(info)
      self:SetPaperInfo(info)
      self:SetOverlay(info)
      self:SetDisableEnchantInfo(info)
      self:SetTooltip(info)
      self:SetChainInfo(info)
    end
  end
  function button:SetTooltip(info)
    self.info = info
  end
  local OnEnter = function(self)
    if self.procOnEnter ~= nil then
      self:procOnEnter()
    end
    if self.tooltipText ~= nil then
      SetTooltip(self.tooltipText, self)
      return
    end
    if self.info ~= nil then
      ShowTooltip(self.info, self)
    end
  end
  button:SetHandler("OnEnter", OnEnter)
  local OnClick = function(self, arg)
    HideTooltip()
    if self.OnClickProc ~= nil then
      self:OnClickProc(arg)
    end
  end
  button:SetHandler("OnClick", OnClick)
  function button:ReregisterClickHandler()
    self:SetHandler("OnClick", OnClick)
  end
  local OnLeave = function()
    HideTooltip()
  end
  button:SetHandler("OnLeave", OnLeave)
  function button:Init()
    if buttonType == "constant" then
      self:ReleaseSlot()
    end
    self:SetTooltip(nil)
    if not button:IsBuffType() then
      self:SetItemIcon(nil)
      self:SetPackInfo(nil)
      self:SetDestroyInfo(nil)
      self:SetOverlay(nil)
      self:SetPaperInfo(nil)
      self:SetLifeTimeIcon(nil)
      self:ResetStack()
      self:SetDyeingInfo(nil)
      self:SetLookIcon(nil)
      self:SetLifeTimeIcon(nil)
      self:SetDisableEnchantInfo(nil)
      self:SetChainInfo(nil)
    end
    if HideTooltip ~= nil then
      HideTooltip()
    end
  end
  button:Init()
  local OnEnableChanged = function(self, enabled)
    self:SetDisableColor(enabled)
  end
  button:SetHandler("OnEnableChanged", OnEnableChanged)
  function button:SetDisableColor(enabled)
    local alpha = self.searchColored and 4596373779694328218 or 1
    if button:IsEnabled() and enabled == true then
      self.icon:SetColor(1, 1, 1, alpha)
    else
      self.icon:SetColor(4602678819172646912, 4602678819172646912, 4602678819172646912, alpha)
    end
  end
  return button
end
