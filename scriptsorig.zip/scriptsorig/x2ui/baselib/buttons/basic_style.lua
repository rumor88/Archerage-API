local EXPEDITION_ROLE_BUTTON_EXTENT = {WIDTH = 82, HEIGHT = 53}
local EXPEDITION_ROLE_BUTTON_OFFSET = {X = 12, Y = 2}
BUTTON_BASIC = {
  TAB_SELECT = {
    drawableType = "threePart",
    path = TEXTURE_PATH.TAB_LIST,
    coordsKey = "tab_selected",
    fontColor = GetTitleButtonFontColor(),
    fontSize = FONT_SIZE.LARGE,
    fontInset = {
      left = 15,
      right = 15,
      top = 1,
      bottom = 0
    },
    autoResize = true
  },
  TAB_UNSELECT = {
    drawableType = "threePart",
    path = TEXTURE_PATH.TAB_LIST,
    coordsKey = "tab_unselected",
    fontColor = GetTitleButtonFontColor(),
    fontSize = FONT_SIZE.LARGE,
    fontInset = {
      left = 15,
      right = 15,
      top = 1,
      bottom = 0
    },
    autoResize = true
  },
  TAB_SELECT_BATTLEFIELD_RESULT = {
    drawableType = "threePart",
    path = TEXTURE_PATH.BATTLEFIELD_RESULT_FACTION,
    coordsKey = "tab_selected",
    fontColor = GetWhiteButtonFontColor(),
    fontSize = FONT_SIZE.MIDDLE,
    fontInset = {
      left = 15,
      right = 15,
      top = 0,
      bottom = 0
    },
    ellipsis = true
  },
  TAB_UNSELECT_BATTLEFIELD_RESULT = {
    drawableType = "threePart",
    path = TEXTURE_PATH.BATTLEFIELD_RESULT_FACTION,
    coordsKey = "tab_unselected",
    fontColor = GetWhiteButtonFontColor(),
    fontSize = FONT_SIZE.MIDDLE,
    fontInset = {
      left = 15,
      right = 15,
      top = 0,
      bottom = 0
    },
    ellipsis = true
  },
  TAB_SELECT_RAID = {
    drawableType = "drawable",
    path = TEXTURE_PATH.RAID_TAB,
    coordsKey = "raid_tab_select",
    fontColor = GetWhiteButtonFontColor(),
    fontSize = FONT_SIZE.MIDDLE,
    fontInset = {
      left = 0,
      right = 5,
      top = 5,
      bottom = 0
    },
    fontAlign = ALIGN_RIGHT,
    autoResize = true
  },
  TAB_UNSELECT_RAID = {
    drawableType = "drawable",
    path = TEXTURE_PATH.RAID_TAB,
    coordsKey = "raid_tab",
    fontColor = GetWhiteButtonFontColor(),
    fontSize = FONT_SIZE.MIDDLE,
    fontInset = {
      left = 0,
      right = 5,
      top = 5,
      bottom = 0
    },
    fontAlign = ALIGN_RIGHT,
    autoResize = true
  },
  SLIDER_VERTICAL_THUMB = {
    drawableType = "ninePart",
    path = "ui/button/scroll_button.dds",
    coordsKey = "thumb"
  },
  SLIDER_VERTICAL_MINI_THUMB = {
    drawableType = "drawable",
    path = "ui/button/scroll_button.dds",
    coordsKey = "mini_btn"
  },
  SLIDER_UP = {
    drawableType = "drawable",
    path = "ui/button/scroll_button.dds",
    coordsKey = "scroll_button_up",
    useSameTexture = true,
    drawableColorKey = {
      normal = "normal",
      over = "over",
      click = "click",
      disable = "disable"
    }
  },
  SLIDER_DOWN = {
    drawableType = "drawable",
    path = "ui/button/scroll_button.dds",
    coordsKey = "scroll_button_down",
    useSameTexture = true,
    drawableColorKey = {
      normal = "normal",
      over = "over",
      click = "click",
      disable = "disable"
    }
  },
  RESET = {
    drawableType = "drawable",
    path = BUTTON_TEXTURE_PATH.COMMON_RESET,
    coordsKey = "reset"
  },
  REMOVE = {
    drawableType = "drawable",
    path = BUTTON_TEXTURE_PATH.COMMON_REMOVE,
    coordsKey = "remove"
  },
  LISTCTRL_COLUMN = {
    drawableType = "threePart",
    path = TEXTURE_PATH.TAB_LIST,
    coordsKey = "column",
    useSameTexture = true,
    disuseExtent = true,
    drawableColorKey = {
      normal = "none",
      over = "over",
      click = "click",
      disable = "none"
    },
    fontInset = {
      left = 0,
      right = 0,
      top = 8,
      bottom = 0
    },
    fontSize = FONT_SIZE.LARGE
  },
  QUEST_NOTIFIER = {
    {
      drawableType = "threePart",
      path = TEXTURE_PATH.CHAT,
      coordsKey = "tab_quest_bg",
      drawableColorKey = {
        normal = "default",
        over = "default",
        click = "default",
        disable = "default"
      }
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.HUD,
      drawableAnchor = {
        anchor = "BOTTOM",
        x = 0,
        y = 0
      },
      coordsKey = "tab_quest"
    }
  },
  CHRONICLE_NOTIFIER = {
    {
      drawableType = "threePart",
      path = TEXTURE_PATH.CHAT,
      coordsKey = "tab_quest_bg",
      drawableColor = {
        normal = "default",
        over = "default",
        click = "default",
        disable = "default"
      }
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.HUD,
      coordsKey = "chronicle",
      drawableAnchor = {
        anchor = "BOTTOM",
        x = 0,
        y = -5
      }
    }
  },
  ASSIGNMENT_NOTIFIER = {
    {
      drawableType = "threePart",
      path = TEXTURE_PATH.CHAT,
      coordsKey = "tab_quest_bg",
      drawableColor = {
        normal = "default",
        over = "default",
        click = "default",
        disable = "default"
      }
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.HUD,
      coordsKey = "tab_result",
      drawableAnchor = {
        anchor = "BOTTOM",
        x = 0,
        y = 0
      }
    }
  },
  AUCTION_POST_MIN_STACK = {
    drawableType = "ninePart",
    path = TEXTURE_PATH.DEFAULT,
    coordsKey = "btn_num",
    autoResize = true
  },
  AUCTION_BID_STACK = {
    drawableType = "ninePart",
    path = TEXTURE_PATH.DEFAULT,
    coordsKey = "btn_buy_num",
    autoResize = true
  },
  GUILDBANK_CELL_BUTTON = {
    drawableType = "drawable",
    path = "ui/button/guildbank_cell_button.dds",
    coordsKey = "cell"
  }
}
BUTTON_CONTENTS = {
  FAVORITE_CHECK = {
    drawableType = "drawable",
    path = TEXTURE_PATH.BOOKMARK,
    coordsKey = "bookmark"
  },
  CRAFT_FAVORITE_CATEGORY = {
    drawableType = "drawable",
    path = TEXTURE_PATH.CRAFT_POSITION_BUTTON,
    coordsKey = "bookmark"
  },
  MAP_SCALE = {
    {
      drawableType = "drawable",
      path = BUTTON_TEXTURE_PATH.MAP,
      coordsKey = "map_scale_1"
    },
    {
      drawableType = "drawable",
      path = BUTTON_TEXTURE_PATH.MAP,
      coordsKey = "map_scale_2"
    },
    {
      drawableType = "drawable",
      path = BUTTON_TEXTURE_PATH.MAP,
      coordsKey = "map_scale_3"
    }
  },
  MAP_FILTER_OPEN = {
    drawableType = "drawable",
    path = BUTTON_TEXTURE_PATH.MAP,
    coordsKey = "filter_open"
  },
  MAP_FILTER_CLOSE = {
    drawableType = "drawable",
    path = BUTTON_TEXTURE_PATH.MAP,
    coordsKey = "filter_close"
  },
  MAP_PING_BTN = {
    drawableType = "drawable",
    path = BUTTON_TEXTURE_PATH.MAP,
    coordsKey = "mark"
  },
  MAP_ROUTE_BTN = {
    drawableType = "drawable",
    path = BUTTON_TEXTURE_PATH.MAP,
    coordsKey = "line"
  },
  MAP_ENEMY_BTN = {
    drawableType = "drawable",
    path = BUTTON_TEXTURE_PATH.MAP,
    coordsKey = "enemy"
  },
  MAP_ATTACK_BTN = {
    drawableType = "drawable",
    path = BUTTON_TEXTURE_PATH.MAP,
    coordsKey = "attack"
  },
  MAP_LINE_BTN = {
    drawableType = "drawable",
    path = BUTTON_TEXTURE_PATH.MAP,
    coordsKey = "drawing"
  },
  CINEMA_NEXT = {
    drawableType = "drawable",
    path = BUTTON_TEXTURE_PATH.CINEMA,
    coordsKey = "next",
    drawableAnchor = {
      anchor = "TOP",
      x = -1,
      y = 0
    },
    fontSize = FONT_SIZE.LARGE,
    fontAlign = ALIGN_BOTTOM,
    width = 80,
    height = 65,
    fontColor = GetQuestDirectingButtonFontColor()
  },
  CINEMA_PREV = {
    drawableType = "drawable",
    path = BUTTON_TEXTURE_PATH.CINEMA,
    coordsKey = "prev",
    drawableAnchor = {
      anchor = "TOP",
      x = -1,
      y = 0
    },
    fontSize = FONT_SIZE.LARGE,
    fontAlign = ALIGN_BOTTOM,
    width = 80,
    height = 65,
    fontColor = GetQuestDirectingButtonFontColor()
  },
  CINEMA_ACCEPT = {
    drawableType = "drawable",
    path = BUTTON_TEXTURE_PATH.CINEMA,
    coordsKey = "accept",
    drawableAnchor = {
      anchor = "TOP",
      x = 0,
      y = 0
    },
    fontSize = FONT_SIZE.LARGE,
    fontAlign = ALIGN_BOTTOM,
    width = 80,
    height = 65,
    fontColor = GetQuestDirectingButtonFontColor()
  },
  CINEMA_QUEST = {
    drawableType = "threePart",
    path = BUTTON_TEXTURE_PATH.CINEMA,
    coordsKey = "quest_effect",
    fontColor = {
      normal = F_COLOR.GetColor("white"),
      highlight = F_COLOR.GetColor("soft_yellow"),
      pushed = F_COLOR.GetColor("white"),
      disabled = F_COLOR.GetColor("white")
    },
    width = 30,
    height = 30,
    autoResize = true,
    fontAlign = ALIGN_LEFT,
    fontPath = FONT_PATH.DEFAULT,
    fontSize = FONT_SIZE.XLARGE
  },
  PREV_PAGE = {
    drawableType = "drawable",
    path = BUTTON_TEXTURE_PATH.COMMON_BACK,
    coordsKey = "back_btn",
    fontInset = {
      left = 30,
      top = 5,
      right = 0,
      bottom = 0
    },
    drawableAnchor = {
      anchor = "LEFT",
      x = 0,
      y = 0
    },
    fontAlign = ALIGN_LEFT,
    autoResize = true
  },
  REWARD_ITEM = {
    drawableType = "drawable",
    path = "ui/button/reward.dds",
    coordsKey = "reward_item",
    fontInset = {
      left = 50,
      top = 0,
      right = 10,
      bottom = 0
    },
    fontAlign = ALIGN_LEFT,
    ellipsis = true,
    fontColor = GetButtonDefaultFontColor()
  },
  HIDDEN_QUEST_REWARD_ITEM = {
    drawableType = "drawable",
    path = "ui/button/reward.dds",
    coordsKey = "reward_item_small",
    fontInset = {
      left = 50,
      top = 0,
      right = 10,
      bottom = 0
    },
    fontAlign = ALIGN_LEFT,
    ellipsis = true,
    fontColor = GetButtonDefaultFontColor()
  },
  OPTION_LIST = {
    drawableType = "drawable",
    path = TEXTURE_PATH.DEFAULT,
    coordsKey = "option",
    colorKey = "default",
    fontColor = GetOptionListButtonFontColor()
  },
  OPTION_KEY = {
    drawableType = "drawable",
    path = TEXTURE_PATH.OPTION,
    coordsKey = "key_binding",
    useSameTexture = true,
    drawableColorKey = {
      normal = "normal",
      over = "over",
      click = "click",
      disable = "disable"
    },
    fontSize = FONT_SIZE.SMALL,
    fontColor = GetOptionListKeyButtonFontColor()
  },
  OPTION_KEY_OVERRIDABLE = {
    drawableType = "drawable",
    path = TEXTURE_PATH.OPTION,
    coordsKey = "key_binding",
    useSameTexture = true,
    drawableColorKey = {
      normal = "overridable_normal",
      over = "overridable_over",
      click = "overridable_click",
      disable = "overridable_disable"
    },
    fontSize = FONT_SIZE.SMALL,
    fontColor = GetOptionListOverrideKeyButtonFontColor()
  },
  ALL_ABILITY = {
    drawableType = "threePart",
    path = TEXTURE_PATH.SKILL_ABILITY,
    coordsKey = "btn_skill",
    fontColor = {
      normal = F_COLOR.GetColor("default"),
      highlight = F_COLOR.GetColor("default"),
      pushed = F_COLOR.GetColor("default"),
      disabled = F_COLOR.GetColor("gray")
    },
    fontSize = FONT_SIZE.LARGE
  },
  EXPEDITION_ROLE_1 = {
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.EXPEDITION,
      coordsKey = "background",
      drawableAnchor = {
        anchor = "CENTER",
        x = EXPEDITION_ROLE_BUTTON_OFFSET.X,
        y = EXPEDITION_ROLE_BUTTON_OFFSET.Y
      },
      width = EXPEDITION_ROLE_BUTTON_EXTENT.WIDTH,
      height = EXPEDITION_ROLE_BUTTON_EXTENT.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.EXPEDITION,
      coordsKey = "owner",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = 0
      }
    }
  },
  EXPEDITION_ROLE_2 = {
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.EXPEDITION,
      coordsKey = "background",
      drawableAnchor = {
        anchor = "CENTER",
        x = EXPEDITION_ROLE_BUTTON_OFFSET.X,
        y = EXPEDITION_ROLE_BUTTON_OFFSET.Y
      },
      width = EXPEDITION_ROLE_BUTTON_EXTENT.WIDTH,
      height = EXPEDITION_ROLE_BUTTON_EXTENT.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.EXPEDITION,
      coordsKey = "subowner",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = 0
      }
    }
  },
  EXPEDITION_ROLE_3 = {
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.EXPEDITION,
      coordsKey = "background",
      drawableAnchor = {
        anchor = "CENTER",
        x = EXPEDITION_ROLE_BUTTON_OFFSET.X,
        y = EXPEDITION_ROLE_BUTTON_OFFSET.Y
      },
      width = EXPEDITION_ROLE_BUTTON_EXTENT.WIDTH,
      height = EXPEDITION_ROLE_BUTTON_EXTENT.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.EXPEDITION,
      coordsKey = "officer",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = 0
      }
    }
  },
  EXPEDITION_ROLE_4 = {
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.EXPEDITION,
      coordsKey = "background",
      drawableAnchor = {
        anchor = "CENTER",
        x = EXPEDITION_ROLE_BUTTON_OFFSET.X,
        y = EXPEDITION_ROLE_BUTTON_OFFSET.Y
      },
      width = EXPEDITION_ROLE_BUTTON_EXTENT.WIDTH,
      height = EXPEDITION_ROLE_BUTTON_EXTENT.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.EXPEDITION,
      coordsKey = "member",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = 0
      }
    }
  },
  EXPEDITION_ROLE_5 = {
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.EXPEDITION,
      coordsKey = "background",
      drawableAnchor = {
        anchor = "CENTER",
        x = EXPEDITION_ROLE_BUTTON_OFFSET.X,
        y = EXPEDITION_ROLE_BUTTON_OFFSET.Y
      },
      width = EXPEDITION_ROLE_BUTTON_EXTENT.WIDTH,
      height = EXPEDITION_ROLE_BUTTON_EXTENT.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.EXPEDITION,
      coordsKey = "none",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = 0
      }
    }
  },
  BAG_ICON = {
    drawableType = "drawable",
    path = TEXTURE_PATH.INVENTORY_DEFAULT,
    coordsKey = "bg"
  },
  BAG_TAB_ICON = {
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_01",
      drawableAnchor = {
        anchor = "CENTER",
        x = 2,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_02",
      drawableAnchor = {
        anchor = "CENTER",
        x = 1,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_03",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_04",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_05",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_06",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_07",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_08",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_09",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_10",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_11",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_12",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_13",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_14",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_15",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_16",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_17",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.INVENTORY_DEFAULT,
      coordsKey = "tab_icon_18",
      drawableAnchor = {
        anchor = "CENTER",
        x = 0,
        y = -1
      },
      width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
      height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
    }
  },
  INVENTORY_TAB_ADD = {
    drawableType = "drawable",
    path = TEXTURE_PATH.INVENTORY_DEFAULT,
    coordsKey = "tab_add",
    drawableAnchor = {
      anchor = "CENTER",
      x = 0,
      y = 2
    },
    width = BUTTON_SIZE.IMAGE_TAB.WIDTH,
    height = BUTTON_SIZE.IMAGE_TAB.HEIGHT
  },
  PET_STATE = {
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.PET,
      coordsKey = "btn_knife"
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.PET,
      coordsKey = "btn_shield"
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.PET,
      coordsKey = "btn_arrow"
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.PET,
      coordsKey = "btn_hand"
    }
  },
  EQUIP_UP = {
    drawableType = "drawable",
    path = "ui/button/scroll_button.dds",
    coordsKey = "scroll_button_up",
    useSameTexture = true,
    drawableColorKey = {
      normal = "costume_df",
      over = "costume_ov",
      click = "costume_on",
      disable = "costume_dis"
    }
  },
  EQUIP_DOWN = {
    drawableType = "drawable",
    path = "ui/button/scroll_button.dds",
    coordsKey = "scroll_button_down",
    useSameTexture = true,
    drawableColorKey = {
      normal = "costume_df",
      over = "costume_ov",
      click = "costume_on",
      disable = "costume_dis"
    }
  },
  BOOK_READ = {
    drawableType = "drawable",
    path = TEXTURE_PATH.PAPER_DECO,
    coordsKey = "btn_skill"
  },
  INGAMESHOP_SUB_MENU_SELECTED = {
    drawableType = "colorDrawable",
    drawableColor = {
      normal = {
        1,
        1,
        1,
        0
      },
      over = {
        1,
        1,
        1,
        0
      },
      click = {
        1,
        1,
        1,
        0
      },
      disable = {
        1,
        1,
        1,
        0
      }
    },
    fontColor = GetIngameShopSelectedSubMenuButtonFontColor(),
    width = 20,
    height = 20
  },
  INGAMESHOP_SUB_MENU_UNSELECTED = {
    drawableType = "colorDrawable",
    drawableColor = {
      normal = {
        1,
        1,
        1,
        0
      },
      over = {
        1,
        1,
        1,
        0
      },
      click = {
        1,
        1,
        1,
        0
      },
      disable = {
        1,
        1,
        1,
        0
      }
    },
    fontColor = GetIngameShopUnselectedSubMenuButtonFontColor(),
    width = 20,
    height = 20
  },
  REPUTATION_GOOD = {
    drawableType = "drawable",
    path = TEXTURE_PATH.REPUTATION,
    coordsKey = "btn_good",
    fontAlign = ALIGN_BOTTOM,
    drawableAnchor = {
      anchor = "TOP",
      x = 0,
      y = 0
    },
    fontColor = {
      normal = F_COLOR.GetColor("gender_male"),
      highlight = F_COLOR.GetColor("blue"),
      pushed = F_COLOR.GetColor("blue"),
      disabled = F_COLOR.GetColor("default")
    },
    fontSize = FONT_SIZE.XLARGE,
    fontPath = FONT_PATH.SUB
  },
  REPUTATION_NOGOOD = {
    drawableType = "drawable",
    path = TEXTURE_PATH.REPUTATION,
    coordsKey = "btn_nogood",
    fontAlign = ALIGN_BOTTOM,
    drawableAnchor = {
      anchor = "TOP",
      x = 0,
      y = 0
    },
    fontColor = {
      normal = F_COLOR.GetColor("gender_female"),
      highlight = F_COLOR.GetColor("rose_pink"),
      pushed = F_COLOR.GetColor("rose_pink"),
      disabled = F_COLOR.GetColor("default")
    },
    fontSize = FONT_SIZE.XLARGE,
    fontPath = FONT_PATH.SUB
  },
  INGAMESHOP_COMMERCIAL_MAIL_OLD = {
    drawableType = "drawable",
    path = "ui/itemshopold.dds",
    coordsKey = "mail"
  },
  ENCHANT_TAB_EVOLVING = {
    drawableType = "drawable",
    path = TEXTURE_PATH.ENCHANT_TAB,
    coordsKey = "compose"
  },
  ENCHANT_TAB_GRADE = {
    drawableType = "drawable",
    path = TEXTURE_PATH.ENCHANT_TAB,
    coordsKey = "grade"
  },
  ENCHANT_TAB_SOCKET = {
    drawableType = "drawable",
    path = TEXTURE_PATH.ENCHANT_TAB,
    coordsKey = "crescent_moon"
  },
  ENCHANT_TAB_GEM = {
    drawableType = "drawable",
    path = TEXTURE_PATH.ENCHANT_TAB,
    coordsKey = "full_moon"
  },
  ENCHANT_TAB_SCALE = {
    drawableType = "drawable",
    path = TEXTURE_PATH.ENCHANT_TAB,
    coordsKey = "refurbishment"
  },
  ENCHANT_TAB_SMELTING = {
    drawableType = "drawable",
    path = TEXTURE_PATH.ENCHANT_TAB,
    coordsKey = "smelt"
  },
  ENCHANT_TAB_AWAKEN = {
    drawableType = "drawable",
    path = TEXTURE_PATH.ENCHANT_TAB,
    coordsKey = "awaken"
  },
  COMMUNITY_TAB_RELATION = {
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.COMMUNITY_BUTTON,
      coordsKey = "btn_bg",
      colorKey = "default",
      fontSize = 15,
      fontAlign = ALIGN_LEFT,
      fontInset = {
        left = 54,
        top = 0,
        bottom = 0,
        right = 0
      }
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.COMMUNITY_BUTTON,
      coordsKey = "relation",
      drawableAnchor = {
        anchor = "LEFT",
        x = 0,
        y = 0
      }
    }
  },
  COMMUNITY_TAB_FAMILY = {
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.COMMUNITY_BUTTON,
      coordsKey = "btn_bg",
      colorKey = "default",
      fontSize = 15,
      fontAlign = ALIGN_LEFT,
      fontInset = {
        left = 58,
        top = 0,
        bottom = 0,
        right = 0
      }
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.COMMUNITY_BUTTON,
      coordsKey = "family",
      drawableAnchor = {
        anchor = "LEFT",
        x = 0,
        y = 0
      }
    }
  },
  COMMUNITY_TAB_EXPEDITION = {
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.COMMUNITY_BUTTON,
      coordsKey = "btn_bg",
      colorKey = "default",
      fontSize = 15,
      fontAlign = ALIGN_LEFT,
      fontInset = {
        left = 54,
        top = 0,
        bottom = 0,
        right = 0
      }
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.COMMUNITY_BUTTON,
      coordsKey = "expedition",
      drawableAnchor = {
        anchor = "LEFT",
        x = 0,
        y = 0
      }
    }
  },
  COMMUNITY_TAB_NATION = {
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.COMMUNITY_BUTTON,
      coordsKey = "btn_bg",
      colorKey = "default",
      fontSize = 15,
      fontAlign = ALIGN_LEFT,
      fontInset = {
        left = 58,
        top = 0,
        bottom = 0,
        right = 0
      }
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.COMMUNITY_BUTTON,
      coordsKey = "nation",
      drawableAnchor = {
        anchor = "LEFT",
        x = 0,
        y = 0
      }
    }
  },
  CHARACTER_INFO_SUB_TAB_ATTACK = {
    drawableType = "drawable",
    path = TEXTURE_PATH.CHARACTER_INFO_SUB_TAB,
    coordsKey = "attack"
  },
  CHARACTER_INFO_SUB_TAB_DEFENCE = {
    drawableType = "drawable",
    path = TEXTURE_PATH.CHARACTER_INFO_SUB_TAB,
    coordsKey = "defend"
  },
  CHARACTER_INFO_SUB_TAB_RECOVERY = {
    drawableType = "drawable",
    path = TEXTURE_PATH.CHARACTER_INFO_SUB_TAB,
    coordsKey = "etc"
  },
  CHARACTER_INFO_SUB_TAB_ELEMENT = {
    drawableType = "drawable",
    path = TEXTURE_PATH.CHARACTER_INFO_SUB_TAB,
    coordsKey = "element"
  }
}
BUTTON_HUD = {
  MAP_ZOOMINOUT_SLIDER = {
    drawableType = "drawable",
    path = TEXTURE_PATH.HUD,
    coordsKey = "map_btn_slider"
  },
  TIMER = {
    drawableType = "drawable",
    layer = "overlay",
    path = TEXTURE_PATH.TIMER,
    coordsKey = "item_btn"
  },
  COMBAT_RESOURCE_TAB = {
    {
      drawableType = "threePart",
      path = TEXTURE_PATH.CHAT,
      coordsKey = "tab_quest_bg",
      drawableColorKey = {
        normal = "default",
        over = "default",
        click = "default",
        disable = "default"
      },
      drawableAnchor = {
        anchor = "BOTTOMLEFT",
        x = 0,
        y = 0
      }
    },
    {
      drawableType = "drawable",
      path = TEXTURE_PATH.HUD,
      coordsKey = "tab_resources",
      drawableAnchor = {
        anchor = "BOTTOM",
        x = 0,
        y = 0
      }
    }
  }
}
BUTTON_LOGINSTAGE = {
  CUSTOM_SAVE_LOAD = {
    drawableType = "drawable",
    path = LOGIN_STAGE_TEXTURE_PATH.SAVE_LOAD,
    coordsKey = "list",
    fontInset = {
      left = 70,
      top = 0,
      right = 0,
      bottom = 0
    },
    fontAlign = ALIGN_LEFT,
    fontColor = GetButtonDefaultFontColor()
  }
}
