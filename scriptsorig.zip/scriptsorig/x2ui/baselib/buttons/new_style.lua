BUTTON_STYLE = {
  TRANSFER = {
    drawableType = "threePart",
    path = TEXTURE_PATH.SERVER_SELECT,
    coordsKey = "server_transfer",
    fontColorKey = "white",
    fontSize = FONT_SIZE.LARGE,
    autoResize = true,
    fontInset = {
      left = 8,
      right = 8,
      top = 0,
      bottom = 0
    }
  },
  POS_PICKER = {
    drawableType = "drawable",
    path = TEXTURE_PATH.CUSTOMIZING,
    coordsKey = "tattoo_position"
  },
  CUSTOMIZING_SELECTION = {
    drawableType = "ninePart",
    path = TEXTURE_PATH.CUSTOMIZING,
    layer = "overlay",
    coordsKey = "selected",
    useSameTexture = true,
    drawableColorKey = {
      normal = "alpha_0",
      over = "alpha_100",
      click = "alpha_100",
      disable = "alpha_0"
    }
  },
  RESET_BIG = {
    drawableType = "drawable",
    path = "ui/button/common/reset_big.dds",
    coordsKey = "reset"
  }
}
