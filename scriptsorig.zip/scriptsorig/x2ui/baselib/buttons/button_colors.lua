function GetButtonDefaultFontColor()
  local color = {}
  color.normal = F_COLOR.GetColor("btn_normal")
  color.highlight = F_COLOR.GetColor("btn_highlighted")
  color.pushed = F_COLOR.GetColor("btn_pushed")
  color.disabled = F_COLOR.GetColor("btn_disabled")
  return color
end
function GetTitleButtonFontColor()
  local color = {}
  color.normal = F_COLOR.GetColor("middle_title")
  color.highlight = F_COLOR.GetColor("middle_title")
  color.pushed = F_COLOR.GetColor("middle_title")
  color.disabled = F_COLOR.GetColor("title_button_dis")
  return color
end
function GetWhiteButtonFontColor()
  local color = {}
  color.normal = F_COLOR.GetColor("white_buttton_df")
  color.highlight = F_COLOR.GetColor("white")
  color.pushed = F_COLOR.GetColor("white_buttton_on")
  color.disabled = F_COLOR.GetColor("white_buttton_dis")
  return color
end
function GetOptionListButtonFontColor()
  local color = {}
  color.normal = F_COLOR.GetColor("default")
  color.highlight = F_COLOR.GetColor("blue")
  color.pushed = F_COLOR.GetColor("blue")
  color.disabled = F_COLOR.GetColor("option_list_button_dis")
  return color
end
function GetOptionListKeyButtonFontColor()
  local color = {}
  color.normal = F_COLOR.GetColor("white")
  color.highlight = F_COLOR.GetColor("option_key_list_button_ov")
  color.pushed = F_COLOR.GetColor("white")
  color.disabled = F_COLOR.GetColor("option_list_button_dis")
  return color
end
function GetOptionListOverrideKeyButtonFontColor()
  local color = {}
  color.normal = F_COLOR.GetColor("white")
  color.highlight = F_COLOR.GetColor("blue")
  color.pushed = F_COLOR.GetColor("blue")
  color.disabled = F_COLOR.GetColor("option_list_button_dis")
  return color
end
function GetMyAbilityButtonFontColor()
  local color = {}
  color.normal = F_COLOR.GetColor("my_ability_button_df")
  color.highlight = F_COLOR.GetColor("purple")
  color.pushed = F_COLOR.GetColor("my_ability_button_on")
  color.disabled = F_COLOR.GetColor("gray")
  return color
end
function GetLoginStageDefaultFontColor()
  local color = {}
  color.normal = F_COLOR.GetColor("white")
  color.highlight = F_COLOR.GetColor("login_stage_button_ov")
  color.pushed = F_COLOR.GetColor("login_stage_button_on")
  color.disabled = F_COLOR.GetColor("original_light_gray")
  return color
end
function GetRoadMapSizeButtonFontColor()
  local color = {}
  color.normal = F_COLOR.GetColor("zone_peace_blue")
  color.highlight = F_COLOR.GetColor("white")
  color.pushed = F_COLOR.GetColor("light_blue")
  color.disabled = F_COLOR.GetColor("off_gray")
  return color
end
function GetQuestDirectingButtonFontColor()
  local color = {}
  color.normal = F_COLOR.GetColor("white")
  color.highlight = F_COLOR.GetColor("quest_directing_button_ov")
  color.pushed = F_COLOR.GetColor("quest_directing_button_on")
  color.disabled = F_COLOR.GetColor("gray")
  return color
end
function GetIngameShopSelectedSubMenuButtonFontColor()
  local color = {}
  color.normal = F_COLOR.GetColor("middle_title")
  color.highlight = F_COLOR.GetColor("default")
  color.pushed = F_COLOR.GetColor("middle_title")
  color.disabled = F_COLOR.GetColor("middle_title_row_alpha")
  return color
end
function GetIngameShopUnselectedSubMenuButtonFontColor()
  local color = {}
  color.normal = F_COLOR.GetColor("medium_brown")
  color.highlight = F_COLOR.GetColor("reward")
  color.pushed = F_COLOR.GetColor("medium_brown")
  color.disabled = F_COLOR.GetColor("medium_brown_row_alpha")
  return color
end
function GetCommunityButtonFontColor()
  local color = {}
  color.normal = F_COLOR.GetColor("default")
  color.highlight = F_COLOR.GetColor("default")
  color.pushed = F_COLOR.GetColor("soft_yellow")
  color.disabled = F_COLOR.GetColor("dark_gray")
  return color
end
