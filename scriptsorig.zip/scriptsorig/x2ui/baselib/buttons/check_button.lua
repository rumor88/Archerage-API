local DEFAULT_CHECK_ICON_WIDTH = 16
local DEFAULT_CHECK_ICON_HEIGHT = 16
local CreateCheckButtonBackGround = function(button, path)
  button.bgs = {}
  for i = 1, 6 do
    button.bgs[i] = button:CreateDrawable(path, "btn_df", "background")
    button.bgs[i]:AddAnchor("CENTER", button, 0, 0)
  end
end
local ChangeCheckButtonBackGround = function(button, path)
  for i = 1, 6 do
    if button.bgs[i].SetTexture ~= nil then
      button.bgs[i]:SetTexture(path)
    end
  end
end
local CHECK_BUTTON_STYLE = {
  default = {
    path = TEXTURE_PATH.CHECK_BTN,
    coords = {
      "btn_df",
      "btn_ov",
      "btn_on",
      "btn_dis",
      "btn_chk_df",
      "btn_chk_dis"
    }
  },
  eye_shape = {
    text = {
      anchor = {
        "RIGHT",
        "LEFT",
        -5,
        0
      }
    },
    path = TEXTURE_PATH.CHECK_EYE_SHAPE,
    coords = {
      "eye_btn_df",
      "eye_btn_df",
      "eye_btn_df",
      "eye_btn_dis",
      "eye_btn_sel",
      "eye_btn_dis"
    }
  }
}
local function SetViewOfCheckButton(id, parent, initData)
  local style = "default"
  local textData, imageData
  if initData then
    style = initData.style or "default"
    textData = initData.textData
    imageData = initData.imageData
  end
  local button = UIParent:CreateWidget("checkbutton", id, parent)
  button:SetExtent(DEFAULT_CHECK_ICON_WIDTH, DEFAULT_CHECK_ICON_HEIGHT)
  CreateCheckButtonBackGround(button, TEXTURE_PATH.CHECK_BTN)
  local xOffset = 0
  if imageData and imageData.path ~= nil and imageData.key ~= nil then
    local inset = 3
    local image = button:CreateDrawable(imageData.path, imageData.key, "background")
    image:AddAnchor("LEFT", button, "RIGHT", inset, 0)
    xOffset = image:GetWidth() + inset
  end
  if textData then
    xOffset = xOffset + 3
    local textButton = button:CreateChildWidget("textbox", "textButton", 0, true)
    textButton:AddAnchor("TOPLEFT", button, "TOPRIGHT", xOffset, 0)
    textButton:SetAutoResize(true)
    textButton:SetAutoWordwrap(false)
    textButton:SetHeight(FONT_SIZE.LARGE)
    textButton.style:SetColorByKey("default")
    textButton.style:SetAlign(ALIGN_LEFT)
    if textData.fixedWidth then
      textButton.fixedWidth = textData.fixedWidth
      textButton.autoWordwrap = textData.autoWordwrap
      textButton.ellipsis = textData.ellipsis
    end
    if textData.color then
      textButton.style:SetColorByKey(textData.color)
    end
  end
  local function InitButtonStyle(style)
    local data = CHECK_BUTTON_STYLE[style]
    if data == nil then
      UIParent:DevLog("buttons style is nil(%s)", tostring(style))
      return
    end
    if data.path then
      ChangeCheckButtonBackGround(button, data.path)
    end
    if data.coords then
      local coords = data.coords
      for i = 1, #coords do
        SetButtonBackground(button)
        button.bgs[i]:SetTextureInfo(coords[i])
      end
    end
    if button.textButton and data.text then
      local anchor = data.text.anchor
      local color = data.text.color
      if anchor then
        button.textButton:RemoveAllAnchors()
        button.textButton:AddAnchor(anchor[1], button, anchor[2], anchor[3], anchor[4])
      end
      if color then
        button.textButton.style:SetColorByKey(color)
      end
    end
  end
  function button:UpdateText(text)
    local textBox = self.textButton
    if textBox == nil then
      return
    end
    if textBox.fixedWidth then
      local textWidth = textBox.style:GetTextWidth(text)
      local width = textWidth + button:GetWidth() + xOffset
      if width < textBox.fixedWidth then
        textBox:SetAutoResize(true)
        textBox.style:SetEllipsis(false)
      else
        textBox:SetWidth(textBox.fixedWidth - button:GetWidth() - xOffset)
        if textBox.autoWordwrap then
          textBox:SetAutoWordwrap(true)
          textBox:SetAutoResize(true)
        else
          textBox:SetAutoResize(false)
          textBox:SetAutoWordwrap(false)
          if textBox.ellipsis then
            textBox.style:SetEllipsis(true)
          end
        end
      end
    end
    textBox:SetText(text)
  end
  InitButtonStyle(style)
  if textData and textData.text then
    button:UpdateText(textData.text)
  end
  function button:GetMaxWidth()
    local width = self:GetWidth() + xOffset
    if self.textButton ~= nil then
      width = width + self.textButton:GetWidth()
    end
    return width
  end
  function button:GetMaxHeight()
    local height = self:GetHeight()
    if self.textButton ~= nil then
      local textButtonHeight = self.textButton:GetHeight()
      if height < textButtonHeight then
        height = textButtonHeight
      end
    end
    return height
  end
  return button
end
function CreateCheckButton(id, parent, initData)
  local button = SetViewOfCheckButton(id, parent, initData)
  function button:SetEnableCheckButton(enable)
    self:Enable(enable, true)
    if self.textButton ~= nil then
      self.textButton:Enable(enable)
      if enable then
        self.textButton:SetAlpha(1)
      else
        self.textButton:SetAlpha(4602678819172646912)
      end
    end
  end
  function button:OnCheckChanged()
    if self.CheckBtnCheckChagnedProc ~= nil then
      self:CheckBtnCheckChagnedProc(self:GetChecked())
    end
  end
  button:SetHandler("OnCheckChanged", button.OnCheckChanged)
  if button.textButton ~= nil then
    function button.textButton:OnClick()
      if button:IsEnabled() then
        button:SetChecked(not button:GetChecked())
      end
    end
    button.textButton:SetHandler("OnClick", button.textButton.OnClick)
  end
  return button
end
