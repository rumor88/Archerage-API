local curProvider = X2Util:GetGameProvider()
L_HELPER = {}
function L_HELPER.Get(set)
  local retValue = set.default
  if set[curProvider] ~= nil then
    for key, value in pairs(set[curProvider]) do
      retValue[key] = value
    end
  end
  return retValue
end
