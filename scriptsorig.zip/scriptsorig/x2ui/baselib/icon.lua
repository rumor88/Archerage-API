W_ICON = {}
local IsBigTargetIconSize = function(iconSize, targetSize)
  iconSize = iconSize + 4602678819172646912
  return targetSize > iconSize
end
local brokenSlaveIcon = X2Util:GetConstIconPath("broken_slave")
function W_ICON.CreateDestroyIcon(widget, layer)
  local ValidInfo = function(info)
    if info == nil then
      return false
    end
    if info.item_impl == nil or info.dead == nil then
      return false
    end
    if info.item_impl ~= "summon_slave" and info.item_impl ~= "slave_equipment" then
      return false
    end
    return info.dead
  end
  function widget:SetDestroyInfo(info)
    if IsBigTargetIconSize(self:GetWidth(), F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_30)) then
      return
    end
    if not ValidInfo(info) then
      if self.destroyIcon ~= nil then
        self.destroyIcon:SetVisible(false)
      end
      return
    end
    if self.destroyIcon == nil then
      if layer == nil then
        layer = "overlay"
      end
      local destroyIcon = widget:CreateIconDrawable(layer)
      destroyIcon:SetVisible(false)
      destroyIcon:AddTexture(brokenSlaveIcon)
      destroyIcon:AddAnchor("TOPLEFT", widget, 1, 1)
      destroyIcon:AddAnchor("BOTTOMRIGHT", widget, -1, -1)
      widget.destroyIcon = destroyIcon
    end
    if widget.realSlotLabel ~= nil and widget.realSlotLabel:IsVisible() and widget.virtualSlotIdx ~= nil and widget.realSlotIdx ~= nil then
      ChatLog(string.format("destroyIcon:SetVisible V%d/R%d", widget.virtualSlotIdx - 1, widget.realSlotIdx - 1))
    end
    self.destroyIcon:SetVisible(true)
  end
  return destroyIcon
end
local itemPackingIcon = X2Util:GetConstIconPath("item_packing")
function W_ICON.CreatePackIcon(widget, layer)
  local ValidInfo = function(info)
    if info == nil then
      return false
    end
    if info.needsUnpack == nil then
      return false
    end
    return info.needsUnpack
  end
  function widget:SetPackInfo(info)
    if not ValidInfo(info) then
      if self.packIcon ~= nil then
        self.packIcon:SetVisible(false)
      end
      return
    end
    if self.packIcon == nil then
      if layer == nil then
        layer = "overlay"
      end
      local packIcon = widget:CreateIconDrawable(layer)
      packIcon:SetVisible(false)
      packIcon:AddTexture(itemPackingIcon)
      packIcon:AddAnchor("TOPLEFT", widget, 1, 1)
      packIcon:AddAnchor("BOTTOMRIGHT", widget, -1, -1)
      widget.packIcon = packIcon
    end
    if widget.realSlotLabel ~= nil and widget.realSlotLabel:IsVisible() and widget.virtualSlotIdx ~= nil and widget.realSlotIdx ~= nil then
      ChatLog(string.format("packIcon:SetVisible V%d/R%d", widget.virtualSlotIdx - 1, widget.realSlotIdx - 1))
    end
    self.packIcon:SetVisible(true)
  end
  return packIcon
end
function W_ICON.CreateLifeTimeIcon(widget, layer)
  local ValidInfo = function(info)
    if info == nil then
      return
    end
    if info.lifeSpan == nil then
      return
    end
    return info.lifeSpan
  end
  function widget:SetLifeTimeIcon(info)
    if IsBigTargetIconSize(self:GetWidth(), F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_35)) then
      return
    end
    if not ValidInfo(info) then
      if self.lifeTimeIcon ~= nil then
        self.lifeTimeIcon:SetVisible(false)
      end
      return
    end
    if self.lifeTimeIcon == nil then
      if layer == nil then
        layer = "overlay"
      end
      local lifeTimeIcon = widget:CreateDrawable(TEXTURE_PATH.HUD, "icon_clock", layer)
      lifeTimeIcon:SetVisible(false)
      lifeTimeIcon:AddAnchor("TOPLEFT", widget, 1, 2)
      widget.lifeTimeIcon = lifeTimeIcon
    end
    if widget.realSlotLabel ~= nil and widget.realSlotLabel:IsVisible() and widget.virtualSlotIdx ~= nil and widget.realSlotIdx ~= nil then
      ChatLog(string.format("lifeTimeIcon:SetVisible V%d/R%d", widget.virtualSlotIdx - 1, widget.realSlotIdx - 1))
    end
    self.lifeTimeIcon:SetVisible(true)
  end
  return lifeTimeIcon
end
function W_ICON.CreateLookIcon(widget, layer)
  local ValidInfo = function(info)
    if info == nil then
      return
    end
    if not info.lookChanged and not info.useAsSkin then
      return false
    end
    return true
  end
  function widget:SetLookIcon(info)
    if IsBigTargetIconSize(self:GetWidth(), F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_35)) then
      return
    end
    if not ValidInfo(info) then
      if self.lookIcon ~= nil then
        self.lookIcon:SetVisible(false)
      end
      return
    end
    if self.lookIcon == nil then
      if layer == nil then
        layer = "overlay"
      end
      local lookIcon = widget:CreateDrawable(TEXTURE_PATH.HUD, "material", layer)
      lookIcon:SetVisible(false)
      lookIcon:AddAnchor("BOTTOMLEFT", widget, 1, -2)
      widget.lookIcon = lookIcon
    end
    if widget.realSlotLabel ~= nil and widget.realSlotLabel:IsVisible() and widget.virtualSlotIdx ~= nil and widget.realSlotIdx ~= nil then
      ChatLog(string.format("lookIcon:SetVisible V%d/R%d", widget.virtualSlotIdx - 1, widget.realSlotIdx - 1))
    end
    self.lookIcon:SetVisible(true)
    if info.lookChanged then
      self.lookIcon:SetTextureInfo("complete")
    end
    if info.useAsSkin then
      self.lookIcon:SetTextureInfo("material")
    end
  end
  return lookIcon
end
function W_ICON.CreateLockIcon(widget, layer)
  local ValidInfo = function(info)
    if info == nil then
      return false
    end
    if info.securityState == nil then
      return false
    end
    if info.securityState == ITEM_SECURITY_UNLOCKED then
      return false
    end
    return true
  end
  function widget:SetLockInfo(info)
    if IsBigTargetIconSize(self:GetWidth(), F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_35)) then
      return
    end
    if not ValidInfo(info) then
      if self.lockIcon ~= nil then
        self.lockIcon:SetVisible(false)
      end
      return ICON_BUTTON_OVERLAY_COLOR.NONE
    end
    if self.lockIcon == nil then
      if layer == nil then
        layer = "overlay"
      end
      local lockIcon = widget:CreateDrawable(TEXTURE_PATH.HUD, "blue_lock", layer)
      lockIcon:SetVisible(false)
      lockIcon:AddAnchor("TOPRIGHT", widget, 0, 0)
      widget.lockIcon = lockIcon
    end
    if widget.realSlotLabel ~= nil and widget.realSlotLabel:IsVisible() and widget.virtualSlotIdx ~= nil and widget.realSlotIdx ~= nil then
      ChatLog(string.format("lockIcon:SetVisible V%d/R%d", widget.virtualSlotIdx - 1, widget.realSlotIdx - 1))
    end
    self.lockIcon:SetVisible(true)
    if info.securityState == ITEM_SECURITY_LOCKED then
      self.lockIcon:SetTextureInfo("blue_lock")
    elseif info.securityState == ITEM_SECURITY_UNLOCKING then
      self.lockIcon:SetTextureInfo("pink_unlock")
    end
    return ICON_BUTTON_OVERLAY_COLOR.BLACK
  end
  return lockIcon
end
local itemDisableEnchantIcon = X2Util:GetConstIconPath("item_disable_enchant")
function W_ICON.CreateDisableEnchantItemIcon(widget, layer)
  local ValidInfo = function(info)
    if info == nil then
      return false
    end
    return info.isEnchantDisable or false
  end
  function widget:SetDisableEnchantInfo(info)
    if IsBigTargetIconSize(self:GetWidth(), F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_35)) then
      return
    end
    if not ValidInfo(info) then
      if self.disableEnchantIcon ~= nil then
        self.disableEnchantIcon:SetVisible(false)
      end
      return
    end
    if self.disableEnchantIcon == nil then
      if layer == nil then
        layer = "overlay"
      end
      local disableEnchantIcon = widget:CreateIconDrawable(layer)
      disableEnchantIcon:SetVisible(false)
      disableEnchantIcon:AddTexture(itemDisableEnchantIcon)
      disableEnchantIcon:AddAnchor("TOPLEFT", widget, 0, 0)
      disableEnchantIcon:AddAnchor("BOTTOMRIGHT", widget, 0, 0)
      widget.disableEnchantIcon = disableEnchantIcon
    end
    if widget.realSlotLabel ~= nil and widget.realSlotLabel:IsVisible() and widget.virtualSlotIdx ~= nil and widget.realSlotIdx ~= nil then
      ChatLog(string.format("disableEnchantIcon:SetVisible V%d/R%d", widget.virtualSlotIdx - 1, widget.realSlotIdx - 1))
    end
    self.disableEnchantIcon:SetVisible(true)
  end
  return disableEnchantIcon
end
function W_ICON.CreateDyeingIcon(widget, layer)
  local dyeingInfo
  local function ValidInfo(info)
    if info == nil then
      return false
    end
    if not info.dyeable then
      return
    end
    if info.dyeingColor == nil then
      return
    end
    dyeingInfo = {
      r = ConvertColor(info.dyeingColor.r),
      g = ConvertColor(info.dyeingColor.g),
      b = ConvertColor(info.dyeingColor.b)
    }
    return true
  end
  function widget:SetDyeingInfo(info)
    if IsBigTargetIconSize(self:GetWidth(), F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_35)) then
      return
    end
    if not ValidInfo(info) then
      if self.dyeingIcon ~= nil then
        self.dyeingIcon:SetVisible(false)
      end
      return
    end
    if self.dyeingIcon == nil then
      if layer == nil then
        layer = "overlay"
      end
      local dyeingIcon = widget:CreateDrawable(TEXTURE_PATH.HUD, "dyeing", layer)
      dyeingIcon:SetVisible(false)
      dyeingIcon:SetExtent(10, 10)
      dyeingIcon:AddAnchor("TOPRIGHT", widget, -2, 2)
      widget.dyeingIcon = dyeingIcon
    end
    if widget.realSlotLabel ~= nil and widget.realSlotLabel:IsVisible() and widget.virtualSlotIdx ~= nil and widget.realSlotIdx ~= nil then
      ChatLog(string.format("SetDyeingInfo,dyeingIcon:SetVisible V%d/R%d", widget.virtualSlotIdx - 1, widget.realSlotIdx - 1))
    end
    self.dyeingIcon:SetVisible(true)
    self.dyeingIcon:SetColor(dyeingInfo.r, dyeingInfo.g, dyeingInfo.b, 1)
  end
  function widget:SetDirectDyeingInfo(info)
    if IsBigTargetIconSize(self:GetWidth(), F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_35)) then
      return
    end
    if not ValidInfo(info) then
      if self.dyeingIcon ~= nil then
        self.dyeingIcon:SetVisible(false)
      end
      return
    end
    if self.dyeingIcon == nil then
      if layer == nil then
        layer = "overlay"
      end
      local dyeingIcon = widget:CreateDrawable(TEXTURE_PATH.HUD, "dyeing", layer)
      dyeingIcon:SetVisible(false)
      dyeingIcon:SetExtent(10, 10)
      dyeingIcon:AddAnchor("TOPRIGHT", widget, -2, 2)
      widget.dyeingIcon = dyeingIcon
    end
    if widget.realSlotLabel ~= nil and widget.realSlotLabel:IsVisible() and widget.virtualSlotIdx ~= nil and widget.realSlotIdx ~= nil then
      ChatLog(string.format("SetDirectDyeingInfo,dyeingIcon:SetVisible V%d/R%d", widget.virtualSlotIdx - 1, widget.realSlotIdx - 1))
    end
    self.dyeingIcon:SetVisible(true)
    self.dyeingIcon:SetColor(dyeingInfo.red, dyeingInfo.green, dyeingInfo.blue, 1)
  end
  return dyeingIcon
end
function W_ICON.CreateStack(widget)
  local layoutInfo = {
    fontSize = FONT_SIZE.SMALL,
    fontColor = nil
  }
  function widget:LayoutStack(info)
    for k, v in pairs(info) do
      layoutInfo[k] = v
    end
  end
  local stackLabel
  local stackCount = 0
  local requireCount = 0
  function widget:SetStack(newStack, newRequire, numberOnly)
    stackCount = tonumber(newStack) or 0
    requireCount = tonumber(newRequire) or 0
    if stackCount <= 1 and requireCount == 0 then
      self:ResetStack()
      return
    end
    if stackLabel == nil then
      stackLabel = widget:CreateChildWidget("label", "stack", 0, false)
      stackLabel:Raise()
      stackLabel:SetAutoResize(true)
      stackLabel.style:SetShadow(true)
      stackLabel.style:SetFontSize(layoutInfo.fontSize)
    end
    stackLabel:RemoveAllAnchors()
    if requireCount ~= 0 then
      stackLabel:AddAnchor("BOTTOM", self, 0, -9)
      stackLabel:SetNumberOnly(false)
      stackLabel:SetText(F_TEXT.SetSlashFormat(stackCount, requireCount))
      if requireCount > stackCount then
        stackLabel.style:SetColorByKey("red")
        self:SetDisableColorWrap(false)
      else
        stackLabel.style:SetColorByKey("white")
        self:SetDisableColorWrap(true)
      end
    else
      stackLabel:AddAnchor("BOTTOMRIGHT", self, -4, -9)
      if tonumber(stackCount) <= 1 then
        stackLabel:SetText("")
        return
      end
      if numberOnly == nil then
        numberOnly = true
      end
      stackLabel:SetNumberOnly(numberOnly)
      stackLabel:SetText(tostring(stackCount))
    end
  end
  function widget:GetStack()
    if requireCount == 0 then
      return stackCount
    else
      return {stackCount, requireCount}
    end
  end
  function widget:ResetStack()
    if stackLabel ~= nil then
      stackLabel:SetText("")
      stackLabel.style:SetColorByKey("white")
      self:SetDisableColorWrap(true)
    end
  end
  function widget:SetDisableColorWrap(disable)
    if self.SetDisableColor ~= nil then
      self:SetDisableColor(disable)
    end
  end
  return stack
end
function W_ICON.CreateLimitLevel(widget)
  widget.useExpedtionLevel = false
  local FillItemLevel = function(target, requireLevel, targetLevel)
    if targetLevel < requireLevel then
      target:SetText(GetLevelToString(requireLevel, F_COLOR.GetColor("red", true)))
    end
  end
  local FillExpeditionLevel = function(target, requireLevel, targetLevel)
    if targetLevel < requireLevel then
      target.style:SetColorByKey("skyblue")
      target:SetText(tostring(requireLevel))
    end
  end
  function widget:UseExpeditionLevel()
    widget.useExpedtionLevel = true
  end
  function widget:ProcessRequireLevelCheck(itemType)
    if IsBigTargetIconSize(self:GetWidth(), F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_30)) then
      return
    end
    if itemType == nil or itemType == 0 then
      if self.limitLevel ~= nil then
        self.limitLevel:Show(false)
      end
      return ICON_BUTTON_OVERLAY_COLOR.NONE
    end
    local requireLevel = 0
    local targetLevel = 0
    local FillFunc
    local requireLevel = X2Item:GetExpeditionLevelRequirement(itemType) or 0
    if widget.useExpedtionLevel and requireLevel ~= 0 then
      targetLevel = X2Faction:GetMyExpeditionLevel() or 0
      FillFunc = FillExpeditionLevel
    else
      requireLevel = X2Item:GetLevelRequirement(itemType) or 0
      local level = X2Unit:UnitLevel("player") or 0
      local heirLevel = X2Unit:UnitHeirLevel("player") or 0
      targetLevel = level + heirLevel
      if targetLevel == 0 then
        targetLevel = 1
      end
      FillFunc = FillItemLevel
    end
    if requirelevel == 0 then
      if self.limitLevel ~= nil then
        self.limitLevel:Show(false)
      end
      return ICON_BUTTON_OVERLAY_COLOR.NONE
    end
    if self.limitLevel == nil then
      local limitLevel = widget:CreateChildWidget("textbox", "limitLevel", 0, true)
      limitLevel:AddAnchor("TOPLEFT", widget, 0, 0)
      limitLevel:AddAnchor("BOTTOMRIGHT", widget, 0, 0)
      limitLevel.style:SetFontSize(FONT_SIZE.LARGE)
      limitLevel:SetAutoResize(false)
      limitLevel:EnablePick(false)
      limitLevel.style:SetColorByKey("red")
      limitLevel:Show(false)
      widget.limitLevel = limitLevel
    end
    self.limitLevel:Show(requireLevel > targetLevel)
    FillFunc(self.limitLevel, requireLevel, targetLevel)
    return requireLevel > targetLevel and ICON_BUTTON_OVERLAY_COLOR.BLACK or ICON_BUTTON_OVERLAY_COLOR.NONE
  end
  function widget:SetLimitLevelManualHandling(info)
    widget:SetOverlayColor(ICON_BUTTON_OVERLAY_COLOR.NONE)
    if IsBigTargetIconSize(self:GetWidth(), F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_30)) then
      return
    end
    if info == nil or info.level == nil then
      return
    end
    local level = info.level or 0
    local requireLevel = info.reqlevel or 0
    if requirelevel == 0 and self.limitLevel ~= nil then
      self.limitLevel:Show(false)
    end
    if self.limitLevel == nil then
      local limitLevel = self:CreateChildWidget("textbox", "limitLevel", 0, true)
      limitLevel:AddAnchor("TOPLEFT", self, 0, 0)
      limitLevel:AddAnchor("BOTTOMRIGHT", self, 0, 0)
      limitLevel.style:SetFontSize(FONT_SIZE.LARGE)
      limitLevel:SetAutoResize(false)
      limitLevel:EnablePick(false)
      limitLevel.style:SetColorByKey("red")
      limitLevel:Show(false)
      self.limitLevel = limitLevel
    end
    self.limitLevel:Show(level < requireLevel)
    self.limitLevel:SetText(tostring(requireLevel))
    if level < requireLevel then
      widget:SetOverlayColor(ICON_BUTTON_OVERLAY_COLOR.BLACK)
    end
  end
  return limitLevel
end
local itemCheckUnitRequireIcon = X2Util:GetConstIconPath("item_check_unit_require")
function W_ICON.CreateChainIcon(widget, layer)
  local ShowIcon = function(info)
    if info == nil then
      return false
    end
    if info.checkUnitReq == nil then
      return false
    end
    return not info.checkUnitReq
  end
  function widget:SetChainInfo(info)
    if not ShowIcon(info) then
      if self.chainIcon ~= nil then
        self.chainIcon:SetVisible(false)
      end
      return
    end
    if self.chainIcon == nil then
      if layer == nil then
        layer = "overlay"
      end
      local chainIcon = widget:CreateIconDrawable(layer)
      chainIcon:SetVisible(false)
      chainIcon:AddTexture(itemCheckUnitRequireIcon)
      chainIcon:AddAnchor("TOPLEFT", widget, 1, 1)
      chainIcon:AddAnchor("BOTTOMRIGHT", widget, -1, -1)
      widget.chainIcon = chainIcon
    end
    if widget.realSlotLabel ~= nil and widget.realSlotLabel:IsVisible() and widget.virtualSlotIdx ~= nil and widget.realSlotIdx ~= nil then
      ChatLog(string.format("chainIcon:SetVisible V%d/R%d", widget.virtualSlotIdx - 1, widget.realSlotIdx - 1))
    end
    self.chainIcon:SetVisible(true)
  end
  return chainIcon
end
local EXPEDITION_ROLE_ICON = {
  ["1"] = "ui/icon/top_member.dds",
  ["2"] = "ui/icon/top_officer.dds",
  ["3"] = "ui/icon/top_subowner.dds",
  ["255"] = "ui/icon/top_owner.dds"
}
function W_ICON.CreateExpeditionRoleIcon(widget, layer)
  local ShowIcon = function(info)
    if info == nil then
      return false
    end
    if info.expedition_role == nil then
      return false
    end
    return true
  end
  function widget:ProcessExpeditionRoleCheck(info)
    return
  end
  return
end
function W_ICON.CreateOverlayStateImg(widget, layer)
  local function CreateOverlayStateImg()
    if widget.overlay == nil then
      if layer == nil then
        layer = "artwork"
      end
      local overlay = widget:CreateColorDrawableByKey("icon_button_overlay_none", layer)
      overlay:AddAnchor("TOPLEFT", widget, 1, 1)
      overlay:AddAnchor("BOTTOMRIGHT", widget, -1, -1)
      widget.overlay = overlay
    end
  end
  function widget:SetOverlayColor(color)
    CreateOverlayStateImg()
    if color == ICON_BUTTON_OVERLAY_COLOR.RED then
      self.overlay:SetTextureColor("icon_button_overlay_red")
    elseif color == ICON_BUTTON_OVERLAY_COLOR.YELLOW then
      self.overlay:SetTextureColor("icon_button_overlay_yellow")
    elseif color == ICON_BUTTON_OVERLAY_COLOR.BLACK then
      self.overlay:SetTextureColor("icon_button_overlay_black")
    elseif color == ICON_BUTTON_OVERLAY_COLOR.NONE then
      self.overlay:SetTextureColor("icon_button_overlay_none")
    end
  end
  function widget:OverlayInvisible()
    if self.overlay == nil then
      return
    end
    local colorTable = self.overlay:GetColor()
    if colorTable[4] ~= 0 then
      self.overlay:SetTextureColor("icon_button_overlay_none")
    end
  end
  function widget:ProcessDurabilityColor(info)
    if info == nil then
      return ICON_BUTTON_OVERLAY_COLOR.NONE
    end
    local durability = info.durability
    local maxDurability = info.maxDurability
    if maxDurability == nil or maxDurability == 0 then
      return ICON_BUTTON_OVERLAY_COLOR.NONE
    end
    local percent = durability / maxDurability
    if percent > 4598175219545276416 then
      return ICON_BUTTON_OVERLAY_COLOR.NONE
    end
    if percent > 0 then
      return ICON_BUTTON_OVERLAY_COLOR.YELLOW
    end
    return ICON_BUTTON_OVERLAY_COLOR.RED
  end
  function widget:ProcessBreakInfo(info)
    if info == nil then
      return ICON_BUTTON_OVERLAY_COLOR.NONE
    end
    if info["break"] ~= true then
      if self.breakIcon ~= nil then
        self.breakIcon:SetVisible(false)
      end
      return ICON_BUTTON_OVERLAY_COLOR.NONE
    end
    if self.breakIcon == nil then
      local breakIcon = itemIcon:CreateDrawable(TEXTURE_PATH.ITEM_DIAGONAL_LINE, "line", "overlay")
      breakIcon:SetTextureColor("red")
      breakIcon:AddAnchor("CENTER", itemIcon, 0, 0)
      widget.breakIcon = breakIcon
      return ICON_BUTTON_OVERLAY_COLOR.RED
    end
    return ICON_BUTTON_OVERLAY_COLOR.NONE
  end
  function widget:SetOverlay(info)
    self:OverlayInvisible()
    if info == nil then
      self:SetLockInfo(nil)
      self:ProcessRequireLevelCheck(nil)
      self:ProcessDurabilityColor(nil)
      self:ProcessBreakInfo(nil)
      if self.ProcessExpeditionRoleCheck ~= nil then
        self:ProcessExpeditionRoleCheck(nil)
      end
      return
    end
    local color = ICON_BUTTON_OVERLAY_COLOR.NONE
    local function SetColor(newColor)
      if newColor == ICON_BUTTON_OVERLAY_COLOR.NONE then
        return
      end
      color = newColor
    end
    SetColor(self:SetLockInfo(info))
    local btnColor = {}
    btnColor[1] = self:ProcessBreakInfo(info)
    btnColor[2] = self:ProcessDurabilityColor(info)
    btnColor[3] = self:ProcessRequireLevelCheck(info.itemType)
    btnColor[4] = self.ProcessExpeditionRoleCheck ~= nil and self:ProcessExpeditionRoleCheck(info) or ICON_BUTTON_OVERLAY_COLOR.NONE
    for i, v in pairs(btnColor) do
      if v ~= ICON_BUTTON_OVERLAY_COLOR.NONE then
        SetColor(v)
        break
      end
    end
    if not (widget.realSlotLabel ~= nil and widget.realSlotLabel:IsVisible()) or widget.virtualSlotIdx == nil or widget.realSlotIdx ~= nil then
    end
    self:SetOverlayColor(color)
  end
  return overlay
end
function W_ICON.CreateOpenPaperItemIcon(widget, layer)
  local ValidInfo = function(info)
    if info == nil then
      return false
    end
    if info.item_impl ~= "open_paper" and info.item_impl ~= "learn_lock" then
      return false
    end
    return true
  end
  function widget:SetPaperInfo(info)
    if IsBigTargetIconSize(self:GetWidth(), F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_35)) then
      return
    end
    if not ValidInfo(info) then
      if self.paperIcon ~= nil then
        self.paperIcon:SetVisible(false)
      end
      return
    end
    if self.paperIcon == nil then
      if layer == nil then
        layer = "overlay"
      end
      local paperIcon = widget:CreateDrawable(TEXTURE_PATH.HUD, "readable", layer)
      paperIcon:SetVisible(false)
      widget.paperIcon = paperIcon
    end
    if not (widget.realSlotLabel ~= nil and widget.realSlotLabel:IsVisible()) or widget.virtualSlotIdx == nil or widget.realSlotIdx ~= nil then
    end
    self.paperIcon:SetVisible(true)
    self.paperIcon:RemoveAllAnchors()
    if info.item_impl == "learn_lock" then
      self.paperIcon:AddAnchor("BOTTOMLEFT", widget, 0, 0)
      self.paperIcon:SetTextureInfo("icon_skill_book")
    else
      self.paperIcon:AddAnchor("BOTTOMLEFT", widget, 2, -2)
      self.paperIcon:SetTextureInfo("readable")
    end
  end
  return paperIcon
end
function W_ICON.CreatePartyIconWidget(widget)
  local icon = widget:CreateChildWidget("emptywidget", "icon", 0, true)
  icon:Raise()
  local iconTexture = icon:CreateDrawable(TEXTURE_PATH.HUD, "party_blue", "background")
  iconTexture:AddAnchor("CENTER", icon, 0, 0)
  icon:SetExtent(iconTexture:GetExtent())
  local OnEnter = function(self)
    SetTooltip(locale.expedition.partyPlay, self)
  end
  icon:SetHandler("OnEnter", OnEnter)
  return icon
end
function W_ICON.CreateLootIconWidget(widget)
  local lootIcon = widget:CreateChildWidget("emptywidget", "lootIcon", 0, true)
  lootIcon:Raise()
  local iconTexture = lootIcon:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "pouch", "background")
  iconTexture:AddAnchor("CENTER", lootIcon, 0, 0)
  lootIcon:SetExtent(iconTexture:GetExtent())
  local OnEnter = function(self)
    SetTooltip(locale.raid.lootingTip, self)
  end
  lootIcon:SetHandler("OnEnter", OnEnter)
  return lootIcon
end
function W_ICON.CreateGuideIconWidget(widget, id, tip)
  if id == nil then
    id = "guide"
  end
  local guide = widget:CreateChildWidget("emptywidget", id, 0, false)
  local bg = guide:CreateDrawable(TEXTURE_PATH.HUD, "questionmark", "background")
  bg:AddAnchor("CENTER", guide, 0, 0)
  guide:SetExtent(bg:GetExtent())
  if tip ~= nil and tip ~= "" then
    local function OnEnter(self)
      SetTooltip(tip, self)
    end
    guide:SetHandler("OnEnter", OnEnter)
  end
  return guide
end
function W_ICON.CreateAchievementGradeIcon(widget)
  local gradeIcon = widget:CreateImageDrawable(TEXTURE_PATH.RANKING_GRADE, "artwork")
  gradeIcon:SetVisible(false)
  gradeIcon:SetExtent(0, 19)
  function widget:SetAchievementGrade(grade)
    gradeIcon:SetVisible(false)
    gradeIcon:SetExtent(0, 19)
    if grade == nil or grade < 2 then
      return
    end
    local textureCoords = {
      "grand",
      "grand",
      "grand",
      "rare",
      "arcane",
      "heroic",
      "unique",
      "celestial",
      "divine",
      "epic",
      "legendary",
      "mythic"
    }
    local coords = textureCoords[grade]
    gradeIcon:SetTextureInfo(coords)
    gradeIcon:SetVisible(true)
  end
  return gradeIcon
end
function W_ICON.CreateGradeIcon(widget, layer)
  if layer == nil then
    layer = "background"
  end
  local gradeIcon = widget:CreateImageDrawable(TEXTURE_PATH.ITEM_GRADE, layer)
  gradeIcon:SetVisible(false)
  gradeIcon:SetExtent(0, 19)
  function gradeIcon:SetGrade(grade)
    gradeIcon:SetVisible(false)
    gradeIcon:SetExtent(0, 19)
    if grade == nil then
      return
    end
    if grade < 1 then
      grade = 1
    end
    local textureCoords = {
      "normal",
      "grand",
      "rare",
      "arcane",
      "heroic",
      "unique",
      "celestial",
      "divine",
      "epic",
      "legendary",
      "mythic",
      "arche"
    }
    local coords = textureCoords[grade]
    gradeIcon:SetTextureInfo(coords)
    gradeIcon:SetVisible(true)
  end
  return gradeIcon
end
function W_ICON.CreateQuestGradeMarker(parent)
  local widget = parent:CreateChildWidget("emptywidget", "gradeMarker", 0, true)
  widget:Show(false)
  widget:SetExtent(30, 30)
  local gradeIcon = widget:CreateImageDrawable(TEXTURE_PATH.QUEST_LEVEL, "artwork")
  gradeIcon:AddAnchor("TOPLEFT", widget, 0, 0)
  gradeIcon:AddAnchor("BOTTOMRIGHT", widget, 0, 0)
  widget.gradeIcon = gradeIcon
  local OnEnter = function(self)
    SetTooltip(GetUIText(COMMON_TEXT, "quest_grade_tip"), self)
  end
  widget:SetHandler("OnEnter", OnEnter)
  function widget:SetQuestGrade(grade)
    self:Show(false)
    self:SetExtent(30, 30)
    local textureCoords = {
      elite = "elite",
      boss_c = "epic",
      boss_b = "legendary",
      boss_a = "mythic",
      boss_s = "mythic"
    }
    local coords = textureCoords[grade]
    if coords == nil then
      return
    end
    self.gradeIcon:SetTextureInfo(coords)
    self:Show(true)
  end
  return widget
end
function W_ICON.DrawMoneyIcon(parent, arg)
  local icon = parent:CreateImageDrawable(TEXTURE_PATH.MONEY_WINDOW, "background")
  icon:SetVisible(true)
  local keys = {
    gold = "money_gold",
    silver = "money_silver",
    copper = "money_copper",
    aapointGold = "aa_point_gold",
    aapointSilver = "aa_point_silver",
    aapointCopper = "aa_point_copper"
  }
  if keys[arg] ~= nil then
    icon:SetTextureInfo(keys[arg])
  end
  return icon
end
function W_ICON.DrawSkillFlameIcon(widget, layer)
  if layer == nil then
    layer = "artwork"
  end
  local flameIcon = widget:CreateDrawable(TEXTURE_PATH.SKILL, "draw_skill_flame_icon", "artwork")
  return flameIcon
end
function W_ICON.DrawItemSideEffectBackground(widget)
  if baselibLocale.itemSideEffect == false then
    return nil
  end
  local bgTime = 4600877379321698714
  local itemSideEffectBg = widget:CreateEffectDrawableByKey(TEXTURE_PATH.ITEM_SID_EEFFECT, "icon_frame", "artwork")
  itemSideEffectBg:SetVisible(false)
  itemSideEffectBg:AddAnchor("TOPLEFT", widget, 0, 0)
  itemSideEffectBg:AddAnchor("BOTTOMRIGHT", widget, 0, 0)
  widget.itemSideEffectBg = itemSideEffectBg
  itemSideEffectBg:SetRepeatCount(0)
  itemSideEffectBg:SetEffectPriority(1, "alpha", bgTime, bgTime)
  itemSideEffectBg:SetEffectInitialColor(1, 1, 1, 1, 0)
  itemSideEffectBg:SetEffectFinalColor(1, 1, 1, 1, 1)
  itemSideEffectBg:SetEffectPriority(2, "alpha", bgTime, bgTime)
  itemSideEffectBg:SetEffectInitialColor(2, 1, 1, 1, 1)
  itemSideEffectBg:SetEffectFinalColor(2, 1, 1, 1, 0)
  local width, height = widget:GetExtent()
  local light1 = widget:CreateEffectDrawableByKey(TEXTURE_PATH.ITEM_SID_EEFFECT, "light", "artwork")
  light1:SetVisible(false)
  light1:SetExtent(width, height)
  light1:AddAnchor("TOPLEFT", widget, 0, 1)
  widget.light1 = light1
  light1:SetMoveEffectType(1, "top", 0, 4602678819172646912, 4604480259023595110, 4604480259023595110)
  light1:SetMoveEffectEdge(1, 0, 1)
  light1:SetEffectPriority(1, "alpha", 4596373779694328218, 4596373779694328218)
  light1:SetEffectScale(1, 4601868171239720223, 4603219251127931372, 4594932627813569659, 4595473059768854118)
  light1:SetEffectInitialColor(1, 1, 1, 1, 0)
  light1:SetEffectFinalColor(1, 1, 1, 1, 1)
  light1:SetEffectPriority(2, "alpha", 4596373779694328218, 4596373779694328218)
  light1:SetEffectScale(2, 4603219251127931372, 4607002274814922588, 4595473059768854118, 4595473059768854118)
  light1:SetEffectInitialColor(2, 1, 1, 1, 1)
  light1:SetEffectFinalColor(2, 1, 1, 1, 1)
  light1:SetEffectPriority(3, "alpha", 4599075939470750515, 4599075939470750515)
  light1:SetEffectScale(3, 4607002274814922588, 4601237667291888353, 4595473059768854118, 4594932627813569659)
  light1:SetEffectInitialColor(3, 1, 1, 1, 1)
  light1:SetEffectFinalColor(3, 1, 1, 1, 0)
  light1:SetMoveEffectType(2, "right", 4602318531202457272, 4602678819172646912, 4604480259023595110, 4604480259023595110)
  light1:SetMoveEffectEdge(2, 0, 1)
  light1:SetEffectPriority(4, "alpha", 4596373779694328218, 4596373779694328218)
  light1:SetEffectScale(4, 4601868171239720223, 4603219251127931372, 4594932627813569659, 4595473059768854118)
  light1:SetEffectInitialColor(4, 1, 1, 1, 0)
  light1:SetEffectFinalColor(4, 1, 1, 1, 1)
  light1:SetEffectPriority(5, "alpha", 4596373779694328218, 4596373779694328218)
  light1:SetEffectScale(5, 4603219251127931372, 4607002274814922588, 4595473059768854118, 4595473059768854118)
  light1:SetEffectInitialColor(5, 1, 1, 1, 1)
  light1:SetEffectFinalColor(5, 1, 1, 1, 1)
  light1:SetEffectPriority(6, "alpha", 4599075939470750515, 4599075939470750515)
  light1:SetEffectScale(6, 4607002274814922588, 4601237667291888353, 4595473059768854118, 4594932627813569659)
  light1:SetEffectInitialColor(6, 1, 1, 1, 1)
  light1:SetEffectFinalColor(6, 1, 1, 1, 0)
  local light2 = widget:CreateEffectDrawableByKey(TEXTURE_PATH.ITEM_SID_EEFFECT, "light", "artwork")
  light2:SetVisible(false)
  light2:SetExtent(width, height)
  light2:AddAnchor("TOPLEFT", widget, 0, -1)
  widget.light2 = light2
  light2:SetMoveEffectType(1, "bottom", 0, 4602678819172646912, 4604480259023595110, 4604480259023595110)
  light2:SetMoveEffectEdge(1, 1, 0)
  light2:SetEffectPriority(1, "alpha", 4596373779694328218, 4596373779694328218)
  light2:SetEffectScale(1, 4601868171239720223, 4603219251127931372, 4594932627813569659, 4595473059768854118)
  light2:SetEffectInitialColor(1, 1, 1, 1, 0)
  light2:SetEffectFinalColor(1, 1, 1, 1, 1)
  light2:SetEffectPriority(2, "alpha", 4596373779694328218, 4596373779694328218)
  light2:SetEffectScale(2, 4603219251127931372, 4607002274814922588, 4595473059768854118, 4595473059768854118)
  light2:SetEffectInitialColor(2, 1, 1, 1, 1)
  light2:SetEffectFinalColor(2, 1, 1, 1, 1)
  light2:SetEffectPriority(3, "alpha", 4599075939470750515, 4599075939470750515)
  light2:SetEffectScale(3, 4607002274814922588, 4601237667291888353, 4595473059768854118, 4594932627813569659)
  light2:SetEffectInitialColor(3, 1, 1, 1, 1)
  light2:SetEffectFinalColor(3, 1, 1, 1, 0)
  light2:SetMoveEffectType(2, "left", 4602318531202457272, 0, 4604480259023595110, 4604480259023595110)
  light2:SetMoveEffectEdge(2, 1, 0)
  light2:SetEffectPriority(4, "alpha", 4596373779694328218, 4596373779694328218)
  light2:SetEffectScale(4, 4601868171239720223, 4603219251127931372, 4594932627813569659, 4595473059768854118)
  light2:SetEffectInitialColor(4, 1, 1, 1, 0)
  light2:SetEffectFinalColor(4, 1, 1, 1, 1)
  light2:SetEffectPriority(5, "alpha", 4596373779694328218, 4596373779694328218)
  light2:SetEffectScale(5, 4603219251127931372, 4607002274814922588, 4595473059768854118, 4595473059768854118)
  light2:SetEffectInitialColor(5, 1, 1, 1, 1)
  light2:SetEffectFinalColor(5, 1, 1, 1, 1)
  light2:SetEffectPriority(6, "alpha", 4599075939470750515, 4599075939470750515)
  light2:SetEffectScale(6, 4607002274814922588, 4601237667291888353, 4595473059768854118, 4594932627813569659)
  light2:SetEffectInitialColor(6, 1, 1, 1, 1)
  light2:SetEffectFinalColor(6, 1, 1, 1, 0)
  function widget:Anim_Item_Side_effect(isStart)
    if isStart == true then
      if self.itemSideEffectBg:IsVisible() == false then
        self.itemSideEffectBg:SetStartEffect(true)
        self.light1:SetStartEffect(true)
        self.light2:SetStartEffect(true)
      end
    elseif self.itemSideEffectBg:IsVisible() == true then
      self.itemSideEffectBg:SetStartEffect(false)
      self.light1:SetStartEffect(false)
      self.light2:SetStartEffect(false)
    end
  end
  return itemSideEffectBg
end
function W_ICON.CreateArrowIcon(widget, layer, useDouble)
  if layer == nil then
    layer = "overlay"
  end
  local iconKey = useDouble == true and "double_arrow" or "single_arrow"
  local icon = widget:CreateDrawable(TEXTURE_PATH.HUD, iconKey, layer)
  icon:SetTextureColor("brown")
  function widget:ChangeArrowType(useDouble)
    local iconKey = useDouble == true and "double_arrow" or "single_arrow"
    icon:SetTextureInfo(iconKey)
  end
  return icon
end
function W_ICON.CreateLeaderMark(id, parent)
  local leaderMark = CreateEmptyButton(id, parent)
  leaderMark:SetExtent(11, 11)
  local bg = leaderMark:CreateImageDrawable(TEXTURE_PATH.HUD, "background")
  bg:SetExtent(11, 11)
  bg:AddAnchor("CENTER", leaderMark, 0, 0)
  leaderMark.bg = bg
  function leaderMark:SetMarkTexture(style)
    leaderMark:Show(true)
    if style == "leader" then
      bg:SetTextureInfo("leader_icon")
    elseif style == "subleader" then
      bg:SetTextureInfo("sub_leader_icon")
    elseif style == "jointleader" then
      bg:SetTextureInfo("crown_gold_small")
    elseif style == "jointsubleader" then
      bg:SetTextureInfo("crown_silver_small")
    elseif style == "siegeRaidleader" then
      bg:SetTextureInfo("crown_gold_small")
    elseif style == "siegeRaidsubleader" then
      bg:SetTextureInfo("crown_silver_small")
    else
      leaderMark:Show(false)
    end
  end
  function leaderMark:SetMark(grade, showTooltip)
    if grade == nil or grade == "looting" then
      self.grade = ""
      self:Show(false)
      return
    end
    self:Show(true)
    self.grade = grade
    self:SetMarkTexture(grade)
    self.showTooltip = showTooltip
  end
  local text
  local function OnEnter(self)
    if self.showTooltip == true then
      if self.grade == "leader" then
        text = locale.team.leaderTip()
      elseif self.grade == "subleader" then
        text = locale.raid.subleaderTip
      elseif self.grade == "jointleader" then
        text = GetCommonText("raid_joint_owner")
      elseif self.grade == "jointsubleader" then
        text = GetCommonText("raid_joint_officer")
      elseif self.grade == "siegeRaidleader" then
        text = GetCommonText("siege_raid_team_owner")
      elseif self.grade == "siegeRaidsubleader" then
        text = GetCommonText("siege_raid_team_officer")
      end
      SetTooltip(text, self)
    end
  end
  leaderMark:SetHandler("OnEnter", OnEnter)
  return leaderMark
end
local gradeIconKeys = {
  "normal",
  "grand",
  "rare",
  "arcane",
  "heroic",
  "unique",
  "celestial",
  "divine",
  "epic",
  "legendary",
  "mythic",
  "arche"
}
function SetRankingGradeDataFunc(bg, icon, grade)
  grade = 12 - (grade - 1)
  if bg ~= nil then
    bg:Show(true)
    bg:SetTextureColor(string.format("grade_%d", grade))
  end
  if icon ~= nil then
    icon:Show(true)
    icon:SetTextureInfo(gradeIconKeys[grade])
  end
end
function W_ICON.CreateHeroGradeTextBadge(id, parent)
  local badge = W_ICON.CreateTextBadge(id, parent, {
    info = {
      grade_01 = {
        text = GetUIText(COMMON_TEXT, "hero_first_grade"),
        colorKey = "1st_orange"
      },
      grade_01_gray = {
        text = GetUIText(COMMON_TEXT, "hero_first_grade"),
        colorKey = "gray"
      },
      grade_02 = {
        text = GetUIText(COMMON_TEXT, "hero_second_grade"),
        colorKey = "2nd_red"
      },
      grade_02_gray = {
        text = GetUIText(COMMON_TEXT, "hero_second_grade"),
        colorKey = "gray"
      },
      grade_03 = {
        text = GetUIText(COMMON_TEXT, "hero_third_grade"),
        colorKey = "3rd_blue"
      },
      grade_03_gray = {
        text = GetUIText(COMMON_TEXT, "hero_third_grade"),
        colorKey = "gray"
      }
    },
    fontSize = FONT_SIZE.SMALL,
    textureKey = "text_bg_hero"
  })
  return badge
end
function W_ICON.CreateHeroGradeEmblem(parent, grade, useEffect)
  local defaultDisable = "disable_01"
  local gradeKey = {
    {
      enableKey = "levle_01_size_90",
      leftEffect = nil,
      rightEffect = nil,
      offsetX = 0,
      offsetY = 0
    },
    {
      enableKey = "level_02",
      leftEffect = nil,
      rightEffect = "hero_effect_right",
      offsetX = 66,
      offsetY = 15
    },
    {
      enableKey = "level_02",
      leftEffect = "hero_effect_left",
      rightEffect = nil,
      offsetX = 66,
      offsetY = 15
    },
    {
      enableKey = "level_03",
      leftEffect = nil,
      rightEffect = "hero_effect_right",
      offsetX = 66,
      offsetY = 12
    },
    {
      enableKey = "level_03",
      leftEffect = "hero_effect_left",
      rightEffect = "hero_effect_right",
      offsetX = 66,
      offsetY = 12
    },
    {
      enableKey = "level_03",
      leftEffect = "hero_effect_left",
      rightEffect = nil,
      offsetX = 66,
      offsetY = 12
    }
  }
  local emblem = CreateCacheCharacterNameLabel("name", parent, false, 0)
  emblem.style:SetAlign(ALIGN_CENTER)
  emblem.style:SetFontSize(FONT_SIZE.LARGE)
  emblem.style:SetColorByKey("middle_title")
  local heroMark = parent:CreateDrawable(TEXTURE_PATH.HERO_CURRENT_STATUS, defaultDisable, "background")
  heroMark:AddAnchor("BOTTOM", emblem, "TOP", 0, -5)
  emblem.grade = grade
  local badge = W_ICON.CreateHeroGradeTextBadge("badge", parent)
  badge:AddAnchor("BOTTOM", heroMark, 0, -5)
  if useEffect and gradeKey[grade] then
    if gradeKey[grade].leftEffect then
      local leftEff = parent:CreateDrawable(TEXTURE_PATH.HERO_CONDITION_EFFECT, gradeKey[grade].leftEffect, "background")
      leftEff:AddAnchor("TOPRIGHT", heroMark, "TOPRIGHT", -gradeKey[grade].offsetX, gradeKey[grade].offsetY)
      emblem.effectLeft = leftEff
    end
    if gradeKey[grade].rightEffect then
      local rightEff = parent:CreateDrawable(TEXTURE_PATH.HERO_CONDITION_EFFECT, gradeKey[grade].rightEffect, "background")
      rightEff:AddAnchor("TOPLEFT", heroMark, "TOPLEFT", gradeKey[grade].offsetX, gradeKey[grade].offsetY)
      emblem.effectRight = rightEff
    end
  end
  local badgeKeys = {
    "grade_01",
    "grade_02",
    "grade_02",
    "grade_03",
    "grade_03",
    "grade_03"
  }
  function emblem:SetGradeAndNameInfo(name, grade)
    if name == nil or gradeKey[grade] == nil then
      heroMark:SetTextureInfo(defaultDisable)
      self.style:SetColorByKey("gray")
      self:SetText(GetUIText(COMMON_TEXT, "vacancy"))
      self:SetAlpha(4599075939470750515)
      badge:Show(false)
    else
      self:SetText(name)
      heroMark:SetTextureInfo(gradeKey[grade].enableKey)
      self.style:SetColorByKey("middle_title")
      self:SetText(name)
      self:SetAlpha(1)
      badge:Set(badgeKeys[grade] or "grade_03")
      badge:Show(true)
    end
    if self.effectLeft then
      self.effectLeft:SetVisible(false)
    end
    if self.effectRight then
      self.effectRight:SetVisible(false)
    end
  end
  function emblem:SetInfo(name, nameCacheQueryId)
    local effectVisible = false
    if name == nil and nameCacheQueryId == nil or gradeKey[self.grade] == nil then
      heroMark:SetTextureInfo(defaultDisable)
      self.style:SetColorByKey("gray")
      self:SetText(GetUIText(COMMON_TEXT, "vacancy"))
      self:SetAlpha(4599075939470750515)
      badge:Show(false)
    else
      heroMark:SetTextureInfo(gradeKey[self.grade].enableKey)
      self.style:SetColorByKey("middle_title")
      self:SetValue(nameCacheQueryId, name)
      self:SetAlpha(1)
      badge:Set(badgeKeys[self.grade] or "grade_03")
      badge:Show(true)
      effectVisible = true
    end
    if self.effectLeft then
      self.effectLeft:SetVisible(effectVisible)
    end
    if self.effectRight then
      self.effectRight:SetVisible(effectVisible)
    end
  end
  function emblem:SetAcive(active)
    self:Show(active)
    heroMark:SetVisible(active)
    badge:Show(active)
  end
  return emblem
end
function W_ICON.CreateTextBadge(id, parent, data)
  if data == nil or data.info == nil then
    return
  end
  local fontSize = data.fontSize
  local badge = parent:CreateChildWidget("label", id, 0, false)
  local align = data.align or ALIGN_CENTER
  local textureKey = "text_badge_bg"
  local leftInset = 10
  local rightInset = 10
  local badgeHeight = 23
  if align ~= ALIGN_CENTER then
    leftInset = 5
    righInset = 20
    badgeHeight = 15
    textureKey = "text_badge_gradation"
  end
  local maxWidth = 0
  for k, v in pairs(data.info) do
    local width = badge.style:GetTextWidth(v.text or "")
    if maxWidth < width then
      maxWidth = width
    end
  end
  maxWidth = maxWidth + (leftInset + rightInset)
  if data.minWidth ~= nil and maxWidth < data.minWidth then
    maxWidth = data.minWidth
  end
  badge:SetExtent(maxWidth, badgeHeight)
  badge:SetInset(leftInset, 0, rightInset, 0)
  if fontSize ~= nil then
    badge.style:SetFontSize(fontSize)
  end
  badge.style:SetAlign(align)
  if data.textureKey ~= nil then
    textureKey = data.textureKey
  end
  local bg = badge:CreateDrawable(TEXTURE_PATH.DEFAULT, textureKey, "background")
  bg:AddAnchor("TOPLEFT", badge, 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", badge, 0, 0)
  local currentKey
  function badge:Set(key, newStr)
    local finded = data.info[key]
    if finded == nil then
      return
    end
    if self:GetWidth() == maxWidth then
      self:SetWidth(maxWidth)
    end
    local str = newStr == nil and finded.text or newStr
    self:SetText(str)
    bg:SetTextureColor(finded.colorKey)
    currentKey = key
  end
  function badge:ResetWidth()
    self:SetWidth(0)
  end
  local function OnEnter(self)
    if currentKey == nil then
      return
    end
    local finded = data.info[currentKey]
    if finded == nil then
      return
    end
    if finded.tooltip == nil or finded.tooltip == "" then
      return
    end
    SetTooltip(finded.tooltip, self)
  end
  badge:SetHandler("OnEnter", OnEnter)
  return badge
end
function W_ICON.CreateGradeTextBadge(id, parent)
  local badge = parent:CreateChildWidget("emptywidget", id, 0, false)
  badge:Show(true)
  local icon = badge:CreateDrawable(TEXTURE_PATH.RANKING_GRADE, "normal", "overlay")
  icon:AddAnchor("CENTER", badge, 0, 0)
  function badge:Set(grade)
    icon:SetTextureInfo(gradeIconKeys[grade])
    badge:SetExtent(icon:GetExtent())
  end
  return badge
end
function W_ICON.CreateAbilityIcon(id, parent, textureColorKey)
  local size = 12
  local inset = 5
  local jobIconFrame = parent:CreateChildWidget("emptywidget", id, 0, true)
  jobIconFrame:Show(true)
  jobIconFrame:SetExtent(MAX.MY_ABILITY_COUNT * size + inset * 2, 17)
  local colorKey = textureColorKey == nil and "default" or textureColorKey
  local bg = jobIconFrame:CreateDrawable(TEXTURE_PATH.HUD_GAUGE, "unitframe_job_frame_bg", "background")
  bg:SetTextureColor(colorKey)
  bg:AddAnchor("TOPLEFT", jobIconFrame, 0, 1)
  bg:AddAnchor("BOTTOMRIGHT", jobIconFrame, 0, 1)
  local icons = {}
  for i = 1, MAX.MY_ABILITY_COUNT do
    local icon = jobIconFrame:CreateDrawable(TEXTURE_PATH.HUD_GAUGE, "icon_ability_fight", "overlay")
    icon:SetVisible(false)
    icon:AddAnchor("LEFT", jobIconFrame, (i - 1) * size + inset, 0)
    table.insert(icons, icon)
  end
  local OnEnter = function(self)
    if self.tip == nil and self.tip == "" then
      return
    end
    SetTooltip(self.tip, self)
  end
  jobIconFrame:SetHandler("OnEnter", OnEnter)
  function jobIconFrame:SetAbility(abilityNames)
    for i = 1, MAX.MY_ABILITY_COUNT do
      icons[i]:Show(false)
    end
    if abilityNames == nil or #abilityNames == 0 then
      return
    end
    local count = 0
    local str = ""
    local abilityIndex = {}
    for i = 1, #abilityNames do
      local ability = abilityNames[i]
      if ability ~= "invalid ability" then
        local textureKey = string.format("icon_ability_%s", ability)
        icons[i]:Show(true)
        icons[i]:SetTextureInfo(textureKey)
        count = count + 1
        abilityIndex[i] = X2Ability:FindAbilityIndexForStr(ability)
        if str == "" then
          str = locale.common.abilityNameWithStr(ability)
        else
          str = string.format("%s, %s", str, locale.common.abilityNameWithStr(ability))
        end
      end
    end
    self.tip = F_TEXT.SetEnterString(string.format("|ny;%s|r", F_UNIT.GetCombinedAbilityName(abilityIndex[1], abilityIndex[2], abilityIndex[3])), str)
  end
  return jobIconFrame
end
