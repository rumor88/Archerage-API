local AttachMemberFunc = function(edit)
  local textureInfo = {
    default = {},
    disable = {}
  }
  if X2LoginCharacter:GetCurrentStage() <= STAGE_SERVER then
    textureInfo.default.path = TEXTURE_PATH.DEFAULT_NEW
    textureInfo.default.key = "enter_box"
  else
    textureInfo.default.path = TEXTURE_PATH.DEFAULT
    textureInfo.default.key = "editbox_df"
  end
  textureInfo.default.fontColor = "default"
  textureInfo.disable.path = TEXTURE_PATH.DEFAULT
  textureInfo.disable.key = "editbox_dis"
  textureInfo.disable.fontColor = "off_gray"
  local bg = edit:CreateDrawable(textureInfo.default.path, textureInfo.default.key, "background")
  bg:AddAnchor("TOPLEFT", edit, 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", edit, 0, 0)
  edit.bg = bg
  edit.style:SetColorByKey(textureInfo.default.fontColor)
  local function OnEnableChanged(self, enabled)
    local target = enabled and textureInfo.default or textureInfo.disable
    bg:SetTexture(target.path)
    bg:SetTextureInfo(target.key)
    self.style:SetColorByKey(target.fontColor)
  end
  edit:SetHandler("OnEnableChanged", OnEnableChanged)
  function edit:CreateGuideText(msg, align, inset)
    self:SetGuideText(msg)
    if inset ~= nil then
      self:SetGuideTextInset(inset)
    end
    self.guideTextStyle:SetColorByKey("guide_text_in_editbox")
    if align == nil then
      align = ALIGN_LEFT
    end
    self.guideTextStyle:SetAlign(align)
    function self:OnTextChanged()
      if self.TextChangedFunc ~= nil then
        self:TextChangedFunc(self)
      end
    end
    self:SetHandler("OnTextChanged", self.OnTextChanged)
  end
end
local function CommonEditInit(edit)
  edit:SetCursorColorByColorKey("editbox_cursor_default")
  baselibLocale:SetEditCursor(edit)
  edit.style:SetSnap(true)
  edit.style:SetShadow(false)
  AttachMemberFunc(edit)
end
function InitEdit(edit)
  CommonEditInit(edit)
  edit:SetInset(5, 5, 5, 5)
  edit:UseSelectAllWhenFocused(true)
  edit.style:SetAlign(ALIGN_LEFT)
  edit.style:SetColorByKey("title")
end
function W_CTRL.CreateEdit(id, parent)
  local edit = parent:CreateChildWidgetByType(UOT_X2_EDITBOX, id, 0, true)
  edit:SetHeight(DEFAULT_SIZE.EDIT_HEIGHT)
  InitEdit(edit)
  return edit
end
function W_CTRL.CreateMultiLineEdit(id, parent)
  local edit = parent:CreateChildWidgetByType(UOT_EDITBOX_MULTILINE, id, 0, true)
  local function InitMultiline(edit)
    CommonEditInit(edit)
    local EDITBOX_MULTILINE_GUIDE_INSET = {
      10,
      10,
      15,
      0
    }
    edit:SetGuideTextInset(EDITBOX_MULTILINE_GUIDE_INSET)
    edit:SetInset(EDITBOX_MULTILINE_GUIDE_INSET[1], EDITBOX_MULTILINE_GUIDE_INSET[2], EDITBOX_MULTILINE_GUIDE_INSET[3], EDITBOX_MULTILINE_GUIDE_INSET[4])
    edit.style:SetAlign(ALIGN_TOP_LEFT)
    edit.guideTextStyle:SetAlign(ALIGN_TOP_LEFT)
    edit.guideTextStyle:SetColorByKey("guide_text_in_editbox")
  end
  InitMultiline(edit)
  return edit
end
