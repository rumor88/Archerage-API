local SetViewOfPageControl = function(id, parent, layoutInfo)
  local frame = parent:CreateChildWidget("emptywidget", id, 0, true)
  local createFirstPage = true
  local firstPageButton
  local createLastPage = true
  local lastPageButton
  local createPageLabel = true
  local pageLabel
  local firstPageButtonStyleKey = "first_page"
  local prevPageButtonStyleKey = "prev_page"
  local nextPageButtonStyleKey = "next_page"
  local lastPageButtonStyleKey = "last_page"
  local pageFontSize = FONT_SIZE.LARGE
  local pageFontColorKey = "title"
  local pageLabelBgCreater
  local pageFormatSetter = function(pageLabel, currentPage, lastPage)
    pageLabel:SetText(F_TEXT.SetSlashFormat(currentPage, lastPage))
  end
  local vertical = false
  if layoutInfo ~= nil then
    vertical = layoutInfo.vertical or false
    createFirstPage = not vertical and layoutInfo.useFirstPageButton and true or false
    createLastPage = not vertical and layoutInfo.useLastPageButton and true or false
    createPageLabel = layoutInfo.usePageLabel or false
    pageFontSize = layoutInfo.pageFontSize or pageFontSize
    pageFontColorKey = layoutInfo.pageFontColorKey or pageFontColorKey
    pageLabelBgCreater = layoutInfo.pageLabelBgCreater or nil
    pageFormatSetter = layoutInfo.pageFormatSetter or pageFormatSetter
    if layoutInfo.buttonStyle ~= nil then
      firstPageButtonStyleKey = layoutInfo.buttonStyle.firstPage or firstPageButtonStyleKey
      prevPageButtonStyleKey = layoutInfo.buttonStyle.prevPage or prevPageButtonStyleKey
      nextPageButtonStyleKey = layoutInfo.buttonStyle.nextPage or nextPageButtonStyleKey
      lastPageButtonStyleKey = layoutInfo.buttonStyle.lastPage or lastPageButtonStyleKey
    end
  end
  local buttons = {}
  if createFirstPage then
    firstPageButton = frame:CreateChildWidget("button", "firstPageButton", 0, true)
    firstPageButton:SetStyle(firstPageButtonStyleKey)
    table.insert(buttons, firstPageButton)
  end
  local prevPageButton = frame:CreateChildWidget("button", "prevPageButton", 0, true)
  prevPageButton:SetStyle(prevPageButtonStyleKey)
  table.insert(buttons, prevPageButton)
  local nextPageButton = frame:CreateChildWidget("button", "nextPageButton", 0, true)
  nextPageButton:SetStyle(nextPageButtonStyleKey)
  table.insert(buttons, nextPageButton)
  if createLastPage then
    lastPageButton = frame:CreateChildWidget("button", "lastPageButton", 0, true)
    lastPageButton:SetStyle(lastPageButtonStyleKey)
    table.insert(buttons, lastPageButton)
  end
  local maxValue = 0
  for i, v in ipairs(buttons) do
    if vertical then
      local width = v:GetWidth()
      if maxValue < width then
        maxValue = width or maxValue
      end
    else
      local height = v:GetHeight()
      maxValue = maxValue < height and height or maxValue
    end
  end
  local pageLabel
  if createPageLabel then
    pageLabel = frame:CreateChildWidget("label", "pageLabel", 0, true)
    pageLabel:AddAnchor("CENTER", frame, 0, 0)
    pageLabel.style:SetFontSize(pageFontSize)
    pageLabel.style:SetColorByKey(pageFontColorKey)
    if pageLabelBgCreater ~= nil and type(pageLabelBgCreater) == "function" then
      pageLabelBgCreater(pageLabel)
    end
    if vertical then
      prevPageButton:AddAnchor("BOTTOM", pageLabel, "TOP", 0, 0)
      nextPageButton:AddAnchor("TOP", pageLabel, "BOTTOM", 0)
    else
      prevPageButton:AddAnchor("RIGHT", pageLabel, "LEFT", 0, 0)
      nextPageButton:AddAnchor("LEFT", pageLabel, "RIGHT", 0, 0)
      if firstPageButton ~= nil then
        firstPageButton:AddAnchor("RIGHT", prevPageButton, "LEFT", 0, 0)
      end
      if lastPageButton ~= nil then
        lastPageButton:AddAnchor("LEFT", nextPageButton, "RIGHT", 0, 0)
      end
    end
    function frame:SetPage(currentPage, lastPage)
      pageFormatSetter(pageLabel, currentPage, lastPage)
    end
    function frame:UpdateColorByEnable(enable)
      local colorKey = enabled and pageFontColorKey or "gray"
      pageLabel.style:SetColorByKey(colorKey)
    end
    if vertical then
      pageLabel:SetExtent(maxValue + 5, pageFontSize)
    else
      pageLabel:SetExtent(80, maxValue)
    end
  elseif vertical then
    prevPageButton:AddAnchor("TOP", frame, 0, 0)
    nextPageButton:AddAnchor("TOP", prevPageButton, "BOTTOM", 0, 2)
  else
    prevPageButton:AddAnchor("LEFT", frame, 0, 0)
    nextPageButton:AddAnchor("LEFT", prevPageButton, "RIGHT", 3, 0)
  end
  if vertical then
    local _, height = F_LAYOUT.GetExtentWidgets(prevPageButton, nextPageButton)
    frame:SetExtent(maxValue, height)
  else
    local startTarget = firstPageButton ~= nil and firstPageButton or prevPageButton
    local endTarget = lastPageButton ~= nil and lastPageButton or nextPageButton
    local width, _ = F_LAYOUT.GetExtentWidgets(startTarget, endTarget)
    frame:SetExtent(width, maxValue)
  end
  return frame
end
function W_CTRL.CreatePageControl(id, parent, style)
  local frame = SetViewOfPageControl(id, parent, style)
  local rotatePage = false
  function frame:Init()
    self.currentPage = 1
    self.maxPage = 1
    self.countPerPage = 1
    self.labelStyle = "normal"
    self.title = ""
    if self.firstPageButton ~= nil then
      self.firstPageButton:Enable(false)
    end
    self.prevPageButton:Enable(false)
    self.nextPageButton:Enable(false)
    if self.lastPageButton ~= nil then
      self.lastPageButton:Enable(false)
    end
    self:SetCurrentPage(1, false)
  end
  local function UpdatePage()
    if frame.SetPage == nil then
      return
    end
    frame:SetPage(frame.currentPage, frame.maxPage)
  end
  local enabled = true
  local function UpdatePageButton()
    if not enabled then
      return
    end
    if frame.firstPageButton ~= nil then
      frame.firstPageButton:Enable(true)
    end
    frame.prevPageButton:Enable(true)
    frame.nextPageButton:Enable(true)
    if frame.lastPageButton ~= nil then
      frame.lastPageButton:Enable(true)
    end
    if rotatePage then
      return
    end
    if frame.currentPage <= 1 and frame.currentPage >= frame.maxPage then
      if frame.firstPageButton ~= nil then
        frame.firstPageButton:Enable(false)
      end
      frame.prevPageButton:Enable(false)
      frame.nextPageButton:Enable(false)
      if frame.lastPageButton ~= nil then
        frame.lastPageButton:Enable(false)
      end
    elseif frame.currentPage >= frame.maxPage then
      if frame.lastPageButton ~= nil then
        frame.lastPageButton:Enable(false)
      end
      frame.nextPageButton:Enable(false)
    elseif frame.currentPage <= 1 then
      if frame.firstPageButton ~= nil then
        frame.firstPageButton:Enable(false)
      end
      frame.prevPageButton:Enable(false)
    end
  end
  function frame:Enable(isEnable)
    if self.firstPageButton ~= nil then
      self.firstPageButton:Enable(isEnable)
    end
    self.prevPageButton:Enable(isEnable)
    self.nextPageButton:Enable(isEnable)
    if self.lastPageButton ~= nil then
      self.lastPageButton:Enable(isEnable)
    end
    if self.UpdateColorByEnable ~= nil then
      self.UpdateColorByEnable(isEnable)
    end
    enabled = isEnable
    if isEnable then
      UpdatePageButton()
    end
  end
  function frame:UseActionBarPageRotate()
    rotatePage = true
    UpdatePageButton()
  end
  function frame:SetPageCount(count, countPerPage, notify)
    if count == nil or count < 1 then
      count = 1
    end
    if notify == nil then
      notify = true
    end
    self.countPerPage = countPerPage
    self.maxPage = count
    if self.currentPage > self.maxPage then
      self:SetCurrentPage(self.maxPage, notify)
    end
    UpdatePage()
  end
  function frame:SetPageByItemCount(itemCount, countPerPage, notify)
    if itemCount == nil then
      itemCount = 0
    end
    if notify == nil then
      notify = true
    end
    local pageCount = math.floor(itemCount / countPerPage)
    if itemCount % countPerPage ~= 0 then
      pageCount = pageCount + 1
    end
    self:SetPageCount(pageCount, countPerPage, notify)
    UpdatePageButton()
  end
  local prevPageIndex = 1
  function frame:SetCurrentPage(index, notify)
    prevPageIndex = self.currentPage
    self.currentPage = index
    if self.currentPage < 1 then
      self.currentPage = 1
      notify = false
    elseif self.currentPage > self.maxPage then
      self.currentPage = self.maxPage
      notify = false
    end
    UpdatePage()
    UpdatePageButton()
    if notify ~= false then
      self:CallPageChangedHanlder()
    end
  end
  function frame:GetCurrentPageIndex()
    return self.currentPage
  end
  function frame:GetPrevPageIndex()
    return prevPageIndex
  end
  function frame:GetTotalPageCount()
    return self.maxPage
  end
  function frame:SetTotalPageCount(pageCount)
    self.maxPage = pageCount
  end
  function frame:GetCountPerPage()
    return self.countPerPage
  end
  function frame:Refresh()
    UpdatePage()
    self:CallPageChangedHanlder()
  end
  function frame:CallPageChangedHanlder()
    self:OnPageChanged(self.currentPage, self.countPerPage)
  end
  function frame:MoveFirstPage()
    self:SetCurrentPage(1)
    UpdatePageButton()
  end
  function frame:MoveLastPage()
    self:SetCurrentPage(self.maxPage)
    UpdatePageButton()
  end
  local function MovePrevPage()
    if rotatePage and frame.currentPage == 1 then
      frame:SetCurrentPage(frame.maxPage)
    else
      frame:SetCurrentPage(frame.currentPage - 1)
    end
    UpdatePageButton()
  end
  local function MoveNextPage()
    if rotatePage and frame.currentPage >= frame.maxPage then
      frame:SetCurrentPage(1)
    else
      frame:SetCurrentPage(frame.currentPage + 1)
    end
    UpdatePageButton()
  end
  if frame.firstPageButton ~= nil then
    local function LeftClickFuncFirstPageButton()
      frame:MoveFirstPage()
    end
    ButtonOnClickHandler(frame.firstPageButton, LeftClickFuncFirstPageButton)
  end
  local function LeftClickFuncPrevPageButton()
    MovePrevPage()
  end
  ButtonOnClickHandler(frame.prevPageButton, LeftClickFuncPrevPageButton)
  local function LeftClickFuncNextPageButton()
    MoveNextPage()
  end
  ButtonOnClickHandler(frame.nextPageButton, LeftClickFuncNextPageButton)
  if frame.lastPageButton ~= nil then
    local function LeftClickFuncLastPageButton()
      frame:MoveLastPage()
    end
    ButtonOnClickHandler(frame.lastPageButton, LeftClickFuncLastPageButton)
  end
  function frame:OnPageChanged(pageIndex, countPerPage)
    if self.ProcOnPageChanged ~= nil then
      self:ProcOnPageChanged(pageIndex, countPerPage)
    end
  end
  frame:Init()
  return frame
end
