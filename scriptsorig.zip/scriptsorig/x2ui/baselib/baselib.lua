MAX = {MY_ABILITY_COUNT = 3}
COMBAT_ABILITY_MAX = X2Ability:GetCombatAbilityMax()
UNIT_VISIBLE_MAX_DISTANCE = 130
AUTO_REGISTER_ACTIONBAR_NUM = 3
MAX_SILVER = 100000000
BUTTON_STATE = {
  NORMAL = 1,
  HIGHLIGHTED = 2,
  PUSHED = 3,
  DISABLED = 4
}
PLAYER_EQUIP_SLOTS = {
  ES_HEAD,
  ES_NECK,
  ES_CHEST,
  ES_WAIST,
  ES_LEGS,
  ES_HANDS,
  ES_FEET,
  ES_ARMS,
  ES_BACK,
  ES_EAR_1,
  ES_EAR_2,
  ES_FINGER_1,
  ES_FINGER_2,
  ES_UNDERSHIRT,
  ES_UNDERPANTS,
  ES_MAINHAND,
  ES_OFFHAND,
  ES_RANGED,
  ES_MUSICAL,
  ES_BACKPACK,
  ES_COSPLAY,
  ES_COSPLAYLOOKS
}
BUTTON_COMMON_INSET = {TWO_BUTTON_BETEEN = 43, MESSAGEBOX_BOTTOM = -30}
MARGIN = {
  WINDOW_SIDE = 20,
  WINDOW_TITLE = 50,
  WINDOW_BOTTOM = -65
}
EDITBOX_GUIDE_INSET = {
  7,
  1,
  0,
  0
}
DEFAULT_SIZE = {
  DIALOG_CONTENT_WIDTH = 312,
  EDIT_HEIGHT = 26,
  COMBOBOX_HEIGHT = 26,
  INVENTORY_TAB_BUTTON_WIDTH = 40,
  TOOLTIP_MAX_WIDTH = 350,
  CHAT_EDIT_HEIGHT = 23
}
TEXTBOX_LINE_SPACE = {
  SMALL = 3,
  MIDDLE = 5,
  LARGE = 7,
  TOOLTIP = 4,
  QUESTGUIDE = 5
}
BUTTON_SIZE = {
  IMAGE_TAB = {WIDTH = 40, HEIGHT = 30},
  TAB_SELECT = {WIDTH = 95, HEIGHT = 29},
  TAB_UNSELECT = {WIDTH = 95, HEIGHT = 25}
}
MAX_HERO = 6
MAX_HERO_COND = 10
function ChatLog(arg)
  if X2Debug ~= nil and X2Debug:GetDevMode() then
    X2Chat:DispatchChatMessage(CMF_SAY, tostring(arg))
  end
end
function LuaAssert(msg)
  if X2Debug ~= nil and X2Debug:GetDevMode() then
    X2Chat:DispatchChatMessage(CMF_SAY, tostring(msg))
  end
  X2Util:RaiseLuaCallStack(msg)
end
function DumpTable(o)
  if X2Debug == nil or not X2Debug:GetDevMode() then
    return
  end
  if type(o) == "table" then
    local s = "{ "
    for k, v in pairs(o) do
      if type(k) ~= "number" then
        k = string.format("\"%s\"", k)
      end
      s = string.format("%s [%s]: %s, ", s, k, DumpTable(v))
    end
    return string.format("%s }", s)
  else
    return tostring(o)
  end
end
function RegistUIEvent(window, eventTable)
  for key, _ in pairs(eventTable) do
    window:RegisterEvent(key)
  end
end
W_CTRL = {}
function AttachStyleMemberFunc(controlWidget, styleTable)
  function controlWidget:SetStyle(style)
    if style == nil then
      style = "default"
    end
    local styleFunc = styleTable[style]
    if styleFunc == nil then
      UIParent:Warning(string.format("[Lua] invalid style type. %s/%s", controlWidget:GetName(), style))
      styleTable.default(self)
      return
    end
    styleFunc(self)
  end
  function controlWidget:GetStyleList()
    return styleTable
  end
end
local alreadyNotified = false
function ShowDisconnectMsg(title, body)
  if alreadyNotified then
    return
  end
  local function DialogHandler(wnd)
    wnd:SetTitle(title)
    local textData = {
      [W_MODULE.ATTRIBUTE.TEXT] = body
    }
    local textbox = W_MODULE:Create("textbox", wnd, W_MODULE.TYPES.TEXTBOX, textData)
    wnd:RegisterStack(textbox)
    function wnd:OkProc()
      X2World:LeaveWorld(EXIT_CLIENT)
    end
    function wnd:OnUpdate()
      self:Raise()
      self:SetUILayer("system")
    end
    wnd:SetHandler("OnUpdate", wnd.OnUpdate)
  end
  local id = X2DialogManager:RequestDialog(DialogHandler, UIParent:GetId(), {buttonType = DBT_OK})
  alreadyNotified = id ~= "0"
end
UIParent:SetEventHandler("DISCONNECTED_BY_WORLD", ShowDisconnectMsg)
function GetAdjustCamera(race, gender)
  local height = {
    nuian = {
      male = {
        height = 4593851763903000740,
        zoom = -4619792497756654797,
        center = -4622494657533077094
      },
      female = {
        height = 4596373779694328218,
        zoom = -4620693217682128896,
        center = -4623395377458551194
      }
    },
    elf = {
      male = {
        height = 4591870180066957722,
        zoom = -4618891777831180698,
        center = -4620693217682128896
      },
      female = {
        height = 4596373779694328218,
        zoom = -4618891777831180698,
        center = -4618891777831180698
      }
    },
    hariharan = {
      male = {
        height = 4594572339843380019,
        zoom = -4620693217682128896,
        center = -4622494657533077094
      },
      female = {
        height = 4594572339843380019,
        zoom = -4620693217682128896,
        center = -4623935809413835653
      }
    },
    ferre = {
      male = {
        height = 4593851763903000740,
        zoom = -4617991057905706598,
        center = -4620242857719391846
      },
      female = {
        height = 4591870180066957722,
        zoom = -4620693217682128896,
        center = -4623395377458551194
      }
    },
    dwarf = {
      male = {
        height = 4596373779694328218,
        zoom = -4620693217682128896,
        center = -4623395377458551194
      },
      female = {
        height = 4598175219545276416,
        zoom = -4620693217682128896,
        center = -4622494657533077094
      }
    },
    warborn = {
      male = {
        height = 0,
        zoom = 4594572339843380019,
        center = 4597094355634707497
      },
      female = {
        height = 4594572339843380019,
        zoom = -4620693217682128896,
        center = -4623395377458551194
      }
    }
  }
  if height[race] == nil then
    local errorStr = string.format("!!!!!!!!!!!!!!!!!!!!! check model cammera value, doesn't exist %s value", race)
    ChatLog(errorStr)
    UIParent:DevLog(errorStr)
    return height.nuian[gender]
  else
    return height[race][gender]
  end
end
function IsHeirLevel(level)
  if X2Player:IsEnabledHeirLevel() then
    local heirLevel = level - X2Player:GetMinHeirLevel()
    if heirLevel > 0 then
      return true
    end
  end
  return false
end
function GetLevelToString(level, hex_color, disable_heir_icon, useLevelText)
  local colorStr = ""
  if hex_color then
    colorStr = string.format("%s", hex_color)
  end
  if X2Player:IsEnabledHeirLevel() then
    local minHeirLevel = X2Player:GetMinHeirLevel()
    if level > minHeirLevel then
      local heirLevel = level - minHeirLevel
      local levelStr = useLevelText and GetCommonText("level_with_value", tostring(heirLevel)) or tostring(heirLevel)
      if hex_color == nil then
        colorStr = string.format("%s", F_COLOR.GetColor("level_successor", true))
      end
      if disable_heir_icon then
        return string.format("%s|E%s;|r", colorStr, levelStr)
      else
        return string.format("%s|e%s;|r", colorStr, levelStr)
      end
    end
  end
  local levelStr = useLevelText and GetCommonText("level_with_value", tostring(level)) or tostring(level)
  return string.format("%s%s|r", colorStr, levelStr)
end
IS_TICK_RECOVER_LOCAL_LABOR_POWER = X2Player:IsTickRecoverLocalLaborPower()
function deepcopy(orig, copies)
  copies = copies or {}
  local orig_type = type(orig)
  local copy
  if orig_type == "table" then
    if copies[orig] then
      copy = copies[orig]
    else
      copy = {}
      copies[orig] = copy
      for orig_key, orig_value in next, orig, nil do
        copy[deepcopy(orig_key, copies)] = deepcopy(orig_value, copies)
      end
      setmetatable(copy, deepcopy(getmetatable(orig), copies))
    end
  else
    copy = orig
  end
  return copy
end
