if X2Util:GetGameProvider() == MAILRU then
  TEXTBOX_LINE_SPACE = {
    SMALL = -3,
    MIDDLE = -2,
    LARGE = 3,
    TOOLTIP = 2,
    QUESTGUIDE = 0
  }
  function baselibLocale.GetDate(year, month, day, hour, minute, second, filter)
    filter = filter or DEFAULT_FORMAT_FILTER
    local function Get(value, key)
      local x = math.floor(filter / key)
      if x % 2 ~= 1 then
        return ""
      end
      if value <= 0 then
        value = 0
      end
      filter = filter - key
      local separator = ""
      if key == FORMAT_FILTER.MINUTE or key == FORMAT_FILTER.SECOND then
        separator = ":"
      elseif key == FORMAT_FILTER.MONTH or key == FORMAT_FILTER.YEAR then
        separator = "."
      end
      return string.format("%s%02d", separator, value)
    end
    local timeStr = math.floor(filter / FORMAT_FILTER.HOUR) % 2 == 1 or math.floor(filter / FORMAT_FILTER.MINUTE) % 2 == 1 or math.floor(filter / FORMAT_FILTER.SECOND) % 2 == 1
    local dateStr = math.floor(filter / FORMAT_FILTER.DAY) % 2 == 1 or math.floor(filter / FORMAT_FILTER.MONTH) % 2 == 1 or math.floor(filter / FORMAT_FILTER.YEAR) % 2 == 1
    local space = ""
    if timeStr and dateStr then
      space = " "
    end
    return string.format("%s%s%s%s%s%s%s", Get(hour, FORMAT_FILTER.HOUR), Get(minute, FORMAT_FILTER.MINUTE), Get(second, FORMAT_FILTER.SECOND), space, Get(day, FORMAT_FILTER.DAY), Get(month, FORMAT_FILTER.MONTH), Get(year, FORMAT_FILTER.YEAR))
  end
  baselibLocale.visibleAddedRefundInfo = true
  function baselibLocale:GetDefaultDateString(year, month, day)
    if year == nil and month == nil and day == nil then
      return
    end
    if year ~= nil then
      return string.format("%02d. %02d. %d", day, month, year)
    else
      return string.format("%02d. %02d", day, month)
    end
  end
  function baselibLocale:ChangeSequenceOfWord(format, word1, word2)
    if format == nil then
      format = "%s%s"
    end
    if type(word1) ~= "string" then
      word1 = tostring(word1)
    end
    if type(word2) ~= "string" then
      word2 = tostring(word2)
    end
    return string.format(format, word2, word1)
  end
  baselibLocale.needChangeWordOrder = true
end
