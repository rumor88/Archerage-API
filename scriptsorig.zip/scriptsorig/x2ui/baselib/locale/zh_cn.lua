if X2Util:GetGameProvider() == KAKAONA and X2Locale:GetLocale() == "zh_cn" then
  TEXTBOX_LINE_SPACE = {
    SMALL = 3,
    MIDDLE = 5,
    LARGE = 7,
    TOOLTIP = 3,
    QUESTGUIDE = 5
  }
  baselibLocale.premiumService = {usePremiumGrade = false}
  baselibLocale.openedSextant = true
  baselibLocale.itemSideEffect = false
  baselibLocale.visibleRefundInfo = true
  baselibLocale.visibleAddedRefundInfo = true
  baselibLocale.useEnemyReportPopup = false
  baselibLocale.useWebQuickDiary = false
  baselibLocale.useWebWiki = false
  baselibLocale.visibleRefundInfo = true
  baselibLocale.visibleAddedRefundInfo = true
end
