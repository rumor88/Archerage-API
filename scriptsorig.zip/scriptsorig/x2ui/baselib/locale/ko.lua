if baselibLocale == nil then
  baselibLocale = {}
end
function baselibLocale.GetDate(year, month, day, hour, minute, second, filter)
  filter = filter or DEFAULT_FORMAT_FILTER
  local function Get(value, msg, key)
    local x = math.floor(filter / key)
    if x ~= 1 then
      return ""
    end
    if value <= 0 then
      filter = math.floor(filter % key)
      return ""
    end
    filter = filter - key
    return X2Locale:LocalizeUiText(DATE_TIME_TEXT, msg, tostring(value))
  end
  local function GetHour(value, msg, key)
    if value < 0 then
      filter = math.floor(filter % key)
      return ""
    end
    local x = math.floor(filter / key)
    if x ~= 1 then
      return ""
    end
    filter = filter - key
    local prefix = ""
    if value < 12 then
      prefix = string.format("%s", X2Locale:LocalizeUiText(DATE_TIME_TEXT, "am"))
    elseif value == 12 then
      prefix = string.format("%s", X2Locale:LocalizeUiText(DATE_TIME_TEXT, "pm"))
    else
      value = value - 12
      prefix = string.format("%s", X2Locale:LocalizeUiText(DATE_TIME_TEXT, "pm"))
    end
    local text = string.format("%s %s", prefix, X2Locale:LocalizeUiText(DATE_TIME_TEXT, msg, tostring(value)))
    return text
  end
  return string.format("%s %s %s %s %s%s", Get(year, "year", FORMAT_FILTER.YEAR), Get(month, "month", FORMAT_FILTER.MONTH), Get(day, "day", FORMAT_FILTER.DAY), GetHour(hour, "hour", FORMAT_FILTER.HOUR), Get(minute, "minute", FORMAT_FILTER.MINUTE), Get(second, "second", FORMAT_FILTER.SECOND))
end
function baselibLocale.GetSimpleDate(year, month, day, hour, minute, second)
  local output = string.format("%d. %d. %d. %02d:%02d", year, month, day, hour, minute)
  if second > 0 then
    output = string.format("%s:%02d", output, second)
  end
  return output
end
baselibLocale.bindingKeyModifierName = {
  ["CTRL--"] = "Ctrl ",
  ["ALT--"] = "Alt ",
  ["SHIFT--"] = "Shift "
}
baselibLocale.bindingKeyName = {
  MINUS = "-",
  EQUALS = "=",
  INSERT = "Insert",
  DELETE = "Delete",
  END = "End",
  PAGEUP = "PgUp",
  PAGEDOWN = "PgDn",
  HOME = "Home",
  ["\\"] = "b",
  NUMBER1 = "Num 1",
  NUMBER2 = "Num 2",
  NUMBER3 = "Num 3",
  NUMBER4 = "Num 4",
  NUMBER5 = "Num 5",
  NUMBER6 = "Num 6",
  NUMBER7 = "Num 7",
  NUMBER8 = "Num 8",
  NUMBER9 = "Num 9",
  NUMBER0 = "Num 0",
  WHEELUP = "(W)Up",
  WHEELDOWN = "(W)Dn",
  APOSTROPHE = "`"
}
baselibLocale.visibleRefundInfo = true
baselibLocale.visibleAddedRefundInfo = true
baselibLocale.useRefundWebLink = false
baselibLocale.openedSextant = true
baselibLocale.itemSideEffect = false
baselibLocale.webWidgetName = X2:GetWebWidgetName()
function baselibLocale:SetEditCursor(edit)
  edit:SetCursorHeight(2)
  edit:SetCursorOffset(-2)
end
function baselibLocale:GetDefaultDateString(year, month, day)
  if year == nil and month == nil and day == nil then
    return
  end
  if year ~= nil then
    return string.format("%d. %02d. %02d", year, month, day)
  else
    return string.format("%02d. %02d", month, day)
  end
end
function baselibLocale:ChangeSequenceOfWord(format, word1, word2)
  if format == nil then
    format = "%s%s"
  end
  if type(word1) ~= "string" then
    word1 = tostring(word1)
  end
  if type(word2) ~= "string" then
    word2 = tostring(word2)
  end
  return string.format(format, word1, word2)
end
baselibLocale.useEnemyReportPopup = true
baselibLocale.achievementKindString = {
  [EAK_RACIAL_MISSION] = {
    text = X2Locale:LocalizeUiText(COMMON_TEXT, "racial_assignment"),
    enable = true
  },
  [EAK_ACHIEVEMENT] = {
    text = X2Locale:LocalizeUiText(COMMON_TEXT, "achievement"),
    enable = true
  },
  [EAK_COLLECTION] = {
    text = X2Locale:LocalizeUiText(COMMON_TEXT, "collect"),
    enable = true
  },
  [EAK_ARCHERAGE] = {
    text = X2Locale:LocalizeUiText(COMMON_TEXT, "archerage"),
    enable = true
  }
}
baselibLocale.needChangeWordOrder = false
