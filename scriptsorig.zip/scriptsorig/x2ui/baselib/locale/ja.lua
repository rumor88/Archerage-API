if X2Util:GetGameProvider() == GAMEON then
  TEXTBOX_LINE_SPACE = {
    SMALL = -1,
    MIDDLE = -1,
    LARGE = 3,
    TOOLTIP = -1,
    QUESTGUIDE = 0
  }
  baselibLocale.bindingKeyName.APOSTROPHE = "^"
  function baselibLocale:SetEditCursor(edit)
    edit:SetCursorHeight(1)
    edit:SetCursorOffset(2)
  end
  baselibLocale.visibleAddedRefundInfo = false
  baselibLocale.useRefundWebLink = false
  baselibLocale.achievementKindString[EAK_COLLECTION].enable = false
end
