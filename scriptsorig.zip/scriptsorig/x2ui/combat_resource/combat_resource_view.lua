MAX_RESOURCE_COUNT = 3
local screenHeight = UIParent:GetScreenHeight()
local sideMargin, titleMargin, bottomMargin = GetWindowMargin()
local CreateSingleBar = function(parent, firstIndex, secondIndex)
  local indexstring = string.format("_%d_%d", firstIndex, secondIndex)
  local progressBar = W_BAR.CreateStatusBar(string.format("progressBar[%s]", indexstring), parent)
  progressBar:SetExtent(112, 8)
  progressBar:SetBarTextureCoords(TEXTURE_PATH.COMMON_GAUGE, "gage", TEXTURE_PATH.COMMON_GAUGE, "gage", TEXTURE_PATH.COMMON_GAUGE, "gauge_shadow")
  progressBar.bg:SetTextureColor("bg_black")
  progressBar:SetBarColorByKey("fight")
  local status2Bar = progressBar:CreateChildWidget("statusbar", "status2Bar", 0, true)
  status2Bar:AddAnchor("TOPLEFT", progressBar, 0, 0)
  status2Bar:AddAnchor("BOTTOMRIGHT", progressBar, 0, 0)
  status2Bar:SetOrientation("HORIZONTAL")
  status2Bar:SetBarTexture(TEXTURE_PATH.COMMON_GAUGE, "artwork")
  status2Bar:SetBarTextureByKey("gage")
  progressBar.status2Bar = status2Bar
  status2Bar:SetBarColorByKey("fight")
  return progressBar
end
local function CreateDoubleBar(parent, firstIndex)
  local widget = {}
  for i = 1, 2 do
    widget[i] = CreateSingleBar(parent, firstIndex, i)
  end
  return widget
end
local function CreateAbilityFrame(subFrame)
  local size = F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_30)
  for i = 1, MAX_RESOURCE_COUNT do
    local gaugeWidget = subFrame:CreateChildWidget("emptywidget", "gaugeWidget", i, true)
    gaugeWidget:SetExtent(156, 40)
    gaugeWidget:AddAnchor("TOPLEFT", subFrame, 15, (i - 1) * (size + 10) + 3)
    local iconBg = gaugeWidget:CreateChildWidget("emptywidget", "iconBg", 0, true)
    iconBg:SetExtent(size, size)
    iconBg:AddAnchor("TOPLEFT", gaugeWidget, -2, 4)
    local iconFrame = gaugeWidget:CreateDrawable(TEXTURE_PATH.HUD, "ability_icon_frame_01", "artwork")
    iconFrame:AddAnchor("TOPLEFT", iconBg, -3, -3)
    iconFrame:AddAnchor("BOTTOMRIGHT", iconBg, 3, 3)
    gaugeWidget.iconFrame = iconFrame
    local icon = gaugeWidget:CreateIconDrawable("artwork")
    icon:AddAnchor("TOPLEFT", iconBg, 2, 2)
    icon:AddAnchor("BOTTOMRIGHT", iconBg, -2, -2)
    gaugeWidget.icon = icon
    local timer = gaugeWidget:CreateChildWidget("label", "timer", 0, true)
    timer:SetExtent(13, 13)
    timer:AddAnchor("CENTER", icon, -2, 0)
    timer:SetAutoResize(true)
    timer.style:SetAlign(ALIGN_CENTER)
    timer.style:SetOutline(true)
    timer.style:SetFontSize(FONT_SIZE.SMALL)
    timer:EnablePick(false)
    local bar = CreateDoubleBar(gaugeWidget, i)
    gaugeWidget.bar = bar
    local value1 = gaugeWidget:CreateChildWidget("label", "value1", 0, true)
    value1:SetExtent(75, 11)
    value1:AddAnchor("BOTTOMRIGHT", bar[1], "TOPRIGHT", 0, -3)
    value1.style:SetAlign(ALIGN_RIGHT)
    value1.style:SetFontSize(FONT_SIZE.SMALL)
    value1.style:SetShadow(true)
    local value2 = gaugeWidget:CreateChildWidget("label", "value2", 0, true)
    value2:SetExtent(75, 11)
    value2:AddAnchor("BOTTOMLEFT", bar[1], "TOPLEFT", 0, -3)
    value2.style:SetAlign(ALIGN_LEFT)
    value2.style:SetFontSize(FONT_SIZE.SMALL)
    value2.style:SetShadow(true)
  end
end
function SetViewOfCombatResourceWindow(id, parent)
  local window = UIParent:CreateWidget("window", "combat_resource", "UIParent")
  local tab = window:CreateChildWidget("button", "tab", 0, true)
  ApplyButtonSkinTable(tab, BUTTON_HUD.COMBAT_RESOURCE_TAB)
  tab:AddAnchor("TOPLEFT", window, 3, 0)
  tab:Show(true)
  tab:Enable(false)
  window:SetExtent(181, tab:GetHeight())
  local visibleWnd = window:CreateChildWidget("emptywidget", "visibleWnd", 0, true)
  visibleWnd:AddAnchor("TOPLEFT", window, "TOPLEFT", 0, tab:GetHeight())
  visibleWnd:AddAnchor("BOTTOMRIGHT", window, "BOTTOMRIGHT", 0, 125)
  local bg = visibleWnd:CreateDrawable(TEXTURE_PATH.HUD, "bg_quest", "background")
  bg:AddAnchor("TOPLEFT", visibleWnd, "TOPLEFT", 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", visibleWnd, "BOTTOMRIGHT", 0, 0)
  window.bg = bg
  function window:MakeOriginWindowPos()
    if window == nil then
      return
    end
    window:RemoveAllAnchors()
    window:AddAnchor("TOPRIGHT", "UIParent", -combatResourceLocale.gridWidth, F_LAYOUT.CalcDontApplyUIScale(screenHeight / 2 - 100))
    if window.Refresh then
      window:Refresh()
    end
  end
  window:MakeOriginWindowPos()
  local toggleBtn = window:CreateChildWidget("button", "toggleBtn", 0, true)
  toggleBtn:AddAnchor("TOPRIGHT", window, "TOPRIGHT", -3, 8)
  toggleBtn.isOpen = X2:GetCombatResourceUiData()
  window.toggleBtn:SetStyle("combat_resource_open")
  local moveWnd = window:CreateChildWidget("emptywidget", "moveWnd", 0, true)
  moveWnd:AddAnchor("TOPLEFT", window, "TOPLEFT", 65, 0)
  moveWnd:AddAnchor("BOTTOMRIGHT", window, "TOPRIGHT", -25, tab:GetHeight())
  moveWnd:EnableDrag(true)
  moveWnd:SetDragCondition(DC_SHIFT_KEY_DOWN)
  CreateAbilityFrame(visibleWnd)
  return window
end
