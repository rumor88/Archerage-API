﻿## author : zergra
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## combat text

locale/ko.lua
locale/ru.lua
locale/en_us.lua
locale/th.lua

combat_resource_view.lua
combat_resource.lua
