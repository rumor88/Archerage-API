local ONE_SECOND = 1000
local function CreateCombatResourceFrame(id, parent)
  local window = SetViewOfCombatResourceWindow(id, parent)
  window:Show(true)
  local checkMaxResourceUpdateTime = 0
  local groupType = {}
  local recoveryResourceType = {}
  local delay = 0
  local onEnterWidget = false
  local applyAlpha = false
  local function SetAlphaBlending(alpha)
    if applyAlpha == alpha then
      return
    end
    applyAlpha = alpha
    window.tab:SetAlpha(alpha and 4601778099247172813 or 1)
    if alpha then
      window.bg:SetTextureColor("default")
    else
      window.bg:SetTextureColor("over")
    end
  end
  SetAlphaBlending(true)
  local CanUpdateTimer = function(recoveryCycleTime)
    if recoveryCycleTime == nil then
      return false
    end
    if recoveryCycleTime <= 0 then
      return false
    end
    return true
  end
  local SetGaugeValue = function(info, bar1, bar2, value1, value2)
    if info.uiType == CRU_GAUGE then
      if info.resource1Max ~= nil then
        bar1.statusBar:SetMinMaxValues(0, info.resource1Max)
        bar1:SetValue(info.resource1Current)
        value1:SetText(F_TEXT.SetSlashFormat(info.resource1Current, info.resource1Max))
      end
    elseif info.uiType == CRU_OVERLAP then
      if info.resource1Max ~= nil then
        bar1.statusBar:SetMinMaxValues(0, info.resource1Max)
        bar1:SetValue(info.resource1Current)
        value1:SetText(tostring(info.resource1Current))
      end
      if info.resource2Max ~= nil then
        bar1.status2Bar:SetMinMaxValues(0, info.resource2Max)
        bar1.status2Bar:SetValue(info.resource2Current)
        value2:SetText(tostring(info.resource2Current))
      end
    elseif info.uiType == CRU_DOUBLE_GAUGE then
      if info.resource1Max ~= nil then
        bar1.statusBar:SetMinMaxValues(0, info.resource1Max)
        bar1:SetValue(info.resource1Current)
        value1:SetText(F_TEXT.SetSlashFormat(info.resource1Current, info.resource1Max))
      end
      if info.resource2Max ~= nil then
        bar2.statusBar:SetMinMaxValues(0, info.resource2Max)
        bar2:SetValue(info.resource2Current)
      end
    elseif info.uiType == CRU_DOUBLE_GAUGE_2 then
      if info.resource1Max ~= nil then
        bar1.statusBar:SetMinMaxValues(0, info.resource1Max)
        bar1:SetValue(info.resource1Current)
        value1:SetText(tostring(info.resource1Current))
      end
      if info.resource2Max ~= nil then
        bar2.statusBar:SetMinMaxValues(0, info.resource2Max)
        bar2:SetValue(info.resource2Current)
        value2:SetText(tostring(info.resource2Current))
      end
    end
  end
  local FormatRemainTime = function(timeValue)
    local timeStr = ""
    local key = ""
    timeValue = timeValue >= 0 and timeValue or 0
    local multiply = 1000
    if timeValue >= multiply * 86400 then
      timeStr = tostring(math.floor(timeValue / (multiply * 86400)))
      key = "day_initial"
    elseif timeValue >= multiply * 3600 then
      timeStr = tostring(math.floor(timeValue / (multiply * 3600)))
      key = "hour_initial"
    elseif timeValue >= multiply * 60 then
      timeStr = tostring(math.floor(timeValue / (multiply * 60)))
      key = "minute_initial"
    elseif timeValue >= 0 then
      timeStr = tostring(math.floor(timeValue / multiply))
      key = "second_initial"
    end
    return X2Locale:LocalizeUiText(TIME, key, timeStr)
  end
  local function UpdateTimer(updateResourceType, nowTime, show)
    for i = 1, MAX_RESOURCE_COUNT do
      local gaugeWidget = window.visibleWnd.gaugeWidget[i]
      if recoveryResourceType[i] == updateResourceType then
        if CanUpdateTimer(nowTime) == false then
          gaugeWidget.timer:Show(false)
          return
        end
        gaugeWidget.timer:Show(show)
        gaugeWidget.timer:SetText(FormatRemainTime(nowTime))
      end
    end
  end
  local function UpdateWindowAlpha(dt)
    if onEnterWidget == false then
      return
    end
    delay = delay + dt
    if delay < 300 then
      return
    end
    SetAlphaBlending(false)
  end
  local function OnUpdate(frame, dt)
    UpdateWindowAlpha(dt)
    checkMaxResourceUpdateTime = checkMaxResourceUpdateTime + dt
    if checkMaxResourceUpdateTime < ONE_SECOND then
      return
    end
    checkMaxResourceUpdateTime = 0
    for i = 1, MAX_RESOURCE_COUNT do
      local gaugeWidget = window.visibleWnd.gaugeWidget[i]
      if groupType[i] ~= nil then
        local isUpdate = X2CombatResource:CheckCombatResourceMaxPointByGroupType(groupType[i])
        if isUpdate == true then
          local info = X2CombatResource:GetCombatResourceInfoByGroupType(groupType[i])
          SetGaugeValue(info, gaugeWidget.bar[1], gaugeWidget.bar[2], gaugeWidget.value1, gaugeWidget.value2)
        end
      end
    end
  end
  window:SetHandler("OnUpdate", OnUpdate)
  local function OnEnter()
    delay = 0
    onEnterWidget = true
  end
  window:SetHandler("OnEnter", OnEnter)
  local function OnLeave()
    delay = 0
    onEnterWidget = false
    SetAlphaBlending(true)
  end
  window:SetHandler("OnLeave", OnLeave)
  local function SetGauegeData(info, bar1, bar2, icon, value1, value2)
    if info == nil then
      return
    end
    if info.uiType == CRU_GAUGE then
      bar1.status2Bar:Show(false)
      bar1:SetExtent(112, 8)
      bar1:AddAnchor("TOPLEFT", icon, "TOPRIGHT", 10, 16)
      if info.resource1ColorKey ~= nil then
        bar1:SetBarColorByKey(info.resource1ColorKey)
      end
      bar2:Show(false)
      value1:AddAnchor("BOTTOMRIGHT", bar1, "TOPRIGHT", 0, -3)
      value2:Show(false)
    elseif info.uiType == CRU_OVERLAP then
      bar1.status2Bar:Show(true)
      bar1:SetExtent(112, 8)
      bar1:AddAnchor("TOPLEFT", icon, "TOPRIGHT", 10, 16)
      if info.resource1ColorKey ~= nil then
        bar1:SetBarColorByKey(info.resource1ColorKey)
      end
      if info.resource2ColorKey ~= nil then
        bar1.status2Bar:SetBarColorByKey(info.resource2ColorKey)
      end
      bar2:Show(false)
      value2:Show(true)
      value1:AddAnchor("BOTTOMRIGHT", bar1, "TOPRIGHT", 0, -3)
      value2:AddAnchor("BOTTOMLEFT", bar1, "TOPLEFT", 0, -3)
    elseif info.uiType == CRU_DOUBLE_GAUGE then
      bar1.status2Bar:Show(false)
      bar1:SetExtent(112, 6)
      bar2.status2Bar:Show(false)
      bar2:Show(true)
      bar2:SetExtent(112, 6)
      if info.resource1ColorKey ~= nil then
        bar1:SetBarColorByKey(info.resource1ColorKey)
      end
      if info.resource2ColorKey ~= nil then
        bar2:SetBarColorByKey(info.resource2ColorKey)
      end
      bar1:AddAnchor("TOPLEFT", icon, "TOPRIGHT", 10, 8)
      bar2:AddAnchor("TOPLEFT", icon, "TOPRIGHT", 10, 18)
      value1:AddAnchor("BOTTOMRIGHT", bar1, "TOPRIGHT", 0, -2)
      value2:Show(false)
    elseif info.uiType == CRU_DOUBLE_GAUGE_2 then
      bar1.status2Bar:Show(false)
      bar1:SetExtent(112, 6)
      bar2.status2Bar:Show(false)
      bar2:Show(true)
      bar2:SetExtent(112, 6)
      if info.resource1ColorKey ~= nil then
        bar1:SetBarColorByKey(info.resource1ColorKey)
      end
      if info.resource2ColorKey ~= nil then
        bar2:SetBarColorByKey(info.resource2ColorKey)
      end
      bar1:AddAnchor("TOPLEFT", icon, "TOPRIGHT", 10, 8)
      bar2:AddAnchor("TOPLEFT", icon, "TOPRIGHT", 10, 18)
      value1:AddAnchor("BOTTOMRIGHT", bar1, "TOPRIGHT", 0, -3)
      value2:AddAnchor("BOTTOMLEFT", bar1, "TOPLEFT", 0, -3)
    end
    SetGaugeValue(info, bar1, bar2, value1, value2)
  end
  local SetIconFrame = function(info, iconFrame, iconBg)
    if info.isDefaultResource == true or info == nil then
      iconFrame:Show(false)
    else
      if info.ability == ABILITY_MADNESS then
        iconFrame:SetTextureInfo("ability_icon_frame_02", "madness")
        iconFrame:AddAnchor("TOPLEFT", iconBg, -2, -2)
        iconFrame:AddAnchor("BOTTOMRIGHT", iconBg, 2, 2)
      else
        iconFrame:SetTextureInfo("ability_icon_frame_01")
        iconFrame:AddAnchor("TOPLEFT", iconBg, -3, -3)
        iconFrame:AddAnchor("BOTTOMRIGHT", iconBg, 3, 3)
      end
      if info.resource1ColorKey ~= "" then
        iconFrame:SetTextureColor(info.resource1ColorKey)
      end
      iconFrame:Show(true)
    end
  end
  local SetFontColor = function(info, value1, value2)
    if info.resource1ColorKey ~= nil and info.resource1ColorKey ~= "" then
      if info.uiType == CRU_OVERLAP then
        value2.style:SetColorByKey(info.resource1ColorKey)
      else
        value1.style:SetColorByKey(info.resource1ColorKey)
      end
    end
    if info.resource2ColorKey ~= nil and info.resource2ColorKey ~= "" then
      if info.uiType == CRU_OVERLAP then
        value1.style:SetColorByKey(info.resource2ColorKey)
      else
        value2.style:SetColorByKey(info.resource2ColorKey)
      end
    end
  end
  local function InItCombatResource()
    local info = X2CombatResource:GetCombatResourceInfo()
    local visibleCount = 0
    for i = 1, MAX_RESOURCE_COUNT do
      local gaugeWidget = window.visibleWnd.gaugeWidget[i]
      gaugeWidget.timer:Show(false)
      if info[i] == nil then
        gaugeWidget:Show(false)
      else
        visibleCount = visibleCount + 1
        gaugeWidget:Show(true)
        groupType[i] = info[i].groupType
        if info[i].iconPath ~= nil then
          gaugeWidget.icon:SetVisible(true)
          gaugeWidget.icon:ClearAllTextures()
          gaugeWidget.icon:AddTexture(info[i].iconPath)
        else
          gaugeWidget.icon:SetVisible(false)
        end
        local function OnEnter(self)
          if info[i].tooltip ~= nil then
            SetVerticalTooltip(info[i].tooltip, self)
          end
        end
        gaugeWidget.iconBg:SetHandler("OnEnter", OnEnter)
        SetGauegeData(info[i], gaugeWidget.bar[1], gaugeWidget.bar[2], gaugeWidget.icon, gaugeWidget.value1, gaugeWidget.value2)
        SetIconFrame(info[i], gaugeWidget.iconFrame, gaugeWidget.iconBg)
        SetFontColor(info[i], gaugeWidget.value1, gaugeWidget.value2)
        recoveryResourceType[i] = info[i].recoveryResourceType
      end
    end
    window.visibleWnd:AddAnchor("TOPLEFT", window, "TOPLEFT", 0, window.tab:GetHeight())
    window.visibleWnd:AddAnchor("BOTTOMRIGHT", window, "BOTTOMRIGHT", 0, 10 + 40 * visibleCount)
  end
  local function ResetCombatResource()
    local info = X2CombatResource:GetCombatResourceInfo()
    for i = 1, MAX_RESOURCE_COUNT do
      local gaugeWidget = window.visibleWnd.gaugeWidget[i]
      gaugeWidget.timer:Show(false)
      if info[i] == nil then
        gaugeWidget:Show(false)
      else
        gaugeWidget:Show(true)
        SetGaugeValue(info[i], gaugeWidget.bar[1], gaugeWidget.bar[2], gaugeWidget.value1, gaugeWidget.value2)
      end
    end
  end
  function TransformCombatResource(combatResourceGroupType)
    local info = X2CombatResource:GetCombatResourceInfoByGroupType(combatResourceGroupType)
    for i = 1, MAX_RESOURCE_COUNT do
      local gaugeWidget = window.visibleWnd.gaugeWidget[i]
      if info == nil then
      elseif groupType[i] == combatResourceGroupType then
        SetGauegeData(info, gaugeWidget.bar[1], gaugeWidget.bar[2], gaugeWidget.icon, gaugeWidget.value1, gaugeWidget.value2)
        SetGaugeValue(info, gaugeWidget.bar[1], gaugeWidget.bar[2], gaugeWidget.value1, gaugeWidget.value2)
        SetIconFrame(info, gaugeWidget.iconFrame, gaugeWidget.iconBg)
        SetFontColor(info, gaugeWidget.value1, gaugeWidget.value2)
        recoveryResourceType[i] = info.recoveryResourceType
        gaugeWidget.timer:Show(false)
      end
    end
  end
  local function RefreshCombatResourcePoint(combatResourceGroupType, resourceType, point)
    local info = X2CombatResource:GetCombatResourceInfoByGroupType(combatResourceGroupType)
    for i = 1, MAX_RESOURCE_COUNT do
      local gaugeWidget = window.visibleWnd.gaugeWidget[i]
      if info == nil then
      elseif groupType[i] == combatResourceGroupType then
        SetGaugeValue(info, gaugeWidget.bar[1], gaugeWidget.bar[2], gaugeWidget.value1, gaugeWidget.value2)
        recoveryResourceType[i] = info.recoveryResourceType
        if recoveryResourceType[i] == resourceType and point == 0 then
          UpdateTimer(recoveryResourceType[i], nil)
        end
      end
    end
  end
  local function SetOpenStatus(isOpen)
    if isOpen == nil then
      isOpen = X2:GetCombatResourceUiData()
    end
    if isOpen == true then
      window.toggleBtn:SetStyle("combat_resource_open")
    else
      window.toggleBtn:SetStyle("combat_resource_close")
    end
    window:EnablePick(isOpen)
    window.moveWnd:Show(isOpen)
    window.tab:Show(isOpen)
    window.visibleWnd:Show(isOpen)
    window.toggleBtn.isOpen = isOpen
    X2:SetCombatResourceUiData(isOpen)
  end
  local eventHandler = {
    REFRESH_COMBAT_RESOURCE = function(resetBar, groupType, resourceType, point)
      if resetBar == true then
        InItCombatResource()
      else
        RefreshCombatResourcePoint(groupType, resourceType, point)
      end
    end,
    TRANSFORM_COMBAT_RESOURCE = function(groupType)
      TransformCombatResource(groupType)
    end,
    REFRESH_COMBAT_RESOURCE_UPDATE_TIME = function(updateReesourceType, nowTime, show)
      UpdateTimer(updateReesourceType, nowTime, show)
    end,
    LEFT_LOADING = function()
      ResetCombatResource()
    end,
    ENTERED_WORLD = function()
      local visible = true
      if X2Option:GetOptionItemValue(OIT_OPTION_SHOW_COMBAT_RESOURCE_WINDOW) == 0 then
        visible = false
      end
      SetOpenStatus()
      ShowCombatResourceWindowHandler(visible)
    end
  }
  window:SetHandler("OnEvent", function(this, event, ...)
    eventHandler[event](...)
  end)
  RegistUIEvent(window, eventHandler)
  local function OnClick(self)
    SetOpenStatus(not window.toggleBtn.isOpen)
  end
  window.toggleBtn:SetHandler("OnClick", OnClick)
  local function OnDragStart()
    window:StartMoving()
  end
  window.moveWnd:SetHandler("OnDragStart", OnDragStart)
  local function OnDragStop()
    window:StopMovingOrSizing()
  end
  window.moveWnd:SetHandler("OnDragStop", OnDragStop)
  InItCombatResource()
  SetOpenStatus()
  return window
end
local featureSet = X2Player:GetFeatureSet()
local combatResourceFrame
if featureSet.combatResource then
  combatResourceFrame = CreateCombatResourceFrame("combatResourceFrame", "UIParent")
  AddUISaveHandlerByKey("combatResource", combatResourceFrame)
  combatResourceFrame:ApplyLastWindowOffset()
end
function ShowCombatResourceWindowHandler(visible)
  if combatResourceFrame == nil then
    return
  end
  combatResourceFrame:Show(not visible)
end
