if combatResourceLocale == nil then
  combatResourceLocale = {}
end
combatResourceLocale.gridWidth = 315
