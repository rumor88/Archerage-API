if X2Util:GetGameProvider() == KAKAONA then
  combatResourceLocale.gridWidth = 398
end
