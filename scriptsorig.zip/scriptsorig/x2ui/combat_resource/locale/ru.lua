if X2Util:GetGameProvider() == MAILRU then
  combatResourceLocale.gridWidth = 398
end
