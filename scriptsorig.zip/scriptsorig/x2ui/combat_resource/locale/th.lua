if X2Util:GetGameProvider() == XLGAMES_TH then
  combatResourceLocale.gridWidth = 398
end
