local ANIMATION_NAME = "fist_ac_stage_idle"
local newBeautyshop
local function CreateNewBeautyShop(id, parent)
  local wnd = CreateEmptyWindow(id, "UIParent")
  wnd:AddAnchor("TOPLEFT", "UIParent", 0, 0)
  wnd:AddAnchor("BOTTOMRIGHT", "UIParent", 0, 0)
  local modelView = CreateBeautyShopModelView("modelView", wnd)
  modelView:AddAnchor("TOPLEFT", wnd, 0, 0)
  modelView:AddAnchor("BOTTOMRIGHT", wnd, 0, 0)
  wnd.modelView = modelView
  local customizingMenu = CreateCustomizingMenuWnd("customizingMenu", wnd)
  customizingMenu:AddAnchor("LEFT", wnd, 0, 0)
  local customizingContent = CreateCustomizingContentWnd("customizingContent", wnd)
  customizingContent:AddAnchor("RIGHT", wnd, -10, 0)
  customizingMenu:SetContentWnd(customizingContent)
  customizingContent:SetMenuWnd(customizingMenu)
  local cancelBtn = wnd:CreateChildWidget("button", "cancelBtn", 0, true)
  cancelBtn:AddAnchor("BOTTOMLEFT", modelView, 40, -40)
  cancelBtn:SetText(GetUIText(BEAUTYSHOP_TEXT, "exitTitle"))
  cancelBtn:SetStyle("login_stage_text_default")
  local function CancelBtnOnClick()
    local DialogHandler = function(wnd)
      wnd:SetTitle(GetUIText(BEAUTYSHOP_TEXT, "exitTitle"))
      local textData = {
        [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(BEAUTYSHOP_TEXT, "exitBody")
      }
      local textbox = W_MODULE:Create("textbox", wnd, W_MODULE.TYPES.TEXTBOX, textData)
      wnd:RegisterStack(textbox)
      function wnd:OkProc()
        X2Customizer:TerminateBeautyShop()
      end
    end
    X2DialogManager:RequestDialog(DialogHandler, wnd:GetId())
  end
  cancelBtn:SetHandler("OnClick", CancelBtnOnClick)
  local resetBtn = wnd:CreateChildWidget("button", "resetBtn", 0, true)
  resetBtn:AddAnchor("LEFT", cancelBtn, "RIGHT", 15, 0)
  resetBtn:SetText(GetUIText(COMMON_TEXT, "init"))
  resetBtn:SetStyle("login_stage_text_default")
  local function ResetBtnOnClick()
    local function DialogHandler(dialogWnd)
      dialogWnd:SetTitle(GetUIText(BEAUTYSHOP_TEXT, "resetTitle"))
      local textData = {
        [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(BEAUTYSHOP_TEXT, "resetBody")
      }
      local textbox = W_MODULE:Create("textbox", dialogWnd, W_MODULE.TYPES.TEXTBOX, textData)
      dialogWnd:RegisterStack(textbox)
      function dialogWnd:OkProc()
        wnd:ResetModel()
      end
    end
    X2DialogManager:RequestDialog(DialogHandler, wnd:GetId())
  end
  resetBtn:SetHandler("OnClick", ResetBtnOnClick)
  local confirmBtn = wnd:CreateChildWidget("button", "confirmBtn", 0, true)
  confirmBtn:Enable(false)
  confirmBtn:AddAnchor("BOTTOMRIGHT", wnd, -40, -40)
  confirmBtn:SetText(GetUIText(COMMON_TEXT, "apply"))
  confirmBtn:SetStyle("login_stage_text_default")
  local function ConfirmBtnOnClick()
    local DialogHandler = function(dialogWnd)
      local itemType, has, need, tipInfo = X2Customizer:GetBeautyShopConfigInfo()
      dialogWnd:SetSounds("cosmetic_details")
      dialogWnd:SetTitle(GetUIText(BEAUTYSHOP_TEXT, "detailsTitle"))
      local str = GetUIText(COMMON_TEXT, "beautyshop_confirm_content")
      if itemType == 0 then
        str = string.format([[
%s

%s]], str, GetUIText("beautyshop_free_reason"))
      end
      function addTextBoxModule()
        local textData = {
          [W_MODULE.ATTRIBUTE.TEXT] = str
        }
        local textbox = W_MODULE:Create("textbox", dialogWnd, W_MODULE.TYPES.TEXTBOX, textData)
        dialogWnd:RegisterStack(textbox)
      end
      if tipInfo and tipInfo.lifeSpan then
        addTextBoxModule()
      end
      if itemType ~= 0 then
        local data = {
          itemInfo = tipInfo,
          stack = {has, need}
        }
        local itemIcon = W_MODULE:Create("itemIcon", dialogWnd, W_MODULE.TYPES.ICON_VERTICAL, data)
        dialogWnd:RegisterStack(itemIcon)
      end
      if not tipInfo or not tipInfo.lifeSpan then
        addTextBoxModule()
      elseif tipInfo and has > 0 then
        local dt = locale.time.GetDateFormatFromSec(tipInfo.lifeSpan)
        local timeString = F_TEXT.SetColonFormat(GetUIText(TOOLTIP_TEXT, "left_time"), string.format("%s %s", locale.time.GetRemainDateToDateFormat(dt), locale.housing.left))
        if timeString ~= "" then
          UIParent:Warning(timeString)
          local periodData = {
            type = "period",
            [W_MODULE.ATTRIBUTE.TEXT] = timeString
          }
          local period = W_MODULE:Create("period", dialogWnd, W_MODULE.TYPES.TEXTBOX, periodData)
          dialogWnd:RegisterStack(period)
        end
      end
      function dialogWnd:OkProc()
        local unit = GetBeautyshopModelUnit()
        unit:PayBeautyShop()
      end
    end
    X2DialogManager:RequestDialog(DialogHandler, wnd:GetId())
  end
  confirmBtn:SetHandler("OnClick", ConfirmBtnOnClick)
  local function OnModelChanged(self)
    confirmBtn:Enable(modelView:HasDiffWithClientUnit())
  end
  modelView:SetHandler("OnModelChanged", OnModelChanged)
  local OnEnter = function(self)
    if self:IsEnabled() then
      return
    end
    local str = ""
    local ticketType = X2Customizer:GetBeautyShopConfigInfo()
    if ticketType ~= 0 then
      local ticketItemInfo = X2Item:GetItemInfoByType(ticketType)
      str = GetUIText(COMMON_TEXT, "not_have_changing_or_not_have_item_in_beautyshop", ticketItemInfo.gradeColor, ticketItemInfo.name)
    else
      str = GetUIText(COMMON_TEXT, "not_have_changing_in_beautyshop")
    end
    SetTooltip(str, self)
  end
  confirmBtn:SetHandler("OnEnter", OnEnter)
  local customSaveLoadWnd = CreateCustomSaveLoadWnd("customSaveLoadWnd", wnd)
  customSaveLoadWnd:AddAnchor("RIGHT", confirmBtn, "LEFT", -20, 0)
  customSaveLoadWnd:Show(true)
  function wnd:MakeParamFromUnit()
    modelView:InitCustomizerControl(false)
  end
  function wnd:MakeUnitFromParam()
    modelView:ApplyCustomizerParamToUnit()
    customizingContent:RefreshUI()
  end
  customSaveLoadWnd:SetPreSaveFunc(wnd.MakeParamFromUnit)
  customSaveLoadWnd:SetPreLoadFunc(wnd.MakeParamFromUnit)
  customSaveLoadWnd:SetPostLoadFunc(wnd.MakeUnitFromParam)
  local function SetFreeze(isStop)
    modelView:SetFreeze(isStop)
  end
  local function IsFreeze()
    return modelView:IsFrozen()
  end
  local freezewnd = CreateCustomFreezeWnd("freezewnd", wnd)
  freezewnd:AddAnchor("TOPRIGHT", wnd, -20, 10)
  freezewnd:Show(false)
  freezewnd.getFunc = IsFrozen
  freezewnd.setFunc = SetFreeze
  local hideCostumeWnd = CreateHideCostumeWnd("hideCostumeWnd", wnd)
  hideCostumeWnd:AddAnchor("BOTTOMRIGHT", confirmBtn, "TOPRIGHT", -5, -15)
  function wnd:ResetModel()
    modelView:ResetBeautyShop()
    hideCostumeWnd.chk:CheckBtnCheckChagnedProc(hideCostumeWnd.chk:GetChecked())
    customizingContent:RefreshUI()
  end
  function wnd.OnScale()
    wnd:AddAnchor("TOPLEFT", "UIParent", 0, 0)
    wnd:AddAnchor("BOTTOMRIGHT", "UIParent", 0, 0)
  end
  wnd:SetHandler("OnScale", wnd.OnScale)
  function wnd:OnShow()
    modelView:Init()
    modelView:PlayAnimation(ANIMATION_NAME, true)
    modelView:Show(true)
    freezewnd:Show(true)
    local race = modelView:GetRace()
    local gender = modelView:GetGender()
    customizingMenu:ApplyRaceGender(race, gender)
    customizingContent:ApplyRaceGender(race, gender)
    customizingMenu:SelectCustomizingType(RECOMMAND_MENU_TYPE)
    if hideCostumeWnd.chk:GetChecked() then
      hideCostumeWnd.chk:CheckBtnCheckChagnedProc(true)
    else
      hideCostumeWnd.chk:SetChecked(true)
    end
    if X2Equipment:GetEquippedItemType(ES_COSPLAY) == nil then
      hideCostumeWnd:Enable(false, true)
      hideCostumeWnd.chk:SetEnableCheckButton(false)
    else
      hideCostumeWnd:Enable(true, true)
      hideCostumeWnd.chk:SetEnableCheckButton(true)
    end
  end
  wnd:SetHandler("OnShow", wnd.OnShow)
  function wnd:OnHide()
    modelView:ClearModel()
    modelView:Show(false)
  end
  wnd:SetHandler("OnHide", wnd.OnHide)
  local BeautyShopEvents = {
    LEFT_LOADING = function()
      wnd:Raise()
    end,
    UI_RELOADED = function()
      wnd:Raise()
    end,
    BEAUTYSHOP_CLOSE_BY_SYSTEM = function()
      if wnd:IsVisible() then
        wnd:Show(false, 500)
        local ResultBeautyShopCloseBySystem = function(dlg)
          dlg:SetTitle(X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_message"))
          local textData = {
            [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "cusomizing_data_is_saved_temporary")
          }
          local textbox = W_MODULE:Create("textbox", dlg, W_MODULE.TYPES.TEXTBOX, textData)
          dlg:RegisterStack(textbox)
        end
        X2DialogManager:RequestDialog(ResultBeautyShopCloseBySystem, wnd:GetId(), {buttonType = DBT_OK})
      end
    end
  }
  wnd:SetHandler("OnEvent", function(this, event, ...)
    BeautyShopEvents[event](...)
  end)
  RegistUIEvent(wnd, BeautyShopEvents)
  return wnd
end
function GetBeautyshopModelUnit()
  if newBeautyshop ~= nil then
    return newBeautyshop.modelView
  end
end
function ToggleNewBeautyShop(show)
  if newBeautyshop == nil then
    newBeautyshop = CreateNewBeautyShop("newBeautyshop", "UIParent")
    newBeautyshop:EnableFocus(true)
  end
  newBeautyshop:Show(show)
  if show and X2Customizer:HasTemporaryCustomData() then
    local function AskTemporaryCustomData(dlg)
      function dlg:OkProc()
        X2Customizer:LoadTemporaryCustomData()
        newBeautyshop:MakeUnitFromParam()
        X2Customizer:DeleteTemporaryCustomData()
      end
      function dlg:CancelProc()
        X2Customizer:DeleteTemporaryCustomData()
      end
      dlg:SetTitle(X2Locale:LocalizeUiText(MSG_BOX_TITLE_TEXT, "error_message"))
      local textData = {
        [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "want_to_load_temporary_data")
      }
      local textbox = W_MODULE:Create("textbox", dlg, W_MODULE.TYPES.TEXTBOX, textData)
      dlg:RegisterStack(textbox)
    end
    X2DialogManager:RequestDialog(AskTemporaryCustomData, newBeautyshop:GetId())
  end
end
ADDON:RegisterContentTriggerFunc(UIC_BEAUTY_SHOP, ToggleNewBeautyShop)
if X2Customizer:IsEnteredBeautyShop() then
  X2Customizer:TerminateBeautyShop()
end
