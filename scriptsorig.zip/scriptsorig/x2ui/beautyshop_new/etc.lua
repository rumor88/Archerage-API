local titleMargin, sideMargin, bottomMargin = GetWindowMargin()
local SCREEN_WIDTH = UIParent:GetScreenWidth()
local SCREEN_HEIGHT = UIParent:GetScreenHeight()
function CreateBeautyShopModelView(id, parent)
  local modelView = parent:CreateChildWidget("modelview", id, 0, true)
  modelView:SetModelViewBackground("ui/beautyshop/bg.dds")
  modelView:SetTextureSize(SCREEN_WIDTH, SCREEN_HEIGHT)
  modelView:SetModelViewExtent(SCREEN_WIDTH, SCREEN_HEIGHT)
  modelView:SetModelViewCoords(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)
  modelView:SetFov(20)
  function modelView:OnWheelDown()
    modelView:ZoomInOutBeautyShop(1)
  end
  modelView:SetHandler("OnWheelDown", modelView.OnWheelDown)
  function modelView:OnWheelUp()
    modelView:ZoomInOutBeautyShop(-1)
  end
  modelView:SetHandler("OnWheelUp", modelView.OnWheelUp)
  function modelView:Init()
    modelView:InitBeautyShop()
  end
  return modelView
end
function CreateHideCostumeWnd(id, parent)
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  wnd:SetHeight(50)
  local initData = {
    textData = {
      text = X2Locale:LocalizeUiText(COMMON_TEXT, "hide_cosplay"),
      color = "check_btn_df"
    }
  }
  local chk = CreateCheckButton("chk", wnd, initData)
  chk:AddAnchor("LEFT", wnd, 0, 0)
  chk.textButton.style:SetFont(FONT_PATH.SUB, FONT_SIZE.LARGE)
  wnd.chk = chk
  function chk:CheckBtnCheckChagnedProc(checked)
    local unit = GetBeautyshopModelUnit()
    if checked == nil then
      checked = true
    end
    unit:ToggleCosplayEquipped(not checked)
  end
  wnd:SetExtent(chk:GetWidth() + chk.textButton:GetWidth(), chk.textButton:GetHeight())
  return wnd
end
