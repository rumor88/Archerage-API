## author : prodg
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## customizing

SCRIPTS/customizing_new/style.lua
SCRIPTS/customizing_new/color.lua
SCRIPTS/customizing_new/common.lua
SCRIPTS/customizing_new/modifier.lua
SCRIPTS/customizing_new/beautyshop.lua
SCRIPTS/customizing_new/components.lua
SCRIPTS/customizing_new/customizing_menu.lua
SCRIPTS/customizing_new/customizing_content.lua
SCRIPTS/customizing_new/etc.lua

etc.lua
beautyshop.lua
