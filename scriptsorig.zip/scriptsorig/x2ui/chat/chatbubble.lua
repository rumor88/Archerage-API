local MINIMUM_BUBBLE_WIDTH = 57
local DEFAULT_BUBBLE_WIDTH = 225
local nameTagHeight = 24
function CreateChatBubbleFrame()
  local frame = CreateEmptyWindow("chatBubbleFrame", "UIParent")
  frame:Show(true)
  frame:SetExtent(0, 0)
  frame:AddAnchor("CENTER", "UIParent", 0, 0)
  frame:EnablePick(false)
  frame:SetUILayer("game")
  frame.bubbles = {}
  function frame:IsExistSpeakerId(speakerId)
    return self.bubbles[speakerId] ~= nil
  end
  function frame:EraseBubble(speakerId)
    if self:IsExistSpeakerId(speakerId) then
      self.bubbles[speakerId] = nil
      return true
    end
    return false
  end
  function frame:AddBubble(speakerId, isUnit, chatType, showTime)
    if self:IsExistSpeakerId(speakerId) and self.bubbles[speakerId].isUnit == isUnit then
      self.bubbles[speakerId].curTime = 0
      self.bubbles[speakerId].showTime = showTime or 5000
      self.bubbles[speakerId].chatType = chatType or CHAT_SAY
      self.bubbles[speakerId]:SetWidth(DEFAULT_BUBBLE_WIDTH)
      return self.bubbles[speakerId]
    end
    local textbox = frame:CreateChildWidget("textbox", string.format("bubbleTextbox[%s]", speakerId), 0, true)
    textbox:EnablePick(false)
    self.bubbles[speakerId] = textbox
    textbox.speakerId = speakerId
    textbox:Show(true)
    textbox.curTime = 0
    textbox.showTime = showTime or 5000
    textbox.chatType = chatType or CHAT_SAY
    textbox.isUnit = isUnit
    if textbox.isUnit then
      textbox.speakerInfo = X2Unit:GetUnitInfoById(speakerId)
    else
      textbox.speakerInfo = X2Unit:GetDoodadInfoById(speakerId)
    end
    textbox:EnableHidingIsRemove(true)
    textbox:SetWidth(DEFAULT_BUBBLE_WIDTH)
    textbox.style:SetAlign(ALIGN_TOP_LEFT)
    textbox.style:SetSnap(true)
    textbox.style:SetShadow(false)
    textbox.style:SetFontSize(FONT_SIZE.LARGE)
    local nameTag = W_CTRL.CreateLabel("nameTag", textbox)
    nameTag:EnablePick(false)
    nameTag:SetHeight(nameTagHeight)
    nameTag.style:SetEllipsis(true)
    nameTag:AddAnchor("BOTTOMLEFT", textbox, "TOPLEFT", 0, 0)
    nameTag:AddAnchor("BOTTOMRIGHT", textbox, "TOPRIGHT", 0, 0)
    nameTag.style:SetAlign(ALIGN_TOP_LEFT)
    nameTag.style:SetShadow(false)
    textbox.nameTag = nameTag
    local tail = textbox:CreateDrawable(TEXTURE_PATH.HUD, "chat_bubble_tail_normal", "overlay")
    tail:SetTextureColor("default")
    textbox.tail = tail
    local bg = textbox:CreateDrawable(TEXTURE_PATH.HUD, "chat_bubble_bg", "background")
    bg:AddAnchor("BOTTOMRIGHT", textbox, 17, 19)
    textbox.bg = bg
    function textbox:SetTailType(tailType)
      if tailType == CBK_NORMAL then
        self.tail:SetTextureInfo("chat_bubble_tail_normal")
        self.tail:AddAnchor("TOP", self.bg, "BOTTOM", 18, -10)
      elseif tailType == CBK_THINK then
        self.tail:SetTextureInfo("chat_bubble_tail_think")
        self.tail:AddAnchor("TOP", self.bg, "BOTTOM", 12, -9)
      elseif tailType == CBK_SYSTEM then
        self.tail:SetTextureInfo("chat_bubble_tail_think")
        self.tail:AddAnchor("TOP", self.bg, "BOTTOM", 12, -9)
      end
    end
    textbox:SetTailType(CBK_NORMAL)
    function textbox:AdjustBubbleLayout()
      if self.speakerInfo == nil then
        return
      end
      local myId = X2Unit:GetUnitId("player")
      if myId == self.speakerId then
        self.nameTag:Show(false)
        self.bg:AddAnchor("TOPLEFT", self, -17, -19)
      else
        self.nameTag:Show(true)
        self.bg:AddAnchor("TOPLEFT", self.nameTag, -17, -19)
      end
      local faction = self.speakerInfo.faction
      local tailType = self.speakerInfo.type
      if faction == "hostile" then
        self.nameTag.style:SetColorByKey("bubble_name_hostile")
      elseif tailType == "character" then
        self.nameTag.style:SetColorByKey("bubble_name_friendly_char")
      elseif tailType == "npc" then
        self.nameTag.style:SetColorByKey("bubble_name_friendly_npc")
      end
      if self.chatType == CHAT_SAY then
        self.style:SetColorByKey("bubble_chat_say")
        if faction == "hostile" then
          self.style:SetColorByKey("bubble_chat_say_hostile")
        elseif tailType == "character" then
          self.style:SetColorByKey("bubble_chat_say")
        elseif tailType == "npc" then
          self.style:SetColorByKey("bubble_chat_say_npc")
        end
      elseif self.chatType == CHAT_WHISPER or self.chatType == CHAT_PARTY then
        self.style:SetColorByKey("bubble_chat_etc")
      else
        self.style:SetColorByKey("bubble_chat_etc")
      end
      local name = self.nameTag:GetText()
      local nameWidth = self.nameTag.style:GetTextWidth(name)
      local textWidth = self:GetLongestLineWidth()
      local lineCount = self:GetLineCount()
      if lineCount == 1 then
        local width = math.max(nameWidth, textWidth + 10)
        width = math.max(width, MINIMUM_BUBBLE_WIDTH)
        self.nameTag:SetWidth(width)
        self:SetWidth(width)
      end
      local left, top, right, bottom = self:GetInset()
      local height = self:GetTextHeight()
      if height < 15 then
        height = 15
      end
      self:SetHeight(height)
    end
    function textbox:SetChatMsg(name, text, specifyName)
      if name ~= nil then
        self.nameTag:SetText(name)
      end
      if specifyName then
        self:SetText(text, specifyName)
      else
        self:SetText(text)
      end
      self:AdjustBubbleLayout()
    end
    function textbox:OnHide()
      frame:EraseBubble(self.speakerId)
    end
    textbox:SetHandler("OnHide", textbox.OnHide)
    function textbox:OnUpdate(dt)
      local sx, sy, sz
      if self.speakerId == nil then
        self:Show(false)
        return
      end
      if self.isUnit then
        sx, sy, sz = X2Unit:GetUnitScreenNameTagOffset(self.speakerId)
      else
        sx, sy, sz = X2Unit:GetDoodadScreenPosition(self.speakerId)
      end
      if sx == nil or sy == nil or sz == nil then
        self:Show(false)
        return
      end
      local bubbleWidth, bubbleHeight = self:GetEffectiveExtent()
      if sx > -bubbleWidth / 2 and sx < UIParent:GetScreenWidth() + bubbleWidth / 2 and sy > bubbleHeight and sy < UIParent:GetScreenHeight() then
        if sz ~= nil and sz > 0 then
          if not self:IsVisible() then
            self:Show(true)
          end
          self:AddAnchor("BOTTOM", "UIParent", "TOPLEFT", math.floor(sx), math.floor(sy) - self.tail:GetHeight())
        else
          self:Show(false)
          return
        end
      else
        self:Show(false)
        return
      end
      if self.curTime < self.showTime then
        self:SetAlpha(1)
      elseif self.curTime < self.showTime + 1000 then
        self:SetAlpha(1 - (self.curTime - self.showTime) / 1000)
      else
        self:Show(false)
        return
      end
      self.curTime = self.curTime + dt
    end
    textbox:SetHandler("OnUpdate", textbox.OnUpdate)
    return textbox
  end
  return frame
end
chatBubbleFrame = CreateChatBubbleFrame()
local OnChatMessage = function(chatType, relation, speakerName, message, info)
  local show = GetOptionItemValue(OIT_SHOWCHATBUBBLE) == 1
  if show == false then
    return
  end
  if chatType ~= CHAT_SAY and chatType ~= CHAT_PARTY and chatType ~= CHAT_RAID and chatType ~= CHAT_EXPEDITION then
    return
  end
  local speakerId = info and info.unitId or 0
  if speakerId == 0 then
    return
  end
  local speakerInChatBound = info and info.speakerInChatBound or false
  if speakerInChatBound == false then
    return
  end
  local specifyName = info and info.specifyName or nil
  bubble = chatBubbleFrame:AddBubble(speakerId, true, chatType, 5000)
  bubble:SetChatMsg(speakerName, message, specifyName)
end
local OnChatMsgQuest = function(message, speakerName, speakerId, self, tailType, showTime, fadeTime, currentBubbleType, qtype, forceFinished)
  if X2Quest:IsQuestDirectingMode() == true then
    return
  end
  local show = GetOptionItemValue(OIT_SHOWCHATBUBBLE) == 1
  if show == false then
    return
  end
  if forceFinished then
    return
  end
  local convertMessage = X2Util:ApplyUIMacroString(message, speakerName)
  bubble = chatBubbleFrame:AddBubble(speakerId, true, CHAT_QUEST, showTime or 5000)
  bubble:SetChatMsg(speakerName, convertMessage)
  bubble:SetTailType(tailType)
end
local OnChatMsgDoodad = function(message, speakerName, speakerId, self, tailType, showTime, fadeTime, hasNext, qtype, forceFinished)
  if X2Quest:IsQuestDirectingMode() == true then
    return
  end
  local show = GetOptionItemValue(OIT_SHOWCHATBUBBLE) == 1
  if show == false then
    return
  end
  if forceFinished then
    return
  end
  local convertMessage = X2Util:ApplyUIMacroString(message, speakerName)
  bubble = chatBubbleFrame:AddBubble(speakerId, false, CHAT_QUEST, showTime or 5000)
  bubble:SetChatMsg(speakerName, convertMessage)
  bubble:SetTailType(tailType)
end
local chatBubbleEvents = {
  CHAT_MESSAGE = OnChatMessage,
  CHAT_MSG_QUEST = OnChatMsgQuest,
  CHAT_MSG_DOODAD = OnChatMsgDoodad,
  CHAT_EMOTION = function(message)
    X2Chat:DispatchChatMessage(CMF_EMOTIOIN_EXPRESS, message)
  end
}
chatBubbleFrame:SetHandler("OnEvent", function(this, event, ...)
  chatBubbleEvents[event](...)
end)
chatBubbleFrame:RegisterEvent("CHAT_MESSAGE")
chatBubbleFrame:RegisterEvent("CHAT_MSG_QUEST")
chatBubbleFrame:RegisterEvent("CHAT_MSG_DOODAD")
chatBubbleFrame:RegisterEvent("CHAT_EMOTION")
