local InsertToCheckBoxTabls = function(checkBoxTable, checkBox, extraValue)
  if checkBoxTable == nil then
    return
  end
  if checkBoxTable.boxArray == nil then
    checkBoxTable.boxArray = {}
  end
  table.insert(checkBoxTable.boxArray, checkBox)
  if extraValue == nil then
    return
  end
  if checkBoxTable.boxMapUseExtraValue == nil then
    checkBoxTable.boxMapUseExtraValue = {}
  end
  checkBoxTable.boxMapUseExtraValue[extraValue] = checkBox
end
function CreateCheckGroup(id, parent, info, checkBoxs)
  local window = CreateCheckGroupWindow(id, parent, info)
  if info.menuTexts ~= nil then
    for i = 1, #info.menuTexts do
      InsertToCheckBoxTabls(checkBoxs, window.checks[i], info.extraValue[i])
      if info.tipValue ~= nil and info.tipValue[i] ~= nil then
        local function OnEnter(self)
          SetTooltip(info.tipValue[i], self)
        end
        window.checks[i]:SetHandler("OnEnter", OnEnter)
        window.checks[i].textButton:SetHandler("OnEnter", OnEnter)
      end
    end
  end
  if info.subMenuTexts ~= nil then
    for j = 1, #info.subMenuTexts do
      InsertToCheckBoxTabls(checkBoxs, window.subChecks[j], info.subExtraValue[j])
    end
  end
  return window
end
function SetViewOfColorPickCheckGroup(id, parent, info, checkBoxs)
  local window = CreateCheckGroupWindow(id, parent, info)
  if info.menuTexts ~= nil then
    window.colorPicks = {}
    if info.menuChkboxOffset == nil then
      info.menuChkboxOffset = 145
    end
    for i = 1, #info.menuTexts do
      local colorPick = CreateColorPickButtons(string.format("colorPick[%d]", i), window.checks[i])
      colorPick:SetExtent(23, 15)
      colorPick:AddAnchor("TOPLEFT", window.checks[i], info.menuChkboxOffset, 3)
      window.colorPicks[i] = colorPick
      window.checks[i].colorPick = colorPick
      InsertToCheckBoxTabls(checkBoxs, window.checks[i], info.extraValue[i])
      if info.tipValue ~= nil and info.tipValue[i] ~= nil then
        local function OnEnter(self)
          SetTooltip(info.tipValue[i], self)
        end
        window.checks[i]:SetHandler("OnEnter", OnEnter)
        window.checks[i].textButton:SetHandler("OnEnter", OnEnter)
      end
    end
  end
  if info.subMenuTexts ~= nil then
    window.subColorPicks = {}
    if info.submenuChkboxOffset == nil then
      info.submenuChkboxOffset = 127
    end
    for j = 1, #info.subMenuTexts do
      local colorPick = CreateColorPickButtons(string.format("colorPick[%d]", j), window.subChecks[j])
      colorPick:SetExtent(23, 15)
      colorPick:AddAnchor("TOPLEFT", window.subChecks[j], info.submenuChkboxOffset, 3)
      window.subColorPicks[j] = colorPick
      window.subChecks[j].colorPick = colorPick
      InsertToCheckBoxTabls(checkBoxs, window.subChecks[j], info.subExtraValue[j])
    end
  end
  return window
end
function CreateColorPickCheckGroup(id, parent, info, checkBoxs)
  local window = SetViewOfColorPickCheckGroup(id, parent, info, checkBoxs)
  if info.menuTexts ~= nil then
    for i = 1, #info.menuTexts do
      local button = window.colorPicks[i]
      local finalOrder = #info.menuTexts
      function button:SelectedProcedure(r, g, b, a)
        self.colorBG:SetColor(r, g, b, a)
        if i == finalOrder then
          for j = 1, #window.subChecks do
            window.subChecks[j].colorPick.colorBG:SetColor(r, g, b, a)
          end
        end
      end
      function button:OnClick(arg)
        if arg == "LeftButton" then
          F_PALETTE.ShowPalette(button)
        end
      end
      button:SetHandler("OnClick", button.OnClick)
    end
  end
  if info.subMenuTexts ~= nil then
    for i = 1, #info.subMenuTexts do
      local button = window.subColorPicks[i]
      function button:SelectedProcedure(r, g, b, a)
        self.colorBG:SetColor(r, g, b, a)
      end
      function button:OnClick(arg)
        if arg == "LeftButton" then
          F_PALETTE.ShowPalette(button)
        end
      end
      button:SetHandler("OnClick", button.OnClick)
    end
  end
  return window
end
local sideMargin, titleMargin, bottomMargin = GetWindowMargin()
function AddLinkItem(linkText)
  if linkText ~= nil then
    X2Chat:AddItemLinkToActiveChatInput(linkText)
    return true
  end
  return false
end
function AddItemLinkHandlerToMessageWidget(widget)
  local OnMouseDown = function(self, arg)
    if arg ~= "LeftButton" then
      return
    end
    local info = self:GetLinkInfoOnCursor()
    if info.linkType == "none" then
      return false
    else
      return true
    end
  end
  widget:SetHandler("OnMouseDown", OnMouseDown)
  function widget:OnClick(arg)
    local info = self:GetLinkInfoOnCursor()
    if info.linkType == "item" and arg == "LeftButton" then
      local itemInfo = X2Item:InfoFromLink(info.itemLinkText, tostring(info.linkKind))
      ShowItemLinkTooltip(itemInfo)
      return true
    end
    if info.linkType == "character" and arg == "RightButton" then
      local name = info.charNameWithWorld
      local data = {
        relation = info.relation,
        messageTimeStamp = info.messageTimeStamp,
        filter = info.filter,
        isOtherWorld = info.isOtherWorld
      }
      data.jointOrder, data.memberIndex = X2Team:GetMemberIndexByName(name, false)
      local myMemberIndex = X2Team:GetTeamPlayerIndex()
      if data.relation == UR_FRIENDLY and data.jointOrder == nil and X2Team:IsRaidTeam() and not X2Team:IsJointTeam() and X2Team:IsTeamOwner(X2Team:GetMyTeamJointOrder(), myMemberIndex) then
        widget.savedData = data
        X2Team:JointInfoReq(TEAM_JOINT_MENU_CHAT, name)
        return true
      end
      ActivatePopupMenu(self, name, data)
      self:BackupString(name)
      return true
    end
    if info.linkType == "quest" and arg == "LeftButton" then
      ShowQuestLinkTooltip(info)
      return true
    end
    if info.linkType == "raid" and arg == "LeftButton" then
      X2Team:RaidRecruitDetail(info.ownerId, info.createTime)
      return true
    end
    if info.linkType == "squad" and arg == "LeftButton" then
      X2Squad:JoinSquadByKey(info.squadId, info.battleFieldType, info.joinKey)
      return true
    end
    if info.linkType == "url" and arg == "LeftButton" then
      ShowUrlCopyWindow("urlCopy", "UIParent", info.addr)
      return true
    end
    if info.linkType == "craft" and arg == "LeftButton" then
      if UIParent:GetPermission(UIC_CRAFT_BOOK) then
        ExternalCraftTypeSearch(info.craftType)
      else
        AddMessageToSysMsgWindow(X2Locale:LocalizeUiText(ERROR_MSG, "INVALID_LINK"))
      end
      return true
    end
    if info.linkType == "invalid" and arg == "LeftButton" then
      AddMessageToSysMsgWindow(X2Locale:LocalizeUiText(ERROR_MSG, "INVALID_LINK"))
      return true
    end
    if arg == "RightButton" then
      local result = self:CopyTextToClipboard()
      if result == true then
        X2Chat:DispatchChatMessage(CMF_SYSTEM, GetUIText(COMMON_TEXT, "chat_copy_to_clipboard"))
      end
      return true
    end
    return false
  end
  widget:SetHandler("OnClick", widget.OnClick)
  widget:EnableItemLink(true)
  function widget:OnEvent(event, ...)
    if event == "TEAM_JOINT_CHAT" and self.savedData ~= nil then
      local data = self.savedData
      data.jointable = arg[2]
      ActivatePopupMenu(self, arg[1], data)
      self:BackupString(arg[1])
    end
  end
  widget:SetHandler("OnEvent", widget.OnEvent)
  widget:RegisterEvent("TEAM_JOINT_CHAT")
end
function DrawChatEditBackground(editWidget)
  local bg = editWidget:CreateDrawable(TEXTURE_PATH.HUD, "chat_common_edit_bg", "background")
  bg:AddAnchor("TOPLEFT", editWidget, 0, 0)
  bg:AddAnchor("BOTTOMRIGHT", editWidget, 0, 0)
end
function DrawLineDoubleTarget(widget, widget_2)
  local line = CreateLine(widget, "TYPE1", "overlay")
  line:SetTextureColor("default")
  line:SetExtent(0, 3)
  line:AddAnchor("LEFT", widget, 0, 0)
  line:AddAnchor("RIGHT", widget_2, 0, 0)
  widget.line = line
  if widget:GetHeight() > widget_2:GetHeight() then
    line:AddAnchor("BOTTOM", widget, 0, 5)
  else
    line:AddAnchor("BOTTOM", widget_2, 0, 5)
  end
end
function IsPossibleChatFilter(chatType)
  local chatTypeCheckFunc = {
    [CMF_RACE] = X2Player:GetFeatureSet().chatRace,
    [CMF_SQUAD] = X2Player:GetFeatureSet().squad,
    [CMF_FACTION] = X2Chat:IsEnableChatChannel(CHAT_FACTION),
    [CMF_LOCALE_SERVER] = X2Chat:IsEnableChatChannel(CHAT_LOCALE_SERVER),
    [CMF_SELF_HONOR_POINT_CHANGED] = not X2Player:GetFeatureSet().blockSpendableGamePoint,
    [CMF_SELF_LIVING_POINT_CHANGED] = not X2Player:GetFeatureSet().blockSpendableGamePoint,
    [CMF_DOMINION_AND_SIEGE_INFO] = X2Player:GetFeatureSet().siege
  }
  if chatTypeCheckFunc[chatType] ~= nil then
    return chatTypeCheckFunc[chatType]
  end
  return true
end
function MakeOptionGroupList(filters)
  local info = {}
  for i = 1, #filters do
    info[i] = {
      menuTexts = {},
      extraValue = {},
      subMenuTexts = {},
      subExtraValue = {},
      tipValue = {}
    }
    for j = 1, #filters[i] do
      local chatType = filters[i][j]
      if type(chatType) == "table" then
        for k = 1, #filters[i][j] do
          chatType = filters[i][j][k]
          if IsPossibleChatFilter(chatType) then
            table.insert(info[i].subMenuTexts, locale.chatFiltering.texts[chatType])
            table.insert(info[i].subExtraValue, chatType)
          end
        end
      elseif IsPossibleChatFilter(chatType) then
        table.insert(info[i].menuTexts, locale.chatFiltering.texts[chatType])
        table.insert(info[i].extraValue, chatType)
        info[i].tipValue[#info[i].menuTexts] = locale.chatFiltering.tip[chatType]
      end
    end
  end
  return info
end
