local layoutSet = {
  default = {
    chatOptionWidth = F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_510),
    normalPageFilter = {
      {
        CMF_SAY,
        CMF_WHISPER,
        CMF_PARTY,
        CMF_RAID,
        CMF_EXPEDITION,
        CMF_FACTION,
        CMF_LOCALE_SERVER,
        CMF_ALL_SERVER,
        CMF_ZONE,
        CMF_TRADE,
        CMF_FIND_PARTY,
        CMF_SQUAD,
        CMF_TRIAL,
        CMF_FAMILY,
        CMF_RACE
      },
      {CMF_OTHER_CONTINENT},
      {CMF_KO}
    }
  },
  [KAKAONA] = {
    chatOptionWidth = F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_600),
    normalPageFilter = {
      {
        CMF_SAY,
        CMF_WHISPER,
        CMF_PARTY,
        CMF_RAID,
        CMF_EXPEDITION,
        CMF_FACTION,
        CMF_LOCALE_SERVER,
        CMF_ALL_SERVER,
        CMF_ZONE,
        CMF_TRADE,
        CMF_FIND_PARTY,
        CMF_SQUAD,
        CMF_TRIAL,
        CMF_FAMILY,
        CMF_RACE
      },
      {CMF_OTHER_CONTINENT},
      {
        CMF_EN_US,
        CMF_DE,
        CMF_FR
      }
    }
  },
  [GAMEON] = {
    chatOptionWidth = F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_510),
    normalPageFilter = {
      {
        CMF_SAY,
        CMF_WHISPER,
        CMF_PARTY,
        CMF_RAID,
        CMF_EXPEDITION,
        CMF_FACTION,
        CMF_LOCALE_SERVER,
        CMF_ALL_SERVER,
        CMF_ZONE,
        CMF_TRADE,
        CMF_FIND_PARTY,
        CMF_SQUAD,
        CMF_TRIAL,
        CMF_FAMILY,
        CMF_RACE
      },
      {CMF_OTHER_CONTINENT},
      {CMF_JA}
    }
  },
  [MAILRU] = {
    chatOptionWidth = F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_600),
    normalPageFilter = {
      {
        CMF_SAY,
        CMF_WHISPER,
        CMF_PARTY,
        CMF_RAID,
        CMF_EXPEDITION,
        CMF_FACTION,
        CMF_LOCALE_SERVER,
        CMF_ALL_SERVER,
        CMF_ZONE,
        CMF_TRADE,
        CMF_FIND_PARTY,
        CMF_SQUAD,
        CMF_TRIAL,
        CMF_FAMILY,
        CMF_RACE
      },
      {CMF_OTHER_CONTINENT},
      {CMF_RU}
    }
  },
  [XLGAMES_TH] = {
    chatOptionWidth = F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_600),
    normalPageFilter = {
      {
        CMF_SAY,
        CMF_WHISPER,
        CMF_PARTY,
        CMF_RAID,
        CMF_EXPEDITION,
        CMF_FACTION,
        CMF_LOCALE_SERVER,
        CMF_ALL_SERVER,
        CMF_ZONE,
        CMF_TRADE,
        CMF_FIND_PARTY,
        CMF_SQUAD,
        CMF_TRIAL,
        CMF_FAMILY,
        CMF_RACE
      },
      {CMF_OTHER_CONTINENT},
      {
        CMF_EN_SG,
        CMF_ZH_TW,
        CMF_TH,
        CMF_IND
      }
    }
  }
}
function GetLayoutSetChatOption()
  return L_HELPER.Get(layoutSet)
end
