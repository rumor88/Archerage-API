local sideMargin, titleMargin, bottomMargin = GetWindowMargin()
function CreateCombatChatOptionTab(parent)
  local filters = {
    {CMF_COMBAT_SRC_GROUP},
    {CMF_COMBAT_DST_GROUP},
    {
      CMF_COMBAT_MELEE_GROUP,
      {CMF_COMBAT_MELEE_DAMAGE, CMF_COMBAT_MELEE_MISSED}
    },
    {
      CMF_COMBAT_SPELL_GROUP,
      {
        CMF_COMBAT_SPELL_DAMAGE,
        CMF_COMBAT_SPELL_MISSED,
        CMF_COMBAT_SPELL_HEALED,
        CMF_COMBAT_SPELL_ENERGIZE
      }
    },
    {
      CMF_COMBAT_SPELL_AURA,
      CMF_COMBAT_ENVIRONMENTAL_DMANAGE,
      CMF_COMBAT_DEAD
    }
  }
  local menuChkboxOffset = (parent:GetWidth() - sideMargin * 2) / 2 - 15
  local submenuChkboxOffset = menuChkboxOffset - 18
  local offsetX = 0
  local offsetY = 10
  local checkBoxs = {}
  local groups = {}
  local list = MakeOptionGroupList(filters)
  for i = 1, #list do
    if i > 2 and i % 2 == 1 then
      DrawLineDoubleTarget(groups[i - 2], groups[i - 1])
    end
    list[i].menuChkboxOffset = menuChkboxOffset
    list[i].submenuChkboxOffset = submenuChkboxOffset
    local group = CreateColorPickCheckGroup(string.format("group[%d]", i), parent, list[i], checkBoxs)
    group:AddAnchor("TOPLEFT", parent, offsetX, offsetY)
    group:SetWidth(menuChkboxOffset + 23)
    groups[i] = group
    if i % 2 == 1 then
      offsetX = menuChkboxOffset + 45
    else
      offsetX = 0
      offsetY = offsetY + group:GetHeight() + 10
    end
  end
  function parent:ReadOption(info, isDefault)
    local boxMap = checkBoxs.boxMapUseExtraValue
    for key, checkbox in pairs(boxMap) do
      local checked = info.filters[key]
      local enabled = not info.filterLocked[key]
      local color = info.filterColors[key]
      checkbox:SetChecked(checked, false)
      checkbox:Enable(enabled)
      checkbox.colorPick.colorBG:SetColor(color.r, color.g, color.b, color.a)
    end
  end
  function parent:WriteOption(info)
    local boxMap = checkBoxs.boxMapUseExtraValue
    for key, checkBox in pairs(boxMap) do
      info.filters[key] = checkBox:GetChecked()
      info.filterColors[key] = checkBox.colorPick.colorBG:GetColor()
    end
  end
end
