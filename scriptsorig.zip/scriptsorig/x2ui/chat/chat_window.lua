local lastPopupParent
local function OnHidedPopup(popup)
  if lastPopupParent ~= nil then
    lastPopupParent:UseDynamicDrawableState("background", true)
    lastPopupParent:UseDynamicDrawableState("artwork", true)
    lastPopupParent:UseDynamicDrawableState("overlay", true)
    lastPopupParent = nil
  end
end
function OnContextChatTab(chatMessage, tabButton, chatTabId)
  lastPopupParent = chatMessage:GetParent()
  lastPopupParent:UseDynamicDrawableState("background", false)
  lastPopupParent:UseDynamicDrawableState("artwork", false)
  lastPopupParent:UseDynamicDrawableState("overlay", false)
  PopupChatTabContext(chatMessage, tabButton, chatTabId, OnHidedPopup)
end
function OnClickedChatTabAddButton(windowId)
  ShowDialogCreateNameChatTab(windowId)
  return true
end
function OnCreateChatWindow(chatWindow)
  local data = UIParent:GetTextureData(TEXTURE_PATH.CHAT, "tab_chat_select_normal")
  if data ~= nil then
    chatWindow:SetTabWidth(data.extent[1])
    chatWindow:SetTabAreaHeight(data.extent[2])
    chatWindow:SetMinTabWidth(data.coords[3])
  end
  chatWindow:SetOffset(0)
  chatWindow:SetCaretOffset(0, 5)
  chatWindow:UseAutoResizingTabButtonMode(true)
  chatWindow:SetMinResizingExtent(345, 160)
  chatWindow:SetMaxResizingExtent(1050, 1020)
  chatWindow:SetTabAreaInset(0, 0, 10, 0)
  chatWindow:UseResizing(true)
  local locker = chatWindow:GetLockNotifyDrawable()
  locker:SetTexture(TEXTURE_PATH.HUD)
  locker:SetTextureInfo("lock_big")
  chatWindow:SetMaxNotifyTime(3000)
  chatWindow:SetNotifyBlinkingFreq(400)
  local caret = chatWindow:GetCaretDrawable()
  caret:SetTexture(TEXTURE_PATH.HUD)
  caret:SetTextureInfo("caret")
  local addButton = chatWindow:GetAddButton()
  addButton:SetStyle("hud_btn_chat_add_tab")
  local imeToggleBtn = chatWindow:GetImeToggleButton()
  imeToggleBtn:SetStyle("hud_btn_ime_korea")
  imeToggleBtn:RemoveAllAnchors()
  imeToggleBtn:AddAnchor("LEFT", chatWindow:GetChatEdit(), "RIGHT", 0, 1)
  function imeToggleBtn:UpdateImeMode()
    local inputLanguage = X2Input:GetInputLanguage()
    if inputLanguage == "English" then
      imeToggleBtn:SetStyle("hud_btn_ime_english")
    else
      imeToggleBtn:SetStyle("hud_btn_ime_korea")
    end
  end
  function imeToggleBtn:OnClick()
    chatWindow:GetChatEdit():SetFocus()
    local inputLanguage = X2Input:GetInputLanguage()
    if inputLanguage ~= "English" then
      X2Input:SetInputLanguage("English")
    else
      X2Input:SetInputLanguage("Native")
    end
    self:UpdateImeMode()
  end
  imeToggleBtn:SetHandler("OnClick", imeToggleBtn.OnClick)
  function imeToggleBtn:OnEvent(event)
    self:UpdateImeMode()
  end
  imeToggleBtn:SetHandler("OnEvent", imeToggleBtn.OnEvent)
  imeToggleBtn:RegisterEvent("IME_STATUS_CHANGED")
  imeToggleBtn:UpdateImeMode()
  local urlBtn = chatWindow:GetUrlButton()
  urlBtn:SetStyle("hud_btn_url_link")
  if X2Player:GetFeatureSet().useUrlLink == false then
    urlBtn:Enable(false)
  else
    function urlBtn:OnClick()
      ShowUrlLinkWindow("urlLink", "UIParent")
    end
    urlBtn:SetHandler("OnClick", urlBtn.OnClick)
    local urlBtnOnEnter = function(self)
      SetTooltip(GetCommonText("url_icon_tooltip"), self)
    end
    urlBtn:SetHandler("OnEnter", urlBtnOnEnter)
  end
  local edit = chatWindow:GetChatEdit()
  edit:SetCursorColorByColorKey("editbox_cursor_light")
  edit:SetHeight(DEFAULT_SIZE.CHAT_EDIT_HEIGHT)
  edit:RemoveAllAnchors()
  edit:AddAnchor("TOPLEFT", chatWindow, "BOTTOMLEFT", 2, 2)
  edit:AddAnchor("RIGHT", chatWindow, "RIGHT", -47, 0)
  edit:SetMaxTextLength(160)
  local restrictLabel = edit:CreateChildWidget("label", "restrictLabel", 0, true)
  restrictLabel:Show(false)
  restrictLabel:SetHeight(23)
  restrictLabel:SetAutoResize(true)
  restrictLabel:AddAnchor("LEFT", edit, 85, 0)
  restrictLabel:SetText(X2Locale:LocalizeUiText(RESTRICT_TEXT, "restrict_info"))
  restrictLabel.style:SetColorByKey("pure_red")
  function edit:OnAcceptFocus()
    local keyboardLayout = X2Locale:GetKeyboardLayout()
    imeToggleBtn:Show(keyboardLayout == "KOREAN" or keyboardLayout == "JAPANESE")
    local enableChat = X2Player:IsEnableChat()
    restrictLabel:Show(not enableChat)
    urlBtn:Show(true)
  end
  edit:SetHandler("OnAcceptFocus", edit.OnAcceptFocus)
  function edit:OnTextChanged()
    if string.len(edit:GetText()) > 0 then
      restrictLabel:Show(false)
    end
  end
  edit:SetHandler("OnTextChanged", edit.OnTextChanged)
  DrawChatEditBackground(edit)
  edit:SetPrefixInset(0, 0, 5, 0)
  local chatTypeButton = chatWindow:GetChatMethodSelector()
  chatTypeButton:SetHeight(DEFAULT_SIZE.EDIT_HEIGHT)
  chatTypeButton:RemoveAllAnchors()
  chatTypeButton:AddAnchor("LEFT", edit, 0, 0)
  chatTypeButton.icon = chatTypeButton:CreateDrawable(TEXTURE_PATH.HUD, "white_balloon", "artwork")
  chatTypeButton.icon:AddAnchor("LEFT", chatTypeButton, 3, -1)
  local typeInset = 5
  chatTypeButton:SetInset(chatTypeButton.icon:GetWidth() + typeInset, 0, 0, 0)
  local costWnd = edit:CreateChildWidget("textbox", "costWnd", 0, true)
  costWnd:SetExtent(100, edit:GetHeight())
  costWnd:SetInset(0, 0, 5, 0)
  costWnd:AddAnchor("RIGHT", edit, 0, 0)
  costWnd.style:SetAlign(ALIGN_RIGHT)
  costWnd:Show(false)
  function costWnd:SetValue(str, len)
    if str ~= nil then
      costWnd:SetWidth(200)
      costWnd:SetText(str)
      local width = costWnd:GetLongestLineWidth() + 5
      costWnd:SetWidth(width)
      edit:SetInset(30 + len + 10, 0, 5 + width, 0)
      costWnd:Show(true)
    else
      edit:SetInset(30 + len + 10, 0, 5, 0)
      costWnd:Show(false)
    end
  end
  CreateComboList(chatTypeButton)
  local init = true
  local lastChannel
  function chatTypeButton:OnContentUpdated(kind, arg1, arg2)
    local text = chatTypeButton:GetText()
    local len = chatTypeButton.style:GetTextWidth(text)
    local calcInset = len + chatTypeButton.icon:GetWidth() + typeInset
    chatTypeButton:SetWidth(calcInset)
    edit:SetInset(calcInset + 5, 0, 5, 0)
    local info = X2Chat:GetChatChannelInfo(arg2)
    local costStr, msgStr
    if info ~= nil and 0 < info.amount then
      if info.spendMoney then
        msgStr = MakeMoneyText(tostring(info.amount))
        costStr = F_MONEY:GetCostStringByCurrency(CURRENCY_GOLD, info.amount)
      else
        msgStr = X2Item:GetItemLinkedTextByItemType(info.itemType)
        if msgStr ~= nil and info.amount > 1 then
          msgStr = string.format("%sX%d ", msgStr, info.amount)
        end
      end
    end
    if lastChannel ~= arg2 then
      costWnd:SetValue(costStr, len)
      if msgStr ~= nil then
        X2Chat:DispatchChatMessage(CMF_SYSTEM, string.format("%s%s", F_COLOR.GetColor("battlefield_red", true), GetCommonText("notify_spend_for_chat", info.name, msgStr)))
      end
      lastChannel = arg2
    end
  end
  chatTypeButton:SetHandler("OnContentUpdated", chatTypeButton.OnContentUpdated)
  return true
end
function CreateComboList(chatTypeButton)
  local chatComboList = chatTypeButton:GetList()
  chatComboList:RemoveAllAnchors()
  chatComboList:SetInset(0, 10, 15, 5)
  chatComboList.itemStyle:SetAlign(ALIGN_LEFT)
  chatComboList.itemStyle:SetEllipsis(false)
  chatComboList:AddAnchor("BOTTOMLEFT", chatTypeButton, "TOPLEFT", 0, -5)
  local bg = chatComboList:CreateDrawable(TEXTURE_PATH.HUD, "list_chat_bg", "background")
  bg:AddAnchor("TOPLEFT", chatComboList, 0, -10)
  bg:AddAnchor("BOTTOMRIGHT", chatComboList, 0, 5)
  chatComboList.bg = bg
end
function OnSetChatTabId(chatTabButton, chatTabId)
  function chatTabButton:OnEnter()
    if chatTabId == nil or chatTabId == -1 then
      return
    end
    local tipInfo = X2Chat:GetChatTabInfoTable(chatTabId)
    if tipInfo ~= nil then
      SetTooltip(tipInfo.name, self)
    end
  end
  chatTabButton:SetHandler("OnEnter", chatTabButton.OnEnter)
end
function OnCreateChatTabButton(chatTabButton)
  chatTabButton:SetStyle("chat_tab_selected")
  chatTabButton:SetAutoClipChar(true)
  return true
end
function OnSelectedChatTab(chatTabButton, selected)
  if selected then
    chatTabButton:SetStyle("chat_tab_selected")
  else
    chatTabButton:SetStyle("chat_tab_unselected")
  end
end
function OnCreateChatMessage(chatMessage)
  AddItemLinkHandlerToMessageWidget(chatMessage)
  chatMessage:SetMaxLines(300)
  chatMessage.style:SetAlign(ALIGN_LEFT)
  chatMessage.style:SetSnap(true)
  chatMessage.style:SetShadow(true)
  chatMessage.style:SetFont("font_chat", FONT_SIZE.MIDDLE)
  chatMessage:SetLineSpace(TEXTBOX_LINE_SPACE.SMALL)
  chatMessage:SetInset(35, 0, 10, 10)
  chatMessage:SetTimeVisible(120)
  chatMessage.bg = chatMessage:CreateDrawable(TEXTURE_PATH.HUD, "chat_message_bg", "background")
  chatMessage.bg:AddAnchor("TOPLEFT", chatMessage, 1, 0)
  chatMessage.bg:AddAnchor("BOTTOMRIGHT", chatMessage, 0, 0)
  local DrawFlickerEffect = function(widget)
    local effect_texture = widget:CreateEffectDrawableByKey(TEXTURE_PATH.HUD, "slider_down_to_bottom_flicker", "overlay")
    effect_texture:SetVisible(false)
    effect_texture:AddAnchor("CENTER", widget, 0, 0)
    effect_texture:SetRepeatCount(0)
    effect_texture:SetEffectPriority(1, "alpha", 4591870180066957722, 4591870180066957722)
    effect_texture:SetEffectInitialColor(1, 1, 1, 1, 1)
    effect_texture:SetEffectFinalColor(1, 1, 1, 1, 1)
    effect_texture:SetEffectInterval(1, 4596373779694328218)
    effect_texture:SetEffectPriority(2, "alpha", 4591870180066957722, 4591870180066957722)
    effect_texture:SetEffectInitialColor(2, 1, 1, 1, 0)
    effect_texture:SetEffectFinalColor(2, 1, 1, 1, 0)
    effect_texture:SetEffectInterval(2, 4596373779694328218)
    widget.effect_texture = effect_texture
    function widget:ApplyFlickerEffect(isShow)
      self.effect_texture:SetStartEffect(isShow)
    end
  end
  DrawFlickerEffect(chatMessage:GetDownToBottomButton())
  local OnContentUpdated = function(self, arg)
    local button = self:GetDownToBottomButton()
    if arg == "read_chat_message" then
      button:ApplyFlickerEffect(false)
    elseif arg == "unread_chat_message" then
      button:ApplyFlickerEffect(true)
    end
  end
  chatMessage:SetHandler("OnContentUpdated", OnContentUpdated)
  local OnWheelUp = function(self, delta)
    self:MouseWheelUp(delta)
  end
  chatMessage:SetHandler("OnWheelUp", OnWheelUp)
  local OnWheelDown = function(self, delta)
    self:MouseWheelDown(delta)
  end
  chatMessage:SetHandler("OnWheelDown", OnWheelDown)
  local upBtn = chatMessage:GetUpButton()
  ApplyButtonSkin(upBtn, BUTTON_BASIC.SLIDER_UP)
  upBtn:RemoveAllAnchors()
  upBtn:AddAnchor("TOPLEFT", chatMessage, 5, 5)
  local downBtn = chatMessage:GetDownButton()
  ApplyButtonSkin(downBtn, BUTTON_BASIC.SLIDER_DOWN)
  downBtn:RemoveAllAnchors()
  downBtn:AddAnchor("BOTTOMLEFT", chatMessage:GetDownToBottomButton(), "TOPLEFT", 2, 0)
  local downToBottomBtn = chatMessage:GetDownToBottomButton()
  downToBottomBtn:SetStyle("hud_btn_chat_scroll_down_bottom")
  downToBottomBtn:RemoveAllAnchors()
  downToBottomBtn:AddAnchor("BOTTOMLEFT", chatMessage, 3, -5)
  local slider = chatMessage:GetSlider()
  slider:RemoveAllAnchors()
  slider:SetWidth(17)
  slider:AddAnchor("TOP", upBtn, "BOTTOM", 0, 0)
  slider:AddAnchor("BOTTOM", downBtn, "TOP", 0, 0)
  local bg = slider:CreateDrawable(TEXTURE_PATH.SCROLL, "scroll_frame_bg", "artwork")
  bg:RemoveAllAnchors()
  bg:AddAnchor("TOPLEFT", slider, 2, -10)
  bg:AddAnchor("BOTTOMRIGHT", slider, -2, 8)
  local thumbButton = slider:GetThumbButtonWidget()
  ApplyButtonSkin(thumbButton, BUTTON_BASIC.SLIDER_VERTICAL_THUMB)
  thumbButton:AddAnchor("LEFT", slider, 5, 0)
  return true
end
local AddUISaveHandler = function(chatWindow, id, delayed)
  function chatWindow:ProcCorrectBound(info)
    if IsValidBoundInfo(info) == false then
      return
    end
    local bound = info.bound
    local screenWidth = UIParent:GetScreenWidth()
    local screenHeight = UIParent:GetScreenHeight()
    local screenRatio = screenHeight / info.screenResolution.y
    bound.y = bound.y * screenRatio
    local scale = UIParent:GetUIScale()
    local margin = 7 * scale
    local bottomMargin = 30 * scale
    bound.width = bound.width * scale
    bound.height = bound.height * scale
    if bound.x < 0 then
      bound.x = margin
    end
    if bound.y < 0 then
      bound.y = margin
    end
    if screenWidth < bound.width then
      bound.width = screenWidth - margin * 2
    end
    if screenHeight < bound.height then
      bound.height = screenHeight - (margin + bottomMargin)
    end
    if screenWidth < bound.x + bound.width then
      bound.x = screenWidth - (bound.width + margin)
    end
    if screenHeight < bound.y + bound.height then
      bound.y = screenHeight - (bound.height + bottomMargin)
    end
    self:RemoveAllAnchors()
    self:AddAnchor("TOPLEFT", "UIParent", F_LAYOUT.CalcDontApplyUIScale(bound.x), F_LAYOUT.CalcDontApplyUIScale(bound.y))
    self:SetExtent(F_LAYOUT.CalcDontApplyUIScale(bound.width), F_LAYOUT.CalcDontApplyUIScale(bound.height))
  end
  function chatWindow:OnScale()
    AddUISaveHandlerByKey(string.format("chatWindow[%d]", id), self, true)
    self:ApplyLastWindowBound()
  end
  chatWindow:SetHandler("OnScale", chatWindow.OnScale)
  chatWindow:OnScale()
  if delayed == false then
    AddUISaveHandlerByKey(string.format("chatWindow[%d]", id), chatWindow, true)
  end
end
function OnDuplicatedChatWindow(chatWindow, id)
  AddUISaveHandler(chatWindow, id, false)
end
function CreateChatTabWindow()
  local chatWindowIds = X2Chat:AllChatWindowIds()
  local tabWindows = {}
  local lastTab
  for i, id in pairs(chatWindowIds) do
    local tab = UIParent:CreateWidget("chatwindow", string.format("chatWindow[%d]", i), "UIParent")
    function tab:MakeOriginWindowPos(reset)
      if tab == nil then
        return
      end
      self:RemoveAllAnchors()
      if reset then
        tab:AddAnchor("BOTTOMLEFT", "UIParent", 0, F_LAYOUT.CalcDontApplyUIScale(-145))
      else
        tab:AddAnchor("BOTTOMLEFT", "UIParent", 0, -145)
      end
      tab:SetExtent(430, 350)
    end
    tab:MakeOriginWindowPos()
    tab:Show(true)
    tab:SetSlideTimeInDragging(150)
    tab:AllowTabSwitch(true)
    tab:SetResizingBorderSize(11, 11, 12, 12)
    tab:UseAddTabButton(true)
    tab:SetChatWindowId(id)
    if lastTab ~= nil then
      tab:AddAnchor("BOTTOMLEFT", lastTab, "TOPLEFT", 0, -10)
      tab:SetExtent(430, 160)
    end
    AddUISaveHandler(tab, id, true)
    table.insert(tabWindows, tab)
    lastTab = tab
  end
  return tabWindows
end
function OnResetAllChatWindow()
  local tabWindows = CreateChatTabWindow()
  if tabWindows[1] == nil then
    return
  end
  tabWindows[1]:RemoveAllAnchors()
  tabWindows[1]:AddAnchor("BOTTOMLEFT", "UIParent", 0, -145)
  tabWindows[1]:SetExtent(430, 350)
  AddUISaveHandler(tabWindows[1], 0, false)
  tabWindows[1]:SaveBound()
  if tabWindows[2] ~= nil then
    tabWindows[2]:RemoveAllAnchors()
    tabWindows[2]:AddAnchor("BOTTOMLEFT", tabWindows[1], "TOPLEFT", 0, -10)
    tabWindows[2]:SetExtent(430, 160)
    AddUISaveHandler(tabWindows[2], 1, false)
    tabWindows[2]:SaveBound()
  end
  return true
end
chatTabWindow = CreateChatTabWindow()
