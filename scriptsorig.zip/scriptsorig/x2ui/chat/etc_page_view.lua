local sideMargin, titleMargin, bottomMargin = GetWindowMargin()
local AddSlider = function(id, parent, title, titleColor, width, minVal, maxVal, texts, valLabel)
  local wnd = parent:CreateChildWidget("emptywidget", id, 0, true)
  wnd:SetExtent(width, 65)
  local titleLabel = W_CTRL.CreateLabel("titleLabel", wnd)
  titleLabel:SetHeight(FONT_SIZE.MIDDLE)
  titleLabel:SetAutoResize(true)
  titleLabel:AddAnchor("TOPLEFT", wnd, 0, 0)
  titleLabel:SetText(title)
  titleLabel.style:SetColorByKey(titleColor)
  local slider = CreateSlider("slider", wnd)
  slider:SetMinMaxValues(minVal, maxVal)
  slider:SetValueStep(1)
  slider:SetPageStep(1)
  slider:SetInitialValue(math.floor((minVal + maxVal) / 2), false)
  slider:UseWheel()
  slider:AddAnchor("TOPLEFT", titleLabel, "BOTTOMLEFT", 0, 8)
  slider:SetWidth(width)
  local labelSize = FONT_SIZE.MIDDLE
  if valLabel then
    do
      local valueLabel = W_CTRL.CreateLabel("valueLabel", wnd)
      valueLabel:SetHeight(FONT_SIZE.LARGE)
      valueLabel:SetAutoResize(true)
      valueLabel:AddAnchor("LEFT", slider, "RIGHT", 10, 0)
      valueLabel.style:SetColorByKey("blue")
      valueLabel.style:SetFontSize(FONT_SIZE.LARGE)
      valueLabel:SetText(tostring(slider:GetValue()))
      width = width - 30
      slider:SetWidth(width)
      labelSize = FONT_SIZE.SMALL
      function slider:OnSliderChanged(arg)
        local value = slider:GetValue() or 0
        valueLabel:SetText(tostring(value))
      end
      slider:SetHandler("OnSliderChanged", slider.OnSliderChanged)
    end
  end
  for i = 1, #texts do
    local offsetX = (width - slider.thumb:GetWidth()) / (#texts - 1)
    local label = W_CTRL.CreateLabel(string.format("label[%d]", i), wnd)
    label:AddAnchor("TOP", slider, "BOTTOMLEFT", offsetX * (i - 1) + slider.thumb:GetWidth() / 2, 5)
    label:SetHeight(labelSize)
    label:SetAutoResize(true)
    label.style:SetAlign(ALIGN_CENTER)
    label.style:SetFontSize(labelSize)
    label:SetText(texts[i])
  end
  function wnd:SetValue(value)
    slider:SetValue(value, true)
  end
  function wnd:GetValue(value)
    return slider:GetValue()
  end
  return wnd
end
function CreateEtcChatOptionTab(parent)
  local topWnd = parent:CreateChildWidget("emptywidget", "topWnd", 0, true)
  topWnd:AddAnchor("TOPLEFT", parent, 0, 15)
  topWnd:AddAnchor("TOPRIGHT", parent, 0, 15)
  topWnd:SetHeight(85)
  local topBg = CreateContentBackground(topWnd, "TYPE2", "brown")
  topBg:AddAnchor("TOPLEFT", topWnd, 0, 0)
  topBg:AddAnchor("BOTTOMRIGHT", topWnd, 0, 0)
  local sliderWndWidth = parent:GetWidth() - sideMargin * 2
  local fontSizeWnd = AddSlider("fontSizeWnd", topWnd, GetUIText(CHAT_FILTERING, "chat_set_font_size"), "middle_title", sliderWndWidth, 12, 24, {
    "12",
    "13",
    "14",
    "15",
    "16",
    "17",
    "18",
    "19",
    "20",
    "21",
    "22",
    "23",
    "24pt"
  }, false)
  fontSizeWnd:AddAnchor("TOPLEFT", topWnd, 15, 10)
  local guide = W_ICON.CreateGuideIconWidget(fontSizeWnd)
  guide:AddAnchor("TOPRIGHT", topWnd, "TOPRIGHT", -6, 6)
  function guide:OnEnter()
    SetTooltip(GetUIText(CHAT_FILTERING, "chat_set_font_size_tooltip"), self)
  end
  guide:SetHandler("OnEnter", guide.OnEnter)
  local bottomWnd = parent:CreateChildWidget("emptywidget", "bottomWnd", 0, true)
  bottomWnd:AddAnchor("TOPLEFT", topWnd, "BOTTOMLEFT", 0, 3)
  bottomWnd:AddAnchor("TOPRIGHT", topWnd, "BOTTOMRIGHT", 0, 3)
  bottomWnd:SetHeight(212)
  local bottomBg = CreateContentBackground(bottomWnd, "TYPE2", "brown")
  bottomBg:AddAnchor("TOPLEFT", bottomWnd, 0, 0)
  bottomBg:AddAnchor("BOTTOMRIGHT", bottomWnd, 0, 0)
  local titleLabel = W_CTRL.CreateLabel("titleLabel", bottomWnd)
  titleLabel:AddAnchor("TOPLEFT", bottomWnd, 15, 10)
  titleLabel:SetHeight(FONT_SIZE.MIDDLE)
  titleLabel:SetAutoResize(true)
  titleLabel:SetText(GetUIText(CHAT_FILTERING, "chat_window"))
  titleLabel.style:SetColorByKey("middle_title")
  local bgColorLabel = W_CTRL.CreateLabel("bgColorLabel", bottomWnd)
  bgColorLabel:AddAnchor("TOPLEFT", titleLabel, "BOTTOMLEFT", 0, 8)
  bgColorLabel:SetHeight(FONT_SIZE.MIDDLE)
  bgColorLabel:SetAutoResize(true)
  bgColorLabel:SetText(GetUIText(CHAT_FILTERING, "chat_set_bg_color"))
  local bgColorBtn = CreateColorPickButtons("bgColorBtn", bottomWnd)
  bgColorBtn:SetExtent(23, 15)
  bgColorBtn:AddAnchor("LEFT", bgColorLabel, "RIGHT", 5, 0)
  function bgColorBtn:SelectedProcedure(r, g, b, a)
    self.colorBG:SetColor(r, g, b, a)
  end
  function bgColorBtn:OnClick()
    F_PALETTE.ShowPalette(self)
  end
  bgColorBtn:SetHandler("OnClick", bgColorBtn.OnClick)
  local defaultAlphaWnd = AddSlider("defaultAlphaWnd", bottomWnd, GetUIText(CHAT_FILTERING, "chat_set_bg_alpha"), "default", sliderWndWidth, 0, 100, {"0", "100"}, true)
  defaultAlphaWnd:AddAnchor("TOPLEFT", bgColorLabel, "BOTTOMLEFT", 0, 8)
  local overAlphaWnd = AddSlider("overAlphaWnd", bottomWnd, GetUIText(CHAT_FILTERING, "overAlpha"), "default", sliderWndWidth, 0, 100, {"0", "100"}, true)
  overAlphaWnd:AddAnchor("TOPLEFT", defaultAlphaWnd, "BOTTOMLEFT", 0, 20)
  function parent:ReadOption(info, isDefault)
    local fontSize = info.fontSize
    if info.fontSize ~= nil then
      fontSizeWnd:SetValue(info.fontSize)
    end
    if info.bgColor ~= nil then
      bgColorBtn.colorBG:SetColor(info.bgColor.r, info.bgColor.g, info.bgColor.b, 1)
    end
    if isDefault then
      defaultAlphaWnd:SetValue(50)
      overAlphaWnd:SetValue(70)
    else
      local chatOption = X2Chat:GetChatOption()
      defaultAlphaWnd:SetValue(chatOption.leaveAlpha * 100)
      overAlphaWnd:SetValue(chatOption.overAlpha * 100)
    end
  end
  function parent:WriteOption(info)
    if info.fontSize ~= nil then
      local fontSize = fontSizeWnd:GetValue()
      info.fontSize = fontSize
    end
    if info.bgColor ~= nil then
      local color = bgColorBtn.colorBG:GetColor()
      info.bgColor.r = color.r
      info.bgColor.g = color.g
      info.bgColor.b = color.b
    end
    X2Chat:UpdateChatOption({
      leaveAlpha = defaultAlphaWnd:GetValue() / 100,
      overAlpha = overAlphaWnd:GetValue() / 100
    })
  end
end
