function CreateChatOptionWindow(id, parent)
  local layoutSet = GetLayoutSetChatOption()
  local window = CreateWindow(id, parent, "chatOption")
  window:SetExtent(layoutSet.chatOptionWidth, 470)
  local tab = W_TAB.CreateTab("tab", window)
  tab:AddTabs({
    GetUIText(CHAT_FILTERING, "chat_conversation"),
    GetUIText(CHAT_FILTERING, "chat_notice"),
    locale.common.combat,
    GetUIText(CHAT_FILTERING, "chat_config")
  })
  CreateNormalChatOptionTab(tab.window[1])
  CreateAlarmChatOptionTab(tab.window[2])
  CreateCombatChatOptionTab(tab.window[3])
  CreateEtcChatOptionTab(tab.window[4])
  local cancelButton = window:CreateChildWidget("button", "cancelButton", 0, true)
  cancelButton:SetText(GetUIText(COMMON_TEXT, "cancel"))
  cancelButton:SetStyle("text_default")
  cancelButton:AddAnchor("BOTTOMRIGHT", window, -MARGIN.WINDOW_SIDE, -MARGIN.WINDOW_SIDE)
  function cancelButton:OnClick()
    window:Show(false)
  end
  cancelButton:SetHandler("OnClick", cancelButton.OnClick)
  local okButton = window:CreateChildWidget("button", "okButton", 0, true)
  okButton:SetText(GetUIText(COMMON_TEXT, "ok"))
  okButton:SetStyle("text_default")
  okButton:AddAnchor("RIGHT", cancelButton, "LEFT")
  function okButton:OnClick()
    window:SaveOption()
    window:Show(false)
  end
  okButton:SetHandler("OnClick", okButton.OnClick)
  local buttonTable = {cancelButton, okButton}
  AdjustBtnLongestTextWidth(buttonTable)
  local chatResetButton = window:CreateChildWidget("button", "chatResetButton", 0, true)
  chatResetButton:SetText(GetUIText(CHAT_FILTERING, "chat_reset"))
  chatResetButton:SetStyle("text_default")
  chatResetButton:AddAnchor("BOTTOMLEFT", window, MARGIN.WINDOW_SIDE, -MARGIN.WINDOW_SIDE)
  function chatResetButton:OnClick()
    X2Chat:InitChatWindow()
    window:Show(false)
  end
  chatResetButton:SetHandler("OnClick", chatResetButton.OnClick)
  local resetButton = window:CreateChildWidget("button", "resetButton", 0, true)
  resetButton:SetText(GetUIText(COMMON_TEXT, "init"))
  resetButton:SetStyle("text_default")
  resetButton:AddAnchor("LEFT", chatResetButton, "RIGHT")
  function resetButton:OnClick()
    window:LoadOption(true)
  end
  resetButton:SetHandler("OnClick", resetButton.OnClick)
  local buttonTable = {chatResetButton, resetButton}
  AdjustBtnLongestTextWidth(buttonTable)
  return window
end
