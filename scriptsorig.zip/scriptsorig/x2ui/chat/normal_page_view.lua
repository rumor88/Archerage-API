local sideMargin, titleMargin, bottomMargin = GetWindowMargin()
function CreateNormalChatOptionTab(parent)
  local layoutSet = GetLayoutSetChatOption()
  local offsetY = 10
  local checkBoxs = {}
  local groups = {}
  local menuChkboxOffset = (parent:GetWidth() - sideMargin * 2) / 2 - 15
  local enterCountOffsetX = menuChkboxOffset + 45
  local list = MakeOptionGroupList(layoutSet.normalPageFilter)
  local lastWidget
  for i = 1, #list - 1 do
    if i > 1 then
      DrawTargetLine(groups[i - 1])
    end
    list[i].enterCount = math.ceil(#list[i].menuTexts / 2)
    list[i].menuChkboxOffset = menuChkboxOffset
    list[i].enterCountOffsetX = enterCountOffsetX
    local group = CreateColorPickCheckGroup(string.format("group[%d]", i), parent, list[i], checkBoxs)
    group:AddAnchor("TOPLEFT", parent, 0, offsetY)
    group:AddAnchor("TOPRIGHT", parent, 0, offsetY)
    groups[i] = group
    offsetY = offsetY + group:GetHeight() + 20
  end
  local featureSet = X2Player:GetFeatureSet()
  if featureSet.chatLanguageFilter then
    offsetY = offsetY + 10
    local langFilterLabel = W_CTRL.CreateLabel("langFilterLabel", parent)
    langFilterLabel:SetAutoResize(true)
    langFilterLabel:SetText(GetUIText(COMMON_TEXT, "chat_language_filter_title"))
    langFilterLabel:AddAnchor("TOPLEFT", parent, 0, offsetY)
    local langFilterGuideIcon = W_ICON.CreateGuideIconWidget(langFilterLabel, "guide", GetUIText(COMMON_TEXT, "chat_language_filter_guide"))
    langFilterGuideIcon:AddAnchor("LEFT", langFilterLabel, "RIGHT", 5, 0)
    offsetY = offsetY + langFilterLabel:GetHeight() + 15
    local langFilterGroup = 3
    list[langFilterGroup].width = parent:GetWidth()
    list[langFilterGroup].newLineCount = 3
    local group = CreateCheckGroup(string.format("group[%d]", langFilterGroup), parent, list[langFilterGroup], checkBoxs)
    group:AddAnchor("TOPLEFT", parent, 0, offsetY)
    groups[langFilterGroup] = group
    offsetY = offsetY + group:GetHeight() + 20
  end
  function parent:ReadOption(info, isDefault)
    local boxMap = checkBoxs.boxMapUseExtraValue
    for key, checkBox in pairs(boxMap) do
      local checked = info.filters[key]
      local enabled = not info.filterLocked[key]
      local color = info.filterColors[key]
      checkBox:SetChecked(checked, false)
      checkBox:SetEnableCheckButton(enabled)
      if checkBox.colorPick then
        checkBox.colorPick.colorBG:SetColor(color.r, color.g, color.b, color.a)
      end
    end
  end
  function parent:WriteOption(info)
    local boxMap = checkBoxs.boxMapUseExtraValue
    for key, checkBox in pairs(boxMap) do
      info.filters[key] = checkBox:GetChecked()
      if checkBox.colorPick then
        info.filterColors[key] = checkBox.colorPick.colorBG:GetColor()
      end
    end
  end
end
