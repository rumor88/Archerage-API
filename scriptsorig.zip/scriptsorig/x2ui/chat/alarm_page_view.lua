local sideMargin, titleMargin, bottomMargin = GetWindowMargin()
function CreateAlarmChatOptionTab(parent)
  local menuChkboxOffset = (parent:GetWidth() - sideMargin * 2) / 2 - 15
  local submenuChkboxOffset = menuChkboxOffset - 18
  local filters = {
    {
      CMF_NOTICE,
      CMF_SYSTEM,
      CMF_QUEST_INFO,
      CMF_CHANNEL_INFO
    },
    {
      CMF_CONNECT_ALERT,
      {
        CMF_CONNECT_FRIEND,
        CMF_CONNECT_FAMILY,
        CMF_CONNECT_EXPEDITION
      }
    },
    {
      CMF_ADDED_ITEM_GROUP,
      {
        CMF_ADDED_ITEM_SELF,
        CMF_ADDED_ITEM_TEAM,
        CMF_LOOT_METHOD_CHANGED
      }
    },
    {
      CMF_ACQ_CONSUME_GROUP,
      {
        CMF_SELF_MONEY_CHANGED,
        CMF_SELF_HONOR_POINT_CHANGED,
        CMF_SELF_LIVING_POINT_CHANGED
      }
    },
    {
      CMF_PARTY_AND_RAID_INFO,
      CMF_DOMINION_AND_SIEGE_INFO,
      CMF_TRADE_STORE_MSG
    },
    {
      CMF_ETC_GROUP,
      {CMF_EMOTIOIN_EXPRESS, CMF_SELF_SKILL_INFO}
    }
  }
  local offsetX = 0
  local offsetY = 10
  local checkBoxs = {}
  local groups = {}
  local list = MakeOptionGroupList(filters)
  for i = 1, #list do
    if i > 2 and i % 2 == 1 then
      DrawLineDoubleTarget(groups[i - 2], groups[i - 1])
    end
    list[i].menuChkboxOffset = menuChkboxOffset
    list[i].submenuChkboxOffset = submenuChkboxOffset
    local group = CreateColorPickCheckGroup(string.format("group[%d]", i), parent, list[i], checkBoxs)
    group:AddAnchor("TOPLEFT", parent, offsetX, offsetY)
    group:SetWidth(menuChkboxOffset + 23)
    groups[i] = group
    if i % 2 == 1 then
      offsetX = menuChkboxOffset + 45
    else
      offsetX = 0
      if groups[i - 1]:GetHeight() > group:GetHeight() then
        offsetY = offsetY + groups[i - 1]:GetHeight() + 10
      else
        offsetY = offsetY + group:GetHeight() + 10
      end
    end
  end
  function parent:ReadOption(info, isDefault)
    local boxMap = checkBoxs.boxMapUseExtraValue
    for key, checkbox in pairs(boxMap) do
      local checked = info.filters[key]
      local enabled = not info.filterLocked[key]
      local color = info.filterColors[key]
      checkbox:SetChecked(checked, false)
      checkbox:Enable(enabled)
      checkbox.colorPick.colorBG:SetColor(color.r, color.g, color.b, color.a)
    end
  end
  function parent:WriteOption(info)
    local boxMap = checkBoxs.boxMapUseExtraValue
    for key, checkBox in pairs(boxMap) do
      info.filters[key] = checkBox:GetChecked()
      info.filterColors[key] = checkBox.colorPick.colorBG:GetColor()
    end
  end
end
