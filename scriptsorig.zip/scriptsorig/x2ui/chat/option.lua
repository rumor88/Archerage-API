local chatOptionWindow
function SetChatOptionWindowHandler(window)
  function window:LoadOption(isDefault)
    if isDefault == true then
      self.chatTabInfos = X2Chat:GetDefaultChatTabInfoTable(self.chatTabId)
    else
      self.chatTabInfos = X2Chat:GetChatTabInfoTable(self.chatTabId)
    end
    if self.chatTabInfos == nil then
      return
    end
    local tabName = self.chatTabInfos.name
    if tabName ~= nil then
      self:SetTitle(string.format("%s %s", tabName, locale.chatFiltering.title))
    end
    for i = 1, #self.tab.window do
      self.tab.window[i]:ReadOption(self.chatTabInfos, isDefault)
    end
  end
  function window:SaveOption()
    if self.chatTabInfos == nil then
      return
    end
    for i = 1, #self.tab.window do
      self.tab.window[i]:WriteOption(self.chatTabInfos)
    end
    X2Chat:UpdateChatTabInfo(self.chatTabId, self.chatTabInfos)
  end
  function window:ShowProc()
    if self.chatTabId == nil then
      return
    end
    self:LoadOption(false)
    window.chatResetButton:Show(self.chatTabId == 0)
    if self.chatTabId == 0 then
      window.resetButton:AddAnchor("LEFT", window.chatResetButton, "RIGHT")
    else
      window.resetButton:AddAnchor("LEFT", window.chatResetButton)
    end
  end
  function window:OnHide()
    F_PALETTE.HidePalette()
    chatOptionWindow = nil
  end
  window:SetHandler("OnHide", window.OnHide)
end
function ShowChatOptionWindow(chatTabId)
  if chatOptionWindow == nil then
    chatOptionWindow = CreateChatOptionWindow("chatOptionWindow", "UIParent")
    chatOptionWindow:AddAnchor("CENTER", "UIParent", 0, 0)
    chatOptionWindow:EnableHidingIsRemove(true)
    chatOptionWindow:Show(false)
    SetChatOptionWindowHandler(chatOptionWindow)
  end
  chatOptionWindow.chatTabId = chatTabId
  chatOptionWindow:Show(true)
end
