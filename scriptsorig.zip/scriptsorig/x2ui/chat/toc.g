﻿## author : yoseop
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## chat

locale/layout_set.lua

url_link.lua
common.lua

etc_page_view.lua
normal_page_view.lua
alarm_page_view.lua
combat_page_view.lua

option_view.lua
option.lua

tab_popup.lua
chat_window.lua

chatbubble.lua

megaphone.lua

one_and_one_chat_view.lua
one_and_one_chat.lua
