COMBAT_TEXT_MAX_COUNT = 30
COMBAT_TEXT_COLOR = {}
COMBAT_TEXT_COLOR.DAMAGED_SWING = "combat_damaged_swing"
COMBAT_TEXT_COLOR.DAMAGED_SWING_CRITICAL = "combat_damaged_swing"
COMBAT_TEXT_COLOR.DAMAGED_SPELL = "combat_damaged_spell"
COMBAT_TEXT_COLOR.DAMAGED_SPELL_DOT = "combat_damaged_spell"
COMBAT_TEXT_COLOR.DAMAGED_SPELL_CRITICAL = "combat_damaged_spell"
COMBAT_TEXT_COLOR.DEBUFF = "combat_debuff"
COMBAT_TEXT_COLOR.MISSED = "combat_damaged_swing"
COMBAT_TEXT_COLOR.MISSED_MISS = "combat_damaged_swing"
COMBAT_TEXT_COLOR.MISSED_DODGE = "combat_damaged_swing"
COMBAT_TEXT_COLOR.SWING = "combat_swing"
COMBAT_TEXT_COLOR.SWING_MISS = "combat_swing_miss"
COMBAT_TEXT_COLOR.SWING_DODGE = "combat_swing_dodge"
COMBAT_TEXT_COLOR.SWING_BLOCK = "combat_swing_dodge"
COMBAT_TEXT_COLOR.SWING_PARRY = "combat_swing_dodge"
COMBAT_TEXT_COLOR.SWING_IMMUNE = "combat_swing_dodge"
COMBAT_TEXT_COLOR.SWING_RESIST = "combat_swing_dodge"
COMBAT_TEXT_COLOR.SWING_CRITICAL = "combat_swing"
COMBAT_TEXT_COLOR.SWING_ABSORB = "combat_swing_dodge"
COMBAT_TEXT_COLOR.SWING_REFLECT = "combat_swing_dodge"
COMBAT_TEXT_COLOR.SKILL = "combat_skill"
COMBAT_TEXT_COLOR.DOT = "combat_skill"
COMBAT_TEXT_COLOR.HEAL = "combat_heal"
COMBAT_TEXT_COLOR.ENERGIZE_MP = "combat_energize_mp"
COMBAT_TEXT_COLOR.DAMAGE_MP = "combat_energize_mp"
COMBAT_TEXT_COLOR.SYNERGY = "combat_synergy"
COMBAT_TEXT_COLOR.COMBAT_START = "combat_combat_start"
COMBAT_TEXT_COLOR.COMBAT_END = "combat_combat_start"
COMBAT_TEXT_COLOR.GAIN_EXP = "combat_gain_exp"
COMBAT_TEXT_COLOR.GAIN_HONOR_POINT = "combat_gain_honor_point"
COMBAT_TEXT_COLOR.LOSE_HONOR_POINT = "combat_combat_start"
COMBAT_TEXT_COLOR.COLLISION_ME = "combat_collision_me"
COMBAT_TEXT_COLOR.COLLISION_OTHER = "combat_collision_other"
COMBAT_TEXT_COLOR.ABSORB = "combat_absorb"
local gainExpWidget
local oldGainExp = 0
function CreateCombatTextFrame(id, parent, maxCount)
  local frame = CreateEmptyWindow(id, parent)
  frame:EnablePick(false)
  for i = 1, maxCount do
    local combatText = frame:CreateChildWidget("damagedisplay", "combatTexts", i, true)
    combatText:EnablePick(false)
    combatText:SetExtent(142, 82)
    combatText:Show(false)
    combatText.style:SetFont(combatTextLocale.fontPath, combatTextLocale.fontSize, combatTextLocale.fontKind)
    combatText.style:SetColorByKey("combat_text")
    combatText.extraStyle:SetFont(FONT_PATH.COMBAT, combatTextLocale.fontSize)
    combatText.extraStyle:SetColorByKey("combat_text")
    local drawable = combatText:CreateImageDrawable("ui/hud/critical.dds", "background")
    drawable:AddAnchor("CENTER", combatText, combatTextLocale.drawableAnchor.x, combatTextLocale.drawableAnchor.y)
    drawable:SetExtent(142, 82)
    drawable:SetColor(1, 1, 1, 4605380978949069210)
    combatText.drawable = drawable
    if i == maxCount then
      gainExpWidget = combatText
    end
  end
  return frame
end
combatTextFrame = CreateCombatTextFrame("combatTextFrame", "UIParent", COMBAT_TEXT_MAX_COUNT)
combatTextFrame:Show(true)
local ClockPositionCount = 1
local function SetClockPosition(pos)
  local Randompos
  Randompos = {
    x = pos.x,
    y = pos.y,
    z = pos.z
  }
  if ClockPositionCount == 1 then
    Randompos.x = Randompos.x - 50
    Randompos.y = Randompos.y - 50
    ClockPositionCount = ClockPositionCount + 1
  elseif ClockPositionCount == 2 then
    Randompos.x = Randompos.x - 50
    Randompos.y = Randompos.y + 50
    ClockPositionCount = ClockPositionCount + 1
  elseif ClockPositionCount == 3 then
    Randompos.x = Randompos.x + 50
    Randompos.y = Randompos.y - 50
    ClockPositionCount = ClockPositionCount + 1
  elseif ClockPositionCount == 4 then
    Randompos.x = Randompos.x + 50
    Randompos.y = Randompos.y + 50
    ClockPositionCount = ClockPositionCount + 1
  elseif ClockPositionCount == 5 then
    Randompos.x = Randompos.x
    Randompos.y = Randompos.y - 70
    ClockPositionCount = ClockPositionCount + 1
  elseif ClockPositionCount == 6 then
    Randompos.x = Randompos.x - 80
    Randompos.y = Randompos.y
    ClockPositionCount = ClockPositionCount + 1
  elseif ClockPositionCount == 7 then
    Randompos.x = Randompos.x
    Randompos.y = Randompos.y + 70
    ClockPositionCount = ClockPositionCount + 1
  elseif ClockPositionCount == 8 then
    Randompos.x = Randompos.x + 80
    Randompos.y = Randompos.y
    ClockPositionCount = 1
  end
  return Randompos
end
local SetRandomPosition = function(pos)
  local Randompos = {
    x = pos.x,
    y = pos.y,
    z = pos.z
  }
  Randompos.x = Randompos.x + math.random(-3, 3) * 20
  Randompos.y = Randompos.y + math.random(-5, 5) * 3
  return Randompos
end
local function CorrentPosition(skillType, hitOrMissType)
  local pos = {
    x = 0,
    y = 0,
    z = 0
  }
  if skillType == "DAMAGED_SWING" then
    pos.y = pos.y + 60
  elseif skillType == "MISSED" then
    pos.x = pos.x - 120
    pos.y = pos.y - 20
  elseif skillType == "DAMAGED_SPELL" then
    pos = SetRandomPosition(pos)
    pos.y = pos.y + 10
  elseif skillType == "SWING" then
    pos = SetRandomPosition(pos)
    pos.y = pos.y - 100
  elseif skillType == "SKILL" then
    pos = SetClockPosition(pos)
    pos.y = pos.y - 120
  elseif skillType == "DOT" then
    pos = SetRandomPosition(pos)
    pos.y = pos.y - 70
  elseif skillType == "ENERGIZE_MP" then
    pos = SetRandomPosition(pos)
  elseif skillType == "DAMAGE_MP" then
    pos = SetRandomPosition(pos)
  elseif skillType == "HEAL" then
    pos = SetRandomPosition(pos)
    pos.y = pos.y - 100
  elseif skillType == "SYNERGY" then
    pos.x = pos.x + 140
    pos.y = pos.y - 30
  elseif skillType == "COMBAT_START" then
    pos.y = pos.y - 150
  elseif skillType == "COMBAT_END" then
    pos.y = pos.y - 150
  elseif skillType == "GAIN_EXP" then
    pos.y = pos.y - 120
  elseif skillType == "BUFF_REMOVED" then
    pos.y = pos.y + 100
  elseif skillType == "GAIN_HONOR_POINT" then
    pos.x = pos.x + 100
  elseif skillType == "LOSE_HONOR_POINT" then
    pos.x = pos.x + 100
    pos.y = pos.y + 50
  elseif skillType == "COLLISION" then
    pos.x = pos.x + 100
    pos.y = pos.y - 100
  end
  if hitOrMissType == "MISS" then
    pos.y = pos.y - 4604480259023595110
    pos.z = pos.z - 2
  elseif hitOrMissType == "DODGE" then
    pos.y = pos.y - 1
    pos.z = pos.z - 4605380978949069210
  elseif hitOrMissType == "BLOCK" then
    pos.y = pos.y - 1
    pos.z = pos.z - 4613487458278336102
  elseif hitOrMissType == "PARRY" then
    pos.y = pos.y - 4608533498688228557
    pos.z = pos.z - 4612136378390124954
  elseif hitOrMissType == "IMMUNE" then
    pos.y = pos.y + 1
    pos.z = pos.z - 4613487458278336102
  elseif hitOrMissType == "RESIST" then
    pos.y = pos.y - 1
    pos.z = pos.z - 2
  elseif hitOrMissType == "CRITICAL" or hitOrMissType == "REFLECT" then
    pos.y = pos.y + 1
    pos.z = pos.z - 4613487458278336102
  elseif hitOrMissType == "ABSORB" then
    pos = SetRandomPosition(pos)
    pos.y = pos.y - 145
  end
  return pos
end
local SetTextColor = function(skillType, hitOrMissType)
  local color = "combat_text_default"
  if hitOrMissType == "ABSORB" then
    color = COMBAT_TEXT_COLOR.ABSORB
  else
    local damageColor = COMBAT_TEXT_COLOR[skillType]
    local mixedType = string.format("%s_%s", tostring(skillType), tostring(hitOrMissType))
    local hitColor = COMBAT_TEXT_COLOR[mixedType]
    if hitColor ~= nil then
      color = hitColor
    elseif damageColor ~= nil then
      color = damageColor
    end
  end
  return color
end
local function CombatText_Add(sourceUnitId, targetUnitId, combatText, skillType, hitOrMissType, animType, posCalcType)
  local function GetEmptyCombatTextWidget(skillType)
    local combatTextWidget
    if skillType == "GAIN_EXP" then
      combatTextWidget = gainExpWidget
    else
      for i = 1, COMBAT_TEXT_MAX_COUNT - 1 do
        if combatTextFrame.combatTexts[i]:IsVisible() == false then
          combatTextWidget = combatTextFrame.combatTexts[i]
        end
      end
    end
    return combatTextWidget
  end
  function SetFloatingCombatText(textWidget, sourceUnitId, targetUnitId, floatingText, skillType, hitOrMissType, animType, posCalcType)
    if textWidget:IsVisible() == false then
      if targetUnitId == nil then
        targetUnitId = X2Unit:GetUnitId("player")
      end
      textWidget:SetUnitId(sourceUnitId or "", targetUnitId)
      textWidget:SetText(string.format("%s", floatingText))
      textWidget:SetPositionCalculationType(posCalcType or PCT_DEFAULT)
      local pos = CorrentPosition(skillType, hitOrMissType)
      local color = SetTextColor(skillType, hitOrMissType)
      if pos ~= nil then
        textWidget:SetInitPos(pos.x, pos.y)
      else
        textWidget:SetInitPos(UIParent:GetScreenWidth() / 2, UIParent:GetScreenHeight() / 2)
      end
      textWidget.extraStyle:SetColorByKey(color)
      textWidget.style:SetColorByKey(color)
      local effectFrame = GetCombatTextEffect(animType)
      if effectFrame ~= nil then
        textWidget.drawable:SetAnimFrameInfo(effectFrame)
        textWidget.drawable:Animation(true, false)
      else
        textWidget.drawable:SetVisible(false)
      end
      local animFrame = GetCombatTextAnimation(animType)
      if animFrame == nil then
        animFrame = GetCombatTextAnimation(CTA_DMGPOPUP)
      end
      if animFrame ~= nil then
        textWidget:SetAnimFrameInfo(animFrame)
        textWidget:Animation(true)
      end
    end
  end
  local amount, absorb
  amount = combatText.amount ~= nil and combatText.amount or combatText
  absorb = combatText.absorb
  if combatText.element ~= nil and combatText.element ~= "" then
    amount = string.format("%s %s", amount, combatText.element)
  end
  local combatTextWidget
  if amount ~= nil and amount ~= "" then
    combatTextWidget = GetEmptyCombatTextWidget(skillType)
    if combatTextWidget ~= nil then
      SetFloatingCombatText(combatTextWidget, sourceUnitId, targetUnitId, amount, skillType, hitOrMissType, animType, posCalcType)
    end
  end
  if absorb ~= nil and absorb ~= "" then
    combatTextWidget = GetEmptyCombatTextWidget()
    if combatTextWidget ~= nil then
      SetFloatingCombatText(combatTextWidget, sourceUnitId, targetUnitId, absorb, nil, "ABSORB", animType, posCalcType)
    end
  end
end
local hitOrMissTypeToStr = function(hitOrMissType)
  if hitOrMissType == "CRITICAL" then
    return locale.combat.critical
  end
end
local missTypeToStr = function(missType)
  if missType == "MISS" then
    return locale.combat.miss
  elseif missType == "DODGE" then
    return locale.combat.dodge
  elseif missType == "BLOCK" then
    return locale.combat.block
  elseif missType == "PARRY" then
    return locale.combat.parry
  elseif missType == "IMMUNE" then
    return locale.combat.immune
  elseif missType == "RESIST" then
    return locale.combat.resist
  end
end
local function DamageToMe(targetUnitId, combatEvent, source, target, ...)
  if targetUnitId ~= X2Unit:GetUnitId("player") then
    return
  end
  local pos = combatEvent:find("_")
  local prefix = combatEvent:sub(1, pos - 1)
  local suffix = combatEvent:sub(pos + 1)
  local result = ParseCombatMessage(combatEvent, ...)
  local combatText = {}
  local skillType, hitOrMissType, animType
  combatText.amount = ""
  if result.damage ~= nil and result.damage ~= 0 then
    combatText.amount = tostring(-result.damage)
  end
  if result.showElementEffect ~= nil and result.showElementEffect == true then
    combatText.element = "\226\150\178"
  end
  if result.reduced ~= nil and result.reduced ~= 0 then
    combatText.absorb = tostring(result.reduced)
  end
  if combatEvent == "MELEE_DAMAGE" then
    if result.hitType == "HIT" then
      if 0 < result.elementDamage then
        skillType = "DAMAGED_SWING"
        animType = CTA_WEAPONATTACK
      else
        skillType = "DAMAGED_SWING"
        animType = CTA_BASICATTACK
      end
    elseif result.hitType == "CRITICAL" then
      if 0 < result.elementDamage then
        skillType = "DAMAGED_SPELL"
        hitOrMissType = result.hitType
        animType = CTA_WEAPONFATALME
      else
        skillType = "DAMAGED_SPELL"
        hitOrMissType = result.hitType
        animType = CTA_FATALATTACKME
      end
    end
  elseif prefix == "SPELL" then
    if suffix == "DAMAGE" or suffix == "DRAIN" or suffix == "LEECH" then
      if result.hitType == "HIT" then
        if 0 < result.elementDamage then
          if result.synergy == true then
            skillType = "DAMAGED_SPELL"
            animType = CTA_WEAPONCHAIN
          else
            skillType = "DAMAGED_SPELL"
            animType = CTA_WEAPONATTACK
          end
        elseif result.synergy == true then
          skillType = "DAMAGED_SPELL"
          animType = CTA_CHAINNEW
        else
          skillType = "DAMAGED_SPELL"
          animType = CTA_BASICATTACK
        end
      elseif result.hitType == "CRITICAL" then
        if 0 < result.elementDamage then
          if result.synergy == true then
            skillType = "DAMAGED_SPELL"
            hitOrMissType = result.hitType
            animType = CTA_WEAPONCHAINFATALME
          else
            skillType = "DAMAGED_SPELL"
            hitOrMissType = result.hitType
            animType = CTA_WEAPONFATALME
          end
        elseif result.synergy == true then
          skillType = "DAMAGED_SPELL"
          hitOrMissType = result.hitType
          animType = CTA_CHAINFATALME
        else
          skillType = "DAMAGED_SPELL"
          hitOrMissType = result.hitType
          animType = CTA_FATALATTACKME
        end
      end
    elseif suffix == "DOT_DAMAGE" then
      if result.hitType == "HIT" then
        if result.synergy == true then
          skillType = "DAMAGED_SPELL"
          hitOrMissType = "DOT"
          animType = CTA_DOTCHAIN
        else
          skillType = "DAMAGED_SPELL"
          hitOrMissType = "DOT"
          animType = CTA_DOTDAM
        end
      elseif result.hitType == "CRITICAL" then
        if result.synergy == true then
          skillType = "DAMAGED_SPELL"
          hitOrMissType = "DOT"
          animType = CTA_DOTCHAINFATAL
        else
          skillType = "DAMAGED_SPELL"
          hitOrMissType = "DOT"
          animType = CTA_DOTFATAL
        end
      end
    elseif suffix == "AURA_APPLIED" and result.combatText == true then
      if result.auraType == "BUFF" then
        combatText.amount = result.spellName
        skillType = "HEAL"
        animType = CTA_TEXTINFOBUFF
      elseif result.auraType == "DEBUFF" then
        combatText.amount = result.spellName
        skillType = "DEBUFF"
        animType = CTA_TEXTINFOBUFF
      end
    elseif suffix == "AURA_REMOVED" and result.combatText == true then
      combatText.amount = string.format("%s %s", result.spellName, locale.combat.spell_aura_removed)
      skillType = "BUFF_REMOVED"
      animType = CTA_MESSAGEDOWN
    end
  elseif combatEvent == "ENVIRONMENTAL_DAMAGE" then
    combatText.amount = string.format("%s(%s)", combatText.amount, envSourceToStr(result.source))
    skillType = "DAMAGED_SWING"
    animType = CTA_BASICATTACK
  end
  if suffix == "MISSED" then
    combatText.element = nil
    if result.missType == "MISS" then
      combatText.amount = missTypeToStr(result.missType)
      skillType = "MISSED"
      animType = CTA_TEXTINFOCHAIN
    elseif result.missType == "DODGE" then
      combatText.amount = missTypeToStr(result.missType)
      skillType = "MISSED"
      animType = CTA_TEXTINFOCHAIN
    elseif result.missType == "BLOCK" or result.missType == "PARRY" then
      combatText.amount = string.format("%s %s", missTypeToStr(result.missType), combatText.amount)
      skillType = "MISSED"
      animType = CTA_TEXTINFOCHAIN
    else
      combatText.amount = missTypeToStr(result.missType)
      skillType = "MISSED"
      animType = CTA_TEXTINFOCHAIN
    end
  elseif suffix == "HEALED" and 0 < result.heal then
    if result.hitType == "HIT" then
      if result.synergy == true then
        combatText.amount = F_TEXT.SetSignFormat(true, result.heal)
        skillType = "HEAL"
        animType = CTA_HEALCHAIN
      else
        combatText.amount = F_TEXT.SetSignFormat(true, result.heal)
        skillType = "HEAL"
        animType = CTA_NEWHEAL
      end
    elseif result.hitType == "CRITICAL" then
      if result.synergy == true then
        combatText.amount = F_TEXT.SetSignFormat(true, result.heal)
        skillType = "HEAL"
        animType = CTA_HEALCHAINFATAL
      else
        combatText.amount = F_TEXT.SetSignFormat(true, result.heal)
        skillType = "HEAL"
        animType = CTA_HEALFATAL
      end
    end
  elseif suffix == "ENERGIZE" and result.amount > 0 then
    if result.powerType == "HEALTH" then
      combatText.amount = F_TEXT.SetSignFormat(true, result.amount)
      skillType = "HEAL"
      animType = CTA_MPENERGIZE
    else
      combatText.amount = F_TEXT.SetSignFormat(true, result.amount)
      skillType = "ENERGIZE_MP"
      animType = CTA_MPENERGIZE
    end
  end
  CombatText_Add(nil, nil, combatText, skillType, hitOfMissType, animType)
end
local function DamageToOthers(sourceUnitId, targetUnitId, amount, reduce, skillType, hitOrMissType, weaponDamage, showElementEffect, elementType, isSynergy, distance)
  if W_UNIT.IsMyUnitId(targetUnitId) then
    return
  end
  local animType = CTA_DMGPOPUP
  local combatText = {}
  combatText.amount = amount ~= 0 and tostring(-amount) or ""
  combatText.absorb = reduce ~= 0 and tostring(reduce) or nil
  if showElementEffect ~= nil and showElementEffect == true then
    combatText.element = "\226\150\178"
  end
  if skillType == "SWING" then
    if hitOrMissType == "CRITICAL" then
      if weaponDamage ~= nil and weaponDamage > 0 then
        if isSynergy == true then
          animType = CTA_WEAPONCHAINFATAL
        else
          animType = CTA_WEAPONFATAL
        end
      elseif isSynergy == true then
        animType = CTA_CHAINFATAL
      else
        animType = CTA_FATALATTACK
      end
    elseif weaponDamage ~= nil and weaponDamage > 0 then
      if isSynergy == true then
        animType = CTA_WEAPONCHAIN
      else
        animType = CTA_WEAPONATTACK
      end
    elseif isSynergy == true then
      animType = CTA_CHAINNEW
    else
      animType = CTA_BASICATTACK
    end
  elseif skillType == "SKILL" then
    if hitOrMissType == "CRITICAL" then
      if weaponDamage ~= nil and weaponDamage > 0 then
        if isSynergy == true then
          animType = CTA_WEAPONCHAINFATAL
        else
          animType = CTA_WEAPONFATAL
        end
      elseif isSynergy == true then
        animType = CTA_CHAINFATAL
      else
        animType = CTA_FATALATTACKME
      end
    elseif weaponDamage ~= nil and weaponDamage > 0 then
      if isSynergy == true then
        animType = CTA_WEAPONCHAIN
      else
        animType = CTA_WEAPONATTACK
      end
    elseif isSynergy == true then
      animType = CTA_CHAINNEW
    else
      animType = CTA_BASICATTACK
    end
  elseif skillType == "DOT" then
    if hitOrMissType == "CRITICAL" then
      if isSynergy == true then
        animType = CTA_DOTCHAINFATAL
      else
        animType = CTA_DOTFATAL
      end
    elseif isSynergy == true then
      animType = CTA_DOTCHAIN
    else
      animType = CTA_DOTDAM
    end
  elseif skillType == "MANA" then
    if amount > 0 then
      combatText.amount = F_TEXT.SetSignFormat(true, amount)
      skillType = "ENERGIZE_MP"
      animType = CTA_MPENERGIZE
    else
      combatText.amount = tostring(amount)
      skillType = "DAMAGE_MP"
      animType = CTA_MPDAMAGE
    end
  elseif skillType == "HEAL" and amount > 0 then
    combatText.amount = F_TEXT.SetSignFormat(true, amount)
    if hitOrMissType == "CRITICAL" then
      if isSynergy == true then
        animType = CTA_HEALCHAINFATAL
      else
        animType = CTA_HEALFATAL
      end
    elseif isSynergy == true then
      animType = CTA_HEALCHAIN
    else
      animType = CTA_NEWHEAL
    end
  end
  if hitOrMissType == "MISS" or hitOrMissType == "DODGE" or hitOrMissType == "IMMUNE" or hitOrMissType == "RESIST" then
    animType = CTA_TEXTINFOCHAIN
    combatText.amount = missTypeToStr(hitOrMissType) or hitOrMissType
    combatText.element = nil
  end
  if hitOrMissType == "BLOCK" or hitOrMissType == "PARRY" then
    animType = CTA_TEXTINFOCHAIN
    combatText.amount = string.format("%s %s", missTypeToStr(hitOrMissType), tostring(-amount))
    combatText.element = nil
  end
  if isSynergy == true then
    combatText.amount = string.format("%s %s", locale.combat.combat_text_synergy_damage, combatText.amount)
  end
  CombatText_Add(sourceUnitId, targetUnitId, combatText, skillType, hitOrMissType, animType, distance)
end
local function DamageFromCollision(targetUnitId, combatEvent, source, target, ...)
  local pos = combatEvent:find("_")
  local prefix = combatEvent:sub(1, pos - 1)
  local suffix = combatEvent:sub(pos + 1)
  local result = ParseCombatMessage(combatEvent, ...)
  local combatText = ""
  if result.damage ~= nil then
    combatText = tostring(-result.damage)
  end
  local skillType = "COLLISION_ME"
  if not result.mySlave then
    skillType = "COLLISION_OTHER"
  end
  CombatText_Add(nil, targetUnitId, string.format("%s(%s)", combatText, envSourceToStr(result.source, result.subType)), skillType, nil, CTA_BASICATTACK, nil, PCT_SHIP_COLLISION)
end
local damageDisplayEvents = {
  COMBAT_MSG = function(...)
    DamageToMe(unpack(arg))
  end,
  COMBAT_TEXT = function(...)
    DamageToOthers(unpack(arg))
  end,
  COMBAT_TEXT_COLLISION = function(...)
    DamageFromCollision(unpack(arg))
  end,
  COMBAT_TEXT_SYNERGY = function(...)
    CombatText_Add(nil, nil, locale.combat.combat_text_synergy, "SYNERGY", nil, CTA_TEXTINFOCHAIN)
  end,
  UNIT_COMBAT_STATE_CHANGED = function(...)
    if arg[2] == X2Unit:GetUnitId("player") then
      if arg[1] == true then
        CombatText_Add(nil, nil, locale.combat.player_enter_combat, "COMBAT_START", nil, CTA_FIGHTSTART)
      else
        CombatText_Add(nil, nil, locale.combat.player_leave_combat, "COMBAT_END", nil, CTA_FIGHTSTART)
      end
    end
  end,
  EXP_CHANGED = function(...)
    if X2Unit:GetUnitId("player") == arg[1] and 1 <= arg[2] then
      local amount = arg[3]
      if gainExpWidget ~= nil then
        if gainExpWidget:IsVisible() then
          oldGainExp = X2Util:StrNumericAdd(oldGainExp, amount)
          gainExpWidget:SetText(string.format("%s %s", GetUIText(COMMON_TEXT, "exp"), F_TEXT.SetSignFormat(true, oldGainExp)))
          return
        else
          oldGainExp = amount
        end
      end
      CombatText_Add(nil, nil, string.format("%s %s", GetUIText(COMMON_TEXT, "exp"), F_TEXT.SetSignFormat(true, amount)), "GAIN_EXP", nil, CTA_EXPUP)
    end
  end,
  PLAYER_HONOR_POINT_CHANGED_IN_HPW = function(amount)
    local sign = amount > 0 and "+" or ""
    local msg = string.format("%s %s%d", GetUIText(COMMON_TEXT, "honor_point"), sign, amount)
    if amount > 0 then
      CombatText_Add(nil, nil, msg, "GAIN_HONOR_POINT", nil, CTA_EXPUP)
    else
      CombatText_Add(nil, nil, msg, "LOSE_HONOR_POINT", nil, CTA_MOVEDOWN)
    end
  end
}
combatTextFrame:SetHandler("OnEvent", function(this, event, ...)
  damageDisplayEvents[event](...)
end)
RegistUIEvent(combatTextFrame, damageDisplayEvents)
