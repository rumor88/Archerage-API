if combatTextLocale == nil then
  combatTextLocale = {}
end
combatTextLocale.drawableAnchor = {x = 0, y = 0}
combatTextLocale.fontSize = 60
combatTextLocale.fontPath = "img_font_combat"
combatTextLocale.fontKind = FTK_IMAGETEXT
