if X2Util:GetGameProvider() == XLGAMES_TH then
  combatTextLocale.fontPath = FONT_PATH.COMBAT
  combatTextLocale.fontKind = FTK_GENERAL
end
