if X2Util:GetGameProvider() == MAILRU then
  combatTextLocale.drawableAnchor = {x = 3, y = -9}
  combatTextLocale.fontSize = 38
  combatTextLocale.fontPath = FONT_PATH.COMBAT
  combatTextLocale.fontKind = FTK_GENERAL
end
