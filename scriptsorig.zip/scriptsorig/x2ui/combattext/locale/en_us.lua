if X2Util:GetGameProvider() == KAKAONA then
  combatTextLocale.fontPath = FONT_PATH.COMBAT
  combatTextLocale.fontKind = FTK_GENERAL
end
