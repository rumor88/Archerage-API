﻿## author : zergra
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## combat text

locale/ko.lua
locale/ru.lua
locale/en_us.lua
locale/th.lua

common.lua
combat_text_animation.lua
combat_text_effect.lua
combat_text.lua