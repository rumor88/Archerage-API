CLIENT_DRIVEN_WIDGET = {
  TITLE = {
    EXTENT = {782, 128}
  },
  TITLE_TEXT_BOX = {
    EXTENT = {782, 108}
  },
  CONTENTS = {
    EXTENT = {200, 100}
  },
  CONTENTS_TEXT_BOX = {
    EXTENT = {400, 30}
  },
  CONTENTS_IMG = {
    ["200_1"] = {
      {
        path = TEXTURE_PATH.KEY_WASD,
        key = "wasd"
      }
    },
    ["200_2"] = {
      {
        path = TEXTURE_PATH.KEY_F,
        key = "f"
      }
    },
    ["300_1"] = {
      {
        path = TEXTURE_PATH.KEY_MOUSE
      }
    },
    ["500_1"] = {
      {
        path = TEXTURE_PATH.KEY_F,
        key = "f"
      }
    },
    ["600_2"] = {
      {
        path = TEXTURE_PATH.KEY_F,
        key = "f"
      },
      {
        path = TEXTURE_PATH.KEY_W,
        key = "w"
      }
    },
    ["800_1"] = {
      {
        path = TEXTURE_PATH.KEY_F,
        key = "f"
      }
    },
    ["1000_1"] = {
      {
        path = TEXTURE_PATH.KEY_F,
        key = "f"
      }
    },
    ["1100_2"] = {
      {
        path = TEXTURE_PATH.KEY_R,
        key = "r"
      }
    },
    ["1300_1"] = {
      {
        path = TEXTURE_PATH.KEY_W,
        key = "w"
      }
    },
    ["1400_2"] = {
      {
        path = TEXTURE_PATH.KEY_F,
        key = "f"
      }
    },
    ["1600_1"] = {
      {
        path = TEXTURE_PATH.KEY_F,
        key = "f"
      }
    },
    ["1700_2"] = {
      {
        path = TEXTURE_PATH.KEY_R,
        key = "r"
      }
    },
    ["1900_3"] = {
      {
        path = TEXTURE_PATH.KEY_123,
        key = "123"
      }
    },
    ["2100_1"] = {
      {
        path = TEXTURE_PATH.KEY_F,
        key = "f"
      }
    }
  }
}
