function CreatePreliminaryEquipmentsWindow(parent)
  local prelimEquipWnd = SetViewofPreliminaryEquipmentsWindow("prelimEquipWnd", parent)
  local CreatePreliminaryEquipmentsButton = function(id, parent)
    local toggleBtn = parent:CreateChildWidget("button", id, 0, false)
    toggleBtn:SetStyle("character_lock_off")
    toggleBtn:RegisterForClicks("RightButton")
    function toggleBtn:SetBtnStatus(on)
      if on then
        self:SetStyle("character_swap_on")
      else
        self:SetStyle("character_swap")
      end
    end
    local OnEnter = function(self)
      SetTooltip(GetUIText(COMMON_TEXT, "prelim_swap_button_tooltip"), self)
    end
    toggleBtn:SetHandler("OnEnter", OnEnter)
    return toggleBtn
  end
  local prelimEquipBtn = CreatePreliminaryEquipmentsButton("prelimEquipBtn", parent)
  prelimEquipBtn:AddAnchor("TOPRIGHT", parent.slot[16], "BOTTOMLEFT", 7, -13)
  prelimEquipWnd:AddAnchor("RIGHT", prelimEquipBtn, "LEFT", 2, -14)
  local function OnClickPrelimEquipBtn(self, arg)
    local CanUseInBattlefield = function()
      if UIParent:GetPermission(UIC_PLAYER_EQUIPMENT) == false then
        AddMessageToSysMsgWindow(X2Locale:LocalizeUiText(ERROR_MSG, "CANNOT_USE_IN_BATTLE_FIELD"))
        return false
      end
      return true
    end
    if not CanUseInBattlefield() then
      return
    end
    if arg == "LeftButton" then
      X2Equipment:SwapPrelimEquipments()
      return
    end
    if arg == "RightButton" then
      prelimEquipWnd:Show(not prelimEquipWnd:IsVisible())
      if prelimEquipWnd:IsVisible() then
        ADDON:ShowContent(UIC_BAG, true)
      end
      return
    end
  end
  prelimEquipBtn:SetHandler("OnClick", OnClickPrelimEquipBtn)
  local OnShowPrelimEquipWindow = function()
    X2Equipment:StartPrelimBagInteraction()
  end
  prelimEquipWnd:SetHandler("OnShow", OnShowPrelimEquipWindow)
  local OnHidePrelimEquipWindow = function()
    X2Equipment:EndPrelimBagInteraction()
  end
  prelimEquipWnd:SetHandler("OnHide", OnHidePrelimEquipWindow)
  for i = 1, #prelimEquipWnd.prelimSlots do
    local slot = prelimEquipWnd.prelimSlots[i]
    function slot:PreClick()
      if X2Input:IsShiftKeyDown() and X2Chat:IsActivatedChatInput() then
        local linkText = X2Equipment:GetPrelimLinkText(slot.slotType)
        if AddLinkItem(linkText) == true then
          return true
        end
        return true
      end
      return false
    end
    slot:SetHandler("PreClick", slot.PreClick)
    local lockButton = prelimEquipWnd.prelimLocks[i]
    local OnClickLockButton = function(self, arg)
      X2Equipment:SetPrelimSlotLock(self.slotType, not self.lockStatus)
    end
    lockButton:SetHandler("OnClick", OnClickLockButton)
  end
  local function PrelimEquipBtnUpdate()
    prelimEquipBtn:SetBtnStatus(X2Equipment:HasAnyPrelimEquipments())
  end
  local function UpdatePrelimSlots()
    for i = 1, #prelimEquipWnd.prelimSlots do
      local slot = prelimEquipWnd.prelimSlots[i]
      local tooltip = X2Equipment:GetPreliminaryItemTooltipText(slot.slotType)
      slot:SetInfo(tooltip)
      slot:SetForceVisible(true)
    end
  end
  local function UpdatePrelimLocks()
    local lockStatus = X2Equipment:GetPrelimSlotLockInfo()
    for i = 1, #prelimEquipWnd.prelimLocks do
      local slot = prelimEquipWnd.prelimSlots[i]
      local slotLock = prelimEquipWnd.prelimLocks[i]
      local buttonStatus = lockStatus[slotLock.slotType]
      slot:SetSlotLock(not buttonStatus.isDisabled and buttonStatus.isLocked)
      slotLock:SetSlotLock(buttonStatus.isLocked, buttonStatus.isDisabled)
    end
  end
  local function PrelimEquipWndUpdate()
    UpdatePrelimSlots()
    UpdatePrelimLocks()
  end
  function prelimEquipWnd:ToggleCtrlShow(isShow)
    if isShow == nil then
      isShow = false
    end
    prelimEquipWnd:Show(false)
    prelimEquipBtn:Show(isShow)
  end
  local prelimEquipEvents = {
    PRELIMINARY_EQUIP_UPDATE = function()
      PrelimEquipBtnUpdate()
      PrelimEquipWndUpdate()
    end
  }
  prelimEquipWnd:SetHandler("OnEvent", function(this, event, ...)
    prelimEquipEvents[event](...)
  end)
  RegistUIEvent(prelimEquipWnd, prelimEquipEvents)
  PrelimEquipBtnUpdate()
  PrelimEquipWndUpdate()
  return prelimEquipWnd
end
