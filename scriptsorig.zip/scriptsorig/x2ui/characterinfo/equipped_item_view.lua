function SetViewOfEquipSlotWindow()
  local window = CreateEmptyWindow("equippedItem", "UIParent")
  window:AddAnchor("TOP", "UIParent", "TOP", 0, (UIParent:GetScreenHeight() - 440 - 60) * 4602678819172646912)
  window.slot = {}
  window.bagslot = {}
  window.bagButton = {}
  window.equipSlotReinforceBtn = nil
  window.preliminaryEquipWnd = nil
  window.bagslotItemMaxCnt = 3
  if X2Player:GetFeatureSet().equipSlotEnchantment == true then
    do
      local EQUIP_SLOT_REINFORCE_IMG_INFO = {
        BTN_BUNDLE_EFFECT = {
          drawableType = "drawable",
          path = "ui/character/slot_enchant.dds",
          coordsKey = "btn_set_eff",
          colorKey = ""
        }
      }
      window.equipSlotReinforceBtn = {}
      local reinforceBtn = CreateEmptyButton("equippedItem.equipSlotReinforceBtn.reinforce", window)
      reinforceBtn:Show(true)
      reinforceBtn:RegisterForClicks("LeftButton")
      reinforceBtn:EnableDrag(false)
      reinforceBtn:AddAnchor("TOPRIGHT", window, "TOP", 205, -61)
      reinforceBtn:SetStyle("character_slot_enchant")
      window.equipSlotReinforceBtn.reinforce = reinforceBtn
      local equipBtn = CreateEmptyButton("equippedItem.equipSlotReinforceBtn.equip", window)
      equipBtn:Show(false)
      equipBtn:RegisterForClicks("LeftButton")
      equipBtn:EnableDrag(false)
      equipBtn:SetStyle("character_slot_equipment")
      equipBtn:AddAnchor("TOPRIGHT", window, "TOP", 219, -61)
      window.equipSlotReinforceBtn.equip = equipBtn
      if X2Player:GetFeatureSet().equipSlotBundleEffect == true then
        local bundleEffectBtn = CreateEmptyButton("equippedItem.equipSlotReinforceBtn.bundleEffect", window)
        bundleEffectBtn:Show(false)
        bundleEffectBtn:RegisterForClicks("LeftButton")
        bundleEffectBtn:EnableDrag(false)
        bundleEffectBtn:AddAnchor("TOPRIGHT", window, "TOP", 30, -89)
        window.equipSlotReinforceBtn.bundleEffect = bundleEffectBtn
        local bundleEffectLevelImage = window:CreateDrawable("ui/character/slot_enchant.dds", "num_01", "overlay")
        bundleEffectLevelImage:AddAnchor("CENTER", bundleEffectBtn, "CENTER", 0, -2)
        bundleEffectLevelImage:Show(false)
        window.equipSlotReinforceBtn.bundleEffectLevel = bundleEffectLevelImage
        function window.equipSlotReinforceBtn:UpdateBundleInfo()
          local colors = {
            "grey",
            nil,
            "green",
            "blue"
          }
          local myBundleEffectLevel = X2EquipSlotReinforce:GetBundleEffectTopLevel()
          EQUIP_SLOT_REINFORCE_IMG_INFO.BTN_BUNDLE_EFFECT.colorKey = colors[myBundleEffectLevel + 1]
          ApplyButtonSkin(window.equipSlotReinforceBtn.bundleEffect, EQUIP_SLOT_REINFORCE_IMG_INFO.BTN_BUNDLE_EFFECT)
          if myBundleEffectLevel > 0 then
            window.equipSlotReinforceBtn.bundleEffectLevel:SetTextureInfo(string.format("num_0%d", myBundleEffectLevel))
            window.equipSlotReinforceBtn.bundleEffectLevel:Show(true)
          else
            window.equipSlotReinforceBtn.bundleEffectLevel:Show(false)
          end
        end
      end
    end
  end
  window.leftSlots = CreateEmptyWindow("equippedItem.leftSlots", window)
  window.leftSlots:SetExtent(ICON_SIZE.DEFAULT, 485)
  window.leftSlots:AddAnchor("TOPLEFT", window, "TOP", -200, 0)
  window.rightSlots = CreateEmptyWindow("equippedItem.rightSlots", window)
  window.rightSlots:SetExtent(ICON_SIZE.DEFAULT, 485)
  window.rightSlots:AddAnchor("TOPRIGHT", window, "TOP", 200, 0)
  local GetSignConvert = function(isConvert, value)
    if isConvert == true then
      return -value
    else
      return value
    end
  end
  local function CreateBagSlot(parent, isLeftFlip)
    local slot = {}
    local xSpace = 21
    for i = 1, window.bagslotItemMaxCnt do
      local xOffset = xSpace + (i - 1) * 33
      local button = CreateIconButton(string.format("slot[%d]", i), parent)
      button:SetExtent(ICON_SIZE.APPELLAITON, ICON_SIZE.APPELLAITON)
      button:AddAnchor(GetFlipAnchor(isLeftFlip, "LEFT"), parent, GetSignConvert(isLeftFlip, xOffset), 0)
      F_SLOT.ApplySlotSkin(button, button.back, SLOT_STYLE.DEFAULT)
      slot[i] = button
    end
    return slot
  end
  local function CreateEquipSlot(isLeftFlip, index)
    local parent = isLeftFlip and window.leftSlots or window.rightSlots
    local button = CreateIconButton(string.format("slot[%d]", index), parent, "inventory")
    button:RegisterForClicks("RightButton")
    button:EnableDrag(true)
    button:EstablishSlot(ISLOT_EQUIPMENT, PLAYER_EQUIP_SLOTS[index] - 1)
    local bagslot = CreateEmptyWindow("bagslot", button)
    bagslot:SetExtent(180, ICON_SIZE.DEFAULT)
    bagslot:Show(false)
    local bgKey = "bag_slot_bg_right"
    if isLeftFlip then
      bgKey = "bag_slot_bg_left"
    end
    local bg = bagslot:CreateDrawable(TEXTURE_PATH.CHARACTER_INFO, bgKey, "background")
    bg:SetTextureColor("default")
    bg:AddAnchor("TOPLEFT", bagslot, 0, 0)
    bg:AddAnchor("BOTTOMRIGHT", bagslot, 0, 0)
    bagslot.bg = bg
    local bagButton = CreateEmptyButton("bagButton.", button)
    bagButton:SetStyle("character_equip_open")
    bagButton:Show(true)
    bagButton.showSlots = false
    if isLeftFlip then
      bagButton.openSkin = "character_equip_close"
      bagButton.closeSkin = "character_equip_open"
    else
      bagButton.openSkin = "character_equip_open"
      bagButton.closeSkin = "character_equip_close"
    end
    local up = bagslot:CreateChildWidget("button", "up", 0, true)
    ApplyButtonSkin(up, BUTTON_CONTENTS.EQUIP_UP)
    local down = bagslot:CreateChildWidget("button", "down", 0, true)
    ApplyButtonSkin(down, BUTTON_CONTENTS.EQUIP_DOWN)
    bagButton:SetStyle(bagButton.openSkin)
    bagslot:AddAnchor(GetFlipAnchor(isLeftFlip, "TOPLEFT"), button, GetFlipAnchor(isLeftFlip, "TOPRIGHT"), GetSignConvert(isLeftFlip, 7), 0)
    bagButton:AddAnchor(GetFlipAnchor(isLeftFlip, "LEFT"), bagslot, GetSignConvert(isLeftFlip, -2), 0)
    if index == 20 then
      bagButton:Show(false)
    end
    up:AddAnchor(GetFlipAnchor(isLeftFlip, "RIGHT"), bagslot, GetSignConvert(isLeftFlip, -16), -8)
    down:AddAnchor(GetFlipAnchor(isLeftFlip, "RIGHT"), bagslot, GetSignConvert(isLeftFlip, -16), 8)
    bagslot.slot = CreateBagSlot(bagslot, isLeftFlip)
    bagslot.index = 0
    bagslot.max = 0
    window.bagButton[index] = bagButton
    window.bagslot[index] = bagslot
    window.slot[index] = button
    window.slot[index]:SetForceVisible(true)
    F_SLOT.ApplySlotSkin(window.slot[index], window.slot[index].back, SLOT_STYLE.EQUIP_ITEM[index])
  end
  for i = 1, #PLAYER_EQUIP_SLOTS do
    CreateEquipSlot(IsLeftSide(i), i)
  end
  window.slot[21]:AddAnchor("CENTER", "UIParent", "CENTER", 0, -280)
  if X2Player:GetFeatureSet().useCosplayLooksSlot == false then
    window.bagButton[22]:Show(false)
    window.bagslot[22]:Show(false)
  end
  SetEquipSlotAnchor(window.slot, window, true)
  local optionButton = window:CreateChildWidget("button", "optionButton", 0, true)
  if X2Player:GetFeatureSet().useCosplayLooksSlot == true then
    optionButton:AddAnchor("BOTTOMLEFT", window.slot[21], "TOPLEFT", 34, -4)
  else
    optionButton:AddAnchor("BOTTOM", window.slot[21], "TOP", 0, -5)
  end
  optionButton:SetStyle("common_hud")
  function window:OnScale()
    self.slot[21]:RemoveAllAnchors()
    self.slot[22]:RemoveAllAnchors()
    if X2Player:GetFeatureSet().useCosplayLooksSlot == true then
      self.slot[21]:AddAnchor("CENTER", "UIParent", "CENTER", -self.slot[21]:GetWidth() / 2 - 3, F_LAYOUT.CalcDontApplyUIScale(-280))
      self.slot[22]:AddAnchor("CENTER", "UIParent", "CENTER", self.slot[21]:GetWidth() / 2 + 3, F_LAYOUT.CalcDontApplyUIScale(-280))
    else
      self.slot[21]:AddAnchor("CENTER", "UIParent", "CENTER", 0, F_LAYOUT.CalcDontApplyUIScale(-280))
      self.slot[22]:Show(false)
      self.bagButton[22]:Show(false)
      self.bagslot[22]:Show(false)
    end
  end
  window:SetHandler("OnScale", window.OnScale)
  return window
end
