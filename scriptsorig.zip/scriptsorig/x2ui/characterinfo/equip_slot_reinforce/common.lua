function GetEquipSlotReinforceAttibuteTextColor(attributeType)
  local colors = {
    [ESRA_OFFENCE] = "red",
    [ESRA_DEFENCE] = "bright_blue",
    [ESRA_SUPPORT] = "original_orange"
  }
  if colors[attributeType] ~= nil then
    return colors[attributeType]
  else
    return colors[ESRA_OFFENCE]
  end
end
