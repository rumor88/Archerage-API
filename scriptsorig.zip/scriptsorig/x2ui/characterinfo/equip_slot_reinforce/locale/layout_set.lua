local layoutSet = {
  default = {
    equipSlotReinforce = {
      effectChangeDlg = {
        useExpandWidth = false,
        columnWidth1 = 180,
        columnWidth2 = 111
      }
    }
  },
  [KAKAONA] = {
    equipSlotReinforce = {
      effectChangeDlg = {
        useExpandWidth = true,
        columnWidth1 = 230,
        columnWidth2 = 162
      }
    }
  }
}
layoutSet[MAILRU] = layoutSet[KAKAONA]
layoutSet[GAMEON] = layoutSet[KAKAONA]
function GetLayoutSetEquipSlotReinforce()
  return L_HELPER.Get(layoutSet)
end
