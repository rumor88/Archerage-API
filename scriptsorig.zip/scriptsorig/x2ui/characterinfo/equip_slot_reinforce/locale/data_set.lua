local dataSet = {
  default = {
    ingameshopInfo = {mainTabIndex = nil, subTabIndex = nil}
  },
  [TENCENT] = {
    ingameshopInfo = {mainTabIndex = 4, subTabIndex = 2}
  }
}
function GetDataSetEquipSlotReinforce()
  return L_HELPER.Get(dataSet)
end
