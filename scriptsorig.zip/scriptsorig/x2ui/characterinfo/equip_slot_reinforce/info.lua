function CreateEquipSlotReinforceInfoWindow(id, parent)
  local EQUIP_SLOT_REINFORCE_ELSE_TEXTURE_PATH = "ui/character/slot_enchant_else.dds"
  local MAX_LEVEL_EFFECT_COUNT = 3
  local localeDataInfo = GetDataSetEquipSlotReinforce()
  local localeLayoutInfo = GetLayoutSetEquipSlotReinforce()
  local window = CreateWindow(id, parent)
  window:SetWidth(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_430))
  window:SetTitle(X2Locale:LocalizeUiText(COMMON_TEXT, "equip_slot_reinforce_window_title"))
  local targetTitlebox = W_MODULE:Create("targetTitlebox", window, W_MODULE.TYPES.TITLE_BOX, {
    title = GetUIText(COMMON_TEXT, "equip_slot_reinforce_window_slot"),
    [W_MODULE.ATTRIBUTE.GUIDE_TOOLTIP] = GetCommonText("equip_slot_reinforce_slot_effect_guide_tooltip")
  })
  local body = targetTitlebox:CreateChildWidget("emptywidget", "body", 0, false)
  local slotIcon = CreateIconButton("slotIcon", body)
  slotIcon:SetExtent(ICON_SIZE.LARGE, ICON_SIZE.LARGE)
  slotIcon:EnableDrag(false)
  slotIcon:SetForceVisible(true)
  slotIcon:AddAnchor("TOPLEFT", body, 0, 0)
  local levelOffset = 3
  local levelTextbox = body:CreateChildWidget("textbox", "level", 0, false)
  levelTextbox:SetExtent(slotIcon:GetWidth(), FONT_SIZE.MIDDLE)
  levelTextbox:AddAnchor("TOP", slotIcon, "BOTTOM", 0, levelOffset)
  levelTextbox:SetAutoWordwrap(false)
  levelTextbox.style:SetColorByKey("default")
  local headerTableOffset = 10
  local contentWidth = targetTitlebox:GetContentWidth()
  local remainWidth = contentWidth - slotIcon:GetWidth() - headerTableOffset
  local headerTable = W_MODULE:Create("headerTable", body, W_MODULE.TYPES.HEADER_TABLE_BASE, {
    width = remainWidth,
    [W_MODULE.ATTRIBUTE.LEFT_WIDTH_RATIO] = 4604480259023595110,
    valueAnchor = "RIGHT"
  })
  headerTable:AddAnchor("TOPLEFT", slotIcon, "TOPRIGHT", headerTableOffset, 5)
  local partRowKey = "part"
  headerTable:AddRow(partRowKey, {
    title = {string = ""}
  })
  local expRowKey = "exp"
  headerTable:AddRow(expRowKey, {
    title = {
      string = GetUIText(COMMON_TEXT, "equip_slot_reinforce_gain_exp")
    },
    value = {string = "-"}
  })
  local selectedEquipSlot
  local function IsFullExp()
    return X2EquipSlotReinforce:IsFullExp(selectedEquipSlot) > 0
  end
  local levelupBtn = headerTable:CreateChildWidget("button", "levelupBtn", 0, true)
  levelupBtn:Enable(false)
  levelupBtn:SetStyle("up_arrow")
  local function LevelupBtnLeftClickFunc()
    X2EquipSlotReinforce:StartReinforceLevelup(selectedEquipSlot)
  end
  ButtonOnClickHandler(levelupBtn, LevelupBtnLeftClickFunc)
  local gaugeWidth = remainWidth - levelupBtn:GetWidth() - 3
  local addExpGauge = W_BAR.CreateStatusBar("addExpGauge", window, "reinforceAddExpGuage")
  addExpGauge:SetExtent(gaugeWidth, 14)
  addExpGauge:SetBarColorByKey("equip_slot_reinforce_add_exp")
  addExpGauge:AddAnchor("LEFT", levelTextbox, "RIGHT", headerTableOffset, 0)
  levelupBtn:AddAnchor("LEFT", addExpGauge, "RIGHT", 3, 0)
  local expGauge = W_BAR.CreateStatusBar("expGauge", window, "reinforceExpGuage")
  expGauge:SetExtent(gaugeWidth, 14)
  expGauge:SetBarColorByKey("equip_slot_reinforce_exp")
  expGauge:AddAnchor("LEFT", levelTextbox, "RIGHT", headerTableOffset, 0)
  local function OnEnter(self)
    local function GetExpTooltip()
      if selectedEquipSlot == nil then
        return
      end
      local info = X2EquipSlotReinforce:GetReinforceInfo(selectedEquipSlot)
      if info == nil then
        return
      end
      local exp = info.exp
      local totalExp = info.totalExp
      local str = F_TEXT.SetSlashFormat(F_TEXT.SetCommaFormat(exp), string.format("%s (%.2f%%)", F_TEXT.SetCommaFormat(totalExp), info.exp * 100 / info.totalExp))
      return str
    end
    SetTooltip(GetExpTooltip(), self)
  end
  expGauge:SetHandler("OnEnter", OnEnter)
  local maxLevelLabel = body:CreateChildWidget("label", "maxLevelLabel", 0, false)
  maxLevelLabel:SetExtent(remainWidth, FONT_SIZE.MIDDLE)
  maxLevelLabel.style:SetColorByKey("green")
  maxLevelLabel:SetText(GetUIText(COMMON_TEXT, "equip_slot_reinforce_max_level"))
  maxLevelLabel:AddAnchor("LEFT", levelTextbox, "RIGHT", headerTableOffset, 0)
  maxLevelLabel.style:SetAlign(ALIGN_LEFT)
  body:SetExtent(contentWidth, slotIcon:GetHeight() + levelTextbox:GetHeight() + levelOffset)
  targetTitlebox:AddBody(body)
  window:RegisterStack(targetTitlebox)
  local effectTitlebox = W_MODULE:Create("effectTitlebox", window, W_MODULE.TYPES.TITLE_BOX, {
    title = GetUIText(COMMON_TEXT, "equip_slot_reinforce_window_level_effect_info_title")
  })
  local changeBtn = effectTitlebox:CreateChildWidget("button", "changeBtn", 0, false)
  changeBtn:AddAnchor("TOPRIGHT", effectTitlebox, -15, 7)
  ApplyButtonSkin(changeBtn, {
    drawableType = "drawable",
    path = EQUIP_SLOT_REINFORCE_ELSE_TEXTURE_PATH,
    coordsKey = "btn_change"
  })
  local function ChangeBtnLeftClickFunc()
    local function DialogEquipSlotReinforceLevelEffectChangeHandler(wnd, infoTable)
      local selectedLevelEffectIndex = 1
      if localeLayoutInfo.equipSlotReinforce.effectChangeDlg.useExpandWidth then
        wnd:UseExpandWidth()
      end
      wnd:SetTitle(GetCommonText("equip_slot_reinforce_level_effect_window_title"))
      local info = X2EquipSlotReinforce:GetLevelEffectChangeUIInfo(selectedEquipSlot)
      wnd:RegisterStack(W_MODULE:Create("helpMsg", wnd, W_MODULE.TYPES.TEXTBOX, {
        [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("equip_slot_reinforce_level_effect_change_item_help_msg")
      }))
      local curCnt = X2Bag:GetCountInBag(info.item.itemType)
      local data = {
        itemInfo = X2Item:GetItemInfoByType(info.item.itemType),
        stack = {curCnt, 1}
      }
      local itemIcon = W_MODULE:Create("itemIcon", wnd, W_MODULE.TYPES.ICON_VERTICAL, data)
      wnd:RegisterStack(itemIcon)
      local radioTexts = {}
      local initSelected = false
      if info.levelEffectList ~= nil then
        for i = 1, #info.levelEffectList do
          local levelEffect = info.levelEffectList[i]
          if levelEffect.attributeType ~= nil then
            local attributeStr = locale.attribute(levelEffect.attributeType)
            local valueStr = GetModifierCalcValue(levelEffect.attributeType, levelEffect.value)
            local item = {
              [W_MODULE.ATTRIBUTE.RADIO_GROUP_DATA] = {
                text = string.format("%s %s", attributeStr, valueStr),
                value = i,
                enable = levelEffect.isChangeable,
                checked = levelEffect.isChangeable and not initSelected
              },
              changeable = levelEffect.isChangeable
            }
            table.insert(radioTexts, item)
            if item[W_MODULE.ATTRIBUTE.RADIO_GROUP_DATA].checked then
              initSelected = true
            end
          else
            local item = {
              [W_MODULE.ATTRIBUTE.RADIO_GROUP_DATA] = {
                text = GetUIText(COMMON_TEXT, "equip_slot_reinforce_level_effect_not_ready", tostring(levelEffect.triggerLevel)),
                value = 0,
                enable = false,
                checked = false
              },
              changeable = false
            }
            table.insert(radioTexts, item)
          end
        end
      end
      for i = 1, MAX_LEVEL_EFFECT_COUNT - #radioTexts do
        local item = {
          [W_MODULE.ATTRIBUTE.RADIO_GROUP_DATA] = {
            text = GetUIText(COMMON_TEXT, "none"),
            value = 0,
            enable = false,
            checked = false
          },
          changeable = false
        }
        table.insert(radioTexts, item)
      end
      local listCtrl = W_MODULE:Create("listCtrl", wnd, W_MODULE.TYPES.LISTCTRL, {
        [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = false,
        [W_MODULE.ATTRIBUTE.DATA] = radioTexts
      }, {
        [W_MODULE.ATTRIBUTE.HAS_SCROLL] = false,
        [W_MODULE.ATTRIBUTE.LAYOUT_BG_TYPE] = "type_1",
        [W_MODULE.ATTRIBUTE.LAYOUT_COLUMN_BG_TYPE] = "type_1",
        [W_MODULE.ATTRIBUTE.COLUMN_HEIGHT_TYPE] = "large",
        [W_MODULE.ATTRIBUTE.ROW_COUNT] = MAX_LEVEL_EFFECT_COUNT,
        [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = true,
        [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = "text_large",
        [W_MODULE.ATTRIBUTE.USE_RADIO_GROUP] = true,
        [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
          {
            [W_MODULE.ATTRIBUTE.WIDTH] = localeLayoutInfo.equipSlotReinforce.effectChangeDlg.columnWidth1,
            [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("equip_slot_reinforce_set_effect_set_title"),
            [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW
          },
          {
            [W_MODULE.ATTRIBUTE.WIDTH] = localeLayoutInfo.equipSlotReinforce.effectChangeDlg.columnWidth2,
            [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("equip_slot_reinforce_possible_change"),
            [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
            [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
              subItem.possibleImg = subItem:CreateImageDrawable(TEXTURE_PATH.DEFAULT, "overlay")
              subItem.possibleImg:AddAnchor("CENTER", subItem, 0, 0)
            end,
            [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
              subItem.possibleImg:SetVisible(data.value ~= 0)
              if data.changeable then
                subItem.possibleImg:SetTextureInfo("common_o", "blue")
              else
                subItem.possibleImg:SetTextureInfo("common_x", "red")
              end
            end
          }
        }
      })
      wnd:RegisterStack(listCtrl)
      function listCtrl:Satisfy()
        return initSelected
      end
      warrningTextBox = W_MODULE:Create("warrningTextBox", wnd, W_MODULE.TYPES.TEXTBOX, {
        [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("equip_slot_reinforce_window_level_effect_info_help_msg"),
        type = "warning"
      })
      wnd:RegisterStack(warrningTextBox)
      function wnd:OkProc()
        local selectedData, rowData = listCtrl:GetDataPartially(W_MODULE.ATTRIBUTE.RADIO_SELECTED_DATA)
        if selectedData == nil then
          return
        end
        X2EquipSlotReinforce:ChangeLevelEffect(selectedEquipSlot, selectedData)
      end
    end
    X2DialogManager:RequestDialog(DialogEquipSlotReinforceLevelEffectChangeHandler, window:GetId())
  end
  ButtonOnClickHandler(changeBtn, ChangeBtnLeftClickFunc)
  local detailBtn = effectTitlebox:CreateChildWidget("button", "detailBtn", 0, false)
  detailBtn:AddAnchor("RIGHT", changeBtn, "LEFT", -3, 0)
  detailBtn:SetStyle("search_mini")
  local function CreateDetailWindow()
    local detailWindow = CreateWindow("detailWindow", window)
    detailWindow:SetExtent(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_300), 430)
    detailWindow:AddAnchor("TOPLEFT", window, 0, 0)
    detailWindow:SetTitle(X2Locale:LocalizeUiText(COMMON_TEXT, "equip_slot_reinforce_window_level_effect_info_title"))
    detailWindow:RegisterStack(W_MODULE:Create("infoDesc", detailWindow, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("equip_slot_reinforce_window_level_effect_info_desc")
    }))
    local listCtrlWidth = detailWindow:GetWidth() - 80
    local levelEffectListCtrl = W_MODULE:Create("levelEffectListCtrl", detailWindow, W_MODULE.TYPES.LISTCTRL, nil, {
      [W_MODULE.ATTRIBUTE.HAS_SCROLL] = true,
      [W_MODULE.ATTRIBUTE.LAYOUT_BG_TYPE] = "type_1",
      [W_MODULE.ATTRIBUTE.ROW_COUNT] = 10,
      [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = true,
      [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = "text_small",
      [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
        {
          [W_MODULE.ATTRIBUTE.TEXT] = "",
          [W_MODULE.ATTRIBUTE.WIDTH] = listCtrlWidth * 4604480259023595110,
          [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_TEXTBOX,
          [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
            subItem.style:SetAlign(ALIGN_LEFT)
            subItem.style:SetColorByKey("default")
            subItem.style:SetEllipsis(true)
            local function OnEnter(self)
              local text = self:GetText()
              if subItem:GetWidth() > self.style:GetTextWidth(text) then
                return
              end
              SetTooltip(text, self)
            end
            subItem:SetHandler("OnEnter", OnEnter)
          end,
          [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
            if data ~= nil then
              if data.attributeKey == "" then
                subItem:SetText(F_TEXT.GetEquipReinforceLevelString(data.value))
              else
                local attributeStr = locale.attribute(data.attributeKey)
                subItem:SetText(attributeStr)
              end
            else
              subItem:SetText("")
            end
          end
        },
        {
          [W_MODULE.ATTRIBUTE.TEXT] = "",
          [W_MODULE.ATTRIBUTE.WIDTH] = listCtrlWidth * 4599075939470750515,
          [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_STRING,
          [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
            subItem.style:SetAlign(ALIGN_RIGHT)
            subItem.style:SetColorByKey("default")
          end,
          [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
            if data ~= nil then
              if data.attributeKey ~= "" then
                local valueStr = GetModifierCalcValue(data.attributeKey, data.value)
                subItem:SetText(valueStr)
              else
                subItem:SetText("")
              end
            else
              subItem:SetText("")
            end
          end
        }
      }
    })
    detailWindow:RegisterStack(levelEffectListCtrl)
    detailWindow:RegisterStack(W_MODULE:Create("levelEffectInfoHelpLabel", detailWindow, W_MODULE.TYPES.TEXTBOX, {
      [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("equip_slot_reinforce_window_level_effect_info_help_msg"),
      type = "warning"
    }))
    local noEffectTextbox = detailWindow:CreateChildWidget("textbox", "noEffectTextbox", 0, true)
    noEffectTextbox:SetWidth(listCtrlWidth - 10)
    noEffectTextbox:AddAnchor("CENTER", levelEffectListCtrl, "CENTER", -5, 0)
    noEffectTextbox:SetAutoResize(true)
    noEffectTextbox.style:SetColorByKey("red")
    noEffectTextbox:SetText(GetCommonText("equip_slot_reinforce_window_no_level_effect_info_msg"))
    noEffectTextbox:Show(false)
    local buttonSet = W_MODULE:Create("buttonSet", detailWindow, W_MODULE.TYPES.BUTTON_SET)
    buttonSet:AddButton("okBtn", {
      [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "ok"),
      [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
      clickFunc = function()
        detailWindow:Show(false)
      end
    })
    detailWindow:RegisterStack(buttonSet)
    detailWindow:ApplyAutoHeightByStack()
    function detailWindow:FillData(equipSlot)
      local info = X2EquipSlotReinforce:GetLevelEffectInfoByEquipSlot(equipSlot)
      levelEffectListCtrl:SetData({
        [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
        [W_MODULE.ATTRIBUTE.DATA] = info
      })
      noEffectTextbox:Show(not (#info > 0))
    end
    return detailWindow
  end
  local detailWindow = CreateDetailWindow()
  local function DetailBtnLeftClickFunc()
    if detailWindow:IsVisible() then
      return
    end
    detailWindow:FillData(selectedEquipSlot)
    detailWindow:Show(true)
    detailWindow:Raise()
  end
  ButtonOnClickHandler(detailBtn, DetailBtnLeftClickFunc)
  local function CreateEffectItem(index)
    local item = effectTitlebox:CreateChildWidget("label", "item", index, true)
    item.style:SetAlign(ALIGN_LEFT)
    item.style:SetEllipsis(true)
    local offset = 5
    local icon = item:CreateDrawable(EQUIP_SLOT_REINFORCE_ELSE_TEXTURE_PATH, "icon_special_bg", "background")
    icon:AddAnchor("LEFT", item, 0, 0)
    local iconInset = icon:GetWidth() + 5
    item:SetInset(iconInset, 0, 0, 0)
    item:SetExtent(contentWidth - icon:GetWidth() - offset, FONT_SIZE.MIDDLE)
    function item:SetInfo(str, on)
      self:SetText(str)
      local colorKey = on and "default" or "gray"
      self.style:SetColorByKey(colorKey)
      local textureKey = on and "icon_special" or "icon_special_bg"
      icon:SetTextureInfo(textureKey)
    end
    F_TEXT.ApplyAutoEllipsisTooltipText(item, iconInset)
    return item
  end
  for i = 1, MAX_LEVEL_EFFECT_COUNT do
    local item = CreateEffectItem(i)
    effectTitlebox:AddBody(item)
  end
  window:RegisterStack(effectTitlebox)
  local materialSatisfy = false
  local materialTitlebox = W_MODULE:Create("materialTitlebox", window, W_MODULE.TYPES.TITLE_BOX, {
    title = GetUIText(COMMON_TEXT, "equip_slot_reinforce_window_resource"),
    [W_MODULE.ATTRIBUTE.GUIDE_TOOLTIP] = GetCommonText("equip_slot_reinforce_window_help_msg")
  })
  local filterSection = materialTitlebox:CreateChildWidget("emptywidget", "filterSection", 0, false)
  local offset = 3
  local openIngameShopBtn = CreateEmptyButton("openIngameShopBtn", filterSection)
  openIngameShopBtn:AddAnchor("TOPRIGHT", filterSection, 0, 0)
  ApplyButtonSkin(openIngameShopBtn, {
    drawableType = "drawable",
    path = EQUIP_SLOT_REINFORCE_ELSE_TEXTURE_PATH,
    coordsKey = "list_cash"
  })
  local function CashShopBtnLeftClickFunc()
    local data = {
      mainTabId = localeDataInfo.ingameshopInfo.mainTabIndex,
      subTabId = localeDataInfo.ingameshopInfo.subTabIndex
    }
    ADDON:ShowContent(UIC_INGAME_SHOP, true, data)
  end
  ButtonOnClickHandler(openIngameShopBtn, CashShopBtnLeftClickFunc)
  local filter = W_CTRL.CreateComboBox("filter", filterSection)
  filter:AddAnchor("RIGHT", openIngameShopBtn, "LEFT", -offset, 0)
  filter:SetWidth(contentWidth - openIngameShopBtn:GetWidth() - offset)
  filterSection:SetExtent(contentWidth, openIngameShopBtn:GetHeight())
  materialTitlebox:AddBody(filterSection)
  local materials = materialTitlebox:AddModule("materials", W_MODULE.TYPES.ICON_GROUP, {
    emptyIconShow = true,
    maxIconCount = 7,
    newLineCount = 7,
    iconSize = F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_48),
    iconType = "constant"
  })
  window:RegisterStack(materialTitlebox)
  function materialTitlebox:Satisfy()
    return materialSatisfy and not IsFullExp()
  end
  local cost = W_MODULE:Create("cost", window, W_MODULE.TYPES.VALUE_BOX, {
    [W_MODULE.ATTRIBUTE.TYPE] = "cost",
    [W_MODULE.ATTRIBUTE.VALUE] = 0
  })
  window:RegisterStack(cost)
  local buttonSet = W_MODULE:Create("buttonSet", window, W_MODULE.TYPES.BUTTON_SET)
  local selectedMaterialType
  buttonSet:AddButton("ok", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "ok"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    enable = false,
    clickFunc = function()
      if IsFullExp() then
        return
      end
      X2EquipSlotReinforce:StartReinforceAddExp(selectedEquipSlot, selectedMaterialType)
    end
  })
  buttonSet:AddButton("cancel", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "cancel"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    enable = true,
    clickFunc = function()
      if X2EquipSlotReinforce:IsWorkingAddExp() then
        X2EquipSlotReinforce:StopCasting()
      else
        window:Show(false)
      end
    end
  })
  window:RegisterOkButton(buttonSet:GetButton("ok"))
  window:RegisterStack(buttonSet)
  window:ApplyAutoHeightByStack()
  local isMaxLevel = false
  local function FillSlot(equipSlot, reinforceInfo)
    levelTextbox:SetText(F_TEXT.GetEquipReinforceLevelString(reinforceInfo.level, false))
    F_SLOT.ApplySlotSkin(slotIcon, slotIcon.back, SLOT_STYLE.EQUIP_ITEM[equipSlot])
    slotIcon:Init()
    local attributeType = X2EquipSlotReinforce:GetAttributeType(equipSlot)
    headerTable:UpdateRow(partRowKey, {
      title = {
        string = GetSlotText(equipSlot)
      },
      value = {
        string = GetAttibuteText(attributeType),
        colorKey = GetEquipSlotReinforceAttibuteTextColor(attributeType)
      }
    })
    isMaxLevel = reinforceInfo.isMaxLevel
    if not isMaxLevel then
      local totalExp = reinforceInfo.totalExp
      addExpGauge:SetMinMaxValues(0, totalExp)
      expGauge:SetMinMaxValues(0, totalExp)
      expGauge:SetValue(reinforceInfo.exp)
      addExpGauge:Show(true)
      expGauge:Show(true)
      maxLevelLabel:Show(false)
      levelupBtn:Enable(IsFullExp())
      levelupBtn:Show(true)
    else
      addExpGauge:Show(false)
      expGauge:Show(false)
      maxLevelLabel:Show(true)
      levelupBtn:Show(false)
    end
  end
  local function FillEffect(equipSlot)
    local info = X2EquipSlotReinforce:GetLevelEffectChangeUIInfo(equipSlot)
    if info == nil then
      return
    end
    local changeableCount = 0
    local deactiveEffectCount = 0
    for i = 1, MAX_LEVEL_EFFECT_COUNT do
      local levelEffect = info.levelEffectList[i]
      if levelEffect ~= nil then
        if levelEffect.attributeType ~= nil then
          if levelEffect.isChangeable then
            changeableCount = changeableCount + 1
          end
          local str = string.format("%s %s", locale.attribute(levelEffect.attributeType), GetModifierCalcValue(levelEffect.attributeType, levelEffect.value))
          effectTitlebox.item[i]:SetInfo(str, true)
        else
          local str = GetUIText(COMMON_TEXT, "equip_slot_reinforce_level_effect_not_ready", tostring(levelEffect.triggerLevel))
          effectTitlebox.item[i]:SetInfo(str, false)
          deactiveEffectCount = deactiveEffectCount + 1
        end
      else
        effectTitlebox.item[i]:SetInfo(GetCommonText("none"), false)
      end
    end
    changeBtn:Enable(changeableCount > 0)
    detailBtn:Enable(changeableCount > 0 or deactiveEffectCount > 0)
  end
  local materialInfo
  local filterSelectedIndex = 0
  local function FillMaterial(equipSlot, level)
    filter:Clear()
    materialInfo = X2EquipSlotReinforce:GetMaterialInfo(equipSlot, level)
    if materialInfo == nil or #materialInfo == 0 or isMaxLevel then
      openIngameShopBtn:Enable(false)
      local data = materials:GetData()
      data.iconInfo = {}
      materials:SetData(data)
      materialSatisfy = false
      local costData = cost:GetData()
      costData[W_MODULE.ATTRIBUTE.VALUE] = 0
      cost:SetData(costData)
      headerTable:UpdateRow(expRowKey, {
        value = {string = "-"}
      })
      window:ApplyOkButtonEnablement()
      return
    end
    if filterSelectedIndex == 0 then
      filterSelectedIndex = 1
    end
    local datas = {}
    for i = 1, #materialInfo do
      local data = {
        text = materialInfo[i].name,
        value = i,
        color = materialInfo[i].hasCashItem and F_COLOR.GetColor("rose_pink") or F_COLOR.GetColor("default")
      }
      table.insert(datas, data)
    end
    filter:AppendItems(datas, false)
    filter:Select(filterSelectedIndex)
    levelupBtn:Enable(IsFullExp())
  end
  function filter:SelectedProc(index)
    local curMaterialInfo = materialInfo[index]
    if curMaterialInfo == nil then
      return
    end
    local itemList = curMaterialInfo.itemList
    materialSatisfy = true
    local enableCashBtn = false
    filterSelectedIndex = index
    local data = materials:GetData()
    data.iconInfo = {}
    for i = 1, #itemList do
      local hasCount = X2Bag:GetCountInBag(itemList[i].item.itemType)
      local needCount = itemList[i].count
      data.iconInfo[i] = {
        info = itemList[i].item,
        stack = {hasCount, needCount}
      }
      if materialSatisfy ~= false and hasCount < needCount then
        materialSatisfy = false
      end
      if enableCashBtn == false and X2EquipSlotReinforce:IsInGameShopItemTag(itemList[i].item.itemType) then
        enableCashBtn = true
      end
    end
    materials:SetData(data)
    openIngameShopBtn:Enable(enableCashBtn)
    local costData = cost:GetData()
    costData[W_MODULE.ATTRIBUTE.CURRENCY] = curMaterialInfo.currency
    costData[W_MODULE.ATTRIBUTE.VALUE] = curMaterialInfo.currencyValue
    cost:SetData(costData)
    local curExp = materialInfo.curExp
    local totalExp = materialInfo.totalExp
    local addedExp = curExp + curMaterialInfo.gainExp
    if totalExp < addedExp then
      addedExp = totalExp
    end
    if not isMaxLevel then
      addExpGauge:SetValue(addedExp)
    end
    headerTable:UpdateRow(expRowKey, {
      value = {
        string = tostring(addedExp - curExp)
      }
    })
    selectedMaterialType = curMaterialInfo.materialType
    window:ApplyOkButtonEnablement()
  end
  local function InitFilterSelctedIndex()
    filterSelectedIndex = 0
  end
  function window:SetEquipSlot(equipSlot)
    if selectedEquipSlot ~= equipSlot then
      InitFilterSelctedIndex()
    end
    local reinforceInfo = X2EquipSlotReinforce:GetReinforceInfo(equipSlot)
    if reinforceInfo == nil then
      return
    end
    selectedEquipSlot = equipSlot
    FillSlot(equipSlot, reinforceInfo)
    FillEffect(equipSlot)
    FillMaterial(equipSlot, reinforceInfo.level)
    if detailWindow:IsVisible() then
      detailWindow:FillData(selectedEquipSlot)
    end
  end
  local events = {
    EQUIP_SLOT_REINFORCE_MSG_LEVEL_UP = function(equipSlot)
      InitFilterSelctedIndex()
    end
  }
  window:SetHandler("OnEvent", function(this, event, ...)
    events[event](...)
  end)
  RegistUIEvent(window, events)
  return window
end
