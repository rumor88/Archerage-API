function CreateEquipSlotReinforceEffectWindow(parent)
  local window = CreateWindow("equipSlotReinforce_effect_title", parent)
  window:SetExtent(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_430), 350)
  window:AddAnchor("TOPLEFT", parent, "TOPRIGHT", 5, 30)
  window:SetTitle(GetUIText(COMMON_TEXT, "equip_slot_reinforce_effect_title"))
  local headerTable = W_MODULE:Create("headerTable", window, W_MODULE.TYPES.HEADER_TABLE_A, {
    [W_MODULE.ATTRIBUTE.LEFT_WIDTH_PRESET] = "large"
  })
  window:RegisterStack(headerTable)
  local rowKey = "grade"
  headerTable:AddRow(rowKey, {
    title = {
      string = GetUIText(COMMON_TEXT, "equip_slot_reinforce_all_level")
    }
  })
  local tabNames = {
    GetUIText(TOOLTIP_TEXT, "set"),
    GetUIText(COMMON_TEXT, "special")
  }
  local contentWidth = window:GetWidth() - MARGIN.WINDOW_SIDE * 2
  local tab = W_TAB.CreateTab("tab", window)
  tab:AddTabs(tabNames)
  tab:RemoveAllAnchors()
  window:RegisterStack(tab, 15)
  local listCtrlWidth = contentWidth - 25
  local rowCount = 8
  local listCtrlOffset = 10
  local listCtrlHeight = 0
  local ColumnLayoutFunc = function(subItem, row, listCtrl)
    subItem.style:SetAlign(ALIGN_LEFT)
    subItem.style:SetColorByKey("default")
    subItem.style:SetEllipsis(true)
    local function OnEnter(self)
      local text = self:GetText()
      if subItem:GetWidth() > self.style:GetTextWidth(text) then
        return
      end
      SetTooltip(text, self)
    end
    subItem:SetHandler("OnEnter", OnEnter)
  end
  local listCtrlCommonInfo = {
    [W_MODULE.ATTRIBUTE.HAS_SCROLL] = true,
    [W_MODULE.ATTRIBUTE.COLUMN_HEIGHT_TYPE] = nil,
    [W_MODULE.ATTRIBUTE.ROW_COUNT] = rowCount,
    [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = true,
    [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = "text_small"
  }
  local function CreateSetTab(tabWindow)
    local info = listCtrlCommonInfo
    info[W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = listCtrlWidth,
        [W_MODULE.ATTRIBUTE.TEXT] = "",
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_STRING,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = ColumnLayoutFunc,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data then
            subItem:SetText(tostring(data))
          else
            subItem:SetText("")
          end
        end
      }
    }
    local listCtrl = W_MODULE:Create("grade", tabWindow, W_MODULE.TYPES.LISTCTRL, nil, info)
    listCtrl:AddAnchor("TOP", tabWindow, 0, listCtrlOffset)
    listCtrlHeight = listCtrl:GetHeight()
    function tabWindow:Update()
      local data
      if X2Player:GetFeatureSet().equipSlotBundleEffect == true then
        data = X2EquipSlotReinforce:GetAppliedAllBundleEffect()
      else
        data = X2EquipSlotReinforce:GetAppliedAllSetEffect()
      end
      listCtrl:SetData({
        [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
        [W_MODULE.ATTRIBUTE.DATA] = data
      })
    end
  end
  local function CreateSpecialTab(tabWindow)
    local info = listCtrlCommonInfo
    info[W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = listCtrlWidth * 4604480259023595110,
        [W_MODULE.ATTRIBUTE.TEXT] = "",
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_STRING,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = ColumnLayoutFunc,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data then
            subItem:SetText(tostring(locale.attribute(data.attributeType)))
          else
            subItem:SetText("")
          end
        end
      },
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = listCtrlWidth * 4599075939470750515,
        [W_MODULE.ATTRIBUTE.TEXT] = "",
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_STRING,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
          subItem.style:SetAlign(ALIGN_RIGHT)
          subItem.style:SetColorByKey("default")
        end,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data then
            subItem:SetText(tostring(GetModifierCalcValue(data.attributeType, data.value)))
          else
            subItem:SetText("")
          end
        end
      }
    }
    local listCtrl = W_MODULE:Create("listCtrl", tabWindow, W_MODULE.TYPES.LISTCTRL, nil, info)
    listCtrl:AddAnchor("TOP", tabWindow, 0, listCtrlOffset)
    function tabWindow:Update()
      listCtrl:SetData({
        [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
        [W_MODULE.ATTRIBUTE.DATA] = X2EquipSlotReinforce:GetAppliedAllLevelEffect()
      })
    end
  end
  CreateSetTab(tab.window[1])
  CreateSpecialTab(tab.window[2])
  tab:SetExtent(contentWidth, listCtrlHeight + tab:GetTabButtonHeight() + listCtrlOffset)
  function tab:OnTabChangedProc(selected)
    tab.window[selected]:Update()
  end
  function window:ShowProc()
    headerTable:UpdateRow(rowKey, {
      value = {
        string = F_TEXT.GetEquipReinforceLevelString(X2EquipSlotReinforce:GetTotalReinforceLevel())
      }
    })
    for i, v in ipairs(tab.window) do
      v:Update()
    end
  end
  local buttonSet = W_MODULE:Create("buttonSet", window, W_MODULE.TYPES.BUTTON_SET)
  buttonSet:AddButton("okBtn", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "ok"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    clickFunc = function()
      window:Show(false)
    end
  })
  window:RegisterStack(buttonSet)
  window:ApplyAutoHeightByStack()
  return window
end
