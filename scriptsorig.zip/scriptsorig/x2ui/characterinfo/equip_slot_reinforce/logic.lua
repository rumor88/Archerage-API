function CreateEquipSlotReinforceWindow(parent)
  local reinForceWnd = SetViewOfEquipSlotReinforceWindow(parent)
  local function ShowMsgChangeLevelEffect(levelEffectInfo)
    local function DialogHandler(wnd)
      wnd:SetTitle(GetCommonText("equip_slot_reinforce_msg_change_level_effect_title"))
      local itemIcon = CreateIconButton("itemIcon", wnd)
      F_SLOT.ApplySlotSkin(itemIcon, itemIcon.back, SLOT_STYLE.EQUIP_ITEM[levelEffectInfo.equipSlot])
      itemIcon:SetForceVisible(true)
      itemIcon:Init()
      wnd:RegisterStack(itemIcon)
      local slotName = itemIcon:CreateChildWidget("label", "slotName", 0, false)
      slotName:SetHeight(FONT_SIZE.MIDDLE)
      slotName:SetAutoResize(true)
      slotName.style:SetColorByKey("default")
      slotName:SetText(GetSlotText(levelEffectInfo.equipSlot))
      wnd:RegisterStack(slotName, MARGIN.WINDOW_SIDE / 2)
      local gettedHeaderTable = W_MODULE:Create("changeTable", wnd, W_MODULE.TYPES.HEADER_TABLE_A, {
        [W_MODULE.ATTRIBUTE.LEFT_WIDTH_PRESET] = "middle"
      })
      wnd:RegisterStack(gettedHeaderTable, MARGIN.WINDOW_SIDE / 2)
      local preLevelEffectInfo = levelEffectInfo.preEffectInfo
      local curLevelEffectInfo = levelEffectInfo.curEffectInfo
      if preLevelEffectInfo ~= nil and curLevelEffectInfo ~= nil then
        gettedHeaderTable:AddRow("before", {
          title = {
            string = GetCommonText("evolving_dialog_before_attr_title")
          },
          value = {
            string = string.format("%s %s", locale.attribute(preLevelEffectInfo.attributeType), GetModifierCalcValue(preLevelEffectInfo.attributeType, preLevelEffectInfo.value))
          }
        })
        gettedHeaderTable:AddRow("after", {
          title = {
            string = GetCommonText("evolving_dialog_after_attr_title")
          },
          value = {
            string = string.format("%s %s", locale.attribute(curLevelEffectInfo.attributeType), GetModifierCalcValue(curLevelEffectInfo.attributeType, curLevelEffectInfo.value)),
            colorKey = "blue"
          }
        })
      end
    end
    X2DialogManager:RequestDialog(DialogHandler, reinForceWnd:GetParent():GetId(), {buttonType = DBT_OK})
  end
  local function UpdateSetEffectIconInfo(attributeType, index, visible)
    local coordiKey = ""
    if attributeType == ESRA_DEFENCE then
      coordiKey = "shield"
    elseif attributeType == ESRA_OFFENCE then
      coordiKey = "attack"
    else
      coordiKey = "support"
    end
    local topLevel = X2EquipSlotReinforce:GetSetEffectTopLevel(attributeType)
    local convertedLevel = topLevel
    if convertedLevel <= 0 then
      convertedLevel = 1
    end
    reinForceWnd.setEffect[attributeType].bgImg:SetTextureInfo(string.format("set_bg_%d", convertedLevel), "default")
    reinForceWnd.setEffect[attributeType].icon:SetTextureInfo(string.format("set_%s_%d", coordiKey, convertedLevel))
    local levelStr = GetUIText(TOOLTIP_TEXT, "set_effect")
    if topLevel >= 1 then
      levelStr = string.format("%s %d", levelStr, tostring(topLevel))
    end
    reinForceWnd.setEffect[attributeType].label:SetText(levelStr)
  end
  local function InitEquipSlotReinforceSetEffect()
    for i = ESRA_OFFENCE, ESRA_MAX - 1 do
      UpdateSetEffectIconInfo(i)
    end
  end
  local function ToggleReinForceMode(isReinForceMode)
    if X2Player:GetFeatureSet().equipSlotEnchantment ~= nil and X2Player:GetFeatureSet().equipSlotEnchantment == false then
      return
    end
    if isReinForceMode == nil then
      isReinForceMode = false
    end
    if X2Player:GetFeatureSet().equipSlotBundleEffect == false and isReinForceMode == true then
      InitEquipSlotReinforceSetEffect()
    end
    if X2EquipSlotReinforce:SuitableLevelForEquipSlotReinforce() == true then
      ToggleEquipSlotReinForceBtnShow(not isReinForceMode)
    else
      ToggleEquipSlotReinForceBtnShow(false)
    end
    ToggleEquippedItemSlotShow(not isReinForceMode)
    if isReinForceMode == false and reinForceWnd.bundleEffect ~= nil then
      reinForceWnd.bundleEffect:Show(false)
    end
    reinForceWnd:Show(isReinForceMode)
    reinForceWnd.popup:Show(false)
    if X2Player:GetFeatureSet().equipSlotBundleEffect == false then
      for i = ESRA_OFFENCE, ESRA_MAX - 1 do
        reinForceWnd.setEffect[i].window:Show(isReinForceMode)
      end
    end
  end
  local function UpdateEquipSlotReinforceSlot(equipSlot)
    local info = X2EquipSlotReinforce:GetReinforceInfo(equipSlot)
    if info == nil then
      return
    end
    local level = info.level
    local exp = info.exp
    local totalExp = info.totalExp
    reinForceWnd.slot[equipSlot].levelLabel:SetText(string.format(level))
    reinForceWnd.slot[equipSlot].bonusExpGuage:SetMinMaxValues(0, totalExp)
    reinForceWnd.slot[equipSlot].bonusExpGuage:SetValue(exp)
    local MAX_LEVEL_EFFECT_COUNT = 3
    local maxStep = X2EquipSlotReinforce:GetLevelEffectStep(equipSlot)
    for i = 1, MAX_LEVEL_EFFECT_COUNT do
      local textureKey
      if i > maxStep then
        textureKey = "icon_special_bg_small"
      else
        textureKey = "icon_special_small"
      end
      reinForceWnd.slot[equipSlot].levelEffectStepIcon[i]:SetTextureInfo(textureKey)
    end
  end
  local function InitEquipSlotReinforce()
    ToggleReinForceMode(false)
    for k, v in pairs(reinForceWnd.slot) do
      local index = v.index
      UpdateEquipSlotReinforceSlot(index)
    end
  end
  function HideReinForceMode()
    ToggleReinForceMode(false)
  end
  if parent ~= nil then
    if parent.equipSlotReinforceBtn.reinforce ~= nil then
      local function RefinforceBtnLeftClickFunc()
        ToggleReinForceMode(false)
      end
      ButtonOnClickHandler(parent.equipSlotReinforceBtn.reinforce, RefinforceBtnLeftClickFunc)
    end
    if parent.equipSlotReinforceBtn.equip ~= nil then
      local function EquipBtnLeftClickFunc()
        ToggleReinForceMode(true)
      end
      ButtonOnClickHandler(parent.equipSlotReinforceBtn.equip, EquipBtnLeftClickFunc)
    end
    if parent.equipSlotReinforceBtn.bundleEffect ~= nil then
      local function BundleEffectBtnLeftClickFunc()
        reinForceWnd:ShowBundleEffectWindows()
      end
      ButtonOnClickHandler(parent.equipSlotReinforceBtn.bundleEffect, BundleEffectBtnLeftClickFunc)
    end
  end
  local reinforceWmdEvents = {
    EQUIP_SLOT_REINFORCE_UPDATE = function(equipSlot)
      UpdateEquipSlotReinforceSlot(equipSlot)
      reinForceWnd:UpdateEquipSlotReinforceWindow(equipSlot)
      reinForceWnd:UpdateBundleEffectWindows()
      parent.equipSlotReinforceBtn.UpdateBundleInfo()
    end,
    EQUIP_SLOT_REINFORCE_MSG_CHAGNE_LEVEL_EFFECT = function(levelEffectInfo)
      ShowMsgChangeLevelEffect(levelEffectInfo)
    end,
    REMOVED_ITEM = function()
      reinForceWnd:UpdateEquipSlotReinforceWindow(reinForceWnd:GetSelectedEquipSlot())
      reinForceWnd:UpdateBundleEffectWindows()
    end,
    EQUIP_SLOT_REINFORCE_SELECT_PAGE = function()
      InitEquipSlotReinforce()
    end
  }
  reinForceWnd:SetHandler("OnEvent", function(this, event, ...)
    reinforceWmdEvents[event](...)
  end)
  RegistUIEvent(reinForceWnd, reinforceWmdEvents)
  InitEquipSlotReinforce()
end
