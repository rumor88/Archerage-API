function SetViewOfEquipSlotReinforceWindow(parent)
  local selected_equip_slot = 0
  local EQUIP_SLOT_REINFORCE_TEXTURE_PATH = "ui/character/slot_enchant.dds"
  local EQUIP_SLOT_REINFORCE_IMG_INFO = {
    SLOT_BG_OFFENCE = {
      drawableType = "drawable",
      path = EQUIP_SLOT_REINFORCE_TEXTURE_PATH,
      coordsKey = "slot_bg_attack",
      colorKey = "default"
    },
    SLOT_BG_DEFENCE = {
      drawableType = "drawable",
      path = EQUIP_SLOT_REINFORCE_TEXTURE_PATH,
      coordsKey = "slot_bg_shield",
      colorKey = "default"
    },
    SLOT_BG_SUPPORT = {
      drawableType = "drawable",
      path = EQUIP_SLOT_REINFORCE_TEXTURE_PATH,
      coordsKey = "slot_bg_support",
      colorKey = "default"
    }
  }
  local equip_slot_reinforce_window = CreateEmptyWindow("equip_slot_reinforce_window", "UIParent")
  equip_slot_reinforce_window:AddAnchor("TOP", "UIParent", "TOP", 0, (UIParent:GetScreenHeight() - 440 - 60) * 4602678819172646912)
  equip_slot_reinforce_window.leftSlots = CreateEmptyWindow("equip_slot_reinforce_window.leftSlots", equip_slot_reinforce_window)
  equip_slot_reinforce_window.leftSlots:Show(true)
  equip_slot_reinforce_window.leftSlots:SetExtent(ICON_SIZE.DEFAULT, 401)
  equip_slot_reinforce_window.leftSlots:AddAnchor("TOPLEFT", equip_slot_reinforce_window, "TOP", -200, 0)
  equip_slot_reinforce_window.rightSlots = CreateEmptyWindow("equip_slot_reinforce_window.rightSlots", equip_slot_reinforce_window)
  equip_slot_reinforce_window.rightSlots:Show(true)
  equip_slot_reinforce_window.rightSlots:SetExtent(ICON_SIZE.DEFAULT, 443)
  equip_slot_reinforce_window.rightSlots:AddAnchor("TOPRIGHT", equip_slot_reinforce_window, "TOP", 200, 0)
  equip_slot_reinforce_window.slot = {}
  equip_slot_reinforce_window.setEffect = {}
  local IsFullExp = function(equipSlot)
    return X2EquipSlotReinforce:IsFullExp(equipSlot) > 0
  end
  local function SetTooltipReinforceInfo(target, equipSlot)
    local function CreateGuideToolip()
      local tooltip = CreateEmptyWindow(string.format("tooltipReinforceSlot[%d]", equipSlot), equip_slot_reinforce_window)
      tooltip:SetExtent(230, 145)
      tooltip:SetUILayer("tooltip")
      CreateTooltipDrawable(tooltip)
      tooltip:Show(true)
      tooltip.equipSlot = equipSlot
      local equipSlotLabel = tooltip:CreateChildWidget("label", "equipSlotLabel", 0, true)
      equipSlotLabel:SetExtent(tooltip:GetWidth(), 20)
      equipSlotLabel.style:SetFontSize(FONT_SIZE.LARGE)
      equipSlotLabel.style:SetAlign(ALIGN_LEFT)
      equipSlotLabel.style:SetColorByKey("soft_brown")
      equipSlotLabel:SetText(GetSlotText(equipSlot))
      equipSlotLabel:AddAnchor("TOPLEFT", tooltip, "TOPLEFT", 15, 5)
      local attributeLabel = tooltip:CreateChildWidget("label", "equipSlotAttributeLabel", 0, true)
      attributeLabel:SetExtent(tooltip:GetWidth() / 2, 20)
      attributeLabel.style:SetFontSize(FONT_SIZE.LARGE)
      attributeLabel.style:SetAlign(ALIGN_RIGHT)
      attributeLabel:AddAnchor("TOPRIGHT", tooltip, "TOPRIGHT", -15, 5)
      local reinforceLevel = tooltip:CreateChildWidget("textbox", "reinforceLevel", 0, false)
      reinforceLevel:SetExtent(tooltip:GetWidth() / 2, 20)
      reinforceLevel.style:SetAlign(ALIGN_RIGHT)
      reinforceLevel.style:SetFontSize(FONT_SIZE.MIDDLE)
      reinforceLevel:AddAnchor("TOPRIGHT", attributeLabel, "BOTTOMRIGHT", 0, 2)
      local line = CreateLine(tooltip, "TYPE1")
      line:AddAnchor("TOPLEFT", equipSlotLabel, "BOTTOMLEFT", -15, 25)
      line:AddAnchor("TOPRIGHT", equipSlotLabel, "BOTTOMRIGHT", -15, 25)
      local reinforceExpLabel = tooltip:CreateChildWidget("label", "reinforceExpLabel", 0, false)
      reinforceExpLabel:SetExtent(tooltip:GetWidth(), 20)
      reinforceExpLabel.style:SetFontSize(FONT_SIZE.MIDDLE)
      reinforceExpLabel.style:SetAlign(ALIGN_LEFT)
      reinforceExpLabel.style:SetColorByKey("soft_brown")
      reinforceExpLabel:AddAnchor("TOPLEFT", line, "BOTTOMLEFT", 15, 5)
      local line2 = CreateLine(tooltip, "TYPE1")
      line2:AddAnchor("TOPLEFT", reinforceExpLabel, "BOTTOMLEFT", -15, 5)
      line2:AddAnchor("TOPRIGHT", reinforceExpLabel, "BOTTOMRIGHT", -15, 5)
      local reinforceCurEffectLabel = tooltip:CreateChildWidget("label", "reinforceCurEffectLabel", 0, false)
      reinforceCurEffectLabel:SetExtent(tooltip:GetWidth() / 2, 20)
      reinforceCurEffectLabel.style:SetFontSize(FONT_SIZE.MIDDLE)
      reinforceCurEffectLabel.style:SetAlign(ALIGN_LEFT)
      reinforceCurEffectLabel.style:SetColorByKey("soft_brown")
      reinforceCurEffectLabel:AddAnchor("TOPLEFT", line2, "BOTTOMLEFT", 15, 5)
      reinforceCurEffectLabel:SetText(GetUIText(COMMON_TEXT, "equip_slot_reinforce_cur_effect_label"))
      local reinforceCurEffectValueLabel = tooltip:CreateChildWidget("textbox", "reinforceCurEffectValueLabel", 0, false)
      reinforceCurEffectValueLabel:SetExtent(tooltip:GetWidth() / 2, 20)
      reinforceCurEffectValueLabel.style:SetFontSize(FONT_SIZE.MIDDLE)
      reinforceCurEffectValueLabel.style:SetAlign(ALIGN_LEFT)
      reinforceCurEffectValueLabel:AddAnchor("TOPLEFT", reinforceCurEffectLabel, "BOTTOMLEFT", 5, 0)
      local reinforceNextEffectLabel = tooltip:CreateChildWidget("label", "reinforceNextEffectLabel", 0, false)
      reinforceNextEffectLabel:SetExtent(tooltip:GetWidth(), 20)
      reinforceNextEffectLabel.style:SetFontSize(FONT_SIZE.MIDDLE)
      reinforceNextEffectLabel.style:SetAlign(ALIGN_LEFT)
      reinforceNextEffectLabel.style:SetColorByKey("soft_brown")
      reinforceNextEffectLabel:AddAnchor("TOPLEFT", reinforceCurEffectValueLabel, "BOTTOMLEFT", -5, 5)
      reinforceNextEffectLabel:SetText(GetUIText(COMMON_TEXT, "equip_slot_reinforce_next_effect_label"))
      reinforceNextEffectLabel:Show(false)
      local reinforceNextEffectValueLabel = tooltip:CreateChildWidget("textbox", "reinforceNextEffectValueLabel", 0, false)
      reinforceNextEffectValueLabel:SetExtent(tooltip:GetWidth(), 20)
      reinforceNextEffectValueLabel.style:SetFontSize(FONT_SIZE.MIDDLE)
      reinforceNextEffectValueLabel.style:SetAlign(ALIGN_LEFT)
      reinforceNextEffectValueLabel:AddAnchor("TOPLEFT", reinforceNextEffectLabel, "BOTTOMLEFT", 5, 0)
      reinforceNextEffectValueLabel:Show(false)
      local function UpdateTooltip(equipSlot)
        local reinforceInfo = X2EquipSlotReinforce:GetReinforceInfo(equipSlot)
        if reinforceInfo == nil then
          return
        end
        local attributeType = X2EquipSlotReinforce:GetAttributeType(equipSlot)
        local attributeStr = GetAttibuteText(attributeType)
        local totalExp = reinforceInfo.totalExp
        if totalExp < 1 then
          totalExp = 1
        end
        attributeLabel:SetText(attributeStr)
        attributeLabel.style:SetColorByKey(GetEquipSlotReinforceAttibuteTextColor(attributeType))
        reinforceLevel:SetText(F_TEXT.GetEquipReinforceLevelString(reinforceInfo.level, true))
        reinforceCurEffectValueLabel:SetText(string.format("%s%s %s%s", F_COLOR.GetColor("green", true), GetUIText(COMMON_TEXT, "equip_slot_reinforce_effect_label"), F_COLOR.GetColor("medium_yellow", true), tostring(reinforceInfo.level)))
        if X2EquipSlotReinforce:EnableLevelUp(equipSlot) == true then
          tooltip:SetExtent(230, 190)
          reinforceNextEffectValueLabel:SetText(string.format("%s%s %s%s", F_COLOR.GetColor("green", true), GetUIText(COMMON_TEXT, "equip_slot_reinforce_effect_label"), F_COLOR.GetColor("medium_yellow", true), tostring(reinforceInfo.level + 1)))
          reinforceExpLabel:SetText(GetUIText(COMMON_TEXT, "equip_slot_reinforce_exp", tostring(reinforceInfo.exp), tostring(totalExp), string.format("%.2f", reinforceInfo.exp / totalExp * 100)))
          reinforceNextEffectLabel:Show(true)
          reinforceNextEffectValueLabel:Show(true)
        else
          reinforceExpLabel:SetText(GetUIText(COMMON_TEXT, "equip_slot_reinforce_max_level"))
          tooltip:SetExtent(230, 145)
          reinforceNextEffectLabel:Show(false)
          reinforceNextEffectValueLabel:Show(false)
        end
      end
      function tooltip:UpdateInfo()
        UpdateTooltip(self.equipSlot)
      end
      UpdateTooltip(equipSlot)
      return tooltip
    end
    local function OnEnter(self)
      if target.tooltip == nil then
        target.tooltip = CreateGuideToolip(self)
      else
        target.tooltip:UpdateInfo()
        target.tooltip:Show(true)
      end
      SetDefaultTooltipAnchor(target, target.tooltip)
    end
    target:SetHandler("OnEnter", OnEnter)
    local function OnLeave()
      target.tooltip:Show(false)
    end
    target:SetHandler("OnLeave", OnLeave)
  end
  local function SetTooltipSetEffectInfo(target, attributeType)
    local function CreateGuideToolip()
      local tooltip = CreateEmptyWindow(string.format("tooltipSetEffect[%d]", attributeType), equip_slot_reinforce_window)
      tooltip:Show(true)
      tooltip:SetExtent(260, 276)
      tooltip:SetUILayer("tooltip")
      CreateTooltipDrawable(tooltip)
      tooltip.attributeType = attributeType
      local offsetHeight = 4
      local sectionWidth = tooltip:GetWidth() - 30
      local dafaultInfoSection = tooltip:CreateChildWidget("emptywidget", "dafaultInfoSection", 0, true)
      dafaultInfoSection:SetExtent(sectionWidth, 50)
      dafaultInfoSection:AddAnchor("TOPLEFT", tooltip, "TOPLEFT", 15, 15)
      local defaultInfotitle = dafaultInfoSection:CreateChildWidget("label", "default_info", 0, true)
      defaultInfotitle:SetHeight(FONT_SIZE.MIDDLE)
      defaultInfotitle:SetWidth(sectionWidth)
      defaultInfotitle:SetText(GetUIText(COMMON_TEXT, "equip_slot_reinforce_set_effect_default_info_title"))
      defaultInfotitle.style:SetAlign(ALIGN_LEFT)
      defaultInfotitle:AddAnchor("TOPLEFT", dafaultInfoSection, 0, 0)
      defaultInfotitle.style:SetColorByKey("soft_yellow")
      local labelAttribute = dafaultInfoSection:CreateChildWidget("label", "attr", 0, true)
      labelAttribute:SetAutoResize(true)
      labelAttribute:SetHeight(FONT_SIZE.MIDDLE)
      labelAttribute:SetText(GetUIText(COMMON_TEXT, "equip_slot_reinforce_set_effect_default_info_attribute"))
      labelAttribute.style:SetAlign(ALIGN_LEFT)
      labelAttribute:AddAnchor("TOPLEFT", defaultInfotitle, "BOTTOMLEFT", 5, offsetHeight)
      labelAttribute.style:SetColorByKey("soft_brown")
      local labelAttributeStr = dafaultInfoSection:CreateChildWidget("label", "attr_str", 0, true)
      labelAttribute:SetAutoResize(true)
      labelAttributeStr:SetHeight(FONT_SIZE.MIDDLE)
      labelAttributeStr:SetText(GetAttibuteText(attributeType))
      labelAttributeStr.style:SetAlign(ALIGN_RIGHT)
      labelAttributeStr:AddAnchor("TOPRIGHT", defaultInfotitle, "BOTTOMRIGHT", 0, offsetHeight)
      labelAttributeStr.style:SetColorByKey(GetEquipSlotReinforceAttibuteTextColor(attributeType))
      local labelLevel = dafaultInfoSection:CreateChildWidget("label", "level", 0, true)
      labelAttribute:SetAutoResize(true)
      labelLevel:SetHeight(FONT_SIZE.MIDDLE)
      labelLevel:SetText(GetUIText(COMMON_TEXT, "equip_slot_reinforce_set_effect_default_info_level"))
      labelLevel.style:SetAlign(ALIGN_LEFT)
      labelLevel:AddAnchor("TOPLEFT", labelAttribute, "BOTTOMLEFT", 0, offsetHeight)
      labelLevel.style:SetColorByKey("soft_brown")
      local setLevel = X2EquipSlotReinforce:GetSetEffectTopLevel(attributeType)
      local setLevelStr = GetUIText(COMMON_TEXT, "equip_slot_reinforce_set_effect_default_info_nothing")
      if setLevel > 0 then
        setLevelStr = tostring(setLevel)
      end
      local labelLevelStr = dafaultInfoSection:CreateChildWidget("label", "level_str", 0, true)
      labelAttribute:SetAutoResize(true)
      labelLevelStr:SetHeight(FONT_SIZE.MIDDLE)
      labelLevelStr:SetText(setLevelStr)
      labelLevelStr.style:SetAlign(ALIGN_RIGHT)
      labelLevelStr:AddAnchor("TOPRIGHT", labelAttributeStr, "BOTTOMRIGHT", 0, offsetHeight)
      labelLevelStr.style:SetColorByKey("soft_brown")
      local line = CreateLine(tooltip, "TYPE1")
      line:AddAnchor("TOPLEFT", dafaultInfoSection, "BOTTOMLEFT", -15, 5)
      line:AddAnchor("TOPRIGHT", dafaultInfoSection, "BOTTOMRIGHT", -15, 5)
      local levelInfoSection = tooltip:CreateChildWidget("emptywidget", "levelInfoSection", 0, true)
      levelInfoSection:SetExtent(sectionWidth, 60)
      levelInfoSection:AddAnchor("TOPLEFT", line, "BOTTOMLEFT", 15, offsetHeight)
      local levelInfotitle = levelInfoSection:CreateChildWidget("label", "level_info", 0, true)
      levelInfotitle:SetHeight(FONT_SIZE.MIDDLE)
      levelInfotitle:SetWidth(sectionWidth)
      levelInfotitle:SetText(GetUIText(COMMON_TEXT, "equip_slot_reinforce_set_effect_level_info_title"))
      levelInfotitle.style:SetAlign(ALIGN_LEFT)
      levelInfotitle:AddAnchor("TOPLEFT", levelInfoSection, 0, 0)
      levelInfotitle.style:SetColorByKey("soft_yellow")
      local labelCurrentLevel = levelInfoSection:CreateChildWidget("label", "cur_level", 0, true)
      labelCurrentLevel:SetAutoResize(true)
      labelCurrentLevel:SetHeight(FONT_SIZE.MIDDLE)
      labelCurrentLevel:SetText(GetUIText(COMMON_TEXT, "equip_slot_reinforce_set_effect_level_info_current"))
      labelCurrentLevel.style:SetAlign(ALIGN_LEFT)
      labelCurrentLevel:AddAnchor("TOPLEFT", levelInfotitle, "BOTTOMLEFT", 5, offsetHeight)
      labelCurrentLevel.style:SetColorByKey("soft_brown")
      local icon = levelInfoSection:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "icon_equip_slot_star_small", "background")
      icon:AddAnchor("TOPLEFT", labelCurrentLevel, "TOPRIGHT", 2, 0)
      local labelCurrentLevelStr = levelInfoSection:CreateChildWidget("textbox", "cur_level_str", 0, true)
      labelCurrentLevelStr:SetHeight(FONT_SIZE.MIDDLE)
      labelCurrentLevelStr:SetWidth(40)
      labelCurrentLevelStr.style:SetFontSize(FONT_SIZE.MIDDLE)
      labelCurrentLevelStr.style:SetAlign(ALIGN_RIGHT)
      labelCurrentLevelStr:AddAnchor("TOPRIGHT", levelInfotitle, "BOTTOMRIGHT", 0, offsetHeight)
      labelCurrentLevelStr.style:SetColorByKey("soft_brown")
      local labelNextLevel = levelInfoSection:CreateChildWidget("label", "next_level", 0, true)
      labelNextLevel:SetAutoResize(true)
      labelNextLevel:SetHeight(FONT_SIZE.MIDDLE)
      labelNextLevel:AddAnchor("TOPLEFT", labelCurrentLevel, "BOTTOMLEFT", 0, offsetHeight)
      labelNextLevel.style:SetColorByKey("soft_brown")
      local icon2 = levelInfoSection:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "icon_equip_slot_star_small", "background")
      icon2:AddAnchor("TOPLEFT", labelNextLevel, "TOPRIGHT", 2, 0)
      icon2:Show(false)
      local labelNextLevelStr = levelInfoSection:CreateChildWidget("textbox", "next_level_str", 0, true)
      labelNextLevelStr:SetWidth(40)
      labelNextLevelStr:SetHeight(FONT_SIZE.MIDDLE)
      labelNextLevelStr.style:SetFontSize(FONT_SIZE.MIDDLE)
      labelNextLevelStr.style:SetAlign(ALIGN_RIGHT)
      labelNextLevelStr:AddAnchor("TOPRIGHT", labelCurrentLevelStr, "BOTTOMRIGHT", 0, offsetHeight)
      labelNextLevelStr.style:SetColorByKey("soft_brown")
      labelNextLevelStr:Show(false)
      local labelLevelDesc = levelInfoSection:CreateChildWidget("textbox", "level_desc", 0, true)
      labelLevelDesc:SetWidth(sectionWidth)
      labelLevelDesc:SetHeight(FONT_SIZE.MIDDLE)
      labelLevelDesc.style:SetFontSize(FONT_SIZE.SMALL)
      labelLevelDesc:SetText(GetUIText(COMMON_TEXT, "equip_slot_reinforce_set_effect_level_info_desc"))
      labelLevelDesc.style:SetAlign(ALIGN_LEFT)
      labelLevelDesc:AddAnchor("TOPLEFT", labelNextLevel, "BOTTOMLEFT", -5, offsetHeight)
      labelLevelDesc.style:SetColorByKey("medium_yellow")
      local line2 = CreateLine(tooltip, "TYPE1")
      line2:AddAnchor("TOPLEFT", levelInfoSection, "BOTTOMLEFT", -15, 5)
      line2:AddAnchor("TOPRIGHT", levelInfoSection, "BOTTOMRIGHT", -15, 5)
      local setEffectsSection = tooltip:CreateChildWidget("emptywidget", "setEffectsSection", 0, true)
      setEffectsSection:SetExtent(sectionWidth, 140)
      setEffectsSection:AddAnchor("TOPLEFT", line2, "BOTTOMLEFT", 15, offsetHeight)
      local setEffectDescLabels = {}
      local setEffects = X2EquipSlotReinforce:GetSetEffects(attributeType)
      if setEffects ~= nil then
        local setEffectsTitle = setEffectsSection:CreateChildWidget("label", "effect_title", 0, true)
        setEffectsTitle:SetHeight(FONT_SIZE.MIDDLE)
        setEffectsTitle:SetWidth(sectionWidth)
        setEffectsTitle:SetText(GetUIText(COMMON_TEXT, "equip_slot_reinforce_set_effect_set_title"))
        setEffectsTitle.style:SetAlign(ALIGN_LEFT)
        setEffectsTitle:AddAnchor("TOPLEFT", setEffectsSection, 0, offsetHeight)
        setEffectsTitle.style:SetColorByKey("soft_yellow")
        local anchorHeight = offsetHeight
        for i = 1, #setEffects do
          local info = setEffects[i]
          local setEffectLevelLabel = setEffectsSection:CreateChildWidget("textbox", "setEffectLevel", i, false)
          setEffectLevelLabel:SetWidth(sectionWidth)
          setEffectLevelLabel:SetHeight(FONT_SIZE.MIDDLE)
          setEffectLevelLabel.style:SetAlign(ALIGN_LEFT)
          setEffectLevelLabel:AddAnchor("TOPLEFT", setEffectsTitle, "BOTTOMLEFT", 5, anchorHeight)
          setEffectLevelLabel.style:SetColorByKey("soft_brown")
          setEffectLevelLabel:SetText(GetUIText(COMMON_TEXT, "equip_slot_reinforce_set_effect_set_desc", tostring(info.step), tostring(info.requiredLevel)))
          local setEffectDescLabel = setEffectsSection:CreateChildWidget("label", "setEffectDesc", i, false)
          setEffectDescLabel:SetExtent(sectionWidth, FONT_SIZE.MIDDLE)
          setEffectDescLabels[i] = setEffectDescLabel
          local len = setEffectDescLabel.style:GetTextWidth(info.desc)
          local offset = math.floor(len / sectionWidth)
          tooltip:SetExtent(tooltip:GetWidth(), tooltip:GetHeight() + FONT_SIZE.MIDDLE * offset)
          setEffectDescLabel:SetAutoResize(true)
          setEffectDescLabel.style:SetAlign(ALIGN_LEFT)
          setEffectDescLabel:AddAnchor("TOPLEFT", setEffectLevelLabel, "BOTTOMLEFT", 0, 0)
          if info.enable == true then
            setEffectDescLabel.style:SetColorByKey("green")
          else
            setEffectDescLabel.style:SetColorByKey("default_gray")
          end
          setEffectDescLabel:SetText(info.desc)
          anchorHeight = anchorHeight + setEffectLevelLabel:GetHeight() + setEffectDescLabel:GetHeight() + offsetHeight
        end
      end
      local function UpdateTooltip(attributeType)
        local setLevel = X2EquipSlotReinforce:GetSetEffectTopLevel(attributeType)
        local setLevelStr = GetUIText(COMMON_TEXT, "equip_slot_reinforce_set_effect_default_info_nothing")
        if setLevel > 0 then
          setLevelStr = tostring(setLevel)
        end
        labelLevelStr:SetText(setLevelStr)
        labelCurrentLevelStr:SetText(F_TEXT.GetEquipReinforceLevelString(X2EquipSlotReinforce:GetAttributeTotalLevel(attributeType), true))
        if X2EquipSlotReinforce:HasNextSetEffect(attributeType) then
          labelNextLevel:SetText(GetUIText(COMMON_TEXT, "equip_slot_reinforce_set_effect_level_info_next_level"))
          labelNextLevelStr:SetText(F_TEXT.GetEquipReinforceLevelString(X2EquipSlotReinforce:GetNextSetApplyLevel(attributeType), true))
          icon2:Show(true)
          labelNextLevelStr:Show(true)
        else
          labelNextLevel:SetText(GetUIText(COMMON_TEXT, "equip_slot_reinforce_set_effect_max_level"))
          icon2:Show(false)
          labelNextLevelStr:Show(false)
        end
        local setEffects = X2EquipSlotReinforce:GetSetEffects(attributeType)
        for i = 1, #setEffects do
          local info = setEffects[i]
          local setEffectDescLabel = setEffectDescLabels[i]
          if info.enable == true then
            setEffectDescLabel.style:SetColorByKey("green")
          else
            setEffectDescLabel.style:SetColorByKey("default_gray")
          end
        end
      end
      function tooltip:UpdateInfo()
        UpdateTooltip(self.attributeType)
      end
      UpdateTooltip(attributeType)
      return tooltip
    end
    local function OnEnter(self)
      if target.tooltip == nil then
        target.tooltip = CreateGuideToolip()
      else
        target.tooltip:UpdateInfo()
        target.tooltip:Show(true)
      end
      SetDefaultTooltipAnchor(target, target.tooltip)
    end
    target:SetHandler("OnEnter", OnEnter)
    local function OnLeave()
      if target.tooltip ~= nil then
        target.tooltip:Show(false)
      end
    end
    target:SetHandler("OnLeave", OnLeave)
  end
  local infoWindow = CreateEquipSlotReinforceInfoWindow("infoWindow", equip_slot_reinforce_window)
  infoWindow:AddAnchor("TOPLEFT", equip_slot_reinforce_window, 5, 30)
  local function ShowReinforceWindow(equipSlot)
    if infoWindow:IsVisible() == false then
      infoWindow:Show(true)
      infoWindow:Raise()
    end
    infoWindow:SetEquipSlot(equipSlot)
    selected_equip_slot = equipSlot
  end
  local function CreateReinforceSlot(isLeftFlip, i, excludeReinforceSlotList)
    local GetSignConvert = function(isConvert, value)
      if isConvert == true then
        return -value
      else
        return value
      end
    end
    for index = 1, #excludeReinforceSlotList do
      if i == excludeReinforceSlotList[index] then
        return
      end
    end
    local parent = isLeftFlip and equip_slot_reinforce_window.leftSlots or equip_slot_reinforce_window.rightSlots
    local reinforceParent = CreateEmptyWindow(string.format("slot[%d]", i), parent)
    reinforceParent:SetExtent(96, 45)
    reinforceParent:Show(true)
    equip_slot_reinforce_window.slot[i] = reinforceParent
    equip_slot_reinforce_window.slot[i].index = i
    local imgInfo
    local attributeType = X2EquipSlotReinforce:GetAttributeType(i)
    if attributeType == ESRA_OFFENCE then
      imgInfo = EQUIP_SLOT_REINFORCE_IMG_INFO.SLOT_BG_OFFENCE
    elseif attributeType == ESRA_DEFENCE then
      imgInfo = EQUIP_SLOT_REINFORCE_IMG_INFO.SLOT_BG_DEFENCE
    else
      imgInfo = EQUIP_SLOT_REINFORCE_IMG_INFO.SLOT_BG_SUPPORT
    end
    local reinforceInfoBg = reinforceParent:CreateDrawable(EQUIP_SLOT_REINFORCE_TEXTURE_PATH, imgInfo.coordsKey, "background")
    reinforceInfoBg:SetTextureColor(imgInfo.colorKey)
    equip_slot_reinforce_window.slot[i].view = reinforceInfoBg
    local button = CreateIconButton(string.format("slotBtn[%d]", i), parent, "constant")
    button:RegisterForClicks("LeftButton")
    button:EnableDrag(false)
    button:SetForceVisible(true)
    F_SLOT.ApplySlotSkin(button, button.back, SLOT_STYLE.EQUIP_ITEM[i])
    button:Init()
    equip_slot_reinforce_window.slot[i].btn = button
    local function ReinforceBtnLeftClickFunc()
      ShowReinforceWindow(i)
    end
    ButtonOnClickHandler(button, ReinforceBtnLeftClickFunc)
    local levelEffectStepIcon2 = button:CreateDrawable(EQUIP_SLOT_REINFORCE_TEXTURE_PATH, "icon_special_bg_small", "background")
    levelEffectStepIcon2:AddAnchor("CENTER", button, "CENTER", -1, 15)
    local levelEffectStepIcon1 = button:CreateDrawable(EQUIP_SLOT_REINFORCE_TEXTURE_PATH, "icon_special_small", "background")
    levelEffectStepIcon1:AddAnchor("TOPRIGHT", levelEffectStepIcon2, "TOPLEFT", -3, 0)
    local levelEffectStepIcon3 = button:CreateDrawable(EQUIP_SLOT_REINFORCE_TEXTURE_PATH, "icon_special_bg_small", "background")
    levelEffectStepIcon3:AddAnchor("TOPLEFT", levelEffectStepIcon2, "TOPRIGHT", 3, 0)
    equip_slot_reinforce_window.slot[i].levelEffectStepIcon = {}
    equip_slot_reinforce_window.slot[i].levelEffectStepIcon[1] = levelEffectStepIcon1
    equip_slot_reinforce_window.slot[i].levelEffectStepIcon[2] = levelEffectStepIcon2
    equip_slot_reinforce_window.slot[i].levelEffectStepIcon[3] = levelEffectStepIcon3
    local reinforceExp = W_BAR.CreateStatusBar("reinforceExp", reinforceParent, "equip_slot_reinforce")
    reinforceExp:SetWidth(46)
    reinforceExp:SetMinMaxValues(0, 150)
    reinforceExp:SetValue(100)
    reinforceExp:SetBarColorByKey("default")
    equip_slot_reinforce_window.slot[i].bonusExpGuage = reinforceExp
    local levelIcon = reinforceParent:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "icon_equip_slot_star", "background")
    local levelLabel = reinforceParent:CreateChildWidget("textbox", "levelLabel", 0, false)
    levelLabel:SetExtent(30, FONT_SIZE.MIDDLE)
    levelLabel:SetAutoResize(true)
    levelLabel:SetHeight(15)
    levelLabel.style:SetFontSize(FONT_SIZE.LARGE)
    levelLabel:SetText(F_TEXT.GetEquipReinforceLevelString(i))
    levelLabel.style:SetColorByKey("medium_yellow")
    levelLabel.style:SetAlign(ALIGN_LEFT)
    equip_slot_reinforce_window.slot[i].levelLabel = levelLabel
    button:AddAnchor(GetFlipAnchor(isLeftFlip, "TOPLEFT"), reinforceParent, 0, 0)
    reinforceInfoBg:AddAnchor(GetFlipAnchor(isLeftFlip, "TOPLEFT"), button, GetSignConvert(isLeftFlip, -2), -2)
    reinforceExp:AddAnchor(GetFlipAnchor(isLeftFlip, "TOPLEFT"), reinforceInfoBg, GetSignConvert(isLeftFlip, 45), 38)
    if isLeftFlip then
      levelIcon:AddAnchor("TOPLEFT", reinforceInfoBg, "TOPLEFT", 11, 19)
    else
      levelIcon:AddAnchor("TOPLEFT", reinforceInfoBg, "TOPLEFT", 45, 19)
    end
    levelLabel:AddAnchor("LEFT", levelIcon, "RIGHT", 2, 0)
    SetTooltipReinforceInfo(equip_slot_reinforce_window.slot[i].btn, i)
  end
  local CreateReinforceDetailBtn = function(parent)
    local detailBtn = CreateEmptyButton("equippedItem.equipSlotReinforceBtn.detail", parent)
    detailBtn:Show(true)
    detailBtn:RegisterForClicks("LeftButton")
    detailBtn:EnableDrag(false)
    detailBtn:SetStyle("character_search")
    detailBtn:AddAnchor("TOPRIGHT", parent.equipSlotReinforceBtn.equip, "TOPRIGHT", 34, 26)
    parent.equipSlotReinforceBtn.detailBtn = detailBtn
    local DetailBtnLeftClickFunc = function()
      ADDON:ToggleContent(UIC_EQUIP_SLOT_REINFORCE_TAB)
    end
    ButtonOnClickHandler(parent.equipSlotReinforceBtn.detailBtn, DetailBtnLeftClickFunc)
  end
  local function CreateReinforceSetEffectWindow(parent, attributeType)
    equip_slot_reinforce_window.setEffect[attributeType] = {}
    local window = CreateEmptyWindow(string.format("setEffect[%d]", attributeType), parent)
    window:Show(true)
    equip_slot_reinforce_window.setEffect[attributeType].window = window
    local setEffectBg = window:CreateDrawable(EQUIP_SLOT_REINFORCE_TEXTURE_PATH, "set_bg_1", "background")
    setEffectBg:SetTextureColor("default")
    equip_slot_reinforce_window.setEffect[attributeType].bgImg = setEffectBg
    window:SetExtent(setEffectBg:GetWidth(), setEffectBg:GetHeight())
    setEffectBg:AddAnchor("TOPLEFT", window, 0, 0)
    local setEffectIcon = window:CreateDrawable(EQUIP_SLOT_REINFORCE_TEXTURE_PATH, "set_shield_1", "background")
    setEffectIcon:AddAnchor("TOPLEFT", window, 0, 0)
    window:SetExtent(setEffectIcon:GetWidth(), setEffectIcon:GetHeight())
    equip_slot_reinforce_window.setEffect[attributeType].icon = setEffectIcon
    local setEffectLabel = window:CreateChildWidget("textbox", "setEffectLabel", 0, false)
    setEffectLabel:SetExtent(window:GetWidth(), FONT_SIZE.SMALL)
    setEffectLabel:SetAutoResize(true)
    setEffectLabel:SetHeight(15)
    setEffectLabel.style:SetFontSize(FONT_SIZE.SMALL)
    setEffectLabel.style:SetColorByKey("light_gray")
    setEffectLabel:AddAnchor("TOPLEFT", window, 0, 61)
    equip_slot_reinforce_window.setEffect[attributeType].label = setEffectLabel
    SetTooltipSetEffectInfo(equip_slot_reinforce_window.setEffect[attributeType].window, attributeType)
  end
  local function CreateEquipSlotReinforceBundleEffectWindow()
    local window = CreateWindow("equip_slot_reinforce_bundle_effect", equip_slot_reinforce_window)
    window:SetExtent(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_450), 10)
    window:AddAnchor("TOPLEFT", equip_slot_reinforce_window, "TOPRIGHT", 5, 30)
    window:SetTitle(X2Locale:LocalizeUiText(COMMON_TEXT, "equip_slot_reinforce_bundle_effect_title"))
    window:Show(false)
    equip_slot_reinforce_window.bundleEffect = window
    local scrollList = W_MODULE:Create("listCtrl", window, W_MODULE.TYPES.LISTCTRL, nil, {
      [W_MODULE.ATTRIBUTE.HAS_SCROLL] = true,
      [W_MODULE.ATTRIBUTE.COLUMN_HEIGHT_TYPE] = "large",
      [W_MODULE.ATTRIBUTE.LAYOUT_BG_TYPE] = "type_1",
      [W_MODULE.ATTRIBUTE.LAYOUT_COLUMN_BG_TYPE] = "type_1",
      [W_MODULE.ATTRIBUTE.ROW_COUNT] = 3,
      [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = true,
      [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = 83,
      [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
        {
          [W_MODULE.ATTRIBUTE.WIDTH] = 74,
          [W_MODULE.ATTRIBUTE.TEXT] = X2Locale:LocalizeUiText(COMMON_TEXT, "equip_slot_reinforce_bundle_effect_step"),
          [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
          [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
            local selectedBg = subItem:CreateDrawable(TEXTURE_PATH.TAB_LIST, "enchant_info_bg", "background")
            selectedBg:SetTextureColor("listctrl_overed_red")
            selectedBg:AddAnchor("TOPLEFT", subItem, "TOPLEFT", -10, 0)
            selectedBg:AddAnchor("BOTTOMRIGHT", subItem, "BOTTOMRIGHT", 300, 0)
            selectedBg:Show(false)
            subItem.selectedBg = selectedBg
            local bundleEffectLevelBg = subItem:CreateDrawable(EQUIP_SLOT_REINFORCE_TEXTURE_PATH, "set_eff_mark", "background")
            bundleEffectLevelBg:AddAnchor("TOP", subItem, "TOP", 0, 10)
            bundleEffectLevelBg:Show(false)
            subItem.bundleEffectLevelBg = bundleEffectLevelBg
            local bundleEffectLevelImage = subItem:CreateDrawable(EQUIP_SLOT_REINFORCE_TEXTURE_PATH, "num_01", "background")
            bundleEffectLevelImage:AddAnchor("CENTER", bundleEffectLevelBg, "CENTER", 0, 0)
            bundleEffectLevelImage:Show(false)
            subItem.bundleEffectLevelImage = bundleEffectLevelImage
            local bundleEffectLevelLabel = subItem:CreateChildWidget("label", "bundleEffectLevelLabel", 0, true)
            bundleEffectLevelLabel:SetExtent(subItem:GetWidth(), FONT_SIZE.MIDDLE)
            bundleEffectLevelLabel:AddAnchor("BOTTOM", subItem, "BOTTOM", 0, -10)
            bundleEffectLevelLabel.style:SetAlign(ALIGN_CENTER)
            bundleEffectLevelLabel.style:SetColorByKey("default")
            bundleEffectLevelLabel:Show(false)
            subItem.bundleEffectLevelLabel = bundleEffectLevelLabel
          end,
          [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
            local colors = {
              nil,
              "green",
              "blue"
            }
            local myBundleEffectLevel = X2EquipSlotReinforce:GetBundleEffectTopLevel()
            if data ~= nil then
              subItem.bundleEffectLevelLabel:Show(true)
              subItem.bundleEffectLevelLabel:SetText(X2Locale:LocalizeUiText(COMMON_TEXT, "equip_slot_reinforce_bundle_effect_level", tostring(data.level)))
              if data.level == myBundleEffectLevel then
                subItem.selectedBg:Show(true)
                subItem.bundleEffectLevelBg:Show(true)
                subItem.bundleEffectLevelImage:Show(true)
                subItem.bundleEffectLevelImage:SetTextureInfo(string.format("num_0%d", myBundleEffectLevel))
                subItem.bundleEffectLevelLabel:RemoveAllAnchors()
                subItem.bundleEffectLevelLabel:AddAnchor("BOTTOM", subItem, "BOTTOM", 0, -10)
                if colors[myBundleEffectLevel] ~= nil then
                  subItem.bundleEffectLevelBg:SetTextureColor(colors[myBundleEffectLevel])
                end
              else
                subItem.selectedBg:Show(false)
                subItem.bundleEffectLevelBg:Show(false)
                subItem.bundleEffectLevelImage:Show(false)
                subItem.bundleEffectLevelLabel:RemoveAllAnchors()
                subItem.bundleEffectLevelLabel:AddAnchor("CENTER", subItem, "CENTER", 0, 0)
              end
            else
              subItem.selectedBg:Show(false)
              subItem.bundleEffectLevelBg:Show(false)
              subItem.bundleEffectLevelLabel:Show(false)
            end
          end
        },
        {
          [W_MODULE.ATTRIBUTE.WIDTH] = 292,
          [W_MODULE.ATTRIBUTE.TEXT] = X2Locale:LocalizeUiText(COMMON_TEXT, "equip_slot_reinforce_bundle_effect_desc"),
          [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
          [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
            local offsetX = 17
            local offsetY = 10
            local attributeValue1 = subItem:CreateChildWidget("label", "attributeValue1", 0, true)
            attributeValue1:AddAnchor("TOPRIGHT", subItem, "TOPRIGHT", 0, offsetY)
            attributeValue1:SetExtent(50, FONT_SIZE.MIDDLE)
            attributeValue1:SetAutoResize(true)
            attributeValue1.style:SetAlign(ALIGN_RIGHT)
            attributeValue1.style:SetColorByKey("green")
            attributeValue1:Show(false)
            local attributeName1 = subItem:CreateChildWidget("label", "attributeName1", 0, true)
            attributeName1:AddAnchor("TOPLEFT", subItem, "TOPLEFT", offsetX, offsetY)
            attributeName1:AddAnchor("BOTTOMRIGHT", attributeValue1, "BOTTOMLEFT", -offsetX, 0)
            attributeName1.style:SetAlign(ALIGN_LEFT)
            attributeName1.style:SetEllipsis(true)
            attributeName1.style:SetColorByKey("default")
            attributeName1:Show(false)
            local attributeValue2 = subItem:CreateChildWidget("label", "attributeValue2", 0, true)
            attributeValue2:AddAnchor("TOPRIGHT", attributeValue1, "BOTTOMRIGHT", 0, offsetY)
            attributeValue2:SetExtent(50, FONT_SIZE.MIDDLE)
            attributeValue2:SetAutoResize(true)
            attributeValue2.style:SetAlign(ALIGN_RIGHT)
            attributeValue2.style:SetColorByKey("green")
            attributeValue2:Show(false)
            local attributeName2 = subItem:CreateChildWidget("label", "attributeName2", 0, true)
            attributeName2:AddAnchor("TOPLEFT", attributeName1, "BOTTOMLEFT", 0, offsetY)
            attributeName2:AddAnchor("BOTTOMRIGHT", attributeValue2, "BOTTOMLEFT", -offsetX, 0)
            attributeName2.style:SetAlign(ALIGN_LEFT)
            attributeName2.style:SetEllipsis(true)
            attributeName2.style:SetColorByKey("default")
            attributeName2:Show(false)
            local attributeValue3 = subItem:CreateChildWidget("label", "attributeValue3", 0, true)
            attributeValue3:AddAnchor("TOPRIGHT", attributeValue2, "BOTTOMRIGHT", 0, offsetY)
            attributeValue3:SetExtent(50, FONT_SIZE.MIDDLE)
            attributeValue3:SetAutoResize(true)
            attributeValue3.style:SetAlign(ALIGN_RIGHT)
            attributeValue3.style:SetColorByKey("green")
            attributeValue3:Show(false)
            local attributeName3 = subItem:CreateChildWidget("label", "attributeName3", 0, true)
            attributeName3:AddAnchor("TOPLEFT", attributeName2, "BOTTOMLEFT", 0, offsetY)
            attributeName3:AddAnchor("BOTTOMRIGHT", attributeValue3, "BOTTOMLEFT", -offsetX, 0)
            attributeName3.style:SetAlign(ALIGN_LEFT)
            attributeName3.style:SetEllipsis(true)
            attributeName3.style:SetColorByKey("default")
            attributeName3:Show(false)
            subItem.attributesName = {}
            subItem.attributesValue = {}
            subItem.attributesName[1] = attributeName1
            subItem.attributesValue[1] = attributeValue1
            subItem.attributesName[2] = attributeName2
            subItem.attributesValue[2] = attributeValue2
            subItem.attributesName[3] = attributeName3
            subItem.attributesValue[3] = attributeValue3
          end,
          [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
            if data ~= nil then
              local unitModifierInfos = data.unitModifierInfos
              for i = 1, #unitModifierInfos do
                local unitModifierInfo = unitModifierInfos[i]
                local strPercent = ""
                if unitModifierInfo.unitModifierType == 1 then
                  strPercent = "%"
                end
                local myBundleEffectLevel = X2EquipSlotReinforce:GetBundleEffectTopLevel()
                if myBundleEffectLevel >= data.level then
                  subItem.attributesName[i].style:SetColorByKey("default")
                  subItem.attributesValue[i].style:SetColorByKey("green")
                else
                  subItem.attributesName[i].style:SetColorByKey("gray")
                  subItem.attributesValue[i].style:SetColorByKey("gray")
                end
                subItem.attributesName[i]:SetText(locale.attribute(unitModifierInfo.attributeType))
                subItem.attributesValue[i]:SetText(GetModifierCalcValue(locale.attribute(unitModifierInfo.attributeType), string.format("%s%s", unitModifierInfo.value, strPercent)))
                subItem.attributesName[i]:Show(true)
                subItem.attributesValue[i]:Show(true)
              end
            else
              for i = 1, #subItem.attributesName do
                subItem.attributesName[i]:SetText("")
                subItem.attributesValue[i]:SetText("")
                subItem.attributesName[i]:Show(false)
                subItem.attributesValue[i]:Show(false)
              end
            end
          end
        }
      }
    }, false)
    window:RegisterStack(scrollList)
    window.scrollList = scrollList
    local titleBox = W_MODULE:Create("titleBox", window, W_MODULE.TYPES.TITLE_BOX, {
      title = GetCommonText("equip_slot_reinforce_bundle_effect_condition"),
      [W_MODULE.ATTRIBUTE.GUIDE_TOOLTIP] = GetCommonText("equip_slot_reinforce_bundle_effect_guide")
    }, {
      [W_MODULE.ATTRIBUTE.BODY_INSET] = {
        10,
        10,
        10,
        10
      }
    })
    local bodyFrame = titleBox:CreateChildWidget("emptyWidget", "bodyFrame", 0, true)
    bodyFrame:SetHeight(250)
    titleBox:AddBody(bodyFrame)
    window:RegisterStack(titleBox)
    local attackLabel = window:CreateChildWidget("label", "attackLabel", 0, true)
    attackLabel:AddAnchor("TOPLEFT", bodyFrame, "TOPLEFT", 15, 5)
    attackLabel:SetExtent(50, FONT_SIZE.MIDDLE)
    attackLabel:SetAutoResize(true)
    attackLabel.style:SetColorByKey("default")
    attackLabel:SetText(GetCommonText("equip_slot_reinforce_bundle_effect_attack"))
    local attackStarImage = attackLabel:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "icon_equip_slot_star", "background")
    attackStarImage:AddAnchor("LEFT", attackLabel, "RIGHT", 5, 0)
    local attributeValue = {}
    local statusBar = {}
    local attackValue = window:CreateChildWidget("label", "attackValue", 0, true)
    attackValue:AddAnchor("LEFT", attackStarImage, "RIGHT", 1, 0)
    attackValue:SetExtent(50, FONT_SIZE.MIDDLE)
    attackValue:SetAutoResize(true)
    attackValue.style:SetColorByKey("default")
    attributeValue[ESRA_OFFENCE] = attackValue
    local attackBg = attackLabel:CreateDrawable(TEXTURE_PATH.DEFAULT, "common_bg", "background")
    attackBg:SetTextureColor("alpha40")
    attackBg:AddAnchor("TOPLEFT", attackLabel, "TOPLEFT", -15, -5)
    attackBg:AddAnchor("BOTTOMRIGHT", attackValue, "BOTTOMRIGHT", 15, 5)
    local attackStatusBar = W_BAR.CreateStatusBar("attackStatusBar", window, "craft")
    attackStatusBar:SetBarColorByKey("equip_slot_reinforce")
    attackStatusBar:SetWidth(390)
    attackStatusBar:AddAnchor("TOPLEFT", attackLabel, "BOTTOMLEFT", -15, 10)
    statusBar[ESRA_OFFENCE] = attackStatusBar
    local attackRequireImage1 = attackLabel:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "icon_equip_slot_star", "background")
    local attackRequireImage2 = attackLabel:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "icon_equip_slot_star", "background")
    local attackRequireImage3 = attackLabel:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "icon_equip_slot_star", "background")
    local attackNeedLevel1 = window:CreateChildWidget("label", "attackNeedLevel1", 0, true)
    attackNeedLevel1:AddAnchor("LEFT", attackRequireImage1, "RIGHT", 1, 0)
    attackNeedLevel1:SetExtent(50, FONT_SIZE.MIDDLE)
    attackNeedLevel1:SetAutoResize(true)
    attackNeedLevel1.style:SetColorByKey("default")
    local attackNeedLevel2 = window:CreateChildWidget("label", "attackNeedLevel2", 0, true)
    attackNeedLevel2:AddAnchor("LEFT", attackRequireImage2, "RIGHT", 1, 0)
    attackNeedLevel2:SetExtent(50, FONT_SIZE.MIDDLE)
    attackNeedLevel2:SetAutoResize(true)
    attackNeedLevel2.style:SetColorByKey("default")
    local attackNeedLevel3 = window:CreateChildWidget("label", "attackNeedLevel3", 0, true)
    attackNeedLevel3:AddAnchor("LEFT", attackRequireImage3, "RIGHT", 1, 0)
    attackNeedLevel3:SetExtent(50, FONT_SIZE.MIDDLE)
    attackNeedLevel3:SetAutoResize(true)
    attackNeedLevel3.style:SetColorByKey("default")
    statusBar[ESRA_OFFENCE].requireLevelImage = {}
    statusBar[ESRA_OFFENCE].requireLevelImage[1] = attackRequireImage1
    statusBar[ESRA_OFFENCE].requireLevelImage[2] = attackRequireImage2
    statusBar[ESRA_OFFENCE].requireLevelImage[3] = attackRequireImage3
    statusBar[ESRA_OFFENCE].requireLevel = {}
    statusBar[ESRA_OFFENCE].requireLevel[1] = attackNeedLevel1
    statusBar[ESRA_OFFENCE].requireLevel[2] = attackNeedLevel2
    statusBar[ESRA_OFFENCE].requireLevel[3] = attackNeedLevel3
    local line01 = attackLabel:CreateDrawable(TEXTURE_PATH.DEFAULT, "line_01", "background")
    line01:SetTextureColor("default")
    line01:AddAnchor("TOP", attackStatusBar, "BOTTOM", 0, attackRequireImage1:GetHeight() + 11)
    line01:SetWidth(390)
    local defenceLabel = window:CreateChildWidget("label", "defenceLabel", 0, true)
    defenceLabel:AddAnchor("TOPLEFT", line01, "BOTTOMLEFT", 15, 15)
    defenceLabel:SetExtent(50, FONT_SIZE.MIDDLE)
    defenceLabel:SetAutoResize(true)
    defenceLabel.style:SetColorByKey("default")
    defenceLabel:SetText(GetCommonText("equip_slot_reinforce_bundle_effect_defence"))
    local defenceStarImage = defenceLabel:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "icon_equip_slot_star", "background")
    defenceStarImage:AddAnchor("LEFT", defenceLabel, "RIGHT", 5, 0)
    local defenceValue = window:CreateChildWidget("label", "defenceValue", 0, true)
    defenceValue:AddAnchor("LEFT", defenceStarImage, "RIGHT", 1, 0)
    defenceValue:SetExtent(50, FONT_SIZE.MIDDLE)
    defenceValue:SetAutoResize(true)
    defenceValue.style:SetColorByKey("default")
    attributeValue[ESRA_DEFENCE] = defenceValue
    local defenceBg = defenceLabel:CreateDrawable(TEXTURE_PATH.DEFAULT, "common_bg", "background")
    defenceBg:SetTextureColor("alpha40")
    defenceBg:AddAnchor("TOPLEFT", defenceLabel, "TOPLEFT", -15, -5)
    defenceBg:AddAnchor("BOTTOMRIGHT", defenceValue, "BOTTOMRIGHT", 15, 5)
    local defenceStatusBar = W_BAR.CreateStatusBar("defenceStatusBar", window, "craft")
    defenceStatusBar:SetBarColorByKey("equip_slot_reinforce")
    defenceStatusBar:SetWidth(390)
    defenceStatusBar:AddAnchor("TOPLEFT", defenceLabel, "BOTTOMLEFT", -15, 10)
    statusBar[ESRA_DEFENCE] = defenceStatusBar
    local defenceRequireImage1 = defenceLabel:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "icon_equip_slot_star", "background")
    local defenceRequireImage2 = defenceLabel:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "icon_equip_slot_star", "background")
    local defenceRequireImage3 = defenceLabel:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "icon_equip_slot_star", "background")
    local defenceNeedLevel1 = window:CreateChildWidget("label", "defenceNeedLevel1", 0, true)
    defenceNeedLevel1:AddAnchor("LEFT", defenceRequireImage1, "RIGHT", 1, 0)
    defenceNeedLevel1:SetExtent(50, FONT_SIZE.MIDDLE)
    defenceNeedLevel1:SetAutoResize(true)
    defenceNeedLevel1.style:SetColorByKey("default")
    local defenceNeedLevel2 = window:CreateChildWidget("label", "defenceNeedLevel2", 0, true)
    defenceNeedLevel2:AddAnchor("LEFT", defenceRequireImage2, "RIGHT", 1, 0)
    defenceNeedLevel2:SetExtent(50, FONT_SIZE.MIDDLE)
    defenceNeedLevel2:SetAutoResize(true)
    defenceNeedLevel2.style:SetColorByKey("default")
    local defenceNeedLevel3 = window:CreateChildWidget("label", "defenceNeedLevel3", 0, true)
    defenceNeedLevel3:AddAnchor("LEFT", defenceRequireImage3, "RIGHT", 1, 0)
    defenceNeedLevel3:SetExtent(50, FONT_SIZE.MIDDLE)
    defenceNeedLevel3:SetAutoResize(true)
    defenceNeedLevel3.style:SetColorByKey("default")
    statusBar[ESRA_DEFENCE].requireLevelImage = {}
    statusBar[ESRA_DEFENCE].requireLevelImage[1] = defenceRequireImage1
    statusBar[ESRA_DEFENCE].requireLevelImage[2] = defenceRequireImage2
    statusBar[ESRA_DEFENCE].requireLevelImage[3] = defenceRequireImage3
    statusBar[ESRA_DEFENCE].requireLevel = {}
    statusBar[ESRA_DEFENCE].requireLevel[1] = defenceNeedLevel1
    statusBar[ESRA_DEFENCE].requireLevel[2] = defenceNeedLevel2
    statusBar[ESRA_DEFENCE].requireLevel[3] = defenceNeedLevel3
    local line02 = defenceLabel:CreateDrawable(TEXTURE_PATH.DEFAULT, "line_01", "background")
    line02:SetTextureColor("default")
    line02:AddAnchor("TOP", defenceStatusBar, "BOTTOM", 0, defenceRequireImage1:GetHeight() + 11)
    line02:SetWidth(390)
    local supportLabel = window:CreateChildWidget("label", "supportLabel", 0, true)
    supportLabel:AddAnchor("TOPLEFT", line02, "BOTTOMLEFT", 15, 15)
    supportLabel:SetExtent(50, FONT_SIZE.MIDDLE)
    supportLabel:SetAutoResize(true)
    supportLabel.style:SetColorByKey("default")
    supportLabel:SetText(GetCommonText("equip_slot_reinforce_bundle_effect_support"))
    local supportStarImage = supportLabel:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "icon_equip_slot_star", "background")
    supportStarImage:AddAnchor("LEFT", supportLabel, "RIGHT", 5, 0)
    local supportValue = window:CreateChildWidget("label", "supportValue", 0, true)
    supportValue:AddAnchor("LEFT", supportStarImage, "RIGHT", 1, 0)
    supportValue:SetExtent(50, FONT_SIZE.MIDDLE)
    supportValue:SetAutoResize(true)
    supportValue.style:SetColorByKey("default")
    attributeValue[ESRA_SUPPORT] = supportValue
    local supportBg = supportLabel:CreateDrawable(TEXTURE_PATH.DEFAULT, "common_bg", "background")
    supportBg:SetTextureColor("alpha40")
    supportBg:AddAnchor("TOPLEFT", supportLabel, "TOPLEFT", -15, -5)
    supportBg:AddAnchor("BOTTOMRIGHT", supportValue, "BOTTOMRIGHT", 15, 5)
    local supportStatusBar = W_BAR.CreateStatusBar("supportStatusBar", window, "craft")
    supportStatusBar:SetBarColorByKey("equip_slot_reinforce")
    supportStatusBar:SetWidth(390)
    supportStatusBar:AddAnchor("TOPLEFT", supportLabel, "BOTTOMLEFT", -15, 10)
    statusBar[ESRA_SUPPORT] = supportStatusBar
    local supportRequireImage1 = supportLabel:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "icon_equip_slot_star", "background")
    local supportRequireImage2 = supportLabel:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "icon_equip_slot_star", "background")
    local supportRequireImage3 = supportLabel:CreateDrawable(TEXTURE_PATH.MONEY_WINDOW, "icon_equip_slot_star", "background")
    local supportNeedLevel1 = window:CreateChildWidget("label", "supportNeedLevel1", 0, true)
    supportNeedLevel1:AddAnchor("LEFT", supportRequireImage1, "RIGHT", 1, 0)
    supportNeedLevel1:SetExtent(50, FONT_SIZE.MIDDLE)
    supportNeedLevel1:SetAutoResize(true)
    supportNeedLevel1.style:SetColorByKey("default")
    local supportNeedLevel2 = window:CreateChildWidget("label", "supportNeedLevel2", 0, true)
    supportNeedLevel2:AddAnchor("LEFT", supportRequireImage2, "RIGHT", 1, 0)
    supportNeedLevel2:SetExtent(50, FONT_SIZE.MIDDLE)
    supportNeedLevel2:SetAutoResize(true)
    supportNeedLevel2.style:SetColorByKey("default")
    local supportNeedLevel3 = window:CreateChildWidget("label", "supportNeedLevel3", 0, true)
    supportNeedLevel3:AddAnchor("LEFT", supportRequireImage3, "RIGHT", 1, 0)
    supportNeedLevel3:SetExtent(50, FONT_SIZE.MIDDLE)
    supportNeedLevel3:SetAutoResize(true)
    supportNeedLevel3.style:SetColorByKey("default")
    statusBar[ESRA_SUPPORT].requireLevelImage = {}
    statusBar[ESRA_SUPPORT].requireLevelImage[1] = supportRequireImage1
    statusBar[ESRA_SUPPORT].requireLevelImage[2] = supportRequireImage2
    statusBar[ESRA_SUPPORT].requireLevelImage[3] = supportRequireImage3
    statusBar[ESRA_SUPPORT].requireLevel = {}
    statusBar[ESRA_SUPPORT].requireLevel[1] = supportNeedLevel1
    statusBar[ESRA_SUPPORT].requireLevel[2] = supportNeedLevel2
    statusBar[ESRA_SUPPORT].requireLevel[3] = supportNeedLevel3
    local buttonSet = W_MODULE:Create("buttonSet", window, W_MODULE.TYPES.BUTTON_SET)
    window:RegisterStack(buttonSet, 20)
    buttonSet:AddButton("okButton", {
      [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "ok"),
      [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
      enable = true,
      clickFunc = function()
        window:Show(false)
      end
    })
    window:ApplyAutoHeightByStack()
    window.attributeValue = attributeValue
    window.statusBar = statusBar
  end
  function equip_slot_reinforce_window:UpdateEquipSlotReinforceWindow(equipSlot)
    if infoWindow:IsVisible() == false then
      return
    end
    if selected_equip_slot == equipSlot then
      ShowReinforceWindow(equipSlot)
    end
  end
  function equip_slot_reinforce_window:GetSelectedEquipSlot()
    return selected_equip_slot
  end
  function HideEquipSlotReinForceWnd()
    if equip_slot_reinforce_window ~= nil then
      equip_slot_reinforce_window:Show(false)
    end
  end
  function equip_slot_reinforce_window:UpdateBundleEffectWindows()
    local data = X2EquipSlotReinforce:GetBundleEffectInfos()
    equip_slot_reinforce_window.bundleEffect.scrollList:SetData({
      [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
      [W_MODULE.ATTRIBUTE.DATA] = data
    })
    if data == nil and #data == 0 then
      return
    end
    local needLevels = {}
    for i = 1, ESRA_MAX - 1 do
      table.insert(needLevels, {})
    end
    for i = 1, #data do
      needLevels[ESRA_OFFENCE][i] = data[i].reqOffenseLevel
      needLevels[ESRA_DEFENCE][i] = data[i].reqDefenseLevel
      needLevels[ESRA_SUPPORT][i] = data[i].reqSupportLevel
    end
    for i = 1, ESRA_MAX - 1 do
      local myTotalLevel = X2EquipSlotReinforce:GetAttributeTotalLevel(i)
      local attributeValue = equip_slot_reinforce_window.bundleEffect.attributeValue[i]
      attributeValue:SetText(tostring(myTotalLevel))
      local bar = equip_slot_reinforce_window.bundleEffect.statusBar[i]
      bar:SetMinMaxValues(0, needLevels[i][#data])
      bar:SetValue(myTotalLevel)
      local maxLevel, _ = bar.statusBar:GetMinMaxValues()
      for j = 1, #data do
        local reqLevel = needLevels[i][j]
        bar.requireLevel[j]:SetText(tostring(needLevels[i][j]))
        local offsetX = reqLevel / tonumber(maxLevel) * bar:GetWidth() - bar.requireLevel[j]:GetWidth() - bar.requireLevelImage[j]:GetWidth()
        bar.requireLevelImage[j]:AddAnchor("TOPLEFT", bar, "BOTTOMLEFT", offsetX, 1)
        if myTotalLevel < reqLevel then
          bar.requireLevelImage[j]:SetTextureColor("grey")
        else
          bar.requireLevelImage[j]:SetTextureColor("default")
        end
      end
    end
  end
  function equip_slot_reinforce_window:ShowBundleEffectWindows()
    if equip_slot_reinforce_window.bundleEffect:IsVisible() then
      equip_slot_reinforce_window.bundleEffect:Show(false)
      return
    end
    equip_slot_reinforce_window:UpdateBundleEffectWindows()
    equip_slot_reinforce_window.bundleEffect:Show(true)
    equip_slot_reinforce_window.bundleEffect:Raise()
  end
  local excludeReinforceSlotList = {
    9,
    14,
    15,
    20,
    21,
    22
  }
  for i = 1, #PLAYER_EQUIP_SLOTS do
    CreateReinforceSlot(IsLeftSide(i), i, excludeReinforceSlotList)
  end
  CreateReinforceDetailBtn(parent)
  equip_slot_reinforce_window.popup = CreateEquipSlotReinforceEffectWindow(parent.equipSlotReinforceBtn.detailBtn)
  SetEquipSlotReinforceSlotAnchor(equip_slot_reinforce_window.slot, equip_slot_reinforce_window)
  if X2Player:GetFeatureSet().equipSlotBundleEffect == false then
    for i = ESRA_OFFENCE, ESRA_MAX - 1 do
      CreateReinforceSetEffectWindow(equip_slot_reinforce_window.rightSlots, i)
    end
    equip_slot_reinforce_window.setEffect[ESRA_DEFENCE].window:AddAnchor("TOPRIGHT", equip_slot_reinforce_window.slot[1], "TOPLEFT", 0, 0)
    equip_slot_reinforce_window.setEffect[ESRA_SUPPORT].window:AddAnchor("TOPLEFT", equip_slot_reinforce_window.slot[2], "TOPRIGHT", 0, 0)
    equip_slot_reinforce_window.setEffect[ESRA_OFFENCE].window:AddAnchor("TOPLEFT", equip_slot_reinforce_window.slot[16], "TOPRIGHT", 0, 0)
  else
    CreateEquipSlotReinforceBundleEffectWindow()
  end
  local function OnHide()
    infoWindow:Show(false)
  end
  equip_slot_reinforce_window:SetHandler("OnHide", OnHide)
  return equip_slot_reinforce_window
end
