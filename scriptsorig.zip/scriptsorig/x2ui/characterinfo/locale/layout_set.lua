local layoutSet = {
  default = {
    windowWidth = F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_350),
    badgeFontSize = FONT_SIZE.MIDDLE
  },
  [MAILRU] = {
    windowWidth = F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_430),
    badgeFontSize = FONT_SIZE.SMALL
  }
}
layoutSet[KAKAONA] = layoutSet[MAILRU]
layoutSet[XLGAMES_TH] = layoutSet[MAILRU]
function GetLayoutSetCharacterInfo()
  return L_HELPER.Get(layoutSet)
end
