﻿## author : yoshimom
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## chracterinfo

locale/layout_set.lua

common.lua

tab_info_sub.lua

target_equipped_item.lua

preliminary_equipments_view.lua
preliminary_equipments.lua

equip_slot_reinforce/locale/data_set.lua
equip_slot_reinforce/locale/layout_set.lua
equip_slot_reinforce/common.lua
equip_slot_reinforce/effect.lua
equip_slot_reinforce/info.lua
equip_slot_reinforce/view.lua
equip_slot_reinforce/logic.lua

equipped_item_view.lua
equipped_item.lua

character_info_table.lua
character_info_option.lua
character_info_sub.lua

character_info_view.lua
character_info.lua