local targetEquippedItem
local SetViewOfTargetEquipedItemWindow = function()
  local slotsByIndex = {}
  local slotTooltipInfos = {}
  local window = CreateWindow("targetEquippedItem", "UIParent")
  window:AddAnchor("TOP", "UIParent", "TOP", 0, (UIParent:GetScreenHeight() - 440 - 60) * 4602678819172646912)
  window:SetExtent(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_430), 640)
  window:SetTitle(GetCommonText("target_equipments_wnd"))
  window.slot = {}
  window.leftSlots = window:CreateChildWidget("emptyWidget", "leftSlots", 0, true)
  window.leftSlots:SetExtent(ICON_SIZE.DEFAULT, 485)
  window.leftSlots:AddAnchor("TOPLEFT", window.titleBar, "BOTTOM", -200, 45)
  window.rightSlots = window:CreateChildWidget("emptyWidget", "rightSlots", 0, true)
  window.rightSlots:SetExtent(ICON_SIZE.DEFAULT, 485)
  window.rightSlots:AddAnchor("TOPRIGHT", window.titleBar, "BOTTOM", 200, 45)
  window.modelView = CreateModelview("modelview", window)
  window.modelView:AddAnchor("TOP", window.titleBar, "BOTTOM", 0, 50)
  window.modelView.rotateRight:AddAnchor("LEFT", window.modelView, 5, 0)
  window.modelView.rotateLeft:AddAnchor("RIGHT", window.modelView, -5, 0)
  window.targetName = window:CreateChildWidget("label", "targetName", 0, true)
  window.targetName:SetExtent(window:GetWidth() - 110, FONT_SIZE.LARGE)
  window.targetName:AddAnchor("BOTTOM", window, "BOTTOM", 0, -FONT_SIZE.LARGE - 16 - 5)
  window.targetName.style:SetFontSize(FONT_SIZE.LARGE)
  window.targetName.style:SetColorByKey("default")
  window.gearScore = window:CreateChildWidget("label", "gearScore", 0, true)
  window.gearScore:SetExtent(window:GetWidth() - 110, FONT_SIZE.LARGE)
  window.gearScore:AddAnchor("BOTTOM", window, "BOTTOM", 0, -16)
  window.gearScore.style:SetFontSize(FONT_SIZE.LARGE)
  window.gearScore.style:SetColorByKey("bright_blue")
  for i = 1, #PLAYER_EQUIP_SLOTS do
    local parent = IsLeftSide(i) and window.leftSlots or window.rightSlots
    local button = CreateIconButton(string.format("slot[%d]", i), parent)
    window.slot[i] = button
    window.slot[i]:SetForceVisible(true)
    F_SLOT.ApplySlotSkin(window.slot[i], window.slot[i].back, SLOT_STYLE.EQUIP_ITEM[i])
  end
  local function SetSlotType(slotIdx, slot)
    slotsByIndex[slotIdx] = slot
  end
  local function InitTargetEquippedItem()
    for i = 1, #PLAYER_EQUIP_SLOTS do
      local equipslot = window.slot[i]
      local slotIdx = PLAYER_EQUIP_SLOTS[i]
      SetSlotType(slotIdx, equipslot)
      slotTooltipInfos[i] = nil
    end
    for i = 1, #PLAYER_EQUIP_SLOTS do
      local button = window.slot[i]
      local function OnEnter()
        local slotIdx = PLAYER_EQUIP_SLOTS[i]
        local tooltip = slotTooltipInfos[i]
        if tooltip ~= nil then
          if tooltip.itemType == 0 then
            local text = GetSlotText(slotIdx)
            SetTooltip(text, button)
          else
            ShowTooltip(tooltip, button, 1, false)
          end
        end
      end
      button:SetHandler("OnEnter", OnEnter)
      local OnHide = function()
        HideTooltip()
      end
      button:SetHandler("OnLeave", OnHide)
    end
    local OnHide = function(self)
      self.modelView:StopAnimation()
      self.modelView:ClearModel()
    end
    window:SetHandler("OnHide", OnHide)
  end
  local function UpdateTargetEquippedItem()
    local index = 1
    local indexY = 1
    local target = X2Unit:GetTargetUnitString()
    local ownerStringId = X2Unit:GetUnitId(target)
    for i = 1, #PLAYER_EQUIP_SLOTS do
      local slotIdx = PLAYER_EQUIP_SLOTS[i]
      local tooltip = X2Equipment:GetEquippedItemTooltipText(target, slotIdx)
      tooltip.targetEquippedItem = true
      tooltip.iconInfo = X2Item:GetItemIconSet(tooltip.lookType, tooltip.itemGrade, ownerStringId)
      slotTooltipInfos[i] = tooltip
      if tooltip then
        local cooldownBtn = window.slot[i]
        cooldownBtn:SetInfo(tooltip)
        cooldownBtn.id = tooltip.skillType
        SetTooltipDelayTime(0)
      end
      window.targetName:SetText(X2Unit:UnitName(target))
      window.gearScore:SetText(F_TEXT.SetColonFormat(GetUIText(COMMON_TEXT, "gear_score"), X2Unit:UnitGearScore(target, true)))
    end
  end
  local function InitModelView()
    local target = X2Unit:GetTargetUnitString()
    window.modelView:Init(target, true)
    window.modelView:SetIngameShopMode(true)
    local adjust = GetAdjustCamera(X2Unit:UnitVisualRace(target), X2Unit:UnitGender(target))
    if adjust ~= nil then
      window.modelView:AdjustCameraPos(adjust.center, adjust.zoom, adjust.height)
    end
    window.modelView:PlayAnimation(RELAX_ANIMATION_NAME, true)
  end
  function window:ShowProc()
    InitTargetEquippedItem()
    UpdateTargetEquippedItem()
    InitModelView()
  end
  SetEquipSlotAnchor(window.slot, window, false)
  return window
end
function ShowTargetEquippedItemWnd()
  if targetEquippedItem == nil then
    targetEquippedItem = SetViewOfTargetEquipedItemWindow()
  end
  targetEquippedItem:Show(true)
end
function ShowTargetEquipment()
  if X2Player:GetFeatureSet().targetEquipmentWnd ~= true then
    return
  end
  local target = X2Unit:GetTargetUnitString()
  if targetEquippedItem == nil then
    targetEquippedItem = SetViewOfTargetEquipedItemWindow()
  elseif targetEquippedItem:IsVisible() then
    targetEquippedItem:Show(false)
    return
  end
  if X2Unit:IsMe("target") == true then
    return
  end
  local isShowable = X2Unit:ShowableEquipInfo(target)
  local unitType = F_UNIT.GetUnitType(target)
  if isShowable and unitType == "character" then
    targetEquippedItem:Show(true)
  end
end
ADDON:RegisterContentTriggerFunc(UIC_TARGET_EQUIPMENT, ShowTargetEquipment)
