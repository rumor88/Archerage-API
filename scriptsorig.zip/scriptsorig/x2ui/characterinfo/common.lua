function GetAttibuteText(attributeType)
  local texts = {
    [ESRA_OFFENCE] = X2Locale:LocalizeUiText(COMMON_TEXT, "equip_slot_reinforce_window_offense"),
    [ESRA_DEFENCE] = X2Locale:LocalizeUiText(COMMON_TEXT, "equip_slot_reinforce_window_defense"),
    [ESRA_SUPPORT] = X2Locale:LocalizeUiText(COMMON_TEXT, "equip_slot_reinforce_window_support")
  }
  if texts[attributeType] ~= nil then
    return texts[attributeType]
  else
    return "unknown"
  end
end
function GetFlipAnchor(isFlip, anchor)
  if isFlip ~= true then
    return anchor
  end
  if anchor == "TOP" then
    return "BOTTOM"
  elseif anchor == "BOTTOM" then
    return "TOP"
  elseif anchor == "LEFT" then
    return "RIGHT"
  elseif anchor == "RIGHT" then
    return "LEFT"
  elseif anchor == "TOPLEFT" then
    return "TOPRIGHT"
  elseif anchor == "TOPRIGHT" then
    return "TOPLEFT"
  elseif anchor == "BOTTOMLEFT" then
    return "BOTTOMLEFT"
  elseif anchor == "BOTTOMRIGHT" then
    return "BOTTOMRIGHT"
  else
    return anchor
  end
end
function IsLeftSide(i)
  local leftGroup = {
    1,
    3,
    4,
    8,
    6,
    9,
    5,
    7,
    14,
    15,
    21
  }
  for j = 1, #leftGroup do
    if leftGroup[j] == i then
      return true
    end
  end
  return false
end
function GetSlotText(slotIdx)
  local emptyTip = {
    [ES_HEAD] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_head"),
    [ES_NECK] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_neck"),
    [ES_CHEST] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_chest"),
    [ES_WAIST] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_waist"),
    [ES_LEGS] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_legs"),
    [ES_HANDS] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_hands"),
    [ES_FEET] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_feet"),
    [ES_ARMS] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_arms"),
    [ES_BACK] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_back"),
    [ES_EAR_1] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_ear_1"),
    [ES_EAR_2] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_ear_2"),
    [ES_FINGER_1] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_finger_1"),
    [ES_FINGER_2] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_finger_2"),
    [ES_UNDERSHIRT] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_undershirt"),
    [ES_UNDERPANTS] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_underpants"),
    [ES_MAINHAND] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_mainhand"),
    [ES_OFFHAND] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_offhand"),
    [ES_RANGED] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_ranged"),
    [ES_MUSICAL] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_musical"),
    [ES_BACKPACK] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_backpack"),
    [ES_COSPLAY] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_cosplay"),
    [ES_COSPLAYLOOKS] = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "equip_slot_es_cosplaylooks")
  }
  if emptyTip[slotIdx] ~= nil then
    return emptyTip[slotIdx]
  else
    return "unknown"
  end
end
function SetTooltipHandlers(widgets)
  for i = 1, #widgets do
    local widget = widgets[i]
    local OnEnter = function(self)
      SetTooltip(self.tooltipText, self)
    end
    widget:SetHandler("OnEnter", OnEnter)
  end
end
function SetExtraTooltipHandlers(widgets)
  for i = 1, #widgets do
    local widget = widgets[i]
    local OnEnter = function(self)
      local extraInfo = ""
      if self.GetExtraInfo ~= nil then
        extraInfo = self:GetExtraInfo()
      end
      if self.isAppellation then
        extraInfo = self:GetText()
      end
      if extraInfo == "" then
        return
      end
      SetTooltip(extraInfo, self)
    end
    widget:SetHandler("OnEnter", OnEnter)
  end
end
function CreateDefaultSubTitle(id, parent, width, height)
  local widget = parent:CreateChildWidget("label", id, 0, true)
  widget:SetText("")
  widget:SetExtent(width, height)
  widget.style:SetEllipsis(true)
  widget.style:SetAlign(ALIGN_LEFT)
  return widget
end
function CreateCrimePointTextBox(parent, width, height)
  local widget = UIParent:CreateWidget("textbox", "character.window.crimePoint", parent)
  widget:SetExtent(width, height)
  widget.style:SetAlign(ALIGN_LEFT)
  function widget:Update()
    local info = X2Player:GetCrimeInfo()
    local point = info.crimePoint
    if point == nil then
      return
    end
    local color
    if point < 50 then
      color = F_COLOR.GetColor("default", true)
    else
      color = F_COLOR.GetColor("red", true)
    end
    local pointStr = F_TEXT.SetSlashFormat(string.format("%s%s|r", color, F_TEXT.SetCommaFormat(point)), 50)
    self:SetText(pointStr)
  end
  widget:SetHandler("OnEvent", function(this, event, ...)
    widget:Update()
  end)
  widget:RegisterEvent("CRIME_REPORTED")
  widget:RegisterEvent("LEFT_LOADING")
  widget:Update()
  return widget
end
function CreateHonorPointLabel(parent, width, height)
  local widget = UIParent:CreateWidget("textbox", "character.window.honorPoint", parent)
  widget:SetExtent(width, height)
  widget.style:SetAlign(ALIGN_LEFT)
  function widget:Update()
    local info = X2Player:GetGamePoints()
    local point = info.honorPointStr
    if point == nil then
      return
    end
    self:SetText(string.format("|h%s;", point))
  end
  widget:SetHandler("OnEvent", function(this, event, ...)
    widget:Update()
  end)
  widget:RegisterEvent("PLAYER_HONOR_POINT")
  widget:Update()
  return widget
end
function CreateLivingPointLabel(parent, width, height)
  local widget = F_UNIT.CreatePlayerLivingPoint("livingPoint", parent)
  widget:SetExtent(width, height)
  return widget
end
function CreateLastSeasonLeadershipPointLabel(parent, width, height)
  local widget = UIParent:CreateWidget("textbox", "character.window.leadershipPoint", parent)
  widget:SetExtent(width, height)
  widget.style:SetAlign(ALIGN_LEFT)
  local badge = W_ICON.CreateTextBadge("badge", widget, {
    info = {
      possible = {
        text = GetUIText(COMMON_TEXT, "vote_available"),
        colorKey = "blue",
        tooltip = GetUIText(COMMON_TEXT, "hero_election_enable_tooltip_of_character_info_window")
      }
    },
    fontSize = GetLayoutSetCharacterInfo().badgeFontSize
  })
  badge:Set("possible")
  badge:AddAnchor("LEFT", widget, "RIGHT", 3, 0)
  function widget:Update()
    local info = X2Player:GetGamePoints()
    local point = info.periodLeadershipPointStr
    if point == nil then
      return
    end
    self:SetText(string.format("|sd%s;", point))
    badge:RemoveAllAnchors()
    badge:AddAnchor("LEFT", widget, widget:GetLongestLineWidth() + 3, 0)
    badge:Show(X2Hero:IsVoter())
  end
  widget:SetHandler("OnEvent", function(this, event, ...)
    widget:Update()
  end)
  widget:RegisterEvent("HERO_SCORE_UPDATED")
  widget:RegisterEvent("START_HERO_ELECTION_PERIOD")
  widget:RegisterEvent("UPDATE_HERO_ELECTION_CONDITION")
  widget:RegisterEvent("END_HERO_ELECTION_PERIOD")
  widget:Update()
  return widget
end
function CreateAccumLeadershipPointLabel(parent, width, height)
  local widget = UIParent:CreateWidget("textbox", "character.window.accumLeadershipPoint", parent)
  widget:SetExtent(width, height)
  widget.style:SetAlign(ALIGN_LEFT)
  function widget:Update()
    local info = X2Player:GetGamePoints()
    local point = info.leadershipPointStr
    if point == nil then
      return
    end
    self:SetText(string.format("|sd%d;", point))
  end
  widget:SetHandler("OnEvent", function(this, event, ...)
    widget:Update()
  end)
  widget:RegisterEvent("HERO_SCORE_UPDATED")
  widget:Update()
  return widget
end
function CreateCurrentLeadershipPointLabel(parent, width, height)
  local widget = UIParent:CreateWidget("textbox", "character.window.currentLeadershipPoint", parent)
  widget:SetExtent(width, height)
  widget.style:SetAlign(ALIGN_LEFT)
  function widget:Update()
    local scoreTable = X2Hero:GetMyScore()
    if scoreTable == nil or scoreTable.score == nil then
      return
    end
    self:SetText(string.format("|sd%s;", tostring(scoreTable.score)))
  end
  widget:SetHandler("OnEvent", function(this, event, ...)
    widget:Update()
  end)
  widget:RegisterEvent("HERO_SCORE_UPDATED")
  widget:RegisterEvent("LEFT_LOADING")
  widget:Update()
  return widget
end
function CreateJuryPointLabel(parent, width, height)
  local widget = W_CTRL.CreateLabel("character.window.juryPoint", parent)
  widget:SetExtent(width, height)
  widget:SetAutoResize(true)
  widget:SetNumberOnly(true)
  local badge = W_ICON.CreateTextBadge("badge", widget, {
    info = {
      waiting = {
        text = GetUIText(COMMON_TEXT, "waiting"),
        colorKey = "orange"
      }
    }
  })
  badge:Set("waiting")
  badge:AddAnchor("LEFT", widget, "RIGHT", 3, 0)
  local OnEnterBadge = function()
    X2Trial:RequestJuryWaitingNumber()
  end
  badge:SetHandler("OnEnter", OnEnterBadge)
  function widget:Update()
    local point = X2Player:GetJuryPoint()
    if point == nil then
      return
    end
    self:SetText(string.format("%d", point - 1))
  end
  local juryStatusEvents = {
    PLAYER_JURY_POINT = function()
      widget:Update()
    end,
    JURY_WAITING_NUMBER = function(num)
      local tooltip_str = locale.trial.wait_jury_tip(num)
      SetTooltip(tooltip_str, badge)
    end
  }
  widget:SetHandler("OnEvent", function(this, event, ...)
    juryStatusEvents[event](...)
  end)
  widget:RegisterEvent("PLAYER_JURY_POINT")
  widget:RegisterEvent("JURY_WAITING_NUMBER")
  widget:Update()
  return widget
end
function CreateAppellationLabel(parent, width, height)
  local widget = W_CTRL.CreateLabel("character.window.appellation", parent)
  widget:SetExtent(width, height)
  widget.style:SetEllipsis(true)
  widget.isAppellation = true
  widget.color = F_COLOR.GetColor("green")
  local function Update()
    local info = X2Player:GetShowingAppellation()
    if X2Player:GetAppellationCount() >= 2 then
      widget.style:SetColorByKey("green")
      if info ~= nil and info[APPELLATION_INFO.TYPE] ~= nil and info[APPELLATION_INFO.TYPE] ~= 0 then
        widget:SetText(info[APPELLATION_INFO.NAME])
      else
        widget:SetText(locale.appellation.unable)
      end
    else
      widget:SetText(locale.appellation.have_not_appellation)
      widget.style:SetColorByKey("default")
      widget.color = F_COLOR.GetColor("default")
    end
  end
  local events = {
    APPELLATION_GAINED = function()
      Update()
    end,
    APPELLATION_CHANGED = function(stringId)
      if not W_UNIT.IsMyUnitId(stringId) then
        return
      end
      Update()
    end
  }
  widget:SetHandler("OnEvent", function(this, event, ...)
    events[event](...)
  end)
  RegistUIEvent(widget, events)
  Update()
  return widget
end
function CreateDishonorPointWindow(parent, width, height)
  local widget = UIParent:CreateWidget("textbox", "character.window.DishonorPoint", parent)
  widget:SetExtent(width, height)
  widget.style:SetAlign(ALIGN_LEFT)
  function widget:Update()
    local info = X2Player:GetCrimeInfo()
    local dishonorPoint = info.crimeRecord
    if dishonorPoint == nil then
      return
    end
    self:SetText(string.format("%d", dishonorPoint))
  end
  widget:SetHandler("OnEvent", function(this, event, ...)
    widget:Update()
  end)
  widget:RegisterEvent("CRIME_REPORTED")
  widget:Update()
  return widget
end
local SetCommonEquipSlotLeftAnchor = function(slots, anchor, anchorType)
  if anchorType == nil then
    anchorType = "TOPLEFT"
  end
  if anchor then
    slots[1]:AddAnchor(anchorType, anchor, 0, 0)
    slots[3]:AddAnchor(anchorType, anchor, 0, 48)
    slots[4]:AddAnchor(anchorType, anchor, 0, 96)
    slots[8]:AddAnchor(anchorType, anchor, 0, 144)
    slots[6]:AddAnchor(anchorType, anchor, 0, 192)
    slots[5]:AddAnchor(anchorType, anchor, 0, 317)
    slots[7]:AddAnchor(anchorType, anchor, 0, 365)
  end
end
local SetCommonEquipSlotRightAnchor = function(slots, anchor, anchorType)
  if anchorType == nil then
    anchorType = "TOPRIGHT"
  end
  if anchor then
    slots[2]:AddAnchor(anchorType, anchor, 0, 0)
    slots[10]:AddAnchor(anchorType, anchor, 0, 48)
    slots[11]:AddAnchor(anchorType, anchor, 0, 96)
    slots[12]:AddAnchor(anchorType, anchor, 0, 144)
    slots[13]:AddAnchor(anchorType, anchor, 0, 192)
    slots[16]:AddAnchor(anchorType, anchor, 0, 250)
    slots[17]:AddAnchor(anchorType, anchor, 0, 298)
    slots[18]:AddAnchor(anchorType, anchor, 0, 346)
    slots[19]:AddAnchor(anchorType, anchor, 0, 394)
  end
end
function SetEquipSlotReinforceSlotAnchor(slots, anchor)
  if slots == nil or anchor == nil then
    return
  end
  if anchor.leftSlots then
    SetCommonEquipSlotLeftAnchor(slots, anchor.leftSlots, "TOPRIGHT")
  end
  if anchor.rightSlots then
    SetCommonEquipSlotRightAnchor(slots, anchor.rightSlots, "TOPLEFT")
  end
end
function SetEquipSlotAnchor(slots, anchor, isCharInfo)
  if slots == nil or anchor == nil then
    return
  end
  if anchor.leftSlots then
    SetCommonEquipSlotLeftAnchor(slots, anchor.leftSlots)
    slots[9]:AddAnchor("TOPLEFT", anchor.leftSlots, 0, 269)
    slots[14]:Show(false)
    slots[15]:AddAnchor("TOPLEFT", anchor.leftSlots, 0, 442)
  end
  if anchor.rightSlots then
    SetCommonEquipSlotRightAnchor(slots, anchor.rightSlots)
    slots[20]:AddAnchor("TOPRIGHT", anchor.rightSlots, 0, 442)
  end
  if X2Player:GetFeatureSet().useCosplayLooksSlot == true then
    if isCharInfo == true then
      slots[21]:AddAnchor("CENTER", "UIParent", "CENTER", -slots[21]:GetWidth() / 2 - 3, -280)
      slots[22]:AddAnchor("CENTER", "UIParent", "CENTER", slots[22]:GetWidth() / 2 + 3, -280)
    else
      slots[21]:AddAnchor("TOP", anchor.titleBar, "BOTTOM", -slots[21]:GetWidth() / 2 - 3, 0)
      slots[22]:AddAnchor("TOP", anchor.titleBar, "BOTTOM", slots[22]:GetWidth() / 2 + 3, 0)
    end
  else
    if isCharInfo == true then
      slots[21]:AddAnchor("CENTER", "UIParent", "CENTER", 0, -280)
    else
      slots[21]:AddAnchor("TOP", anchor.titleBar, "BOTTOM", 0, 0)
    end
    slots[22]:Show(false)
  end
end
