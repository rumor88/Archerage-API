local charInfoStat, charInfoModifierStat
ADDON:RegisterContentWidget(UIC_CHARACTER_INFO, characterInfo.mainWindow)
characterInfo.mainWindow:SetCloseOnEscape(true)
local GetHexColorByValue = function(value)
  if value ~= 0 then
    if value > 0 then
      return F_COLOR.GetColor("green", true)
    elseif value < 0 then
      return F_COLOR.GetColor("red", true)
    end
  end
  return F_COLOR.GetColor("default", true)
end
local function GetTribeOfDownDamage(leftAttr, rightAttr)
  local leftVal = charInfoStat[leftAttr]
  if leftVal ~= 0 then
    leftVal = -leftVal
  end
  local leftColor = GetHexColorByValue(charInfoModifierStat[leftAttr])
  local rightVal = charInfoStat[rightAttr]
  if rightVal ~= 0 then
    rightVal = -rightVal
  end
  local rightStr = ""
  if rightVal ~= 0 then
    local rightColor = GetHexColorByValue(charInfoModifierStat[rightAttr])
    rightStr = string.format("%s(%d)", rightColor, math.abs(rightVal))
  end
  return string.format("%s%.1f %%%s", leftColor, 100 - leftVal, rightStr)
end
local function GetMeleeDps()
  return string.format("%.2f", charInfoStat.melee_dps)
end
local function GetRangedDps()
  return string.format("%.2f", charInfoStat.ranged_dps)
end
local function GetSpellDps()
  local spellDps = string.format("%.2f", charInfoStat.spell_dps)
  if spellDps == "" or spellDps == nil then
    visibilitys[16] = false
    return ""
  end
  return spellDps
end
local function GetHealDps()
  return string.format("%.2f", charInfoStat.heal_dps)
end
local function GetArmor()
  return string.format("%d (%.2f%%)", charInfoStat.armor, charInfoStat.armor_percentage)
end
local function GetSpellResist()
  return string.format("%d (%.2f%%)", charInfoStat.magic_resist, charInfoStat.magic_resist_percentage)
end
local function GetStr()
  return string.format("%d", charInfoStat.str)
end
local function GetInt()
  return string.format("%d", charInfoStat.int)
end
local function GetDex()
  return string.format("%d", charInfoStat.dex)
end
local function GetSpi()
  return string.format("%d", charInfoStat.spi)
end
local function GetSta()
  return string.format("%d", charInfoStat.sta)
end
local function GetMoveSpeed()
  return string.format("%.1f %s (%.1f%%)", charInfoStat.move_speed, locale.util.speed_unit, charInfoStat.move_speed_rate)
end
local function GetCastingTime()
  return string.format("%.1f %%", charInfoStat.casting_time)
end
local function GetAttackAnimSpeed()
  return string.format("%d (%.1f %%)", charInfoStat.attack_anim_speed, charInfoStat.attack_anim_speed_mul)
end
local function GetMeleeSuccessRate()
  return string.format("%.1f %%", math.floor(charInfoStat.melee_success_rate * 10) / 10)
end
local function GetMeleeCriticalRate()
  return string.format("%.1f %%", charInfoStat.melee_critical_rate)
end
local function GetMeleeCriticalBonus()
  return string.format("%.1f %%", charInfoStat.melee_critical_bonus)
end
local function GetRangedSpeed()
  local strSec = X2Locale:LocalizeUiText(TOOLTIP_TEXT, "second")
  return string.format("%.1f %s", charInfoStat.ranged_speed, strSec)
end
local function GetRangedSuccessRate()
  return string.format("%.1f %%", math.floor(charInfoStat.ranged_success_rate * 10) / 10)
end
local function GetRangedCriticalRate()
  return string.format("%.1f %%", charInfoStat.ranged_critical_rate)
end
local function GetRangedCriticalBonus()
  return string.format("%.1f %%", charInfoStat.ranged_critical_bonus + 100)
end
local function GetBullsEyeRate()
  return string.format("%d (%.1f%%)", charInfoStat.bulls_eye, charInfoStat.bulls_eye_rate)
end
local function GetSpellSuccessRate()
  return string.format("%.1f %%", math.floor(charInfoStat.spell_success_rate * 10) / 10)
end
local function GetSpellCriticalRate()
  return string.format("%.1f %%", charInfoStat.spell_critical_rate)
end
local function GetSpellCriticalBonus()
  return string.format("%.1f %%", charInfoStat.spell_critical_bonus + 100)
end
local function GetBackAttackMeleeDamage()
  return string.format("%.1f %%", charInfoStat.backattack_melee_damage_mul + 100)
end
local function GetMeleeDamageMulAntiNpc()
  return string.format("%.1f %%", charInfoStat.melee_damage_mul_anti_npc + 100)
end
local function GetBackAttackRangedDamage()
  return string.format("%.1f %%", charInfoStat.backattack_ranged_damage_mul + 100)
end
local function GetRangedDamageMulAntiNpc()
  return string.format("%.1f %%", charInfoStat.ranged_damage_mul_anti_npc + 100)
end
local function GetBackAttackSpelldDamage()
  return string.format("%.1f %%", charInfoStat.backattack_spell_damage_mul + 100)
end
local function GetSpellDamageMulAntiNpc()
  return string.format("%.1f %%", charInfoStat.spell_damage_mul_anti_npc + 100)
end
local function GetIgnoreShieldChance()
  return string.format("%.1f%%", charInfoStat.ignore_shield_chance)
end
local function GetIgnoreArmor()
  return string.format("%d", charInfoStat.ignore_armor)
end
local function GetMagicPenetration()
  return string.format("%d", charInfoStat.magic_penetration)
end
local function GetMeleeDamageMulAntiPc()
  return string.format("%.1f %%", charInfoStat.melee_damage_mul_anti_pc + 100)
end
local function GetRangedDamageMulAntiPc()
  return string.format("%.1f %%", charInfoStat.ranged_damage_mul_anti_pc + 100)
end
local function GetSpellDamageMulAntiPc()
  return string.format("%.1f %%", charInfoStat.spell_damage_mul_anti_pc + 100)
end
local function GetMeleeParryRate()
  return string.format("%.1f %%", charInfoStat.melee_parry_rate)
end
local function GetBlockRate()
  return string.format("%.1f %%", charInfoStat.block_rate)
end
local function GetDodgeRate()
  return string.format("%.1f %%", charInfoStat.dodge_rate)
end
local function GetFlexibility()
  return string.format("%d", charInfoStat.flexibility)
end
local function GetFlexibilityRatio()
  return string.format("%.1f %%", -1 * charInfoStat.flexibility_ratio)
end
local function GetFlexibilityBonus()
  return string.format("%.1f %%", -1 * charInfoStat.flexibility_bonus)
end
local function GetBattleResist()
  return string.format("%d (%.1f%%)", charInfoStat.battle_resist, 100 * charInfoStat.battle_resist_rate)
end
local function GetHealthRegen()
  return string.format("%d", charInfoStat.health_regen)
end
local function GetPersistentHealthRegen()
  return string.format("%d", charInfoStat.persistent_health_regen)
end
local function GetManaRegen()
  return string.format("%d", charInfoStat.mana_regen)
end
local function GetPersistentManaRegen()
  return string.format("%d", charInfoStat.persistent_mana_regen)
end
local function GetHealCriticalRate()
  return string.format("%.1f %%", charInfoStat.heal_critical_rate)
end
local function GetHealCriticalBonus()
  return string.format("%.1f %%", charInfoStat.heal_critical_bonus)
end
local function GetHealMulRate()
  return string.format("%.1f %%", charInfoStat.heal_mul)
end
local function GetHealDamageMulRate()
  return string.format("%.1f %%", charInfoStat.heal_damage_mul)
end
local function GetHealMulOnlyHeal()
  return string.format("%.1f %%", charInfoStat.heal_mul_only_heal)
end
local function GetHealDamageMulAntiNpc()
  return string.format("%.1f %%", charInfoStat.heal_damage_mul_anti_npc)
end
local function GetIncomingHealMul()
  return string.format("%.1f %%", 100 + charInfoStat.incoming_heal_mul)
end
local function GetExpMul()
  return string.format("%d %%", 100 + charInfoStat.exp_mul)
end
local function GetDropRageMul()
  return string.format("%d %%", 100 + charInfoStat.drop_rate_mul)
end
local function GetLootGoldMul()
  return string.format("%d %%", 100 + charInfoStat.loot_gold_mul)
end
local function GetDetectStealthRangeMul()
  return string.format("%s (%d%%)", X2Locale:LocalizeUiText(COMMON_TEXT, "detect_stealth_range", string.format("%.1f", charInfoStat.detect_stealth_range)), math.abs(charInfoStat.detect_stealth_range_mul))
end
local GetElementMainHand = function()
  return string.format("%d", X2ItemEnchant:GetWeaponElementValue(ES_MAINHAND))
end
local GetElementOffHand = function()
  return string.format("%d", X2ItemEnchant:GetWeaponElementValue(ES_OFFHAND))
end
local GetElementRanged = function()
  return string.format("%d", X2ItemEnchant:GetWeaponElementValue(ES_RANGED))
end
local GetArmorMaterial = function()
  local armorType = X2Unit:UnitAttr("player", "armor_type")
  local key
  if armorType == AT_CLOTH then
    key = "item_category_light_armor"
  elseif armorType == AT_LEATHER then
    key = "item_category_normal_armor"
  elseif armorType == AT_METAL then
    key = "item_category_heavy_armor"
  else
    return X2Locale:LocalizeUiText(COMMON_TEXT, "armor_none")
  end
  return X2Locale:LocalizeUiText(AUCTION_TEXT, key)
end
local function GetGiveMeleeExtraDamage()
  return string.format("%.1f %%", charInfoStat.melee_damage_mul + 100)
end
local function GetGiveRangedExtraDamage()
  return string.format("%.1f %%", charInfoStat.ranged_damage_mul + 100)
end
local function GetGiveSpellExtraDamage()
  return string.format("%.1f %%", charInfoStat.spell_damage_mul + 100)
end
local function GetIncomeMeleeExtraDamage()
  return string.format("%.1f %%", 100 + charInfoStat.incoming_melee_damage_mul)
end
local function GetIncomeRangedExtraDamage()
  return string.format("%.1f %%", 100 + charInfoStat.incoming_ranged_damage_mul)
end
local function GetIncomeSpellExtraDamage()
  return string.format("%.1f %%", 100 + charInfoStat.incoming_spell_damage_mul)
end
local function GetIncomeSiegeExtraDamage()
  return GetTribeOfDownDamage("incoming_siege_damage_mul", "incoming_siege_damage_val")
end
local function GetIncomeMeleeExtraDamageAdd()
  return string.format("%d", math.abs(charInfoStat.incoming_melee_damage_val))
end
local function GetIncomeMeleeDamageAddAntiNpc()
  return string.format("%d", math.abs(charInfoStat.incoming_melee_damage_add_anti_npc))
end
local function GetIncomeRangedExtraDamageAdd()
  return string.format("%d", math.abs(charInfoStat.incoming_ranged_damage_val))
end
local function GetIncomeRangedDamageAddAntiNpc()
  return string.format("%d", math.abs(charInfoStat.incoming_ranged_damage_add_anti_npc))
end
local function GetIncomeSpellExtraDamageAdd()
  return string.format("%d", math.abs(charInfoStat.incoming_spell_damage_val))
end
local function GetIncomeSpellDamageAddAntiNpc()
  return string.format("%d", math.abs(charInfoStat.incoming_spell_damage_add_anti_npc))
end
local function GetIncomingDamageMulAntiNpc()
  return string.format("%.1f %%", 100 + charInfoStat.incoming_damage_mul_anti_npc)
end
local baseInfoTable = {
  {
    func = GetMeleeDps,
    affect = {"melee_dps", "str"},
    affectRate = {1, 4596373779694328218},
    defaultColor = "blue"
  },
  {
    func = GetRangedDps,
    affect = {"ranged_dps", "dex"},
    affectRate = {1, 4596373779694328218},
    defaultColor = "blue"
  },
  {
    func = GetSpellDps,
    affect = {"spell_dps", "int"},
    affectRate = {1, 4596373779694328218},
    defaultColor = "blue"
  },
  {
    func = GetHealDps,
    affect = {"heal_dps", "spi"},
    affectRate = {1, 4596373779694328218},
    defaultColor = "blue"
  },
  {
    func = GetArmor,
    affect = {"armor"},
    defaultColor = "blue"
  },
  {
    func = GetSpellResist,
    affect = {
      "magic_resist",
      "spi"
    },
    affectRate = {1, 1},
    defaultColor = "blue"
  },
  {
    func = GetStr,
    affect = {"str"}
  },
  {
    func = GetInt,
    affect = {"int"}
  },
  {
    func = GetDex,
    affect = {"dex"}
  },
  {
    func = GetSpi,
    affect = {"spi"}
  },
  {
    func = GetSta,
    affect = {"sta"}
  },
  {
    func = GetMoveSpeed,
    affect = {"move_speed"}
  },
  {
    func = GetCastingTime,
    affect = {
      "casting_time"
    }
  },
  {
    func = GetAttackAnimSpeed,
    affect = {
      "attack_anim_speed_mul"
    }
  }
}
local featureSet = X2Player:GetFeatureSet()
local detailInfoTable = {
  [INDEX_ATTACK] = {
    {
      func = GetMeleeSuccessRate,
      affect = {
        "melee_success_rate",
        "str",
        "spi"
      }
    },
    {
      func = GetMeleeCriticalRate,
      affect = {
        "melee_critical_rate",
        "dex",
        "melee_critical_mul"
      }
    },
    {
      func = GetMeleeCriticalBonus,
      affect = {
        "melee_critical_bonus"
      }
    },
    {
      func = GetBackAttackMeleeDamage,
      affect = {
        "backattack_melee_damage_mul"
      }
    },
    {
      func = GetGiveMeleeExtraDamage,
      affect = {
        "melee_damage_mul"
      }
    },
    {
      func = GetMeleeDamageMulAntiNpc,
      affect = {
        "melee_damage_mul_anti_npc"
      }
    },
    {
      func = GetMeleeDamageMulAntiPc,
      affect = {
        "melee_damage_mul_anti_pc"
      },
      show = featureSet.pvpModifiySet
    },
    {
      func = GetRangedSuccessRate,
      affect = {
        "ranged_success_rate",
        "dex",
        "spi"
      }
    },
    {
      func = GetRangedCriticalRate,
      affect = {
        "ranged_critical_rate",
        "int",
        "dex",
        "ranged_critical_mul"
      }
    },
    {
      func = GetRangedCriticalBonus,
      affect = {
        "ranged_critical_bonus"
      }
    },
    {
      func = GetBackAttackRangedDamage,
      affect = {
        "backattack_ranged_damage_mul"
      }
    },
    {
      func = GetGiveRangedExtraDamage,
      affect = {
        "ranged_damage_mul"
      }
    },
    {
      func = GetRangedDamageMulAntiNpc,
      affect = {
        "ranged_damage_mul_anti_npc"
      }
    },
    {
      func = GetRangedDamageMulAntiPc,
      affect = {
        "ranged_damage_mul_anti_pc"
      },
      show = featureSet.pvpModifiySet
    },
    {
      func = GetSpellSuccessRate,
      affect = {
        "spell_success_rate",
        "int",
        "spi"
      }
    },
    {
      func = GetSpellCriticalRate,
      affect = {
        "spell_critical_rate",
        "int",
        "spell_damage_critical_mul",
        "spell_critical_mul"
      }
    },
    {
      func = GetSpellCriticalBonus,
      affect = {
        "spell_damage_critical_bonus",
        "spell_critical_bonus"
      }
    },
    {
      func = GetBackAttackSpelldDamage,
      affect = {
        "backattack_spell_damage_mul"
      }
    },
    {
      func = GetGiveSpellExtraDamage,
      affect = {
        "spell_damage_mul"
      }
    },
    {
      func = GetSpellDamageMulAntiNpc,
      affect = {
        "spell_damage_mul_anti_npc"
      }
    },
    {
      func = GetSpellDamageMulAntiPc,
      affect = {
        "spell_damage_mul_anti_pc"
      },
      show = featureSet.pvpModifiySet
    },
    {
      func = GetBullsEyeRate,
      affect = {"bulls_eye"}
    },
    {
      func = GetIgnoreShieldChance,
      affect = {
        "ignore_shield_chance",
        "ignore_shield_bonus_mul"
      }
    },
    {
      func = GetIgnoreArmor,
      affect = {
        "ignore_armor"
      }
    },
    {
      func = GetMagicPenetration,
      affect = {
        "magic_penetration"
      }
    }
  },
  [INDEX_DEFFENCE] = {
    {
      func = GetMeleeParryRate,
      affect = {
        "melee_parry_rate",
        "str",
        "sta",
        "melee_parry_mul"
      }
    },
    {
      func = GetBlockRate,
      affect = {"block_rate", "block_mul"}
    },
    {
      func = GetDodgeRate,
      affect = {"dodge_rate", "dodge_mul"}
    },
    {
      func = GetFlexibility,
      affect = {
        "flexibility"
      }
    },
    {
      func = GetFlexibilityRatio,
      affect = {
        "flexibility"
      }
    },
    {
      func = GetFlexibilityBonus,
      affect = {
        "flexibility"
      }
    },
    {
      func = GetBattleResist,
      affect = {
        "battle_resist"
      }
    },
    {
      func = GetIncomeSiegeExtraDamage,
      affect = {
        "incoming_siege_damage_mul"
      }
    },
    {
      func = GetIncomingDamageMulAntiNpc,
      affect = {
        "incoming_damage_mul_anti_npc"
      }
    },
    {
      func = GetIncomeMeleeExtraDamage,
      affect = {
        "incoming_melee_damage_mul"
      }
    },
    {
      func = GetIncomeMeleeExtraDamageAdd,
      affect = {
        "incoming_melee_damage_val"
      }
    },
    {
      func = GetIncomeMeleeDamageAddAntiNpc,
      affect = {
        "incoming_melee_damage_add_anti_npc"
      }
    },
    {
      func = GetIncomeRangedExtraDamage,
      affect = {
        "incoming_ranged_damage_mul"
      }
    },
    {
      func = GetIncomeRangedExtraDamageAdd,
      affect = {
        "incoming_ranged_damage_val"
      }
    },
    {
      func = GetIncomeRangedDamageAddAntiNpc,
      affect = {
        "incoming_ranged_damage_add_anti_npc"
      }
    },
    {
      func = GetIncomeSpellExtraDamage,
      affect = {
        "incoming_spell_damage_mul"
      }
    },
    {
      func = GetIncomeSpellExtraDamageAdd,
      affect = {
        "incoming_spell_damage_val"
      }
    },
    {
      func = GetIncomeSpellDamageAddAntiNpc,
      affect = {
        "incoming_spell_damage_add_anti_npc"
      }
    }
  },
  [INDEX_REGEN] = {
    {
      func = GetHealCriticalRate,
      affect = {
        "heal_critical_rate",
        "heal_critical_mul"
      }
    },
    {
      func = GetHealCriticalBonus,
      affect = {
        "heal_critical_bonus"
      }
    },
    {
      func = GetHealMulRate,
      affect = {"heal_mul"}
    },
    {
      func = GetHealDamageMulRate,
      affect = {
        "heal_damage_mul"
      }
    },
    {
      func = GetHealMulOnlyHeal,
      affect = {
        "heal_mul_only_heal"
      }
    },
    {
      func = GetHealDamageMulAntiNpc,
      affect = {
        "heal_damage_mul_anti_npc"
      }
    },
    {
      func = GetHealthRegen,
      affect = {
        "health_regen",
        "spi",
        "persistent_health_regen"
      }
    },
    {
      func = GetPersistentHealthRegen,
      affect = {
        "persistent_health_regen",
        "spi"
      }
    },
    {
      func = GetManaRegen,
      affect = {
        "mana_regen",
        "spi",
        "persistent_mana_regen"
      }
    },
    {
      func = GetPersistentManaRegen,
      affect = {
        "persistent_mana_regen",
        "spi"
      }
    },
    {
      func = GetIncomingHealMul,
      affect = {
        "incoming_heal_mul"
      }
    },
    {
      func = GetExpMul,
      affect = {"exp_mul"}
    },
    {
      func = GetDropRageMul,
      affect = {
        "drop_rate_mul"
      }
    },
    {
      func = GetLootGoldMul,
      affect = {
        "loot_gold_mul"
      }
    },
    {
      func = GetDetectStealthRangeMul,
      affect = {
        "detect_stealth_range_mul"
      }
    }
  },
  [INDEX_ELEMENT] = {
    {
      func = GetElementMainHand,
      affect = {}
    },
    {
      func = GetElementOffHand,
      affect = {}
    },
    {
      func = GetElementRanged,
      affect = {}
    },
    {
      func = GetArmorMaterial,
      affect = {}
    }
  }
}
function ReleaseTooltipHandlers(widgets)
  for i = 1, #widgets do
    widgets[i]:ReleaseHandler("OnEnter")
    widgets[i]:ReleaseHandler("OnLeave")
  end
end
local GetModifierColorByValue = function(value, defaultColor)
  if value > -4647030268302991557 and value < 4562254508917369340 then
    value = 0
  end
  if value > 0 then
    return "green"
  elseif value < 0 then
    return "red"
  end
  return defaultColor ~= nil and defaultColor or "default"
end
local GetModifierReserveColorByValue = function(value, defaultColor)
  if value > -4647030268302991557 and value < 4562254508917369340 then
    value = 0
  end
  if value > 0 then
    return "red"
  elseif value < 0 then
    return "green"
  end
  return defaultColor ~= nil and defaultColor or "default"
end
function characterInfo:UpdateDefaultInfoPart()
  characterInfo.level:ChangedLevel(X2Unit:UnitLevel("player"), X2Unit:UnitHeirLevel("player"))
  local templates = X2Unit:GetTargetAbilityTemplates("player")
  if F_UNIT.GetCombinedAbilityName ~= nil then
    local job = F_UNIT.GetCombinedAbilityName(templates[1].index, templates[2].index, templates[3].index)
    characterInfo.job:Show(true)
    characterInfo.job:SetText(job)
  else
    characterInfo.job:Show(false)
  end
  characterInfo.characterName:SetText(tostring(X2Unit:UnitName("player")))
end
function characterInfo:UpdateCommunityPart(visibilitys)
  local factionName = X2Unit:GetFactionName("player")
  if factionName ~= nil then
    local valueLabel = characterInfo.value[INDEX_FACTION]
    valueLabel:SetText(factionName)
    F_TEXT.ApplyAutoEllipsisTooltipText(valueLabel)
  else
    visibilitys[INDEX_FACTION] = false
  end
  visibilitys[3] = false
  visibilitys[4] = false
  visibilitys[5] = false
end
function characterInfo:UpdateRaceInfo()
  local originRace = X2Unit:GetRace()
  local visualRace = X2Unit:GetVisualRace()
  characterInfo.value[INDEX_RACE]:SetText(locale.raceText[originRace])
  local visualRaceInfoPopupBtn = characterInfo.subtitle[INDEX_VISUAL_RACE].visualRaceInfoPopupBtn
  if originRace ~= visualRace then
    characterInfo.value[INDEX_VISUAL_RACE]:SetText(string.format(locale.raceText[visualRace]))
    characterInfo.value[INDEX_VISUAL_RACE].style:SetColorByKey("default")
    local popupBtnEnable = UIParent:GetPermission(UIC_CHARACTER_INFO_VISUAL_RACE) and not X2Unit:IsVisualRaceExpired()
    visualRaceInfoPopupBtn:Enable(popupBtnEnable)
  else
    characterInfo.value[INDEX_VISUAL_RACE]:SetText(string.format(GetUIText(COMMON_TEXT, "not_use")))
    characterInfo.value[INDEX_VISUAL_RACE].style:SetColorByKey("gray")
    visualRaceInfoPopupBtn:Enable(false)
  end
end
function characterInfo:UpdateCrimePart(visibilitys)
  local crimeInfo = X2Player:GetCrimeInfo()
  local crimePoint = tostring(crimeInfo.crimePoint)
  local crimeRecord = tostring(crimeInfo.crimeRecord)
  if (crimePoint == "" or crimePoint == "0") and (crimeRecord == "" or crimeRecord == "0") then
    visibilitys[10] = false
  end
  if crimeRecord == "" or crimeRecord == "0" then
    visibilitys[11] = false
  end
  local point = X2Player:GetJuryPoint()
  local juryPoint = tostring(point)
  if juryPoint == "" or juryPoint == "0" then
    visibilitys[12] = false
  end
  characterInfo.value[INDEX_GEAR_SCORE]:SetText(X2Unit:UnitGearScore("player", true))
  local featureSet = X2Player:GetFeatureSet()
  visibilitys[INDEX_LEADERSHIP_POINT] = featureSet.hero and not X2BattleField:IsInGlobalField() and not X2Indun:IsEntranceIndunMatch()
  visibilitys[INDEX_ACCUMULATED_LEADERSHIP_POINT] = featureSet.hero and not X2BattleField:IsInGlobalField() and not X2Indun:IsEntranceIndunMatch()
end
function characterInfo:UpdateCombatDefaultInfoPart(visibilitys)
  if charInfoStat == nil then
    charInfoStat = X2Unit:UnitInfo("player")
    charInfoModifierStat = X2Unit:UnitModifierInfo("player")
  end
  local itemStartIndex = 15
  for i = 1, #baseInfoTable do
    local sumVal = 0
    local modifierVal = 0
    local rate = 1
    for idx = 1, #baseInfoTable[i].affect do
      if baseInfoTable[i].affectRate then
        rate = baseInfoTable[i].affectRate[idx]
      end
      modifierVal = charInfoModifierStat[baseInfoTable[i].affect[idx]] * rate
      sumVal = sumVal + modifierVal
    end
    characterInfo.value[itemStartIndex + i].style:SetColorByKey(GetModifierColorByValue(sumVal, baseInfoTable[i].defaultColor))
    local str = string.format("%s", baseInfoTable[i].func())
    characterInfo.value[itemStartIndex + i]:SetText(str)
  end
end
function characterInfo:UpdateValue()
  local visibilitys = {}
  for i = 1, #characterInfo.value do
    visibilitys[i] = true
  end
  visibilitys[INDEX_LIVING_POINT] = X2Player:GetFeatureSet().characterInfoLivingPoint and not X2Player:GetFeatureSet().blockSpendableGamePoint
  visibilitys[INDEX_HONOR_POINT] = not X2Player:GetFeatureSet().blockSpendableGamePoint
  self:UpdateDefaultInfoPart()
  self:UpdateRaceInfo()
  self:UpdateCommunityPart(visibilitys)
  self:UpdateCrimePart(visibilitys)
  self:UpdateCombatDefaultInfoPart(visibilitys)
  UpadateBodyAnchors(visibilitys)
end
characterInfo:UpdateValue()
function characterInfo.popupBtn:OnClick()
  local subWindow = characterInfo.mainWindow.subWindow
  if subWindow:IsVisible() then
    subWindow:Show(false)
  else
    MakeDetailCharacterInfo()
    subWindow:Show(true)
  end
end
characterInfo.popupBtn:SetHandler("OnClick", characterInfo.popupBtn.OnClick)
local OnEnter = function(self)
  SetTooltip(locale.faction.show_detail, self)
end
characterInfo.popupBtn:SetHandler("OnEnter", OnEnter)
local widget = characterInfo.value[INDEX_VISUAL_RACE]
function widget:GetExtraInfo()
  return X2Unit:GetVisualRaceExpiredTimeStr()
end
local widget = characterInfo.value[INDEX_MELEE_DPS]
function widget:GetExtraInfo()
  local meleeMinDps = charInfoStat.melee_min_dps
  local meleeMaxDps = charInfoStat.melee_max_dps
  return F_TEXT.SetColonFormat(locale.character.subtitleInfoTooltip.melee_dmg, locale.common.from_to(meleeMinDps, meleeMaxDps))
end
local widget = characterInfo.value[INDEX_RANGED_DPS]
function widget:GetExtraInfo()
  local rangedMinDps = charInfoStat.ranged_min_dps
  local rangedMaxDps = charInfoStat.ranged_max_dps
  return F_TEXT.SetColonFormat(locale.character.subtitleInfoTooltip.ranged_dmg, locale.common.from_to(rangedMinDps, rangedMaxDps))
end
function ApplyDetailTextColor(popupItems, info)
  local sumVal = 0
  local color = "default"
  if info.affect[1] == "ignore_shield_bonus" then
    sumVal = 0
    for i = 1, #info.affect do
      sumVal = sumVal + charInfoModifierStat[info.affect[i]]
    end
    if sumVal ~= 0 then
      color = "green"
    end
  else
    if charInfoStat[info.affect[1]] ~= 0 then
      for idx = 1, #info.affect do
        sumVal = sumVal + charInfoModifierStat[info.affect[idx]]
      end
    end
    if (info.affect[1] == "incoming_damage_mul_anti_npc" or info.affect[1] == "incoming_melee_damage_add_anti_npc" or info.affect[1] == "incoming_spell_damage_add_anti_npc" or info.affect[1] == "incoming_ranged_damage_add_anti_npc") and sumVal ~= 0 then
      color = GetModifierReserveColorByValue(sumVal)
    else
      color = GetModifierColorByValue(sumVal)
    end
  end
  popupItems.style:SetColorByKey(color)
end
function MakeDetailCharacterInfo()
  local GetPlayerAttribute = function(attribute)
    return X2Unit:UnitAttr("player", attribute)
  end
  for j = 1, #characterInfo.mainWindow.subWindow.SubInfoWnd do
    local popupItems = characterInfo.mainWindow.subWindow.SubInfoWnd[j].popupValue
    for dataCount = #detailInfoTable[INDEX_ELEMENT], 1, -1 do
      if detailInfoTable[INDEX_ELEMENT][dataCount] ~= nil and detailInfoTable[INDEX_ELEMENT][dataCount].func == nil then
        table.remove(detailInfoTable[INDEX_ELEMENT], dataCount)
      end
    end
    for dataCount = #detailInfoTable[INDEX_ATTACK], 1, -1 do
      if detailInfoTable[INDEX_ATTACK][dataCount] ~= nil and detailInfoTable[INDEX_ATTACK][dataCount].show ~= nil and detailInfoTable[INDEX_ATTACK][dataCount].show == false then
        table.remove(detailInfoTable[INDEX_ATTACK], dataCount)
      end
    end
    local elements = X2ItemEnchant:GetItemElementList()
    for _, element in ipairs(elements) do
      local elementResistValue = X2ItemEnchant:GetItemElementResist("player", element.elementType)
      local data = {}
      data.func = nil
      data.affect = {}
      data.value = tostring(elementResistValue)
      table.insert(detailInfoTable[INDEX_ELEMENT], data)
    end
    for i = 1, #popupItems do
      ApplyDetailTextColor(popupItems[i], detailInfoTable[j][i])
      if detailInfoTable[j][i].func ~= nil then
        local func = detailInfoTable[j][i].func
        local value = string.format("%s", func())
        popupItems[i]:SetText(value)
        if popupItems[i].subInfo ~= nil and popupItems[i].subInfo == true then
          popupItems[i].style:SetFontSize(FONT_SIZE.MIDDLE)
        end
        if popupItems[i].label ~= nil then
          if popupItems[i].LabelTextkey == "equip_slot_es_mainhand" then
            elementName = X2ItemEnchant:GetWeaponElementName(ES_MAINHAND)
            if elementName ~= nil then
              popupItems[i].label:SetText(string.format("%s (%s)", X2Locale:LocalizeUiText(popupItems[i].LabelTextCategory, popupItems[i].LabelTextkey), elementName))
            else
              popupItems[i].label:SetText(string.format("%s (%s)", X2Locale:LocalizeUiText(popupItems[i].LabelTextCategory, popupItems[i].LabelTextkey), X2Locale:LocalizeUiText(COMMON_TEXT, "armor_none")))
            end
          elseif popupItems[i].LabelTextkey == "equip_slot_es_offhand" then
            elementName = X2ItemEnchant:GetWeaponElementName(ES_OFFHAND)
            if elementName ~= nil then
              popupItems[i].label:SetText(string.format("%s (%s)", X2Locale:LocalizeUiText(popupItems[i].LabelTextCategory, popupItems[i].LabelTextkey), elementName))
            else
              popupItems[i].label:SetText(string.format("%s (%s)", X2Locale:LocalizeUiText(popupItems[i].LabelTextCategory, popupItems[i].LabelTextkey), X2Locale:LocalizeUiText(COMMON_TEXT, "armor_none")))
            end
          elseif popupItems[i].LabelTextkey == "equip_slot_es_ranged" then
            elementName = X2ItemEnchant:GetWeaponElementName(ES_RANGED)
            if elementName ~= nil then
              popupItems[i].label:SetText(string.format("%s (%s)", X2Locale:LocalizeUiText(popupItems[i].LabelTextCategory, popupItems[i].LabelTextkey), elementName))
            else
              popupItems[i].label:SetText(string.format("%s (%s)", X2Locale:LocalizeUiText(popupItems[i].LabelTextCategory, popupItems[i].LabelTextkey), X2Locale:LocalizeUiText(COMMON_TEXT, "armor_none")))
            end
          end
        end
      elseif detailInfoTable[j][i].value ~= nil then
        popupItems[i]:SetText(detailInfoTable[j][i].value)
      end
    end
  end
end
function OnUpdatedCharacterInfo()
  if characterInfo.mainWindow:IsVisible() == false then
    return
  end
  charInfoStat = X2Unit:UnitInfo("player")
  charInfoModifierStat = X2Unit:UnitModifierInfo("player")
  characterInfo:UpdateValue()
  MakeDetailCharacterInfo()
end
local characterInfoEvents = {
  UNIT_EQUIPMENT_CHANGED = function(equipSlot)
    if equipSlot == -1 then
      OnUpdatedCharacterInfo()
      RefeshOptionFrame()
    end
  end,
  LEVEL_CHANGED = OnUpdatedCharacterInfo,
  ABILITY_CHANGED = OnUpdatedCharacterInfo,
  CRIME_REPORTED = OnUpdatedCharacterInfo,
  PLAYER_VISUAL_RACE = OnUpdatedCharacterInfo,
  PLAYER_HONOR_POINT = OnUpdatedCharacterInfo,
  BUFF_UPDATE = function(action, target)
    if target == "character" then
      OnUpdatedCharacterInfo()
    end
  end,
  DEBUFF_UPDATE = function(action, target)
    if target == "character" then
      OnUpdatedCharacterInfo()
    end
  end,
  SKILL_LEARNED = OnUpdatedCharacterInfo,
  SKILL_CHANGED = OnUpdatedCharacterInfo,
  SKILLS_RESET = OnUpdatedCharacterInfo,
  TOGGLE_WALK = OnUpdatedCharacterInfo,
  PLAYER_JURY_POINT = OnUpdatedCharacterInfo,
  MOVE_SPEED_CHANGE = OnUpdatedCharacterInfo,
  APPELLATION_GAINED = function()
    local visiibilitys = {}
    characterInfo:UpdateCommunityPart(visiibilitys)
  end,
  APPELLATION_CHANGED = function(stringId)
    if not W_UNIT.IsMyUnitId(stringId) then
      return
    end
    local visiibilitys = {}
    characterInfo:UpdateCommunityPart(visiibilitys)
  end,
  OPTION_RESET = UpdateCharacterVisual,
  REFRESH_COMBAT_RESOURCE = OnUpdatedCharacterInfo,
  TRANSFORM_COMBAT_RESOURCE = OnUpdatedCharacterInfo,
  HEIR_LEVEL_UP = function(myUnit)
    if myUnit == true then
      OnUpdatedCharacterInfo()
    end
  end
}
characterInfo.mainWindow:SetHandler("OnEvent", function(this, event, ...)
  characterInfoEvents[event](...)
end)
RegistUIEvent(characterInfo.mainWindow, characterInfoEvents)
function characterInfo.mainWindow:ShowProc()
  charInfoStat = X2Unit:UnitInfo("player")
  charInfoModifierStat = X2Unit:UnitModifierInfo("player")
  characterInfo:UpdateValue()
  ToggleEquippedItemShow(true)
end
function characterInfo.mainWindow:OnHide()
  ToggleEquippedItemShow(false)
  ToggleVisualOptionFrame(false)
  characterInfo.mainWindow.subWindow:Show(false)
end
characterInfo.mainWindow:SetHandler("OnHide", characterInfo.mainWindow.OnHide)
if X2Player:GetFeatureSet().shopOnUI then
  local livingPointPopupBtn = characterInfo.subtitle[INDEX_LIVING_POINT].livingPointPopupBtn
  function livingPointPopupBtn:OnClick()
    DirectOpenStore(SHOP_OPEN_LIVINGPOINT)
  end
  livingPointPopupBtn:SetHandler("OnClick", livingPointPopupBtn.OnClick)
  local honorPointPopupBtn = characterInfo.subtitle[INDEX_HONOR_POINT].honorPointPopupBtn
  function honorPointPopupBtn:OnClick()
    DirectOpenStore(SHOP_OPEN_HONORPOINT)
  end
  honorPointPopupBtn:SetHandler("OnClick", honorPointPopupBtn.OnClick)
end
local visualRaceInfoPopupBtn = characterInfo.subtitle[INDEX_VISUAL_RACE].visualRaceInfoPopupBtn
function visualRaceInfoPopupBtn:OnClick()
  local func = function(wnd)
    function wnd:OkProc()
      X2Unit:RequestResetVisualRace()
    end
    wnd:SetTitle(GetCommonText("reset_visual_race_title"))
    local textData = {
      [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("reset_visual_race_comment")
    }
    wnd:RegisterStack(W_MODULE:Create("textbox", wnd, W_MODULE.TYPES.TEXTBOX, textData))
    textData = {
      [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("reset_visual_race_warning")
    }
    wnd:RegisterStack(W_MODULE:Create("textbox", wnd, W_MODULE.TYPES.TEXTBOX, textData))
  end
  X2DialogManager:RequestDialog(func, characterInfo.mainWindow:GetId())
end
visualRaceInfoPopupBtn:SetHandler("OnClick", visualRaceInfoPopupBtn.OnClick)
local UpdatePermission = function()
  if X2Player:GetFeatureSet().shopOnUI then
    local livingPointPopupBtn = characterInfo.subtitle[INDEX_LIVING_POINT].livingPointPopupBtn
    local honorPointPopupBtn = characterInfo.subtitle[INDEX_HONOR_POINT].honorPointPopupBtn
    livingPointPopupBtn:Enable(UIParent:GetPermission(UIC_STORE))
    honorPointPopupBtn:Enable(UIParent:GetPermission(UIC_STORE))
  end
  local visiibilitys = {}
  characterInfo:UpdateCommunityPart(visiibilitys)
end
UIParent:SetEventHandler("UI_PERMISSION_UPDATE", UpdatePermission)
UpdatePermission()
