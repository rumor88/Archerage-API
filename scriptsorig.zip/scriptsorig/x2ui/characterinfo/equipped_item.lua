local equippedItem
local CreateEquipSlotWindow = function()
  local AUXGROUP = {
    ES_EAR_2,
    ES_FINGER_2,
    ES_OFFHAND,
    ES_COSPLAYLOOKS
  }
  local slotsByIndex = {}
  local window = SetViewOfEquipSlotWindow()
  local arrow = DrawArrowMoveAnim(window.optionButton)
  arrow:AddAnchor("RIGHT", window.optionButton, "LEFT", -30, 0)
  if UIParent:GetUIStamp("equippedItemOpenCount") == nil then
    UIParent:SetUIStamp("equippedItemOpenCount", "0")
  end
  local function SetSlotType(slotIdx, slot)
    slotsByIndex[slotIdx] = slot
    slot.slotIdx = slotIdx
  end
  local function GetSlotBySlotIdx(slotIdx)
    return slotsByIndex[slotIdx]
  end
  local function IsAuxEquipSlot(slotNumber)
    for i = 1, #AUXGROUP do
      local auxSlot = AUXGROUP[i]
      if auxSlot == slotNumber then
        return true
      end
    end
    return false
  end
  local IsExistPreviousSlot = function(itemCount, index)
    if index > 0 then
      return true
    end
    return false
  end
  local function IsExistNextSlot(itemCount, index)
    local value = index * window.bagslotItemMaxCnt
    if itemCount - value > window.bagslotItemMaxCnt then
      return true
    end
    return false
  end
  local function CorrectSlotIndex(bagslot, itemCount)
    if bagslot.index < 0 then
      bagslot.index = 0
    end
    local value = bagslot.index * window.bagslotItemMaxCnt
    local diff = itemCount - value
    if diff > 0 then
      return
    end
    bagslot.index = bagslot.index - (math.floor(math.abs(diff) / window.bagslotItemMaxCnt) + 1)
  end
  local FireSystemMsgCanUseBattleField = function()
    if UIParent:GetPermission(UIC_PLAYER_EQUIPMENT) == false then
      AddMessageToSysMsgWindow(X2Locale:LocalizeUiText(ERROR_MSG, "CANNOT_USE_IN_BATTLE_FIELD"))
      return true
    end
    return false
  end
  local AddEquipmentTooltipFunction = function(target, tip, equipped, slotIdx)
    target:SetInfo(tip)
    function target:OnEnter()
      HideTooltip()
      if lookType == 0 then
        local text = GetSlotText(slotIdx)
        SetTooltip(text, self, true, true)
      else
        ShowTooltip(tip, self, 1, equipped)
      end
    end
    function target:OnLeave()
      HideTooltip()
    end
    target:SetHandler("OnEnter", target.OnEnter)
    target:SetHandler("OnLeave", target.OnLeave)
  end
  local function ResetSlotSide(isLeftSide, bagslot, itemCount)
    local up = bagslot.up
    local down = bagslot.down
    local width = 50
    if itemCount > window.bagslotItemMaxCnt then
      up:Show(true)
      up:Enable(false)
      down:Show(true)
      down:Enable(false)
    end
    if IsExistPreviousSlot(itemCount, bagslot.index) then
      up:Enable(true)
      width = width + 10
    end
    if IsExistNextSlot(itemCount, bagslot.index) then
      down:Enable(true)
      if bagslot.index < 1 then
        width = width + 10
      else
      end
    end
    width = width + window.bagslotItemMaxCnt * 33
    bagslot:SetWidth(width)
  end
  local function RegistEquipSlotTooltip()
    for i = 1, #PLAYER_EQUIP_SLOTS do
      local button = window.slot[i]
      local function OnEnter()
        local slotIdx = PLAYER_EQUIP_SLOTS[i]
        local tooltip = X2Equipment:GetEquippedItemTooltipText("player", slotIdx)
        if tooltip.itemType == 0 then
          local text = GetSlotText(slotIdx)
          SetTooltip(text, button)
        else
          ShowTooltip(tooltip, button, 1, true)
        end
      end
      button:SetHandler("OnEnter", OnEnter)
      local OnHide = function()
        HideTooltip()
      end
      button:SetHandler("OnLeave", OnHide)
    end
  end
  local function RegistHandlerToEquipSlot()
    for i = 1, #PLAYER_EQUIP_SLOTS do
      local bagButton = window.bagButton[i]
      local bagslot = window.bagslot[i]
      local equipslot = window.slot[i]
      local slotIdx = PLAYER_EQUIP_SLOTS[i]
      SetSlotType(slotIdx, equipslot)
      function equipslot:PreClick()
        if X2Input:IsShiftKeyDown() and X2Chat:IsActivatedChatInput() then
          local linkText = X2Equipment:GetLinkText(self.slotIdx)
          if AddLinkItem(linkText) == true then
            return true
          end
          return true
        end
        return false
      end
      equipslot:SetHandler("PreClick", equipslot.PreClick)
      function bagButton:OnClick(arg)
        if FireSystemMsgCanUseBattleField() == true then
          return
        end
        if self.showSlots ~= nil and arg == "LeftButton" then
          if self.showSlots then
            self.showSlots = false
            self:SetStyle(self.openSkin)
          else
            self.showSlots = true
            self:SetStyle(self.closeSkin)
          end
          bagslot:Show(self.showSlots)
        end
      end
      bagButton:SetHandler("OnClick", bagButton.OnClick)
      local up = bagslot.up
      local down = bagslot.down
      function up:GetDx()
        return 1
      end
      function down:GetDx()
        return 1
      end
      function up:OnClick(arg)
        if arg == "LeftButton" then
          local dx = self:GetDx()
          bagslot.index = bagslot.index - dx
          window:Update()
        end
      end
      up:SetHandler("OnClick", up.OnClick)
      function down:OnClick(arg)
        if arg == "LeftButton" then
          local dx = self:GetDx()
          bagslot.index = bagslot.index + dx
          window:Update()
        end
      end
      down:SetHandler("OnClick", down.OnClick)
      for j = 1, window.bagslotItemMaxCnt do
        local slot = bagslot.slot[j]
        function slot:OnClickProc(arg)
          if arg == "LeftButton" then
            if self.equipItem == nil then
              return
            end
            bagButton:OnClick("LeftButton")
            X2Bag:EquipBagItem(self.equipItem, self.isAux)
            window:Update()
          end
        end
      end
    end
  end
  local LeftClickFuncOptionBtn = function()
    ToggleVisualOptionFrame()
  end
  ButtonOnClickHandler(window.optionButton, LeftClickFuncOptionBtn)
  local function OnHide()
    arrow:Animation(false, false)
    local prelimWnd = window.preliminaryEquipWnd
    if prelimWnd ~= nil and prelimWnd:IsVisible() then
      prelimWnd:Show(false)
    end
  end
  window:SetHandler("OnHide", OnHide)
  function window:Update()
    local HideBagButton = function(button)
      button:Show(false)
      button.showSlots = false
      button:SetStyle(button.openSkin)
    end
    local function ClearBagslotInfo(bagslot)
      for i = 1, self.bagslotItemMaxCnt do
        bagslot.slot[i].equipItem = nil
        bagslot.slot[i]:SetInfo(nil)
      end
      bagslot.up:Show(false)
      bagslot.down:Show(false)
    end
    for i = 1, #PLAYER_EQUIP_SLOTS do
      local slotIdx = PLAYER_EQUIP_SLOTS[i]
      local tooltip = X2Equipment:GetEquippedItemTooltipText("player", slotIdx)
      local cooldownBtn = self.slot[i]
      cooldownBtn:SetInfo(tooltip)
      cooldownBtn.id = tooltip.skillType
      local items = X2Bag:FindBagItemByEquipSlot(ISLOT_EQUIPMENT, slotIdx)
      local bagButton = self.bagButton[i]
      local bagslot = self.bagslot[i]
      local up = bagslot.up
      local down = bagslot.down
      if items ~= nil and #items > 0 then
        bagButton:Show(true)
        local itemCount = #items
        ClearBagslotInfo(bagslot)
        CorrectSlotIndex(bagslot, itemCount)
        ResetSlotSide(IsLeftSide(i), bagslot, itemCount)
        local index = 1
        bagslot.max = itemCount / self.bagslotItemMaxCnt - 1
        for j = bagslot.index * self.bagslotItemMaxCnt + 1, itemCount do
          local slot = bagslot.slot[index]
          local item = items[j]
          slot.equipItem = item.slot
          slot.isAux = IsAuxEquipSlot(slotIdx)
          AddEquipmentTooltipFunction(slot, item, false, slotIdx)
          if index >= self.bagslotItemMaxCnt then
            break
          end
          index = index + 1
        end
      else
        HideBagButton(bagButton)
        bagslot:Show(false)
        up:Show(false)
        down:Show(false)
      end
      SetTooltipDelayTime(0)
    end
  end
  function window:ShowProc()
    self.leftSlots:Show(self:IsVisible())
    self.rightSlots:Show(self:IsVisible())
    local openCount = UIParent:GetUIStamp("equippedItemOpenCount")
    if tonumber(openCount) >= self.bagslotItemMaxCnt then
      return
    end
    UIParent:SetUIStamp("equippedItemOpenCount", tostring(openCount + 1))
    arrow:Animation(true, false)
  end
  function window:AninForEquipped(index)
    if not characterInfo.mainWindow:IsVisible() then
      return
    end
    if index == -1 then
      return
    end
    if X2Equipment:ItemIdentifier(index) == 0 then
      return
    end
    local slot = GetSlotBySlotIdx(index)
    slot:SetScaleAnimation(4608083138725491507, 1, 4602678819172646912, 4599075939470750515, "CENTER")
    slot:SetStartAnimation(false, true)
    self:Update()
  end
  local equipSlotEvents = {
    UNIT_EQUIPMENT_CHANGED = function(equipSlot)
      if equipSlot == -1 then
        window:Update()
      else
        window:AninForEquipped(equipSlot)
      end
    end,
    LEVEL_CHANGED = function()
      window:Update()
    end,
    ABILITY_CHANGED = function()
      window:Update()
    end,
    CRIME_REPORTED = function()
      window:Update()
    end,
    PLAYER_HONOR_POINT = function()
      window:Update()
    end,
    SKILL_LEARNED = function()
      window:Update()
    end,
    SKILL_CHANGED = function()
      window:Update()
    end,
    SKILLS_RESET = function()
      window:Update()
    end
  }
  window:SetHandler("OnEvent", function(this, event, ...)
    equipSlotEvents[event](...)
  end)
  RegistUIEvent(window, equipSlotEvents)
  RegistEquipSlotTooltip()
  RegistHandlerToEquipSlot()
  window:Update()
  return window
end
function ToggleEquippedItemShow(isShow)
  if isShow == true then
    equippedItem:Update()
    equippedItem:Show(true)
  else
    equippedItem:Show(false)
  end
  if equippedItem.equipSlotReinforceBtn ~= nil then
    if isShow == true then
      HideReinForceMode()
    else
      HideEquipSlotReinForceWnd()
    end
  end
end
function ToggleEquipSlotReinForceBtnShow(isShow)
  if isShow == nil then
    isShow = false
  end
  if X2EquipSlotReinforce:SuitableLevelForEquipSlotReinforce() == false then
    equippedItem.equipSlotReinforceBtn.equip:Show(false)
    equippedItem.equipSlotReinforceBtn.reinforce:Show(false)
    equippedItem.equipSlotReinforceBtn.detailBtn:Show(false)
    if equippedItem.equipSlotReinforceBtn.bundleEffect ~= nil then
      equippedItem.equipSlotReinforceBtn.bundleEffect:Show(false)
    end
    if equippedItem.equipSlotReinforceBtn.bundleEffectLevel ~= nil then
      equippedItem.equipSlotReinforceBtn.bundleEffectLevel:Show(false)
    end
  else
    equippedItem.equipSlotReinforceBtn.equip:Show(isShow)
    equippedItem.equipSlotReinforceBtn.reinforce:Show(not isShow)
    equippedItem.equipSlotReinforceBtn.detailBtn:Show(isShow)
    if X2Player:GetFeatureSet().equipSlotBundleEffect == true then
      equippedItem.equipSlotReinforceBtn.bundleEffect:Show(not isShow)
      equippedItem.equipSlotReinforceBtn.bundleEffectLevel:Show(not isShow)
      if not isShow then
        equippedItem.equipSlotReinforceBtn:UpdateBundleInfo()
      end
    end
  end
end
function ToggleEquippedItemSlotShow(isShow)
  if isShow == nil then
    isShow = false
  end
  equippedItem.optionButton:Show(isShow)
  equippedItem.leftSlots:Show(isShow)
  equippedItem.rightSlots:Show(isShow)
  if X2Player:GetFeatureSet().preliminaryEquipment == true and equippedItem.preliminaryEquipWnd ~= nil then
    equippedItem.preliminaryEquipWnd:ToggleCtrlShow(isShow)
  end
end
function GetLookOptionFrameAnchor()
  return equippedItem.leftSlots
end
function CreateEquippedItemWindows()
  equippedItem = CreateEquipSlotWindow()
  if equippedItem ~= nil then
    if X2Player:GetFeatureSet().preliminaryEquipment == true then
      equippedItem.preliminaryEquipWnd = CreatePreliminaryEquipmentsWindow(equippedItem)
    end
    if X2Player:GetFeatureSet().equipSlotEnchantment == true then
      CreateEquipSlotReinforceWindow(equippedItem)
    end
  end
end
