CHARACTER_INFO_SUB_WND_TAB = {
  ATTACK = 1,
  DEFENCE = 2,
  RECOVERY = 3,
  ELEMENT = 4
}
local SetViewOfCharacterInfoSubWindow = function(id, parent)
  local sideMargin, titleMargin, bottomMargin = GetWindowMargin()
  local window = CreateWindow(id, parent)
  window:SetWidth(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_430))
  window:SetTitle(locale.faction.detail)
  local tabInfos = {
    [CHARACTER_INFO_SUB_WND_TAB.ATTACK] = {
      tooltip = X2Locale:LocalizeUiText(CHARACTER_TITLE_TEXT, locale.character.title[CHARACTER_INFO_SUB_WND_TAB.ATTACK]),
      buttonStyle = BUTTON_CONTENTS.CHARACTER_INFO_SUB_TAB_ATTACK
    },
    [CHARACTER_INFO_SUB_WND_TAB.DEFENCE] = {
      tooltip = X2Locale:LocalizeUiText(CHARACTER_TITLE_TEXT, locale.character.title[CHARACTER_INFO_SUB_WND_TAB.DEFENCE]),
      buttonStyle = BUTTON_CONTENTS.CHARACTER_INFO_SUB_TAB_DEFENCE
    },
    [CHARACTER_INFO_SUB_WND_TAB.RECOVERY] = {
      tooltip = X2Locale:LocalizeUiText(CHARACTER_TITLE_TEXT, locale.character.title[CHARACTER_INFO_SUB_WND_TAB.RECOVERY]),
      buttonStyle = BUTTON_CONTENTS.CHARACTER_INFO_SUB_TAB_RECOVERY
    },
    [CHARACTER_INFO_SUB_WND_TAB.ELEMENT] = {
      tooltip = X2Locale:LocalizeUiText(CHARACTER_TITLE_TEXT, locale.character.title[CHARACTER_INFO_SUB_WND_TAB.ELEMENT]),
      buttonStyle = BUTTON_CONTENTS.CHARACTER_INFO_SUB_TAB_ELEMENT
    }
  }
  local tab = W_TAB.CreateImageTab("tab", window)
  tab:AddAnchor("TOPLEFT", window, MARGIN.WINDOW_SIDE, MARGIN.WINDOW_TITLE)
  tab:AddAnchor("BOTTOMRIGHT", window, -MARGIN.WINDOW_SIDE, -MARGIN.WINDOW_SIDE)
  tab:AddTabs(tabInfos)
  window.SubInfoWnd = {}
  local AttackInfoSubWnd, height_attack = CreateCharacterTabInfoSubWindow("attackinfosubTab", tab.window[CHARACTER_INFO_SUB_WND_TAB.ATTACK], CHARACTER_INFO_SUB_WND_TAB.ATTACK)
  F_LAYOUT.AttachAnchor(AttackInfoSubWnd, tab.window[CHARACTER_INFO_SUB_WND_TAB.ATTACK])
  AttackInfoSubWnd:Show(true)
  window.SubInfoWnd[CHARACTER_INFO_SUB_WND_TAB.ATTACK] = AttackInfoSubWnd
  window:SetHeight(height_attack)
  local DefenceInfoSubWnd, height_defence = CreateCharacterTabInfoSubWindow("defenceinfosubTab", tab.window[CHARACTER_INFO_SUB_WND_TAB.DEFENCE], CHARACTER_INFO_SUB_WND_TAB.DEFENCE)
  F_LAYOUT.AttachAnchor(DefenceInfoSubWnd, tab.window[CHARACTER_INFO_SUB_WND_TAB.DEFENCE])
  DefenceInfoSubWnd:Show(true)
  window.SubInfoWnd[CHARACTER_INFO_SUB_WND_TAB.DEFENCE] = DefenceInfoSubWnd
  local RecoveryInfoSubWnd, height_recovery = CreateCharacterTabInfoSubWindow("recoveryinfosubTab", tab.window[CHARACTER_INFO_SUB_WND_TAB.RECOVERY], CHARACTER_INFO_SUB_WND_TAB.RECOVERY)
  F_LAYOUT.AttachAnchor(RecoveryInfoSubWnd, tab.window[CHARACTER_INFO_SUB_WND_TAB.RECOVERY])
  RecoveryInfoSubWnd:Show(true)
  window.SubInfoWnd[CHARACTER_INFO_SUB_WND_TAB.RECOVERY] = RecoveryInfoSubWnd
  local elements = X2ItemEnchant:GetItemElementList()
  for _, element in ipairs(elements) do
    local data = {}
    data.name = element.name
    data.tooltip = ""
    table.insert(locale.character.popupSubtitle[INDEX_ELEMENT][INDEX_ELEMENT_RESIST], data)
  end
  local ElementInfoSubWnd, height_element = CreateCharacterTabInfoSubWindow("elementinfosubTab", tab.window[CHARACTER_INFO_SUB_WND_TAB.ELEMENT], CHARACTER_INFO_SUB_WND_TAB.ELEMENT)
  F_LAYOUT.AttachAnchor(ElementInfoSubWnd, tab.window[CHARACTER_INFO_SUB_WND_TAB.ELEMENT])
  ElementInfoSubWnd:Show(true)
  window.SubInfoWnd[CHARACTER_INFO_SUB_WND_TAB.ELEMENT] = ElementInfoSubWnd
  return window
end
function CreateCharacterInfoSubWindow(id, parent)
  local window = SetViewOfCharacterInfoSubWindow(id, parent)
  return window
end
