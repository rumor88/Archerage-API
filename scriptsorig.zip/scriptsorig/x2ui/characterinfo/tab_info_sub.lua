function CreateCharacterTabInfoSubWindow(id, parent, tabIndex)
  local window = CreateEmptyWindow(id, parent)
  local sideMargin, titleMargin, bottomMargin = GetWindowMargin()
  local max_width = parent:GetWidth()
  local label_width = max_width * 4604029899060858061
  local value_width = max_width * 4599976659396224614
  local item_height = 16
  local item_offset = 20
  window.popupItemWindow = {}
  window.popupSubtitle = {}
  window.popupValue = {}
  window.group = {}
  for i = 1, #locale.character.popupSubtitle[tabIndex] do
    local group = window:CreateChildWidget("window", "group", i, true)
    group:Show(true)
    group:SetWidth(max_width)
    if tabIndex == INDEX_REGEN then
      local title = X2Locale:LocalizeUiText(CHARACTER_SUBTITLE_TEXT, locale.character.subtitle[i])
      group:SetTitleText(title)
      group.titleStyle:SetFontSize(FONT_SIZE.XLARGE)
      group.titleStyle:SetAlign(ALIGN_TOP_LEFT)
      group.titleStyle:SetColorByKey("middle_title")
    elseif tabIndex == INDEX_ELEMENT then
      local title = X2Locale:LocalizeUiText(CHARACTER_SUBTITLE_TEXT, locale.character.elementSubtitle[i])
      group:SetTitleText(title)
      group.titleStyle:SetFontSize(FONT_SIZE.XLARGE)
      group.titleStyle:SetAlign(ALIGN_TOP_LEFT)
      group.titleStyle:SetColorByKey("middle_title")
    end
    if i == 1 then
      group:AddAnchor("TOPLEFT", window, 0, 10)
    else
      group:AddAnchor("TOPLEFT", window.group[i - 1], "BOTTOMLEFT", 0, sideMargin)
    end
    if i ~= #locale.character.popupSubtitle[tabIndex] then
      local line = CreateLine(group, "TYPE1")
      line:AddAnchor("TOPLEFT", group, "BOTTOMLEFT", 0, sideMargin / 2)
      line:AddAnchor("TOPRIGHT", group, "BOTTOMRIGHT", 0, sideMargin / 2)
    end
    window.group[i] = group
  end
  local itemIndex = 1
  for i = 1, #locale.character.popupSubtitle[tabIndex] do
    for k = 1, #locale.character.popupSubtitle[tabIndex][i] do
      local subTitleInfo = locale.character.popupSubtitle[tabIndex][i][k]
      local bShow = true
      if subTitleInfo.show ~= nil then
        bShow = subTitleInfo.show
      end
      if bShow then
        local itemWindow = window:CreateChildWidget("emptywidget", "popupItemWindow", itemIndex, true)
        itemWindow:Show(true)
        itemWindow:SetExtent(max_width, item_height)
        local label = window:CreateChildWidget("label", "popupSubtitle", itemIndex, true)
        label:AddAnchor("LEFT", itemWindow, 0, 0)
        label:SetHeight(item_height)
        label:SetAutoResize(true)
        local strTitle
        if subTitleInfo.name then
          strTitle = subTitleInfo.name
        elseif subTitleInfo.category then
          strTitle = X2Locale:LocalizeUiText(subTitleInfo.category, subTitleInfo.key)
        else
          strTitle = locale.attribute(subTitleInfo.key)
        end
        if subTitleInfo.subInfo ~= nil and subTitleInfo.subInfo == true then
          strTitle = string.format("- %s", strTitle)
          label.style:SetFontSize(FONT_SIZE.MIDDLE)
        end
        label:SetText(strTitle)
        if label_width <= label.style:GetTextWidth(label:GetText()) then
          label:SetWidth(label_width)
          label:SetAutoResize(false)
          label.style:SetEllipsis(true)
        end
        if subTitleInfo.tooltip then
          label.tooltipText = subTitleInfo.tooltip
        elseif subTitleInfo.key then
          label.tooltipText = GetCharInfoTooltip(subTitleInfo.key)
        end
        label.style:SetColorByKey("default")
        label.style:SetAlign(ALIGN_LEFT)
        local widgetType = "label"
        if subTitleInfo.widgetType then
          widgetType = subTitleInfo.widgetType
        end
        local value = window:CreateChildWidget(widgetType, "popupValue", itemIndex, true)
        value:SetExtent(value_width, item_height)
        value:AddAnchor("RIGHT", itemWindow, 0, 0)
        if subTitleInfo.key == "equip_slot_es_mainhand" or subTitleInfo.key == "equip_slot_es_offhand" or subTitleInfo.key == "equip_slot_es_ranged" then
          value.label = label
          value.LabelTextCategory = subTitleInfo.category
          value.LabelTextkey = subTitleInfo.key
        end
        if subTitleInfo.subInfo ~= nil and subTitleInfo.subInfo == true then
          value.subInfo = true
        end
        value.style:SetColorByKey("blue")
        value.style:SetAlign(ALIGN_LEFT)
        itemIndex = itemIndex + 1
      end
    end
  end
  SetTooltipHandlers(window.popupSubtitle)
  local popup_offset = 0
  local height_offset = 0
  if tabIndex == INDEX_REGEN or tabIndex == INDEX_ELEMENT then
    popup_offset = 25
    height_offset = sideMargin
  end
  local group_height = {}
  local lastNum = 1
  for m = 1, #locale.character.popupSubtitle[tabIndex] do
    local info = locale.character.popupSubtitle[tabIndex][m]
    local infoCount = 0
    for k = 1, #locale.character.popupSubtitle[tabIndex][m] do
      local subTitleInfo = locale.character.popupSubtitle[tabIndex][m][k]
      if subTitleInfo.show ~= nil then
        if subTitleInfo.show == true then
          infoCount = infoCount + 1
        end
      else
        infoCount = infoCount + 1
      end
    end
    local startIdx = lastNum
    local endIdx = lastNum + (infoCount - 1)
    lastNum = endIdx + 1
    local height = 0
    for i = startIdx, endIdx do
      window.popupItemWindow[i]:AddAnchor("TOPLEFT", window.group[m], 0, (i - startIdx) * item_offset + popup_offset)
      height = height + item_offset
    end
    group_height[m] = height + height_offset
  end
  local windowHeight = sideMargin * 7 + titleMargin
  for i = 1, #group_height do
    windowHeight = windowHeight + group_height[i]
    window.group[i]:SetHeight(group_height[i])
  end
  window:SetHeight(windowHeight)
  return window, windowHeight
end
