local featureSet = X2Player:GetFeatureSet()
local sideMargin, titleMargin, bottomMargin = GetWindowMargin()
local layoutSet = GetLayoutSetCharacterInfo()
local max_width = layoutSet.windowWidth - sideMargin * 4612811918334230528
local item_width = max_width - 10
local item_height = 16
local item_offset = 20
local group_inset = sideMargin / 4608083138725491507
CreateEquippedItemWindows()
characterInfo = {}
characterInfo.mainWindow = CreateWindow("characterInfo.mainWindow", "UIParent")
characterInfo.mainWindow:Show(false)
characterInfo.mainWindow:SetExtent(layoutSet.windowWidth, 450)
characterInfo.mainWindow:AddAnchor("TOPLEFT", "UIParent", 28, 60)
characterInfo.mainWindow:SetTitle(GetUIText(COMMON_TEXT, "character_main_widget_title"))
characterInfo.mainWindow:SetSounds("character_info")
local emptyWindow = characterInfo.mainWindow:CreateChildWidget("emptywidget", "emptyWindow", 0, true)
emptyWindow:Show(true)
emptyWindow:AddAnchor("TOPLEFT", characterInfo.mainWindow, sideMargin, titleMargin)
emptyWindow:AddAnchor("BOTTOMRIGHT", characterInfo.mainWindow, -sideMargin, -sideMargin)
characterInfo.mainWindow.group = {}
for i = 1, #baseWindowSubTitle do
  local group = characterInfo.mainWindow:CreateChildWidget("emptywidget", "group", i, true)
  group:SetWidth(max_width)
  if i == GROUP_DEFAULTINFO then
    group:AddAnchor("TOPLEFT", emptyWindow, 0, 0)
  elseif i == GROUP_COMMUNITY then
    group:AddAnchor("TOPLEFT", characterInfo.mainWindow.group[i - 1], "BOTTOMLEFT", 0, sideMargin / 2)
  else
    group:AddAnchor("TOPLEFT", characterInfo.mainWindow.group[i - 1], "BOTTOMLEFT", 0, sideMargin)
  end
  if i ~= GROUP_DEFAULTINFO and i ~= GROUP_SPEED then
    local line = CreateLine(group, "TYPE1")
    line:AddAnchor("TOPLEFT", group, "BOTTOMLEFT", 0, sideMargin / 2)
    line:AddAnchor("TOPRIGHT", group, "BOTTOMRIGHT", 0, sideMargin / 2)
    group.line = line
  end
end
local group = {}
group.defaultInfo = characterInfo.mainWindow.group[1]
group.community = characterInfo.mainWindow.group[2]
group.raceInfo = characterInfo.mainWindow.group[3]
group.gamePoint = characterInfo.mainWindow.group[4]
group.contentsPoint = characterInfo.mainWindow.group[5]
group.combatDefaultInfo = characterInfo.mainWindow.group[6]
group.baseStats = characterInfo.mainWindow.group[7]
group.speed = characterInfo.mainWindow.group[8]
characterInfo.window = {}
characterInfo.subtitle = {}
characterInfo.value = {}
local itemIndex = 1
for i = 1, #baseWindowSubTitle do
  for k = 1, #baseWindowSubTitle[i] do
    local subTitleInfo = baseWindowSubTitle[i][k]
    local window = CreateEmptyWindow(string.format("subTitle[%d]", itemIndex), characterInfo.mainWindow)
    window:Show(true)
    window:SetExtent(item_width, item_height)
    local label = window:CreateChildWidget("label", "label", 0, true)
    label:Show(true)
    label:SetExtent(item_width / 2, item_height)
    label:AddAnchor("LEFT", window, 0, 0)
    local strTitle
    if subTitleInfo.category then
      strTitle = X2Locale:LocalizeUiText(subTitleInfo.category, subTitleInfo.key)
    else
      strTitle = locale.attribute(subTitleInfo.key)
    end
    label:SetText(strTitle)
    label.style:SetColorByKey("middle_title")
    label.style:SetAlign(ALIGN_LEFT)
    label.tooltipText = GetCharInfoTooltip(subTitleInfo.key)
    local value
    if subTitleInfo.createFunc then
      value = subTitleInfo.createFunc(window, item_width / 2, item_height)
    else
      value = CreateDefaultSubTitle("value", window, item_width / 2, item_height)
    end
    value:Show(true)
    value:AddAnchor("TOPLEFT", label, "TOPRIGHT", 0, 0)
    if subTitleInfo.key ~= "appellation" then
      if subTitleInfo.color then
        value.style:SetColorByKey(subTitleInfo.color)
      else
        value.style:SetColorByKey("default")
      end
    end
    characterInfo.window[itemIndex] = window
    characterInfo.subtitle[itemIndex] = label
    characterInfo.value[itemIndex] = value
    itemIndex = itemIndex + 1
  end
end
SetTooltipHandlers(characterInfo.subtitle)
SetExtraTooltipHandlers(characterInfo.value)
group.defaultInfo:SetHeight(66)
local bg = CreateContentBackground(group.defaultInfo, "TYPE2", "alpha20")
bg:AddAnchor("TOPLEFT", group.defaultInfo, -10, 0)
bg:AddAnchor("BOTTOMRIGHT", group.defaultInfo, 20, 0)
characterInfo.level = W_UNIT.CreateLevelLabel("level", group.defaultInfo, LEVEL_LAYOUT_TYPES.HAS_BACKGROUND)
characterInfo.level:AddAnchor("LEFT", group.defaultInfo, -10, 0)
local levelNameMargin = 5
local yOffset = 9
local nameWidth = max_width - characterInfo.level:GetWidth() - levelNameMargin
if X2Player:IsEnabledHeirLevel() and not featureSet.useHeirSkill then
  characterInfo.upHeirlevelBtn = CreateHeirLevelUpButton("upHeirlevelBtn", group.defaultInfo, false)
  characterInfo.upHeirlevelBtn:AddAnchor("RIGHT", bg, -15, 0)
  nameWidth = nameWidth - characterInfo.upHeirlevelBtn:GetWidth()
end
characterInfo.characterName = group.defaultInfo:CreateChildWidget("label", "characterName", 0, true)
characterInfo.characterName:SetExtent(nameWidth, 15)
characterInfo.characterName.style:SetFontSize(FONT_SIZE.XLARGE)
characterInfo.characterName:AddAnchor("LEFT", characterInfo.level, "RIGHT", levelNameMargin, yOffset)
characterInfo.characterName.style:SetColorByKey("green")
characterInfo.characterName.style:SetAlign(ALIGN_LEFT)
characterInfo.characterName.style:SetEllipsis(true)
characterInfo.job = group.defaultInfo:CreateChildWidget("label", "job", 0, true)
characterInfo.job:SetExtent(nameWidth, 15)
characterInfo.job:AddAnchor("LEFT", characterInfo.level, "RIGHT", levelNameMargin, -yOffset)
characterInfo.job.style:SetColorByKey("default")
characterInfo.job.style:SetAlign(ALIGN_LEFT)
characterInfo.job.style:SetEllipsis(true)
local groupSubtitleX = 0
function UpdateLabelAnchors(target, startIndex, endIndex, visibilitys, itemHeight)
  local yOffset
  local height = 0
  local skip = 0
  for i = startIndex, endIndex do
    yOffset = (i - (startIndex + skip)) * itemHeight
    characterInfo.window[i]:AddAnchor("TOPLEFT", target, "TOPLEFT", groupSubtitleX, yOffset)
    characterInfo.window[i]:Show(visibilitys[i])
    characterInfo.subtitle[i]:Show(visibilitys[i])
    characterInfo.value[i]:Show(visibilitys[i])
    if visibilitys[i] == true then
      height = height + itemHeight
    else
      skip = skip + 1
    end
  end
  return height
end
function UpadateBodyAnchors(visibilitys)
  if visibilitys == nil then
    return
  end
  local totalHeight = titleMargin + MARGIN.WINDOW_SIDE + group.defaultInfo:GetHeight()
  local startIndex = 1
  local endIndex = #baseWindowSubTitle[GROUP_COMMUNITY]
  local height = UpdateLabelAnchors(group.community, startIndex, endIndex, visibilitys, item_offset)
  group.community:SetHeight(height)
  totalHeight = totalHeight + height + group_inset
  startIndex = endIndex + 1
  endIndex = startIndex + #baseWindowSubTitle[GROUP_RACEINFO] - 1
  height = UpdateLabelAnchors(group.raceInfo, startIndex, endIndex, visibilitys, item_offset)
  group.raceInfo:SetHeight(height)
  totalHeight = totalHeight + height + group_inset
  startIndex = endIndex + 1
  endIndex = startIndex + #baseWindowSubTitle[GROUP_GAME_POINT] - 1
  height = UpdateLabelAnchors(group.gamePoint, startIndex, endIndex, visibilitys, item_offset)
  if height == 0 then
    group.gamePoint.line:Show(false)
    group.contentsPoint:RemoveAllAnchors()
    group.contentsPoint:AddAnchor("TOPLEFT", group.raceInfo.line, "BOTTOMLEFT", 0, sideMargin / 2)
  else
    group.gamePoint.line:Show(true)
    group.contentsPoint:RemoveAllAnchors()
    group.contentsPoint:AddAnchor("TOPLEFT", group.gamePoint.line, "BOTTOMLEFT", 0, sideMargin / 2)
    totalHeight = totalHeight + height + group_inset
  end
  group.gamePoint:SetHeight(height)
  startIndex = endIndex + 1
  endIndex = startIndex + #baseWindowSubTitle[GROUP_CONTENTS_POINT] - 1
  height = UpdateLabelAnchors(group.contentsPoint, startIndex, endIndex, visibilitys, item_offset)
  group.contentsPoint:SetHeight(height)
  totalHeight = totalHeight + height + group_inset
  startIndex = endIndex + 1
  endIndex = startIndex + #baseWindowSubTitle[GROUP_COMBAT_STAT] - 1
  height = UpdateLabelAnchors(group.combatDefaultInfo, startIndex, endIndex, visibilitys, item_offset)
  group.combatDefaultInfo:SetHeight(height)
  totalHeight = totalHeight + height + group_inset
  group.baseStats:SetHeight(60)
  local startIndex = endIndex + 1
  local endIndex = startIndex + #baseWindowSubTitle[GROUP_BASE_STAT] - 1
  for i = startIndex, endIndex do
    local x, y
    if i < endIndex - 1 then
      x = 0
      y = (i - startIndex) * item_offset
    else
      x = item_width / 2
      y = (i - (endIndex - 1)) * item_offset
    end
    characterInfo.window[i]:SetExtent(item_width / 2, item_height)
    characterInfo.window[i]:AddAnchor("TOPLEFT", group.baseStats, "TOPLEFT", x, y)
    characterInfo.subtitle[i]:SetExtent(item_width / 4 - 5, item_height)
    characterInfo.value[i]:SetExtent(item_width / 4, item_height)
  end
  totalHeight = totalHeight + group.baseStats:GetHeight() + group_inset
  local startIndex = endIndex + 1
  local endIndex = startIndex + #baseWindowSubTitle[GROUP_SPEED] - 1
  height = UpdateLabelAnchors(group.speed, startIndex, endIndex, visibilitys, item_offset)
  group.speed:SetHeight(height)
  local width, _ = characterInfo.mainWindow:GetExtent()
  totalHeight = totalHeight + height + group_inset
  characterInfo.mainWindow:SetExtent(width, totalHeight)
end
characterInfo.popupBtn = CreateEmptyButton("characterInfo.popupBtn", characterInfo.mainWindow)
characterInfo.popupBtn:AddAnchor("BOTTOMRIGHT", characterInfo.mainWindow, -sideMargin / 4608083138725491507, -sideMargin / 2)
characterInfo.popupBtn:SetStyle("character_info_detail_btn")
local subWindow = CreateCharacterInfoSubWindow("characterInfo.popupWindow", characterInfo.mainWindow)
subWindow:Show(false)
subWindow:AddAnchor("TOPLEFT", characterInfo.mainWindow, "TOPRIGHT", 0, 0)
characterInfo.mainWindow.subWindow = subWindow
if featureSet.shopOnUI then
  local livingPointLable = characterInfo.subtitle[INDEX_LIVING_POINT]
  local livingPointPopupBtn = livingPointLable:CreateChildWidget("button", "livingPointPopupBtn", 0, true)
  livingPointPopupBtn:Enable(true)
  livingPointPopupBtn:AddAnchor("LEFT", characterInfo.window[INDEX_LIVING_POINT], "RIGHT", 0, 0)
  livingPointPopupBtn:SetStyle("character_info_btn_shop")
  livingPointPopupBtn:SetExtent(20, 20)
  local honorPointLable = characterInfo.subtitle[INDEX_HONOR_POINT]
  local honorPointPopupBtn = honorPointLable:CreateChildWidget("button", "honorPointPopupBtn", 0, true)
  honorPointPopupBtn:Enable(true)
  honorPointPopupBtn:AddAnchor("LEFT", characterInfo.window[INDEX_HONOR_POINT], "RIGHT", 0, 0)
  honorPointPopupBtn:SetStyle("character_info_btn_shop")
  honorPointPopupBtn:SetExtent(20, 20)
end
local visualRaceInfo = characterInfo.subtitle[INDEX_VISUAL_RACE]
local visualRaceInfoPopupBtn = visualRaceInfo:CreateChildWidget("button", "visualRaceInfoPopupBtn", 0, true)
visualRaceInfoPopupBtn:Enable(true)
visualRaceInfoPopupBtn:AddAnchor("LEFT", characterInfo.window[INDEX_VISUAL_RACE], "RIGHT", 0, 0)
visualRaceInfoPopupBtn:SetStyle("character_info_change")
visualRaceInfoPopupBtn:SetExtent(20, 20)
