local putupItemList
function CreateAuctionPutupFrame(window)
  SetViewOfAuctionPutupFrame(window)
  local putupItemFrame = window.putupItemFrame
  local timeCheckBoxes = putupItemFrame.timeCheckBoxes
  local itemButton = putupItemFrame.itemButton
  local itemNameLabel = putupItemFrame.itemNameLabel
  local startPriceEditsWindow = putupItemFrame.startPriceEditsWindow
  local directPriceEditsWindow = putupItemFrame.directPriceEditsWindow
  local directBundlePrice = putupItemFrame.directBundlePrice
  local directBundleAmountLabel = putupItemFrame.directBundleAmountLabel
  local lowestPrice = putupItemFrame.lowestPrice
  local putupButton = putupItemFrame.putupButton
  local deposit = putupItemFrame.deposit
  local depositMoney = putupItemFrame.depositMoney
  local chargeText = putupItemFrame.chargeText
  local chargePrice = putupItemFrame.chargePrice
  local chargeDisPrice = putupItemFrame.chargeDisPrice
  local listCtrl = window.listCtrl
  local pageControl = window.pageControl
  local refreshButton = window.refreshButton
  local availableMoney = window.availableMoney
  local availableAAPoint = window.availableAAPoint
  local cancelBidButton = window.cancelBidButton
  local leftMarketPriceBtn = putupItemFrame.marketPriceBtn
  local rightMarketPriceBtn = window.rightMarketPriceBtn
  local postTypeButton = putupItemFrame.postTypeButton
  local minStackCountButtons = putupItemFrame.minStackCountButtons
  local spinner = putupItemFrame.spinner
  local depositGuide = putupItemFrame.depositGuide
  local chargeGuide = putupItemFrame.chargeGuide
  local EnableMarketPriceBtn = function(button, enable)
    if button == nil then
      return
    end
    button:Enable(enable)
  end
  local function SetMarketPriceBtn(button, itemType, itemGrade)
    if button == nil then
      return
    end
    if itemType == nil then
      button:InitMarketPrice()
      EnableMarketPriceBtn(button, false)
    end
    button:SetMarketPrice(itemType, itemGrade)
    EnableMarketPriceBtn(button, true)
  end
  window.attachedItemStackCnt = 0
  window.attachedItemType = 0
  window.attachedItemGrade = 0
  function window:EnableSearch(enable)
    pageControl:Enable(enable, true)
    EnableMarketPriceBtn(rightMarketPriceBtn, listCtrl:GetSelectedIdx() > 0)
  end
  local function OnEnter(self)
    if self:IsEnabled() then
      SetTooltip(locale.auction.bidSuccesfullyCommission, self)
    elseif depositMoney:IsVisible() then
      SetTooltip(locale.auction.lowDirectPrice, self)
    end
  end
  putupButton:SetHandler("OnEnter", OnEnter)
  local function SetPostTypeMode(postType)
    if X2Player:GetFeatureSet().auctionPartialBuy == false then
      postType = PT_BID
    end
    local postTypeLabel = putupItemFrame.postTypeLabel
    local postTypeFrame = putupItemFrame.postTypeFrame
    if postType == PT_BID then
      X2Auction:SetPostType(PT_BID)
      postTypeFrame[1]:Show(true)
      postTypeFrame[2]:Show(false)
      postTypeLabel:SetText(locale.auction.startPrice)
    else
      X2Auction:SetPostType(PT_PARTITION)
      postTypeFrame[1]:Show(false)
      postTypeFrame[2]:Show(true)
      postTypeLabel:SetText(locale.auction.sellPartition)
      local attachItem = X2Auction:GetAttachedItemInfo()
      if attachItem == nil then
        spinner:SetMinMaxValues(1, 1)
      else
        spinner:SetMinMaxValues(1, GetItemStackCount(attachItem))
      end
      local enable = attachItem ~= nil
      if spinner:IsEnabled() ~= enable then
        spinner:SetEnable(enable)
      end
      putupItemFrame:SetEnableStackButtons(enable)
    end
    window:CalcDeposit()
  end
  for i = 1, #minStackCountButtons do
    local function MinStackLeftClickFunc()
      local stackCount = PartitionStack[i]
      local spinnerNum = tonumber(spinner:GetCurValue())
      if spinnerNum ~= nil and spinnerNum ~= 1 then
        stackCount = spinnerNum + PartitionStack[i]
      end
      spinner:SetValue(stackCount, true)
    end
    ButtonOnClickHandler(minStackCountButtons[i], MinStackLeftClickFunc)
  end
  function window:Init()
    itemButton:Init()
    timeCheckBoxes:Check(1)
    itemNameLabel:SetText("")
    availableMoney:Update(X2Util:GetMyMoneyString(), false)
    availableAAPoint:UpdateAAPoint(X2Util:GetMyAAPointString(), false)
    startPriceEditsWindow:SetAmountStr("0")
    directPriceEditsWindow:SetAmountStr("0")
    startPriceEditsWindow:SetCurrencyAmountLimit(startPriceEditsWindow:GetSystemCurrencyAmountLimit())
    directPriceEditsWindow:SetCurrencyAmountLimit(directPriceEditsWindow:GetSystemCurrencyAmountLimit())
    directBundleAmountLabel:Update("-")
    window.attachedItemStackCnt = 0
    window.attachedItemType = 0
    window.attachedItemGrade = 0
    listCtrl:DeleteAllDatas()
    cancelBidButton:Enable(false)
    EnableMarketPriceBtn(rightMarketPriceBtn, false)
    EnableMarketPriceBtn(leftMarketPriceBtn, false)
    pageControl:Init()
    self:UpdateLowestPrice()
    X2Auction:ClearSearchCondition()
    SetPostTypeMode(X2Auction:GetPostType())
  end
  function window:AttachItem(attached)
    if attached == true then
      local itemInfo = X2Auction:GetAttachedItemInfo()
      if itemInfo ~= nil then
        local color = F_COLOR.Hex2Dec(itemInfo.gradeColor)
        itemNameLabel.style:SetColor(color[1], color[2], color[3], color[4])
        itemNameLabel:SetText(itemInfo.name)
        local stackCount = GetItemStackCount(itemInfo)
        window.attachedItemStackCnt = stackCount
        window.attachedItemType = itemInfo.itemType
        window.attachedItemGrade = itemInfo.itemGrade
        itemButton:SetInfo(itemInfo)
        itemButton:SetStack(stackCount)
        if stackCount > 1 then
          SetPostTypeMode(PT_PARTITION)
          postTypeButton:Enable(true)
        else
          SetPostTypeMode(PT_BID)
          postTypeButton:Enable(false)
        end
        startPriceEditsWindow.goldEdit:SetFocus()
        local minLimit = X2Util:MultiplyNumberString(tostring(itemInfo.refund), tostring(stackCount))
        if itemInfo.minPriceLimit ~= nil then
          local minPrice = X2Util:MultiplyNumberString(itemInfo.minPriceLimit, tostring(stackCount))
          if X2Util:StrNumericComp(minPrice, minLimit) > 0 then
            minLimit = minPrice
          end
        end
        startPriceEditsWindow:SetAmountStr(minLimit)
        directPriceEditsWindow:SetAmountStr("0")
        local putupInfo = self:GetPutupedItemList(itemInfo.itemType, itemInfo.itemGrade)
        if putupInfo ~= nil then
          local bidPrice = X2Util:MultiplyNumberString(tostring(putupInfo.bidPrice), tostring(stackCount))
          if X2Util:StrNumericComp(bidPrice, minLimit) > 0 then
            minLimit = bidPrice
          end
          startPriceEditsWindow:SetAmountStr(minLimit)
          directPriceEditsWindow:SetAmountStr(putupInfo.directPrice)
          timeCheckBoxes:Check(putupInfo.duration)
        end
        X2Auction:SetPrice(minLimit, "0")
        local maxLimit = directPriceEditsWindow:GetSystemCurrencyAmountLimit()
        if itemInfo.maxPriceLimit ~= nil then
          local maxPrice = X2Util:MultiplyNumberString(itemInfo.maxPriceLimit, tostring(stackCount))
          if X2Util:StrNumericComp(maxLimit, maxPrice) > 0 then
            maxLimit = maxPrice
          end
        end
        startPriceEditsWindow:SetCurrencyAmountLimit(maxLimit)
        directPriceEditsWindow:SetCurrencyAmountLimit(X2Util:DivideNumberString(maxLimit, tostring(stackCount)))
        directBundleAmountLabel:Update(stackCount)
        depositGuide:Show(true)
        deposit:Show(true)
        depositMoney:Show(true)
        self:CalcDeposit()
        chargeGuide:Show(true)
        chargeText:Show(true)
        chargePrice:Show(true)
        self:CalcCharge()
        putupButton:Enable(true)
        self:UpdateLowestPrice()
        SetMarketPriceBtn(leftMarketPriceBtn, itemInfo.itemType, itemInfo.itemGrade)
      end
    else
      window.attachedItemStackCnt = 0
      window.attachedItemType = 0
      window.attachedItemGrade = 0
      itemButton:Init()
      itemNameLabel:SetText("")
      depositGuide:Show(false)
      deposit:Show(false)
      depositMoney:Show(false)
      chargeGuide:Show(false)
      chargeText:Show(false)
      chargePrice:Show(false)
      chargeDisPrice:Show(false)
      timeCheckBoxes:Check(1)
      putupButton:Enable(false)
      startPriceEditsWindow:SetAmountStr("0")
      directPriceEditsWindow:SetAmountStr("0")
      startPriceEditsWindow:SetCurrencyAmountLimit(startPriceEditsWindow:GetSystemCurrencyAmountLimit())
      directPriceEditsWindow:SetCurrencyAmountLimit(directPriceEditsWindow:GetSystemCurrencyAmountLimit())
      directBundleAmountLabel:Update("-")
      SetMarketPriceBtn(leftMarketPriceBtn)
      self:UpdateLowestPrice()
      SetPostTypeMode(PT_PARTITION)
    end
  end
  function window:CalcDeposit()
    local startPriceStr = startPriceEditsWindow:GetAmountStr()
    local directPriceStr = directBundlePrice.amount
    local duration = timeCheckBoxes:GetChecked()
    local depositPrice = X2Auction:CalcDeposit(startPriceStr, directPriceStr, duration)
    depositMoney:SetText(F_MONEY:GetCostStringByCurrency(F_MONEY.currency.auctionFee, depositPrice))
    local postType = X2Auction:GetPostType()
    if postType == PT_PARTITION then
      if X2Auction:GetAttachedItemInfo() == nil then
        putupButton:Enable(false)
      else
        putupButton:Enable(true)
      end
    elseif depositMoney:IsVisible() then
      if directPriceStr ~= "0" and X2Util:StrNumericComp(startPriceStr, directPriceStr) > 0 then
        putupButton:Enable(false)
        EnableMarketPriceBtn(leftMarketPriceBtn, false)
      else
        putupButton:Enable(true)
        EnableMarketPriceBtn(leftMarketPriceBtn, true)
      end
    end
  end
  function window:CalcCharge()
    local chargeInfo = X2Auction:GetChargeInfo(window.attachedItemType)
    chargePrice:SetText(chargeInfo.defaultRatio)
    if chargeInfo.gapChargeToDefaultRate < 0 then
      chargePrice:SetStrikeThrough(true)
      chargeDisPrice:Show(true)
      local lineColor
      local disPriceStr = ""
      if chargeInfo.useChargeByItem then
        lineColor = F_COLOR.GetColor("blue")
        disPriceStr = string.format("%s%s%%", F_COLOR.GetColor("blue", true), chargeInfo.chargeRate)
      else
        lineColor = F_COLOR.GetColor("title")
        disPriceStr = string.format("%s%%", chargeInfo.chargeRate)
      end
      chargePrice:SetLineColor(lineColor[1], lineColor[2], lineColor[3], lineColor[4])
      chargeDisPrice:SetWidth(60)
      chargeDisPrice:SetText(disPriceStr)
      chargeDisPrice:SetWidth(chargeDisPrice:GetLongestLineWidth() + 5)
    else
      chargePrice:SetStrikeThrough(false)
      chargeDisPrice:Show(false)
    end
  end
  function startPriceEditsWindow:MoneyEditProc()
    window:CalcDeposit()
  end
  function directPriceEditsWindow:MoneyEditProc()
    local each = directPriceEditsWindow:GetAmountStr()
    local cnt = window.attachedItemStackCnt
    local bundel = X2Util:MultiplyNumberString(tostring(each), tostring(cnt))
    directBundlePrice:Update(bundel)
    window:CalcDeposit()
  end
  function timeCheckBoxes:OnRadioChanged(index, dataValue)
    window:CalcDeposit()
  end
  timeCheckBoxes:SetHandler("OnRadioChanged", timeCheckBoxes.OnRadioChanged)
  function pageControl:OnPageChanged(pageIndex, countPerPage)
    self:Enable(false, true)
    X2Auction:SearchMyAuctionArticles(pageIndex)
  end
  function window:OnShow()
    X2Auction:SetCurTab(1)
    UIParent:DevLog(string.format("[LOG] OnShow putup tab(1)"))
    pageControl:Init()
    listCtrl:DeleteAllDatas()
    X2Auction:DetachItem(false)
    timeCheckBoxes:Check(1)
    X2Auction:SearchMyAuctionArticles(0)
    SetSearchCoolTime()
    EnableMarketPriceBtn(leftMarketPriceBtn, false)
  end
  window:SetHandler("OnShow", window.OnShow)
  function window:OnHide()
    X2Auction:DetachItem(false)
  end
  window:SetHandler("OnHide", window.OnHide)
  function window:ClearPutupedItemList()
    if putupItemList == nil then
      return
    end
    while true do
      table.remove(putupItemList, #putupItemList)
      if #putupItemList == 0 then
        break
      end
    end
    putupItemList = nil
  end
  function window:GetPutupedItemList(itemType, itemGrade)
    if putupItemList == nil then
      return nil
    end
    for i = 1, #putupItemList do
      if putupItemList[i].itemType == itemType and putupItemList[i].itemGrade == itemGrade then
        return putupItemList[i]
      end
    end
    return nil
  end
  function window:SaveAttachedItemPriceInfo()
    if putupItemList == nil then
      putupItemList = {}
    end
    local itemInfo = self:GetPutupedItemList(window.attachedItemType, window.attachedItemGrade)
    if itemInfo == nil then
      itemInfo = {}
    end
    itemInfo.itemType = window.attachedItemType
    itemInfo.itemGrade = window.attachedItemGrade
    itemInfo.duration = timeCheckBoxes:GetChecked()
    itemInfo.stackCount = window.attachedItemStackCnt
    if itemInfo.stackCount == 0 then
      UIParent:DevLog(string.format("[ERROR] SaveAttachedItemPriceInfo() stackCount is 0 !!"))
      return
    end
    itemInfo.bidPrice = tonumber(startPriceEditsWindow:GetAmountStr()) / itemInfo.stackCount
    itemInfo.directPrice = tonumber(directPriceEditsWindow:GetAmountStr())
    table.insert(putupItemList, itemInfo)
  end
  function window:UpdateLowestPrice()
    if window.attachedItemType == 0 then
      lowestPrice:SetPrice(nil, nil)
    else
      local price = X2Auction:GetLowestPrice(window.attachedItemType, window.attachedItemGrade)
      lowestPrice:SetPrice(window.attachedItemType, price)
    end
  end
  function directPriceEditsWindow:SetLowestPrice(price)
    local itemType = window.attachedItemType
    local itemGrade = window.attachedItemGrade
    local itemInfo = window:GetPutupedItemList(itemType, itemGrade)
    if itemInfo == nil then
      directPriceEditsWindow:SetAmountStr(price)
    end
  end
  function lowestPrice:SetPrice(itemType, price)
    if itemType == nil and price == nil then
      lowestPrice.style:SetAlign(ALIGN_CENTER)
      lowestPrice:SetText("-")
    elseif itemType == window.attachedItemType then
      if price == nil then
        lowestPrice.style:SetAlign(ALIGN_CENTER)
        lowestPrice:SetText(locale.auction.searching)
      elseif price == "0" then
        lowestPrice.style:SetAlign(ALIGN_CENTER)
        lowestPrice:SetText(locale.auction.no_lowest_price)
        directPriceEditsWindow:SetLowestPrice("0")
      else
        lowestPrice.style:SetAlign(ALIGN_RIGHT)
        lowestPrice:Update(price)
        directPriceEditsWindow:SetLowestPrice(price)
      end
    end
  end
  local itemButton = putupItemFrame.itemButton
  local ItemButtonLeftClickFunc = function()
    local exist = X2Auction:GetAttachedItemExist()
    if exist == true and X2Cursor:GetCursorPickedBagItemIndex() == 0 then
      X2Auction:DetachItem(true)
    else
      X2Auction:AttachItemFromPick()
    end
  end
  local ItemButtonRightClickFunc = function()
    local exist = X2Auction:GetAttachedItemExist()
    if exist == true and X2Cursor:GetCursorPickedBagItemIndex() == 0 then
      X2Auction:DetachItem(true)
    end
  end
  ButtonOnClickHandler(itemButton, ItemButtonLeftClickFunc, ItemButtonRightClickFunc)
  local function PutupButtonLeftButtonClickFunc()
    window:SaveAttachedItemPriceInfo()
    X2Auction:SetDuration(timeCheckBoxes:GetChecked())
    local bidPriceStr = startPriceEditsWindow:GetAmountStr()
    local directPriceStr = directBundlePrice.amount
    local minStack = 0
    local maxStack = 0
    if X2Auction:GetPostType() == PT_PARTITION then
      minStack = tonumber(spinner:GetCurValue())
      if minStack == nil then
        minStack = 0
      end
      maxStack = GetItemStackCount(X2Auction:GetAttachedItemInfo())
      X2Auction:SetPricePartition(directPriceStr, maxStack)
    else
      X2Auction:SetPrice(bidPriceStr, directPriceStr)
    end
    X2Auction:SetPartitionBuyMinMaxCount(minStack, maxStack)
    X2Auction:AskAuctionArticle()
  end
  ButtonOnClickHandler(putupButton, PutupButtonLeftButtonClickFunc)
  local function CancelBidButtonLeftButtonClickFunc()
    local selIdx = listCtrl:GetSelectedIdx()
    local articleId = X2Auction:GetSearchedItemArticleId(selIdx)
    local itemInfo = X2Auction:GetSearchedItemInfo(selIdx)
    if articleId == nil then
      return
    end
    listCtrl:ClearSelection()
    local function DialogHandler(wnd)
      wnd:SetTitle(locale.auction.cancelBid)
      local data = {
        itemInfo = itemInfo,
        stack = itemInfo.stackCount
      }
      local itemIcon = W_MODULE:Create("itemIcon", wnd, W_MODULE.TYPES.ICON_VERTICAL, data)
      wnd:RegisterStack(itemIcon)
      local data = {
        [W_MODULE.ATTRIBUTE.TYPE] = "cost",
        [W_MODULE.ATTRIBUTE.CURRENCY] = F_MONEY.currency.auctionFee,
        [W_MODULE.ATTRIBUTE.VALUE] = itemInfo.depositStr
      }
      local cost = W_MODULE:Create("cost", wnd, W_MODULE.TYPES.VALUE_BOX_DIALOG, data)
      wnd:RegisterStack(cost)
      function wnd:OkProc()
        X2Auction:CancelAuctionArticle(articleId)
      end
    end
    X2DialogManager:RequestDialog(DialogHandler, window:GetParent():GetParent():GetId())
  end
  ButtonOnClickHandler(cancelBidButton, CancelBidButtonLeftButtonClickFunc)
  function listCtrl:OnSelChangedProc(selIdx, doubleClick)
    if selIdx > 0 then
      local itemInfo = X2Auction:GetSearchedItemInfo(selIdx)
      local isEmptyBidder = itemInfo.bidState == BID_STATE.BS_NOBID
      cancelBidButton:Enable(isEmptyBidder)
      SetMarketPriceBtn(rightMarketPriceBtn, itemInfo.itemType, itemInfo.itemGrade)
    else
      cancelBidButton:Enable(false)
      SetMarketPriceBtn(rightMarketPriceBtn)
    end
  end
  local RefreshButtonLeftButtonClickFunc = function()
    X2Auction:SearchRefresh()
    SetSearchCoolTime()
  end
  ButtonOnClickHandler(refreshButton, RefreshButtonLeftButtonClickFunc)
  local function PostTypeLeftClickFunc()
    local postType = X2Auction:GetPostType()
    if postType == PT_BID then
      SetPostTypeMode(PT_PARTITION)
    else
      SetPostTypeMode(PT_BID)
    end
  end
  ButtonOnClickHandler(postTypeButton, PostTypeLeftClickFunc)
  local OnEnterPostTypeButton = function(self)
    SetTooltip(X2Locale:LocalizeUiText(AUCTION_TEXT, "partition_btn_tooltip"), self)
  end
  postTypeButton:SetHandler("OnEnter", OnEnterPostTypeButton)
  local function OnEnterDepositGuide(self)
    local depositRatioTexts = {}
    for i = 1, #putupItemFrame.timeTexts do
      local ratio = X2Auction:GetDepositRatioValue(i)
      depositRatioTexts[i] = locale.auction.depositTooltipRateByTime(putupItemFrame.timeTexts[i].text, string.format("%0.1f", ratio / 10))
    end
    local str = GetUIText(AUCTION_TEXT, "deposit_tooltip_max_price", F_MONEY:GetCostStringByCurrency(F_MONEY.currency.auctionFee, X2Auction:GetMaxDepositValue()))
    local tooltipStr = F_TEXT.SetEnterString(locale.auction.depositTooltipTitle, locale.auction.depositTooltipInfo(depositRatioTexts, str))
    SetTooltip(tooltipStr, self)
  end
  depositGuide:SetHandler("OnEnter", OnEnterDepositGuide)
  local function OnEnterChargeGuide(self)
    local chargeInfo = X2Auction:GetChargeInfo(window.attachedItemType)
    local title = locale.auction.chargeTooltipTitle(tostring(chargeInfo.chargeRate))
    local titleExplan = locale.auction.chargeTooltipTitleNormal
    if chargeInfo.gapChargeToDefaultRate < 0 then
      titleExplan = locale.auction.chargeTooltipTitleItemCharge(tostring(chargeInfo.gapChargeToDefaultRate))
      title = string.format("%s%s", title, locale.auction.chargeTooltipTitleExplan(titleExplan))
    end
    local tooltipStr = F_TEXT.SetEnterString(title, titleExplan)
    SetTooltip(tooltipStr, self)
  end
  chargeGuide:SetHandler("OnEnter", OnEnterChargeGuide)
end
