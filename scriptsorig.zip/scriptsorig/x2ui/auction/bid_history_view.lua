local CreateItemListFrame = function(window)
  local listInfos = {
    width = 860,
    height = 475,
    anchorWidget = nil,
    columns = {
      {
        name = locale.auction.name,
        width = auctionLocale.width.bidHistoryNameCol,
        itemType = LCCIT_WINDOW,
        layoutFunc = LayoutAuctionItemName,
        dataSetFunc = DataSetAuctionItemName
      },
      {
        name = GetUIText(TOOLTIP_TEXT, "left_time"),
        width = auctionLocale.commonWidth.timeCol,
        itemType = LCCIT_STRING,
        layoutFunc = LayoutAuctionItemLeftTime,
        dataSetFunc = DataSetAuctionItemLeftTime
      },
      {
        name = locale.auction.bidState,
        width = 115,
        itemType = LCCIT_TEXTBOX,
        layoutFunc = LayoutAuctionTextboxColumn,
        dataSetFunc = DataSetAuctionItemBiddingState
      },
      {
        name = locale.auction.myBiddingPrice,
        width = 175,
        itemType = LCCIT_WINDOW,
        layoutFunc = LayoutAuctionMyBiddingPrice,
        dataSetFunc = DataSetAuctionMyBiddingPrice
      },
      {
        name = locale.auction.currentBidPrice,
        width = 205,
        itemType = LCCIT_WINDOW,
        layoutFunc = LayoutAuctionBiddingPrice,
        dataSetFunc = DataSetAuctionBiddingPrice
      }
    }
  }
  CreateAuctionItemList(window, listInfos)
end
local CreateBottomFrame = function(window)
  local availableMoney = W_MONEY.CreateTitleMoneyWindow("availableMoney", window, nil, "vertical")
  availableMoney:AddAnchor("BOTTOMLEFT", window, 0, 0)
  window.availableMoney = availableMoney
  local availableAAPoint = W_MONEY.CreateTitleMoneyWindow("availableAAPoint", window, GetUIText(MONEY_TEXT, "aa_point"), "vertical")
  if F_MONEY.currency.auctionFee == CURRENCY_AA_POINT or F_MONEY.currency.auctionBid == CURRENCY_AA_POINT then
    availableAAPoint:Show(true)
  else
    availableAAPoint:Show(false)
  end
  availableAAPoint:AddAnchor("LEFT", availableMoney, "RIGHT", 20, 0)
  window.availableAAPoint = availableAAPoint
  F_MONEY:SetMoneyTooltip(availableMoney, availableAAPoint)
  local marketPriceBtn = CreateMarketPriceBtn("marketPriceBtn", window)
  window.marketPriceBtn = marketPriceBtn
  local directButton = window:CreateChildWidget("button", "directButton", 0, true)
  directButton:AddAnchor("BOTTOMRIGHT", window, 0, 0)
  directButton:SetText(locale.common.buy)
  directButton:SetStyle("text_default")
  if marketPriceBtn == nil then
    directButton:AddAnchor("BOTTOMRIGHT", window, 0, 0)
  else
    marketPriceBtn:AddAnchor("BOTTOMRIGHT", window, 0, 0)
    directButton:AddAnchor("BOTTOMRIGHT", marketPriceBtn, "BOTTOMLEFT", -5, 0)
  end
  local bidButton = window:CreateChildWidget("button", "bidButton", 0, true)
  bidButton:AddAnchor("TOPRIGHT", directButton, "TOPLEFT", 0, 0)
  bidButton:SetText(locale.auction.bid_money)
  bidButton:SetStyle("text_default")
  local buttonTable = {directButton, bidButton}
  AdjustBtnLongestTextWidth(buttonTable)
  local moneyEditsWindow
  if F_MONEY.currency.auctionBid == CURRENCY_AA_POINT then
    moneyEditsWindow = W_MONEY.CreateAAPointEditsWindow("moneyEditsWindow", window)
  else
    moneyEditsWindow = W_MONEY.CreateMoneyEditsWindow("moneyEditsWindow", window)
  end
  moneyEditsWindow:AddAnchor("BOTTOMRIGHT", bidButton, "BOTTOMLEFT", -5, -5)
  window.moneyEditsWindow = moneyEditsWindow
end
function SetViewOfAuctionBidHistoryFrame(window)
  CreateItemListFrame(window)
  CreateBottomFrame(window)
end
