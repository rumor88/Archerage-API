function ShowDialogPurchaseItemInAuction(parentWidgetId, articleId, itemInfo)
  X2Auction:AskMarketPrice(itemInfo.itemType, itemInfo.itemGrade, false)
  local function DialogHandler(wnd)
    wnd:UseExpandWidth()
    local headerTable = W_MODULE:Create("headerTable", wnd, W_MODULE.TYPES.HEADER_TABLE_C, {
      title = GetCommonText("price_info")
    })
    local weeklyRowKey = "weeklyPrice"
    headerTable:AddRow(weeklyRowKey, {
      title = {
        string = GetUIText(COMMON_TEXT, "weekly_trading_average_price")
      },
      value = {string = "-"}
    })
    headerTable:AddRow("pricePerUnit", {
      title = {
        string = GetUIText(COMMON_TEXT, "unit_price")
      },
      value = {
        string = F_MONEY:GetCostStringByCurrency(F_MONEY.currency.auctionBid, tostring(X2Auction:GetPartitionPriceByCount(itemInfo.directPriceStr, itemInfo.stackCount, 1)))
      }
    })
    if IsPartitionAuctionItem(itemInfo) then
      wnd:SetTitle(locale.auction.bidPartition)
      do
        local minValue = math.min(itemInfo.minStack, itemInfo.stackCount)
        itemData = {itemInfo = itemInfo, stack = 0}
        wnd:RegisterStack(W_MODULE:Create("itemIcon", wnd, W_MODULE.TYPES.ICON_VERTICAL, itemData))
        wnd:RegisterStack(headerTable)
        local valueData = {
          [W_MODULE.ATTRIBUTE.TYPE] = "cost",
          [W_MODULE.ATTRIBUTE.CURRENCY] = F_MONEY.currency.auctionBid,
          [W_MODULE.ATTRIBUTE.VALUE] = 0
        }
        local cost = W_MODULE:Create("cost", wnd, W_MODULE.TYPES.VALUE_BOX_DIALOG, valueData)
        local spinnerBox = W_MODULE:Create("spinnerBox", wnd, W_MODULE.TYPES.TITLE_BOX, {
          title = GetUIText(COMMON_TEXT, "auction_count_set")
        })
        local stackFrame = spinnerBox:CreateChildWidget("emptywidget", "bidStackFrame", 0, true)
        stackFrame:Show(true)
        stackFrame:SetExtent(316, 73)
        local spinner = W_ETC.CreateSpinner("bidSpinner", stackFrame, {spinnerWidth = 260, useMaxButton = false})
        spinner:AddAnchor("TOP", stackFrame, 0, 0)
        spinner:SetMinMaxValues(1, itemInfo.stackCount)
        function spinner:OnSpinnerValueChangeProc(value)
          local totalPrice = X2Auction:GetPartitionPriceByCount(itemInfo.directPriceStr, itemInfo.stackCount, value) or 0
          local data = cost:GetData()
          data[W_MODULE.ATTRIBUTE.VALUE] = tostring(totalPrice)
          cost:SetData(data)
          wnd:ApplyOkButtonEnablement()
        end
        for i = 1, 5 do
          local button = wnd:CreateChildWidget("button", "bidStackButton", i, true)
          ApplyButtonSkin(button, BUTTON_BASIC.AUCTION_BID_STACK)
          if i == 1 then
            button:SetText(locale.auction.bidMinStack)
          elseif i == 5 then
            button:SetText(locale.auction.bidMaxStack)
          else
            button:SetText(tostring(PartitionStack[i]))
          end
          button:AddAnchor("TOP", spinner, "BOTTOM", (i - 3) * button:GetWidth() + (i - 3) * 5, 10)
          local function BidStackLeftClickFunc()
            local count = 0
            if i == 1 then
              count = minValue
            elseif i == 5 then
              count = itemInfo.stackCount
            else
              local spinnerNum = tonumber(spinner:GetCurValue())
              count = PartitionStack[i]
              if spinnerNum ~= nil then
                count = spinnerNum + PartitionStack[i]
              end
            end
            spinner:SetValue(count, true)
          end
          ButtonOnClickHandler(button, BidStackLeftClickFunc)
        end
        spinner:OnSpinnerValueChangeProc(minValue)
        spinner:SetValue(minValue, true)
        spinnerBox:AddBody(stackFrame)
        local minCount = spinnerBox:AddModule("minCount", W_MODULE.TYPES.TEXTBOX, {
          [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "auction_min_count", tostring(minValue))
        })
        wnd:RegisterStack(spinnerBox)
        wnd:RegisterStack(cost)
        function cost:Satisfy()
          return spinner:GetCurValue() >= minValue and X2Auction:EnoughByMoneyBuyAuctionItem(cost:GetData()[W_MODULE.ATTRIBUTE.VALUE])
        end
        function wnd:OkProc()
          X2Auction:PartitionAuctionArticle(articleId, itemInfo.stackCount, tostring(spinner:GetCurValue()))
        end
      end
    else
      wnd:SetTitle(locale.auction.directBid)
      local data = {
        itemInfo = itemInfo,
        stack = itemInfo.stackCount
      }
      local itemIcon = W_MODULE:Create("itemIcon", wnd, W_MODULE.TYPES.ICON_VERTICAL, data)
      wnd:RegisterStack(itemIcon)
      wnd:RegisterStack(headerTable)
      local data = {
        [W_MODULE.ATTRIBUTE.TYPE] = "cost",
        [W_MODULE.ATTRIBUTE.CURRENCY] = F_MONEY.currency.auctionBid,
        [W_MODULE.ATTRIBUTE.VALUE] = itemInfo.directPriceStr
      }
      local cost = W_MODULE:Create("cost", wnd, W_MODULE.TYPES.VALUE_BOX_DIALOG, data)
      wnd:RegisterStack(cost)
      function cost:Satisfy()
        return X2Auction:EnoughByMoneyBuyAuctionItem(itemInfo.directPriceStr)
      end
      function wnd:OkProc()
        X2Auction:DirectPurchaseAuctionArticle(articleId)
      end
    end
    local events = {
      DIAGONAL_ASR = function(itemName, itemGrade, askMarketPriceUi, values)
        if askMarketPriceUi then
          return
        end
        if itemGrade == -1 then
          UIParent:Warning("marker price answer, item grade is unusual")
          return
        end
        local weeklyPrice = values[#values].weeklyAvg
        if weeklyPrice == "0" then
          return
        end
        headerTable:UpdateRow(weeklyRowKey, {
          value = {
            string = F_MONEY:GetCostStringByCurrency(F_MONEY.currency.auctionBid, weeklyPrice)
          }
        })
      end
    }
    wnd:SetHandler("OnEvent", function(this, event, ...)
      events[event](...)
    end)
    RegistUIEvent(wnd, events)
  end
  X2DialogManager:RequestDialog(DialogHandler, parentWidgetId)
end
function ShowDialogBidItemInAuction(parentWidgetId, articleId, itemInfo, bidPrice)
  X2Auction:AskMarketPrice(itemInfo.itemType, itemInfo.itemGrade, false)
  local function DialogHandler(wnd)
    wnd:SetTitle(locale.auction.bid_money)
    wnd:UseExpandWidth()
    local data = {
      itemInfo = itemInfo,
      stack = itemInfo.stackCount
    }
    local itemIcon = W_MODULE:Create("itemIcon", wnd, W_MODULE.TYPES.ICON_VERTICAL, data)
    wnd:RegisterStack(itemIcon)
    local headerTable = W_MODULE:Create("headerTable", wnd, W_MODULE.TYPES.HEADER_TABLE_C, {
      title = GetCommonText("price_info")
    })
    local weeklyRowKey = "weeklyPrice"
    headerTable:AddRow(weeklyRowKey, {
      title = {
        string = GetUIText(COMMON_TEXT, "weekly_trading_average_price")
      },
      value = {string = "-"}
    })
    local bidPricePerCnt = "0"
    if itemInfo.stackCount > 1 then
      bidPricePerCnt = X2Util:DivideNumberString(itemInfo.bidPriceStr, tostring(itemInfo.stackCount))
    else
      bidPricePerCnt = itemInfo.bidPriceStr
    end
    local valueString = "-"
    if bidPricePerCnt ~= "0" then
      valueString = F_MONEY:GetCostStringByCurrency(F_MONEY.currency.auctionBid, bidPricePerCnt)
    end
    headerTable:AddRow("pricePerUnit", {
      title = {
        string = GetUIText(COMMON_TEXT, "unit_price")
      },
      value = {string = valueString}
    })
    wnd:RegisterStack(headerTable)
    local data = {
      [W_MODULE.ATTRIBUTE.TYPE] = "cost",
      [W_MODULE.ATTRIBUTE.CURRENCY] = F_MONEY.currency.auctionBid,
      [W_MODULE.ATTRIBUTE.VALUE] = bidPrice
    }
    local cost = W_MODULE:Create("cost", wnd, W_MODULE.TYPES.VALUE_BOX_DIALOG, data)
    wnd:RegisterStack(cost)
    function wnd:OkProc()
      X2Auction:BidAuctionArticle(articleId, bidPrice)
    end
    local events = {
      DIAGONAL_ASR = function(itemName, itemGrade, askMarketPriceUi, values)
        if askMarketPriceUi then
          return
        end
        if itemGrade == -1 then
          UIParent:Warning("marker price answer, item grade is unusual")
          return
        end
        local weeklyPrice = values[#values].weeklyAvg
        if weeklyPrice == "0" then
          return
        end
        headerTable:UpdateRow(weeklyRowKey, {
          value = {
            string = F_MONEY:GetCostStringByCurrency(F_MONEY.currency.auctionBid, weeklyPrice)
          }
        })
      end
    }
    wnd:SetHandler("OnEvent", function(this, event, ...)
      events[event](...)
    end)
    RegistUIEvent(wnd, events)
  end
  X2DialogManager:RequestDialog(DialogHandler, parentWidgetId)
end
