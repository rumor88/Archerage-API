MIN_MAX_LEVEL_INIT_VAL = -1
local CreateSearchFrame = function(window)
  local frame = window:CreateChildWidget("emptywidget", "searchFrame", 0, true)
  local width, _ = window:GetExtent()
  frame:SetExtent(width, 25)
  frame:AddAnchor("TOPLEFT", window, 0, 15)
  local bg = CreateContentBackground(frame, "TYPE5", "brown_2")
  bg:AddAnchor("TOPLEFT", frame, 50, -8)
  bg:AddAnchor("BOTTOMRIGHT", frame, 10, 8)
  local function CreateSearchFrameLabel(strId, msg)
    local label = frame:CreateChildWidget("label", strId, 0, true)
    label:SetHeight(FONT_SIZE.MIDDLE)
    label:SetAutoResize(true)
    label:SetText(msg)
    label.style:SetColorByKey("title")
    return label
  end
  local conditionInitButton = frame:CreateChildWidget("button", "conditionInitButton", 0, true)
  conditionInitButton:AddAnchor("LEFT", frame, 5, 0)
  ApplyButtonSkin(conditionInitButton, BUTTON_STYLE.RESET_BIG)
  local OnEnterConditionInitButton = function(self)
    SetTooltip(locale.auction.searchConditionInit, self)
  end
  conditionInitButton:SetHandler("OnEnter", OnEnterConditionInitButton)
  local levelRangeLabel = CreateSearchFrameLabel("levelRangeLabel", locale.auction.levelRange)
  levelRangeLabel:AddAnchor("LEFT", conditionInitButton, "RIGHT", 8, 0)
  local minHeirButton = frame:CreateChildWidget("button", "minHeirButton", 0, true)
  minHeirButton:AddAnchor("LEFT", levelRangeLabel, "RIGHT", 5, 0)
  minHeirButton:SetStyle("auction_successor_grey")
  minHeirButton.active = false
  local editWidth = 35
  local minLevelEdit = W_CTRL.CreateEdit("minLevelEdit", frame)
  minLevelEdit:AddAnchor("LEFT", minHeirButton, "RIGHT", 2, 0)
  minLevelEdit:SetWidth(editWidth)
  minLevelEdit:SetDigit(true)
  minLevelEdit:SetMaxTextLength(2)
  minLevelEdit:SetInitVal(MIN_MAX_LEVEL_INIT_VAL)
  local tildeLabel = CreateSearchFrameLabel("tildeLabel", "~")
  tildeLabel:AddAnchor("LEFT", minLevelEdit, "RIGHT", 2, 0)
  local maxHeirButton = frame:CreateChildWidget("button", "maxHeirButton", 0, true)
  maxHeirButton:AddAnchor("LEFT", tildeLabel, "RIGHT", 3, 0)
  maxHeirButton:SetStyle("auction_successor_grey")
  maxHeirButton.active = false
  local maxLevelEdit = W_CTRL.CreateEdit("maxLevelEdit", frame)
  maxLevelEdit:AddAnchor("LEFT", maxHeirButton, "RIGHT", 2, 0)
  maxLevelEdit:SetWidth(editWidth)
  maxLevelEdit:SetDigit(true)
  maxLevelEdit:SetMaxTextLength(2)
  maxLevelEdit:SetInitVal(MIN_MAX_LEVEL_INIT_VAL)
  local gradeLabel = CreateSearchFrameLabel("gradeLabel", locale.auction.itemGrade)
  gradeLabel:AddAnchor("LEFT", maxLevelEdit, "RIGHT", 15, 0)
  local gradeComboBoxButton = W_ETC.CreateGradeCombobox("gradeComboBoxButton", frame, auctionLocale.width.bidGradeCombobox)
  gradeComboBoxButton:AddAnchor("LEFT", gradeLabel, "RIGHT", 2, 0)
  local nameEditbox = W_CTRL.CreateAutocomplete("nameEditbox", frame)
  nameEditbox:AddAnchor("LEFT", gradeComboBoxButton, "RIGHT", 5, 0)
  nameEditbox:SetExtent(170, DEFAULT_SIZE.EDIT_HEIGHT)
  nameEditbox.selector:SetMaxTextLength(150)
  nameEditbox:CreateGuideText(locale.auction.guideText, ALIGN_LEFT, EDITBOX_GUIDE_INSET)
  nameEditbox:SetAutocomplete("item", "auctionable")
  local searchButton = frame:CreateChildWidget("button", "searchButton", 0, true)
  searchButton:AddAnchor("LEFT", nameEditbox, "RIGHT", 3, 0)
  searchButton:SetText(GetCommonText("search"))
  searchButton:SetStyle("text_default")
  local matchWordTextbox
  if auctionLocale.viewMatchWordBox then
    matchWordTextbox = CreateCheckButton("matchWordTextbox", frame, {
      textData = {
        text = locale.auction.matchWord
      }
    })
    matchWordTextbox:AddAnchor("LEFT", searchButton, "RIGHT", 5, 0)
  end
  frame.matchWordTextbox = matchWordTextbox
  local showDirectPriceRangeEdit = X2Auction:IsShowDirectPriceRangeEdit()
  local showDirectPriceRangeButton = frame:CreateChildWidget("button", "showDirectPriceRangeButton", 0, true)
  showDirectPriceRangeButton:AddAnchor("RIGHT", frame, 0, 0)
  if showDirectPriceRangeEdit then
    showDirectPriceRangeButton:SetStyle("minus")
  else
    showDirectPriceRangeButton:SetStyle("plus")
  end
  if F_MONEY.currency.auctionBid == CURRENCY_AA_POINT then
    frame.minDirectPriceWindow = W_MONEY.CreateAAPointEditsWindow("minDirectPriceEdit", frame)
  else
    frame.minDirectPriceWindow = W_MONEY.CreateMoneyEditsWindow("minDirectPriceEdit", frame)
  end
  frame.minDirectPriceWindow.goldEdit:Show(showDirectPriceRangeEdit)
  frame.minDirectPriceWindow.silverEdit:Show(false)
  frame.minDirectPriceWindow.copperEdit:Show(false)
  frame.minDirectPriceWindow:SetExtentByMultiplier(1, 4605831338911806259)
  frame.minDirectPriceWindow:SetMoneyFontSize(FONT_SIZE.SMALL)
  frame.minDirectPriceWindow:AddAnchor("TOPLEFT", nameEditbox, "BOTTOMLEFT", 0, 5)
  local tildeLabel2 = CreateSearchFrameLabel("tildeLabel2", "~")
  tildeLabel2:AddAnchor("LEFT", frame.minDirectPriceWindow.goldEdit, "RIGHT", 2, 0)
  tildeLabel2:Show(showDirectPriceRangeEdit)
  if F_MONEY.currency.auctionBid == CURRENCY_AA_POINT then
    frame.maxDirectPriceWindow = W_MONEY.CreateAAPointEditsWindow("maxDirectPriceEdit", frame)
  else
    frame.maxDirectPriceWindow = W_MONEY.CreateMoneyEditsWindow("maxDirectPriceEdit", frame)
  end
  frame.maxDirectPriceWindow.goldEdit:Show(X2Auction:IsShowDirectPriceRangeEdit())
  frame.maxDirectPriceWindow.silverEdit:Show(false)
  frame.maxDirectPriceWindow.copperEdit:Show(false)
  frame.maxDirectPriceWindow:SetExtentByMultiplier(1, 4605831338911806259)
  frame.maxDirectPriceWindow:SetMoneyFontSize(FONT_SIZE.SMALL)
  frame.maxDirectPriceWindow:AddAnchor("TOPLEFT", frame.minDirectPriceWindow.goldEdit, "TOPRIGHT", tildeLabel2:GetWidth() + 4, 0)
  local directPriceRangeLabel = CreateSearchFrameLabel("directPriceRangeLabel", GetCommonText("auction_search_direct_price_per_one"))
  directPriceRangeLabel.style:SetAlign(ALIGN_RIGHT)
  directPriceRangeLabel:AddAnchor("RIGHT", frame.minDirectPriceWindow.goldEdit, "LEFT", -5, 0)
  directPriceRangeLabel:Show(showDirectPriceRangeEdit)
  RegistCoolTimeButton(searchButton, 1)
end
local CreateCategoryFrame = function(window)
  local categoryFrame = W_CTRL.CreateScrollListBox("categoryFrame", window, window)
  categoryFrame.content:EnableSelectionToggle(true)
  categoryFrame:SetExtent(230, 484)
  categoryFrame:AddAnchor("TOPLEFT", window.searchFrame, "BOTTOMLEFT", 0, MARGIN.WINDOW_SIDE)
  categoryFrame.content:ShowTooltip(auctionLocale.categoryTooltip)
  window.categoryFrame = categoryFrame
  categoryFrame:SetTreeImage()
  local MakeCategoryID = function(depth1_id, depth2_id, depth3_id)
    local idStr = string.format("%02d%02d%02d", depth1_id, depth2_id, depth3_id)
    local idNum = tonumber(idStr)
    if idNum == nil then
      UIParent:DevLog(string.format("[ERROR - bid_view.lua] MakeCategoryID() can't make id"))
      return 0
    end
    return idNum
  end
  local itemCategoryTable = {}
  for depth1 = 1, #auctionLocale.auctionCategories do
    itemCategoryTable[depth1] = {}
    local depth1_table = itemCategoryTable[depth1]
    local depth1_categories = auctionLocale.auctionCategories[depth1]
    depth1_table.text = depth1_categories.name
    depth1_table.value = MakeCategoryID(depth1_categories.id, 0, 0)
    if depth1_categories.useColor ~= nil then
      depth1_table.useColor = depth1_categories.useColor
      depth1_table.defaultColor = depth1_categories.defaultColor
      depth1_table.selectColor = depth1_categories.selectColor
      depth1_table.overColor = depth1_categories.overColor
    end
    if depth1_categories.iconPath ~= nil then
      depth1_table.iconPath = depth1_categories.iconPath
      depth1_table.infoKey = depth1_categories.infoKey
    end
    if depth1_categories.child ~= nil then
      depth1_table.child = {}
      for depth2 = 1, #depth1_categories.child do
        depth1_table.child[depth2] = {}
        local depth2_table = depth1_table.child[depth2]
        local depth2_categories = depth1_categories.child[depth2]
        depth2_table.text = depth2_categories.name
        depth2_table.value = MakeCategoryID(depth1_categories.id, depth2_categories.id, 0)
        if depth2_categories.child ~= nil then
          depth2_table.child = {}
          for depth3 = 1, #depth2_categories.child do
            depth2_table.child[depth3] = {}
            local depth3_table = depth2_table.child[depth3]
            local depth3_categories = depth2_categories.child[depth3]
            depth3_table.text = depth3_categories.name
            depth3_table.value = MakeCategoryID(depth1_categories.id, depth2_categories.id, depth3_categories.id)
          end
        end
      end
    end
  end
  categoryFrame:SetItemTrees(itemCategoryTable)
end
local CreateItemListFrame = function(window)
  local listInfos = {
    width = 620,
    height = 475,
    anchorWidget = window.categoryFrame,
    columns = {
      {
        name = locale.auction.name,
        width = auctionLocale.width.bidNameCol,
        itemType = LCCIT_WINDOW,
        layoutFunc = LayoutAuctionItemName,
        dataSetFunc = DataSetAuctionItemName,
        sortKinds = {
          columnSortKind[5]
        }
      },
      {
        name = locale.auction.level,
        width = auctionLocale.width.bidLevelCol,
        itemType = LCCIT_TEXTBOX,
        dataSetFunc = DataSetAuctionItemLevel,
        sortKinds = {
          columnSortKind[6]
        }
      },
      {
        name = GetUIText(TOOLTIP_TEXT, "left_time"),
        width = auctionLocale.width.bidTimeCol,
        itemType = LCCIT_STRING,
        layoutFunc = LayoutAuctionItemLeftTime,
        dataSetFunc = DataSetAuctionItemLeftTime,
        sortKinds = {
          columnSortKind[7]
        }
      },
      {
        name = locale.auction.bidState,
        width = auctionLocale.width.bidStateCol,
        itemType = LCCIT_TEXTBOX,
        layoutFunc = LayoutAuctionTextboxColumn,
        dataSetFunc = DataSetAuctionItemBiddingState
      },
      {
        name = locale.auction.bidPrice,
        width = auctionLocale.width.bidBidPrice,
        itemType = LCCIT_WINDOW,
        layoutFunc = LayoutAuctionBiddingPrice,
        dataSetFunc = DataSetAuctionBiddingPrice,
        sortKinds = {
          columnSortKind[1],
          columnSortKind[2],
          columnSortKind[3],
          columnSortKind[4]
        },
        defaultSortKinds = 3
      }
    }
  }
  CreateAuctionItemList(window, listInfos)
  window.listCtrl:EnableColumn(4, false)
end
local CreateCenterGuideFrame = function(window)
  local center_guide = window:CreateChildWidget("label", "center_guide", 0, true)
  center_guide:Show(false)
  center_guide:SetAutoResize(true)
  center_guide:SetHeight(FONT_SIZE.XLARGE)
  center_guide.style:SetFontSize(FONT_SIZE.XLARGE)
  center_guide:AddAnchor("CENTER", window.listCtrl, 0, 0)
  center_guide.style:SetColorByKey("default")
  function window:ShowFirstGuide(visible)
    self.center_guide:Show(visible)
    if visible then
      self.center_guide:SetText(locale.auction.first_search_guide)
    end
  end
  function window:ShowNoneSearchResult(visible)
    self.center_guide:Show(visible)
    if visible then
      self.center_guide:SetText(locale.auction.none_search_result)
    end
  end
end
local CreateBottomFrame = function(window)
  local availableMoney = W_MONEY.CreateTitleMoneyWindow("availableMoney", window, nil, "vertical")
  availableMoney:AddAnchor("BOTTOMLEFT", window, 0, 0)
  window.availableMoney = availableMoney
  local availableAAPoint = W_MONEY.CreateTitleMoneyWindow("availableAAPoint", window, GetUIText(MONEY_TEXT, "aa_point"), "vertical")
  if F_MONEY.currency.auctionFee ~= CURRENCY_GOLD or F_MONEY.currency.auctionBid ~= CURRENCY_GOLD then
    availableAAPoint:Show(true)
  else
    availableAAPoint:Show(false)
  end
  availableAAPoint:AddAnchor("LEFT", availableMoney, "RIGHT", 20, 0)
  window.availableAAPoint = availableAAPoint
  F_MONEY:SetMoneyTooltip(availableMoney, availableAAPoint)
  local marketPriceBtn = CreateMarketPriceBtn("marketPriceBtn", window)
  window.marketPriceBtn = marketPriceBtn
  local directButton = window:CreateChildWidget("button", "directButton", 0, true)
  directButton:SetText(locale.common.buy)
  directButton:SetStyle("text_default")
  if marketPriceBtn == nil then
    directButton:AddAnchor("BOTTOMRIGHT", window, 0, 0)
  else
    marketPriceBtn:AddAnchor("BOTTOMRIGHT", window, 0, 0)
    directButton:AddAnchor("BOTTOMRIGHT", marketPriceBtn, "BOTTOMLEFT", -5, 0)
  end
  local bidButton = window:CreateChildWidget("button", "bidButton", 0, true)
  bidButton:AddAnchor("BOTTOMRIGHT", directButton, "BOTTOMLEFT", 0, 0)
  bidButton:SetText(locale.auction.bid_money)
  bidButton:SetStyle("text_default")
  local buttonTable = {directButton, bidButton}
  AdjustBtnLongestTextWidth(buttonTable)
  local moneyEditsWindow
  if F_MONEY.currency.auctionBid == CURRENCY_AA_POINT then
    moneyEditsWindow = W_MONEY.CreateAAPointEditsWindow("moneyEditsWindow", window)
  else
    moneyEditsWindow = W_MONEY.CreateMoneyEditsWindow("moneyEditsWindow", window)
  end
  moneyEditsWindow:AddAnchor("BOTTOMRIGHT", bidButton, "BOTTOMLEFT", -5, -5)
  window.moneyEditsWindow = moneyEditsWindow
end
function SetViewOfAuctionBidFrame(window)
  CreateSearchFrame(window)
  CreateCategoryFrame(window)
  CreateItemListFrame(window)
  CreateCenterGuideFrame(window)
  window:ShowFirstGuide(true)
  CreateBottomFrame(window)
end
