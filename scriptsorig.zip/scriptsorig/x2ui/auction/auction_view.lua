function SetViewOfAuctionWindow(id, parent)
  local w = CreateWindow(id, parent, "auction")
  w:Show(false)
  w:Clickable(true)
  w:SetExtent(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_900), 714)
  w:AddAnchor("CENTER", "UIParent", 0, 0)
  w:SetTitle(GetUIText(WINDOW_TITLE_TEXT, "auction"))
  local tabTexts = {
    locale.auction.bid,
    locale.auction.putup,
    locale.auction.bidHistory
  }
  local tab = W_TAB.CreateTab("tab", w)
  tab:AddTabs(tabTexts)
  CreateAuctionBidFrame(tab.window[1])
  CreateAuctionPutupFrame(tab.window[2])
  CreateAuctionBidHistoryFrame(tab.window[3])
  return w
end
