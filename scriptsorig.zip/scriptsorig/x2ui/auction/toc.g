﻿## author : zergra
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## auction

locale/ko.lua
locale/ja.lua
locale/ru.lua
locale/en_us.lua
locale/zh_cn.lua
locale/zh_tw.lua
locale/th.lua

dialog.lua
common.lua

bid_view.lua
bid.lua

putup_view.lua
putup.lua

bid_history_view.lua
bid_history.lua

auction_view.lua
auction.lua

market_price.lua