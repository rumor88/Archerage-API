function CreateAuctionBidHistoryFrame(window)
  SetViewOfAuctionBidHistoryFrame(window)
  local listCtrl = window.listCtrl
  local pageControl = window.pageControl
  local bidButton = window.bidButton
  local directButton = window.directButton
  local moneyEditsWindow = window.moneyEditsWindow
  local availableMoney = window.availableMoney
  local availableAAPoint = window.availableAAPoint
  local refreshButton = window.refreshButton
  local function EnableMarketPriceBtn(enable)
    if window.marketPriceBtn == nil then
      return
    end
    window.marketPriceBtn:Enable(enable)
  end
  local function SetMarketPriceBtn(itemType, itemGrade)
    if window.marketPriceBtn == nil then
      return
    end
    if itemType == nil then
      window.marketPriceBtn:InitMarketPrice()
    end
    window.marketPriceBtn:SetMarketPrice(itemType, itemGrade)
  end
  function window:EnableSearch(enable)
    pageControl:Enable(enable, true)
    local selIdx = listCtrl:GetSelectedIdx()
    if selIdx > 0 then
      bidButton:Enable(enable)
      directButton:Enable(enable)
      EnableMarketPriceBtn(enable)
      local bidPrice, directPrice = X2Auction:GetSearchedItemPrice(selIdx)
      if bidPrice == nil or directPrice == nil then
        return
      end
      if directPrice == "0" then
        directButton:Enable(false)
      end
    else
      bidButton:Enable(false)
      directButton:Enable(false)
      EnableMarketPriceBtn(false)
    end
  end
  function window:Init()
    listCtrl:DeleteAllDatas()
    pageControl:Init()
    moneyEditsWindow:SetAmountStr("0")
    moneyEditsWindow:SetCurrencyAmountLimit(moneyEditsWindow:GetSystemCurrencyAmountLimit())
    bidButton:Enable(false)
    directButton:Enable(false)
    EnableMarketPriceBtn(false)
    availableMoney:Update(X2Util:GetMyMoneyString(), false)
    availableAAPoint:UpdateAAPoint(X2Util:GetMyAAPointString(), false)
  end
  function window:OnShow()
    X2Auction:SetCurTab(2)
    self:Init()
    X2Auction:SearchMyBidList(1)
    SetSearchCoolTime()
  end
  window:SetHandler("OnShow", window.OnShow)
  function listCtrl:OnSelChangedProc(selIdx, doubleClick)
    if selIdx > 0 then
      bidButton:Enable(true)
      directButton:Enable(true)
      EnableMarketPriceBtn(true)
    else
      bidButton:Enable(false)
      directButton:Enable(false)
      EnableMarketPriceBtn(false)
      SetMarketPriceBtn()
      return
    end
    local itemInfo = X2Auction:GetSearchedItemInfo(selIdx)
    SetMarketPriceBtn(itemInfo.itemType, itemInfo.itemGrade)
    local DEFAULT_BID_AMOUNT_DIFF = "10"
    local newPriceStr = X2Util:StrNumericAdd(itemInfo.bidPriceStr, DEFAULT_BID_AMOUNT_DIFF)
    local maxLimitStr = moneyEditsWindow:GetSystemCurrencyAmountLimit()
    local directPrice = itemInfo.directPriceStr
    if directPrice == "0" then
      directButton:Enable(false)
    else
      if 0 < X2Util:StrNumericComp(newPriceStr, directPrice) then
        newPriceStr = directPrice
      end
      maxLimitStr = directPrice
    end
    if itemInfo.maxPriceLimit ~= nil then
      local maxPrice = X2Util:MultiplyNumberString(itemInfo.maxPriceLimit, tostring(itemInfo.stackCount))
      if 0 < X2Util:StrNumericComp(newPriceStr, maxPrice) then
        newPriceStr = maxPrice
      end
      if 0 < X2Util:StrNumericComp(maxLimitStr, maxPrice) then
        maxLimitStr = maxPrice
      end
    end
    moneyEditsWindow:SetAmountStr(newPriceStr)
    moneyEditsWindow:SetCurrencyAmountLimit(maxLimitStr)
    MakeItemLink(selIdx, self)
    if doubleClick then
      directButtonOnClick(window, "LeftButton")
    end
  end
  function pageControl:OnPageChanged(pageIndex, countPerPage)
    self:Enable(false, true)
    X2Auction:SearchMyBidList(pageIndex)
  end
  function bidButton:OnClick(MBT)
    bidButtonOnClick(window, MBT)
  end
  bidButton:SetHandler("OnClick", bidButton.OnClick)
  function directButton:OnClick(MBT)
    directButtonOnClick(window, MBT)
  end
  directButton:SetHandler("OnClick", directButton.OnClick)
  local function RefreshButtonLeftButtonClickFunc()
    X2Auction:SearchMyBidList(pageControl:GetCurrentPageIndex())
    SetSearchCoolTime()
  end
  ButtonOnClickHandler(refreshButton, RefreshButtonLeftButtonClickFunc)
  return frame
end
