local PAGE_PER_COUNT = 9
columnSortKind = {
  {"bid_price", true},
  {"bid_price", false},
  {
    "direct_price",
    true
  },
  {
    "direct_price",
    false
  },
  {"item_name", nil},
  {"item_level", nil},
  {
    "expire_date",
    nil
  },
  {"evaluated", nil}
}
BID_STATE = {
  BS_NOBID = 0,
  BS_MYSELF_BID = 1,
  BS_OTHER_PEOPLE_BID = 2
}
PartitionStack = {
  5,
  10,
  50,
  100
}
local GetSortKindName = function(sortKind, ascending)
  if ascending == nil then
    return GetCommonText(sortKind)
  end
  local attachment = ascending and "_asc" or "_desc"
  return GetCommonText(string.format("%s%s", sortKind, attachment))
end
coolTimeButtons = {}
searchCoolTime = nil
function IsSearchCoolTime()
  UIParent:DevLog(string.format("[LOG] IsSearchCoolTime, %s", tostring(searchCoolTime)))
  return searchCoolTime ~= nil and searchCoolTime > 0
end
function RegistCoolTimeButton(btn, sec)
  local obj = {button = btn, coolTime = sec}
  table.insert(coolTimeButtons, obj)
end
function SetSearchCoolTime()
  searchCoolTime = os.clock()
  UIParent:DevLog(string.format("[LOG] set search cooltime, %s", tostring(searchCoolTime)))
  for i = 1, #coolTimeButtons do
    if coolTimeButtons[i].button.SetEnable ~= nil then
      coolTimeButtons[i].button:SetEnable(false)
    else
      coolTimeButtons[i].button:Enable(false)
    end
  end
  auctionWindow:SetHandler("OnUpdate", auctionWindow.OnUpdate)
end
function CheckSearchCoolTime()
  if searchCoolTime == nil then
    UIParent:DevLog(string.format("[ERROR] auction check search cooltime is nil~!"))
    return
  end
  local enableBtns = 0
  local nowTime = os.clock()
  local sec = nowTime - searchCoolTime
  for i = 1, #coolTimeButtons do
    local coolTime = coolTimeButtons[i].coolTime
    if sec > coolTime then
      if coolTimeButtons[i].button.SetEnable ~= nil then
        coolTimeButtons[i].button:SetEnable(true)
      else
        coolTimeButtons[i].button:Enable(true)
      end
      enableBtns = enableBtns + 1
    end
  end
  if enableBtns == #coolTimeButtons then
    searchCoolTime = nil
    auctionWindow:ReleaseHandler("OnUpdate")
  end
end
function MakeItemLink(selectIndex, listCtrl)
  if X2Input:IsShiftKeyDown() then
    if X2Chat:IsActivatedChatInput() then
      local itemLink = X2Auction:GetLinkText(selectIndex)
      AddLinkItem(itemLink)
    else
      local window = listCtrl:GetParent()
      if window.searchFrame == nil or window.searchFrame.nameEditbox == nil then
        return
      end
      local itemInfo = X2Auction:GetSearchedItemInfo(selectIndex)
      if itemInfo == nil then
        return
      end
      window.searchFrame.nameEditbox:LinkText(tostring(itemInfo.name))
    end
  end
end
function IsPartitionAuctionItem(itemInfo)
  if itemInfo.minStack > 0 and 0 < itemInfo.maxStack then
    return true
  end
  return false
end
function LayoutAuctionItemName(subItem, row, listCtrl)
  local size = F_PREFIX_SIZE:GetIconButtonSize(ICON_SIZE_35)
  local itemButton = CreateIconButton("itemButton", subItem)
  itemButton:SetExtent(size, size)
  itemButton:AddAnchor("LEFT", subItem, 3, 0)
  subItem.itemButton = itemButton
  function itemButton:OnClickProc(arg)
    if arg ~= "LeftButton" or itemButton.auctionItemIdx == nil then
      return
    end
    MakeItemLink(itemButton.auctionItemIdx, listCtrl)
  end
  local width, height = subItem:GetExtent()
  local itemName = subItem:CreateChildWidget("textbox", "itemName", 0, true)
  itemName:AddAnchor("LEFT", itemButton, "RIGHT", 4, 0)
  itemName:SetExtent(width - size - 10, height)
  itemName:SetLineSpace(TEXTBOX_LINE_SPACE.SMALL)
  itemName.style:SetAlign(ALIGN_LEFT)
  itemName.style:SetEllipsis(true)
end
function DataSetAuctionItemName(subItem, data)
  if data == nil then
    subItem.itemButton:Show(true)
    subItem.itemName:SetText("")
    subItem.itemButton.auctionItemIdx = nil
  else
    local color = F_COLOR.Hex2Dec(data.gradeColor)
    local x, y = subItem.itemButton:GetOffset()
    subItem.itemButton:Init()
    subItem.itemButton:SetInfo(data)
    subItem.itemButton:SetStack(data.stackCount, 0, auctionLocale.stackNumberOnly)
    subItem.itemButton:Show(true)
    subItem.itemButton.auctionItemIdx = data.auctionItemIdx
    F_COLOR.ApplyTextColor(subItem.itemName, color)
    subItem.itemName:SetText(tostring(data.name))
    subItem.itemName:Show(true)
  end
end
function LayoutAuctionTextboxColumn(subItem, row, listCtrl)
  subItem:SetLineSpace(TEXTBOX_LINE_SPACE.SMALL)
end
function DataSetAuctionItemLevel(subItem, data)
  if data == nil then
    subItem:SetText("")
  else
    local levelStr = GetLevelToString(data.level_requirement or 1)
    subItem:SetText(levelStr)
  end
end
function DataSetAuctionMyItemBiddingState(subItem, data)
  if data == nil then
    return ""
  else
    local articleId = data.articleId
    local bidState = data.bidState
    local str = ""
    if bidState ~= BID_STATE.BS_NOBID then
      str = locale.auction.bidding
      subItem.style:SetColorByKey("blue")
    else
      str = locale.auction.notBid
      if IsPartitionAuctionItem(data) then
        str = locale.auction.sellPartition
      end
      subItem.style:SetColorByKey("gray")
    end
    subItem:SetText(str)
  end
end
function DataSetAuctionItemBiddingState(subItem, data)
  if data == nil then
    subItem:SetText("")
  else
    local bidState = data.bidState
    local seller = tostring(data.seller)
    local curWorldId = X2:GetCurrentWorldId()
    local str = ""
    if X2Auction:IsMyPutupArticle(data.idx) then
      str = string.format("%s%s|r", F_COLOR.GetColor("default", true), locale.auction.myPutupGoods)
    end
    if bidState == BID_STATE.BS_NOBID then
      if IsPartitionAuctionItem(data) then
        str = F_TEXT.SetEnterString(str, locale.auction.sellPartition)
      else
        str = F_TEXT.SetEnterString(str, locale.auction.notBid)
      end
      subItem.style:SetColorByKey("gray")
    elseif bidState == BID_STATE.BS_MYSELF_BID then
      str = F_TEXT.SetEnterString(str, locale.auction.myselfBid)
      subItem.style:SetColorByKey("green")
    else
      str = F_TEXT.SetEnterString(str, locale.auction.otherPeopleBid)
      subItem.style:SetColorByKey("blue")
    end
    subItem:SetText(str)
  end
end
function LayoutAuctionItemLeftTime(subItem, row, listCtrl)
  subItem:SetInset(0, 0, auctionLocale.leftTimeColInset, 0)
  subItem.style:SetAlign(ALIGN_RIGHT)
  subItem.style:SetColorByKey("default")
end
function DataSetAuctionItemLeftTime(subItem, data)
  if data == nil then
    subItem:SetText("")
  else
    local articleId = data.articleId
    local leftTimeStr, timeWarning = CheckLeftTime(data.leftTime)
    if timeWarning then
      subItem.style:SetColorByKey("red")
    else
      subItem.style:SetColorByKey("default")
    end
    subItem:SetText(leftTimeStr)
  end
end
function LayoutAuctionBiddingPrice(subItem, row, listCtrl)
  local currentIcon = subItem:CreateDrawable(TEXTURE_PATH.AUCTION, "icon_current", "background")
  currentIcon:AddAnchor("TOPRIGHT", subItem, 0, 2)
  subItem.currentIcon = currentIcon
  local currentPrice = W_MONEY.CreateDefaultMoneyWindow("currentPrice", subItem, 150, 15)
  currentPrice:AddAnchor("RIGHT", currentIcon, "LEFT", -2, 0)
  currentPrice.currency = F_MONEY.currency.auctionBid
  subItem.currentPrice = currentPrice
  local directIcon = subItem:CreateDrawable(TEXTURE_PATH.AUCTION, "icon_direct", "background")
  directIcon:AddAnchor("BOTTOMRIGHT", subItem, 0, -2)
  subItem.directIcon = directIcon
  local directPrice = W_MONEY.CreateDefaultMoneyWindow("directPrice", subItem, 150, 15)
  directPrice:AddAnchor("RIGHT", directIcon, "LEFT", -2, 0)
  directPrice.currency = F_MONEY.currency.auctionBid
  subItem.directPrice = directPrice
  local directForbiddenLabel = subItem:CreateChildWidget("label", "directForbiddenLabel", 0, true)
  directForbiddenLabel:SetExtent(110, 15)
  directForbiddenLabel:AddAnchor("RIGHT", directIcon, "LEFT", -2, 0)
  directForbiddenLabel:SetText(locale.auction.directForbidden)
  directForbiddenLabel.style:SetColorByKey("red")
  directForbiddenLabel.style:SetAlign(ALIGN_RIGHT)
end
function DataSetAuctionBiddingPrice(subItem, data)
  if data == nil then
    subItem.currentIcon:SetVisible(false)
    subItem.currentPrice:Show(false)
    subItem.directIcon:SetVisible(false)
    subItem.directPrice:Show(false)
    subItem.directForbiddenLabel:Show(false)
  else
    subItem.currentPrice:Show(true)
    subItem.currentPrice:Update(data.bidPriceStr, false)
    subItem.currentIcon:Show(true)
    local itemDirectPrice = data.directPriceStr
    if itemDirectPrice == "0" then
      subItem.directForbiddenLabel:Show(true)
      subItem.directIcon:SetVisible(false)
      subItem.directPrice:Show(false)
    else
      subItem.directIcon:SetVisible(true)
      subItem.directPrice:Show(true)
      subItem.directPrice:Update(itemDirectPrice, false)
      subItem.directForbiddenLabel:Show(false)
      if IsPartitionAuctionItem(data) then
        subItem.currentPrice:Update(X2Auction:GetPartitionPriceByCount(data.directPriceStr, data.stackCount, 1), false)
        subItem.currentIcon:SetTextureInfo("icon_division")
      else
        subItem.currentIcon:SetTextureInfo("icon_current")
      end
    end
    local itemStackCnt = data.stackCount
    if IsPartitionAuctionItem(data) then
      do
        local minStackCount = math.min(data.minStack, data.stackCount)
        local tipStr = ""
        tipStr = F_TEXT.SetEnterString(tipStr, locale.auction.minStackCount(tostring(minStackCount)))
        tipStr = F_TEXT.SetEnterString(tipStr, F_TEXT.SetColonFormat(locale.auction.minStackPrice, F_MONEY:GetCostStringByCurrency(F_MONEY.currency.auctionBid, tostring(X2Auction:GetPartitionPriceByCount(data.directPriceStr, data.stackCount, minStackCount)))))
        tipStr = F_TEXT.SetEnterString(tipStr, F_TEXT.SetColonFormat(locale.auction.directPriceTooltip, F_MONEY:GetCostStringByCurrency(F_MONEY.currency.auctionBid, tostring(X2Auction:GetPartitionPriceByCount(data.directPriceStr, data.stackCount, 1)))))
        local function OnEnter(self)
          SetTooltip(tipStr, self)
        end
        subItem:SetHandler("OnEnter", OnEnter)
      end
    elseif itemStackCnt > 1 then
      do
        local bidPricePerCnt = X2Util:DivideNumberString(data.bidPriceStr, tostring(itemStackCnt))
        local directPricePerCnt = X2Util:DivideNumberString(itemDirectPrice, tostring(itemStackCnt))
        local tipStr = ""
        tipStr = F_TEXT.SetEnterString(tipStr, F_TEXT.SetColonFormat(locale.auction.bidPriceTooltip, F_MONEY:GetCostStringByCurrency(F_MONEY.currency.auctionBid, tostring(bidPricePerCnt))))
        tipStr = F_TEXT.SetEnterString(tipStr, F_TEXT.SetColonFormat(locale.auction.directPriceTooltip, F_MONEY:GetCostStringByCurrency(F_MONEY.currency.auctionBid, tostring(directPricePerCnt))))
        local function OnEnter(self)
          SetTooltip(tipStr, self)
        end
        subItem:SetHandler("OnEnter", OnEnter)
      end
    else
      subItem:ReleaseHandler("OnEnter")
      subItem:ReleaseHandler("OnLeave")
    end
  end
end
function LayoutAuctionMyBiddingPrice(subItem, row, listCtrl)
  local myBiddingPrice = W_MONEY.CreateDefaultMoneyWindow("myBiddingPrice", subItem, 145, 15)
  myBiddingPrice.currency = F_MONEY.currency.auctionBid
  myBiddingPrice:Show(true)
  myBiddingPrice:AddAnchor("RIGHT", subItem, -10, 0)
  subItem.myBiddingPrice = myBiddingPrice
end
function DataSetAuctionMyBiddingPrice(subItem, data)
  if data == nil then
    subItem.myBiddingPrice:Show(false)
  else
    subItem.myBiddingPrice:Show(true)
    subItem.myBiddingPrice:Update(data.myBidMoney, false)
  end
end
local UpdateComboBoxTypeSorting = function(window)
  local listCtrl = window.listCtrl
  local sortKind, ascendingSort = X2Auction:GetSearchedSortInfo()
  for i = 1, listCtrl:GetColumnCount() do
    local column = listCtrl:GetColumn(i)
    if column.sortKinds ~= nil then
      sortKindCount = #column.sortKinds
      if 1 < sortKindCount then
        for j = 1, sortKindCount do
          if column.sortKinds[j][1] == sortKind and column.sortKinds[j][2] == ascendingSort then
            column.sortKindBtn:Select(j, false)
            break
          end
        end
      end
    end
  end
end
local UpdateSortingArrow = function(window)
  local listCtrl = window.listCtrl
  local sortKind, ascendingSort = X2Auction:GetSearchedSortInfo()
  for i = 1, listCtrl:GetColumnCount() do
    local column = listCtrl:GetColumn(i)
    if column.sortKinds ~= nil then
      local currentColumnSortKind
      if #column.sortKinds == 1 then
        currentColumnSortKind = column.sortKinds[1][1]
      elseif column.sortKindBtn:IsSelected() then
        currentColumnSortKind = column.sortKinds[column.sortKindBtn:GetSelectedIndex()][1]
      end
      if currentColumnSortKind == sortKind then
        if #column.sortKinds == 1 then
          listCtrl:ShowSortMark(i, ascendingSort and W_LISTCTRL.ASCENDING or W_LISTCTRL.DESCENDING)
        end
      elseif 1 < #column.sortKinds then
        column.sortKindBtn:Select(1, false)
      end
    end
  end
end
function RefreshItemList(window, forceAllClear, getmytotalcount)
  local listCtrl = window.listCtrl
  local itemCountNowPage = X2Auction:GetSearchedItemCount()
  if forceAllClear then
    itemCountNowPage = 0
  end
  listCtrl:DeleteAllDatas()
  if window.ShowNoneSearchResult ~= nil then
    window:ShowNoneSearchResult(itemCountNowPage == 0)
  end
  UpdateSortingArrow(window)
  for itemIdx = 1, itemCountNowPage do
    local itemInfo = X2Auction:GetSearchedItemInfo(itemIdx)
    if itemInfo == nil then
      return
    end
    itemInfo.auctionItemIdx = itemIdx
    listCtrl:InsertSharedData(itemIdx, itemInfo)
  end
  listCtrl:Refresh()
  window:EnableSearch(true)
  local maxLimitPage = X2Auction:GetSearchedItemTotalCount()
  local nowPage = X2Auction:GetSearchedItemPage()
  local remainCount = PAGE_PER_COUNT - itemCountNowPage
  if remainCount == 0 then
    if maxLimitPage > nowPage then
      remainCount = -PAGE_PER_COUNT
    end
  elseif remainCount == PAGE_PER_COUNT and nowPage > 1 then
    remainCount = 1
  end
  local totalCount = nowPage * PAGE_PER_COUNT - remainCount
  if getmytotalcount then
    totalCount = X2Auction:GetSearchedItemMyTotalCount()
    window:UpdatePutupCount()
  end
  window.pageControl:SetCurrentPage(nowPage, false)
  window.pageControl:SetPageByItemCount(totalCount, PAGE_PER_COUNT)
end
function CreateAuctionItemList(window, listInfos, isfullpagecontrol)
  local listCtrl = W_CTRL.CreateListCtrlNew("listCtrl", window, W_LISTCTRL.LAYOUT_PRESET_TYPE.DEFAULT_HAS_LOW_LINE)
  listCtrl:UseSortMark()
  listCtrl:SetUseDoubleClick(true)
  if listInfos.anchorWidget ~= nil then
    listCtrl:AddAnchor("TOPLEFT", listInfos.anchorWidget, "TOPRIGHT", 10, 0)
  else
    listCtrl:AddAnchor("TOPLEFT", window, 0, 20)
  end
  local width = 0
  for i = 1, #listInfos.columns do
    local info = listInfos.columns[i]
    local name = info.sortKinds ~= nil and 1 < #info.sortKinds and "" or info.name
    listCtrl:InsertColumn(name, info.width, info.itemType, info.layoutFunc, info.dataSetFunc)
    width = width + info.width
    local column = listCtrl:GetColumn(i)
    column.sortKinds = info.sortKinds
    if column.sortKinds ~= nil then
      if #column.sortKinds == 1 then
        RegistCoolTimeButton(column, 1)
      else
        local sortKinds = {}
        for j = 1, #column.sortKinds do
          local data = {
            text = GetSortKindName(column.sortKinds[j][1], column.sortKinds[j][2]),
            value = i
          }
          table.insert(sortKinds, data)
        end
        local sortKindBtn = W_CTRL.CreateComboBox("sortKindBtn", window)
        sortKindBtn:AddAnchor("TOPLEFT", column, 20, 5)
        sortKindBtn:AddAnchor("BOTTOMRIGHT", column, -20, -5)
        sortKindBtn:AppendItems(sortKinds, false)
        column.sortKindBtn = sortKindBtn
        local savedSortKind = X2Auction:GetSearchedSortInfo()
        if info.defaultSortKinds ~= nil and savedSortKind == "default" then
          sortKindBtn:Select(info.defaultSortKinds, false)
          X2Auction:SetListSort(info.sortKinds[info.defaultSortKinds][1], info.sortKinds[info.defaultSortKinds][2])
        else
          sortKindBtn:Select(1, false)
        end
        RegistCoolTimeButton(sortKindBtn, 1)
      end
    else
      listCtrl:EnableColumn(i, false)
    end
    if column.sortKindBtn == nil then
      function column:OnClick(MBT)
        if MBT == "LeftButton" then
          X2Auction:SearchedListSort(self.sortKinds[1][1], self.sortKinds[1][2])
          SetSearchCoolTime()
        end
      end
      column:SetHandler("OnClick", column.OnClick)
    else
      function column.sortKindBtn:SelectedProc(selectedIndex)
        local result = X2Auction:SearchedListSort(column.sortKinds[selectedIndex][1], column.sortKinds[selectedIndex][2])
        if result == false then
          self:Select(self:GetPrevSelectedIndex(), false)
        end
        SetSearchCoolTime()
      end
    end
  end
  listCtrl:SetExtent(width, listInfos.height)
  listCtrl:InsertRows(10, false)
  listCtrl:UseOverClickTexture()
  UpdateComboBoxTypeSorting(window)
  local pageControl = W_CTRL.CreatePageControl("pageControl", window, {
    useFirstPageButton = false,
    useLastPageButton = false,
    usePageLabel = false
  })
  pageControl:AddAnchor("TOP", listCtrl, "BOTTOM", 0, 5)
  window.pageControl = pageControl
  local refreshButton = window:CreateChildWidget("button", "refreshButton", 0, true)
  refreshButton:AddAnchor("TOPRIGHT", listCtrl, "BOTTOMRIGHT", 0, 5)
  refreshButton:Show(true)
  ApplyButtonSkin(refreshButton, BUTTON_BASIC.RESET)
  RegistCoolTimeButton(refreshButton, 1)
  function window:RefreshItemList(getmytotalcount)
    RefreshItemList(window, false, getmytotalcount)
  end
  function window:UpdateComboBoxTypeSorting()
    UpdateComboBoxTypeSorting(window)
  end
  function pageControl:OnPageChanged(pageIndex, countPerPage)
    if window.SetLastSearchArticlePage ~= nil then
      window:SetLastSearchArticlePage(pageIndex)
    end
    X2Auction:SearchAuctionArticleByPage(pageIndex)
  end
  local OnEnter = function(self)
    SetTooltip(locale.auction.refresh_tooltip, self)
  end
  refreshButton:SetHandler("OnEnter", OnEnter)
end
function bidButtonOnClick(window, MBT)
  if MBT == "LeftButton" then
    local selIdx = window.listCtrl:GetSelectedIdx()
    local articleId = X2Auction:GetSearchedItemArticleId(selIdx)
    local moneyStr = window.moneyEditsWindow:GetAmountStr()
    if articleId == nil or moneyStr == nil then
      return
    end
    window.listCtrl:ClearSelection()
    window.moneyEditsWindow:SetAmountStr("0")
    ShowDialogBidItemInAuction(window:GetParent():GetParent():GetId(), articleId, X2Auction:GetSearchedItemInfo(selIdx), moneyStr)
  end
end
function directButtonOnClick(window, MBT)
  if MBT == "LeftButton" then
    local selIdx = window.listCtrl:GetSelectedIdx()
    local articleId = X2Auction:GetSearchedItemArticleId(selIdx)
    local itemInfo = X2Auction:GetSearchedItemInfo(selIdx)
    if articleId == nil then
      return
    end
    if itemInfo.directPriceStr == "0" then
      AddMessageToSysMsgWindow(X2Locale:LocalizeUiText(ERROR_MSG, "auction_can_not_buy_direct_price"))
      return
    end
    window.listCtrl:ClearSelection()
    window.moneyEditsWindow:SetAmountStr("0")
    ShowDialogPurchaseItemInAuction(window:GetParent():GetParent():GetId(), articleId, itemInfo)
  end
end
function CheckLeftTime(leftSec)
  local hours_1 = 60
  local timeWarning = false
  local leftMin = math.floor(leftSec / hours_1)
  local leftTimeStr
  if hours_1 < leftMin then
    if leftMin % hours_1 > 0 then
      leftTimeStr = string.format("%d%s", math.floor(leftMin / hours_1) + 1, locale.auction.under_time)
    else
      leftTimeStr = string.format("%d%s", math.floor(leftMin / hours_1), locale.auction.under_time)
    end
  elseif leftMin == 0 then
    leftTimeStr = string.format("%s", GetUIText(SERVER_TEXT, "timeBelowOneMinute"))
    timeWarning = true
  else
    leftTimeStr = string.format("%d%s", leftMin, locale.tooltip.minute)
    timeWarning = true
  end
  return leftTimeStr, timeWarning
end
function CreateMarketPriceBtn(id, parent)
  if X2Player:GetFeatureSet().marketPrice ~= true then
    return
  end
  local button = parent:CreateChildWidget("button", id, 0, false)
  button:SetStyle("price")
  function button:SetMarketPrice(itemType, itemGrade)
    self.itemType = itemType
    self.itemGrade = itemGrade
  end
  function button:InitMarketPrice()
    self.itemType = nil
    self.itemGrade = 0
  end
  local OnEnter = function(self)
    SetTooltip(GetUIText(COMMON_TEXT, "maket_price_button_tooltip"), self)
  end
  button:SetHandler("OnEnter", OnEnter)
  local OnClick = function(self)
    if self.itemType == nil then
      return
    end
    if self.itemGrade == nil then
      self.itemGrade = 1
    end
    if ShowMarketPriceWindow ~= nil then
      ShowMarketPriceWindow(self.itemType, self.itemGrade)
    end
  end
  button:SetHandler("OnClick", OnClick)
  return button
end
