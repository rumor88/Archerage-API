local SQUAD_LIST_EVENT_BUTTON_TYPE = {APPLY = 1, CANCEL_RECRUIT = 2}
local currentInstance
local function SetViewOfSquadList(id, parent, width, height, titleHeight)
  local frame = parent:CreateChildWidget("emptywidget", id, 0, true)
  frame:SetExtent(width, height - titleHeight)
  local bgImg = frame:CreateDrawable(TEXTURE_PATH.DEFAULT, "common_bg", "background")
  bgImg:SetTextureColor("bg_01")
  bgImg:AddAnchor("TOPLEFT", frame, 0, -titleHeight)
  bgImg:AddAnchor("BOTTOMRIGHT", frame, 0, 0)
  local backButton = frame:CreateChildWidget("button", "backButton", 0, true)
  backButton:Enable(true)
  backButton:AddAnchor("TOPLEFT", frame, 10, 5)
  backButton:SetText(GetCommonText("squad_recruit_and_search_exit"))
  backButton:SetStyle("prev_page_back")
  local refreshButton = frame:CreateChildWidget("button", "refreshButton", 0, true)
  ApplyButtonSkin(refreshButton, BUTTON_BASIC.RESET)
  refreshButton:AddAnchor("TOPRIGHT", frame, -10, 5)
  local battlefieldLayoutLocale = GetLayoutSetBattleField()
  local squadList = W_MODULE:Create("squadList", frame, W_MODULE.TYPES.LISTCTRL, nil, {
    [W_MODULE.ATTRIBUTE.HAS_PAGE] = true,
    [W_MODULE.ATTRIBUTE.ROW_COUNT] = MAX_SQUAD_SELECT_COUNT_PER_PAGE,
    [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = 130,
    [W_MODULE.ATTRIBUTE.ROW_BACKGROUND_TYPE] = "type_4",
    [W_MODULE.ATTRIBUTE.PAGE_CHANGED_PROC] = function(pageIndex, countPerPage)
      if currentInstance == nil then
        return
      end
      X2Squad:GetSquadList(currentInstance, pageIndex - 1)
    end,
    [W_MODULE.ATTRIBUTE.ROW_CLICK_FUNC] = function(listCtrl, row, clickButton, data)
      if clickButton ~= "LeftButton" then
        return
      end
      if not X2Input:IsShiftKeyDown() then
        return
      end
      if not X2Chat:IsActivatedChatInput() then
        return
      end
      if not data.isMySquad then
        return
      end
      local squadRecruitLinkText = X2Squad:GetLinkText()
      X2Chat:AddSquadRecruitLinkToActiveChatInput(squadRecruitLinkText)
    end,
    [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = frame:GetWidth() - 20,
        [W_MODULE.ATTRIBUTE.TEXT] = "",
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
          local badgeHeight = 30
          local recruiterBg = CreateContentBackground(subItem, "TYPE2", "white_3")
          recruiterBg:AddAnchor("TOPLEFT", subItem, 10, 8)
          local recruiterLabel = subItem:CreateChildWidget("label", "recruiterLabel", 0, false)
          recruiterLabel:SetAutoResize(true)
          recruiterLabel:SetHeight(FONT_SIZE.MIDDLE)
          recruiterLabel.style:SetColorByKey("default")
          recruiterLabel:SetText(GetCommonText("raid_recruiter"))
          local line = CreateLine(subItem, "TYPE1")
          line:AddAnchor("LEFT", subItem, "LEFT", 10, -5)
          line:AddAnchor("RIGHT", subItem, "RIGHT", -10, 0)
          local litmitBg = CreateContentBackground(subItem, "TYPE2", "white_3")
          litmitBg:AddAnchor("TOPLEFT", line, 2, 6)
          local litmitLabel = subItem:CreateChildWidget("label", "litmitLabel", 0, false)
          litmitLabel:SetAutoResize(true)
          litmitLabel:SetHeight(FONT_SIZE.MIDDLE)
          litmitLabel.style:SetColorByKey("default")
          litmitLabel:SetText(GetCommonText("squad_limit_lable"))
          local explanationBg = CreateContentBackground(subItem, "TYPE2", "white_3")
          explanationBg:AddAnchor("TOPLEFT", litmitBg, "BOTTOMLEFT", 0, 0)
          local explanationLabel = subItem:CreateChildWidget("label", "explanationLabel", 0, false)
          explanationLabel:SetAutoResize(true)
          explanationLabel:SetHeight(FONT_SIZE.MIDDLE)
          explanationLabel.style:SetColorByKey("default")
          explanationLabel:SetText(GetCommonText("guide_explanation"))
          local explanationWidth = explanationLabel:GetWidth()
          local recruiterWidth = recruiterLabel:GetWidth()
          local limitWidth = litmitLabel:GetWidth()
          local longestWidth = math.max(explanationWidth, recruiterWidth, limitWidth) + 20
          recruiterBg:SetExtent(longestWidth, badgeHeight)
          recruiterLabel:AddAnchor("CENTER", recruiterBg, 0, 0)
          litmitBg:SetExtent(longestWidth, badgeHeight)
          litmitLabel:AddAnchor("CENTER", litmitBg, 0, 0)
          explanationBg:SetExtent(longestWidth, badgeHeight)
          explanationLabel:AddAnchor("CENTER", explanationBg, 0, 0)
          local openType = subItem:CreateChildWidget("label", "openType", 0, true)
          openType:SetAutoResize(true)
          openType:SetHeight(FONT_SIZE.MIDDLE)
          openType:AddAnchor("TOPRIGHT", subItem, -18, 15)
          openType.style:SetColorByKey("default")
          openType:SetText(GetCommonText("squad_open_type_public"))
          local openTypeGuide = W_ICON.CreateGuideIconWidget(openType)
          openTypeGuide:AddAnchor("RIGHT", openType, "LEFT", -1, 1)
          local OnEnter = function(self)
            SetTooltip(GetCommonText("squad_open_guide_tooltip"), self)
          end
          openTypeGuide:SetHandler("OnEnter", OnEnter)
          local headCountText = subItem:CreateChildWidget("label", "headCountText", 0, true)
          headCountText:SetHeight(FONT_SIZE.MIDDLE)
          headCountText:SetAutoResize(true)
          headCountText:AddAnchor("TOPRIGHT", openType, "BOTTOMRIGHT", 0, 10)
          headCountText.style:SetColorByKey("blue")
          local icon = subItem:CreateChildWidget("emptywidget", "icon", 0, true)
          icon:AddAnchor("RIGHT", headCountText, "LEFT", -4, 0)
          icon:Raise()
          local headCountIcon = subItem:CreateDrawable(TEXTURE_PATH.PEOPLE, "people", "overlay")
          headCountIcon:AddAnchor("CENTER", icon, 0, 0)
          icon:SetExtent(headCountIcon:GetExtent())
          local function OnEnterHeadCountIcon(self)
            local memberList = X2Squad:GetSquadMemberListStr(subItem.squadId)
            if memberList == nil then
              return
            end
            local str = GetCommonText("squad_members")
            str = F_TEXT.SetEnterString(str, memberList)
            SetTooltip(str, self)
          end
          icon:SetHandler("OnEnter", OnEnterHeadCountIcon)
          local topText = subItem:CreateChildWidget("textBox", "topText", 0, true)
          topText:SetHeight(FONT_SIZE.MIDDLE)
          topText.style:SetAlign(ALIGN_LEFT)
          topText:SetAutoWordwrap(false)
          topText:AddAnchor("TOPLEFT", recruiterBg, "TOPRIGHT", 5, 5)
          topText:AddAnchor("BOTTOMRIGHT", openTypeGuide, "BOTTOMLEFT", -8, 0)
          topText.style:SetColorByKey("blue")
          local charName = CreateCacheCharacterNameLabel("charName", subItem)
          charName:SetExtent(topText:GetWidth(), FONT_SIZE.MIDDLE)
          charName:AddAnchor("TOPLEFT", topText, "BOTTOMLEFT", 0, 5)
          charName.style:SetColorByKey("blue")
          local eventButton = subItem:CreateChildWidget("button", "eventButton", 0, true)
          eventButton:AddAnchor("TOPRIGHT", line, "BOTTOMRIGHT", -3, 15)
          eventButton:SetText(GetCommonText("apply_for_instance"))
          eventButton:SetStyle("text_default")
          eventButton.buttonType = nil
          local function OnClickEvenButton(self)
            if self.buttonType == nil then
              return
            elseif self.buttonType == SQUAD_LIST_EVENT_BUTTON_TYPE.APPLY then
              X2Squad:JoinSquad(self.squadId, self.fieldType)
            elseif self.buttonType == SQUAD_LIST_EVENT_BUTTON_TYPE.CANCEL_RECRUIT then
              X2Squad:DisbandSquadInRecruitList()
            end
          end
          eventButton:SetHandler("OnClick", OnClickEvenButton)
          local statusBadge = W_ICON.CreateTextBadge("statusBadge", subItem, {
            info = {
              applied = {
                text = GetUIText(COMMON_TEXT, "applied_in_squad"),
                colorKey = "green"
              },
              unable_to_apply = {
                text = GetUIText(COMMON_TEXT, "unable_to_apply"),
                colorKey = "red"
              }
            },
            fontSize = battlefieldLayoutLocale.textBadgeFontSize
          })
          statusBadge:Set("applied")
          statusBadge:AddAnchor("RIGHT", eventButton, "LEFT", -3, 0)
          subItem.statusBadge = statusBadge
          local limitText = subItem:CreateChildWidget("textBox", "limitText", 0, true)
          limitText.style:SetAlign(ALIGN_TOP_LEFT)
          limitText:AddAnchor("TOPLEFT", litmitBg, "TOPRIGHT", 5, 7)
          limitText:AddAnchor("BOTTOMRIGHT", statusBadge, "BOTTOMLEFT", -3, 13)
          limitText.style:SetColorByKey("blue")
          local explanationText = subItem:CreateChildWidget("label", "explanationText", 0, true)
          explanationText.style:SetAlign(ALIGN_TOP_LEFT)
          explanationText:AddAnchor("TOPLEFT", explanationBg, "TOPRIGHT", 5, 7)
          explanationText:AddAnchor("BOTTOMRIGHT", statusBadge, "BOTTOMLEFT", -3, 13)
          explanationText.style:SetColorByKey("blue")
          explanationText.style:SetEllipsis(true)
          F_TEXT.ApplyAutoEllipsisTooltipText(explanationText)
        end,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          local row = subItem:GetParent()
          if data then
            local isPublic = data.openType == SOT_PUBLIC or data.openType == SOT_MUST_PUBLIC
            local mySquad = data.isMySquad
            local buttonEnable = data.buttonEnable
            if mySquad then
              row:ChangeColorRowBackground("team_green")
            else
              local key = isPublic and "team_blue" or "team_purple"
              row:ChangeColorRowBackground(key)
            end
            row:ShowRowBackground(true)
            local topStr = F_TEXT.SetSlashFormat(GetLevelToString(data.ownerLevel, nil, nil, true), string.format("@%s", data.worldName))
            subItem.topText:SetText(topStr)
            subItem.charName:SetValue(data.nameCacheQueryId, data.ownerName)
            subItem.openType:SetText(isPublic and GetCommonText("squad_open_type_public") or GetCommonText("squad_open_type_private"))
            subItem.headCountText:SetText(F_TEXT.SetSlashFormat(data.curMemberCount, data.maxMemberCount))
            subItem.explanationText:SetText(data.explanationText)
            subItem.limitText:SetText(X2Locale:LocalizeUiText(COMMON_TEXT, "squad_limit_level_and_gear_score", GetLevelToString(data.limitLevel, nil, nil, true), tostring(data.limitGearScore)))
            if mySquad then
              subItem.statusBadge:Show(true)
              subItem.statusBadge:Set("applied")
            elseif not mySquad and not buttonEnable then
              subItem.statusBadge:Show(true)
              subItem.statusBadge:Set("unable_to_apply")
            else
              subItem.statusBadge:Show(false)
            end
            local buttonType = data.buttonType
            subItem.eventButton.buttonType = buttonType
            subItem.eventButton.squadId = data.squadId
            subItem.eventButton.fieldType = data.fieldType
            if buttonType == SQUAD_LIST_EVENT_BUTTON_TYPE.APPLY then
              subItem.eventButton:SetText(GetCommonText("apply_for_instance"))
              subItem.eventButton:Enable(buttonEnable)
            elseif buttonType == SQUAD_LIST_EVENT_BUTTON_TYPE.CANCEL_RECRUIT then
              subItem.eventButton:SetText(GetCommonText("delete"))
              subItem.eventButton:Enable(true)
            end
            subItem.squadId = data.squadId
            subItem:Show(true)
          else
            row:ShowRowBackground(false)
            subItem.eventButton.buttonType = nil
            subItem.eventButton.squadId = nil
            subItem.eventButton.fieldType = nil
            subItem.charName:ClearValue()
            subItem:Show(false)
          end
        end
      }
    }
  })
  squadList:AddAnchor("TOPLEFT", backButton, "BOTTOMLEFT", 0, 4)
  frame.squadList = squadList
  local inviteGuide = W_ICON.CreateGuideIconWidget(frame)
  inviteGuide:AddAnchor("TOPLEFT", frame, "BOTTOMLEFT", 0, 16)
  local inviteGuideLabel = frame:CreateChildWidget("label", "inviteGuideLabel", 0, true)
  inviteGuideLabel:SetAutoResize(true)
  inviteGuideLabel:SetHeight(FONT_SIZE.MIDDLE)
  inviteGuideLabel:AddAnchor("LEFT", inviteGuide, "RIGHT", 5, 0)
  inviteGuideLabel.style:SetColorByKey("default")
  inviteGuideLabel:SetText(GetCommonText("how_to_invite"))
  local OnEnterInviteGuide = function(self)
    SetTooltip(GetUIText(COMMON_TEXT, "squad_invite_guide"), self)
  end
  inviteGuide:SetHandler("OnEnter", OnEnterInviteGuide)
  local recruitButton = frame:CreateChildWidget("button", "recruitButton", 0, true)
  recruitButton:SetText(GetCommonText("raid_recruit"))
  recruitButton:AddAnchor("TOPRIGHT", frame, "BOTTOMRIGHT", -1, 9)
  recruitButton:SetStyle("text_default")
  return frame
end
function CreateSquadList(id, parent, width, height, titleHeight)
  local frame = SetViewOfSquadList(id, parent, width, height, titleHeight)
  local squadList = frame.squadList
  local recruitButton = frame.recruitButton
  function frame:SetCurrentInstance(type)
    currentInstance = type
  end
  local function OnClickRecruitButton()
    if X2Squad:IsInstanceQueuedOrJoined() or X2Team:IsSiegeRaidTeam() then
      return
    end
    if currentInstance == nil then
      return
    end
    ShowSquadRecruitDialog(parent, currentInstance)
  end
  ButtonOnClickHandler(recruitButton, OnClickRecruitButton)
  local function RefreshSquadList()
    if currentInstance == nil then
      return
    end
    local page = frame.squadList:GetDataPartially(W_MODULE.ATTRIBUTE.CURRENT_PAGE)
    if page == nil then
      return
    end
    X2Squad:GetSquadList(currentInstance, page - 1)
  end
  ButtonOnClickHandler(frame.refreshButton, RefreshSquadList)
  function frame:UpdateSquadList(data)
    if currentInstance == nil then
      frame.squadList:SetData({
        [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
        [W_MODULE.ATTRIBUTE.DATA] = nil
      })
      return
    end
    frame.squadList:SetData({
      [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
      [W_MODULE.ATTRIBUTE.DATA] = data.listInfo,
      [W_MODULE.ATTRIBUTE.MAX_DATA_COUNT] = data.maxCount,
      [W_MODULE.ATTRIBUTE.CURRENT_PAGE] = data.curPage + 1
    })
    recruitButton:Enable(not X2Squad:HasMySquad() and not X2Team:IsSiegeRaidTeam())
  end
  local events = {
    SELECT_SQUAD_LIST = function(data)
      if not frame:IsVisible() then
        return
      end
      frame:UpdateSquadList(data)
    end,
    REFRESH_SQUAD_LIST = function()
      RefreshSquadList()
    end
  }
  frame:SetHandler("OnEvent", function(this, event, ...)
    events[event](...)
  end)
  RegistUIEvent(frame, events)
  return frame
end
