local battlefieldLayoutLocale = GetLayoutSetBattleField()
local instanceScoreboard
function GetInstanceRankRuleName(key)
  local strings = {
    score = GetUIText(INSTANT_GAME_TEXT, "score"),
    characterKill = GetUIText(INSTANT_GAME_TEXT, "kill"),
    npcKill = GetUIText(INSTANT_GAME_TEXT, "elimination"),
    slaveKill = GetUIText(INSTANT_GAME_TEXT, "destruction"),
    death = GetUIText(INSTANT_GAME_TEXT, "death"),
    retireTime = GetUIText(INSTANT_GAME_TEXT, "retire_play_time"),
    rating = GetUIText(BATTLE_FIELD_TEXT, "rating"),
    characterAssist = GetUIText(INSTANT_GAME_TEXT, "assist")
  }
  if strings[key] == nil then
    return key
  end
  return strings[key]
end
local texturePath = TEXTURE_PATH.BATTLEFIELD_RESULT_FACTION
local function CreateResultSection(id, parent)
  local frame = parent:CreateChildWidget("emptywidget", id, 0, false)
  frame:Show(true)
  local resultBg = frame:CreateDrawable(texturePath, "bg_title", "background")
  resultBg:AddAnchor("TOP", frame, 0, 0)
  local stateTexture = frame:CreateDrawable("ui/battlefield/scoreboard_text.dds", "draw", "background")
  stateTexture:AddAnchor("CENTER", resultBg, 0, 1)
  resultBg:SetHeight(stateTexture:GetHeight() + 5)
  local detailBgOffset = 5
  local deatilBg = frame:CreateDrawable(texturePath, "bg_main", "background")
  deatilBg:AddAnchor("TOP", resultBg, "BOTTOM", 0, detailBgOffset)
  deatilBg:AddAnchor("LEFT", frame, 0, 0)
  deatilBg:AddAnchor("BOTTOMRIGHT", frame, 0, 0)
  local detailInset = MARGIN.WINDOW_SIDE
  local reasonText = frame:CreateChildWidget("label", "reasonText", 0, true)
  reasonText:SetAutoResize(true)
  reasonText:AddAnchor("TOP", deatilBg, 0, detailInset)
  reasonText:SetHeight(FONT_SIZE.LARGE)
  reasonText.style:SetFontSize(FONT_SIZE.LARGE)
  reasonText.style:SetShadow(true)
  local emblemWidth = 208
  local function CreateEmblem(index, data)
    local emblemFrame = frame:CreateChildWidget("emptywidget", "emblemFrame", index, true)
    emblemFrame:Show(true)
    emblemFrame:SetExtent(emblemWidth, 64)
    local bg = emblemFrame:CreateDrawable(texturePath, "bg_score", "background")
    local emblemIcon = emblemFrame:CreateIconDrawable("artwork")
    emblemIcon:AddAnchor("LEFT", emblemFrame, 0, 0)
    emblemIcon:SetExtent(56, 64)
    bg:AddAnchor("LEFT", emblemIcon, "CENTER", 0, 0)
    bg:AddAnchor("RIGHT", emblemFrame, 0, 0)
    local victoryMark = emblemFrame:CreateDrawable(texturePath, "effect", "artwork")
    victoryMark:AddAnchor("CENTER", emblemIcon, 0, 0)
    victoryMark:SetVisible(false)
    local textInset = 15
    local name = CreateCacheCharacterNameLabel("name", emblemFrame, false)
    name:SetWidth(emblemWidth - emblemIcon:GetWidth())
    name:AddAnchor("TOP", emblemFrame, textInset, 10)
    name.style:SetAlign(ALIGN_CENTER)
    local score = emblemFrame:CreateChildWidget("label", "score", 0, true)
    score:SetHeight(FONT_SIZE.MIDDLE)
    score:SetAutoResize(true)
    score:AddAnchor("BOTTOM", emblemFrame, textInset, -13)
    function emblemFrame:SetData(data)
      if data == nil then
        return
      end
      name:SetValue(data.nameCacheQueryId, data.name)
      score:SetText(tostring(data.score or 0))
      if data.iconPath ~= nil and data.iconPath ~= "" then
        emblemIcon:ClearAllTextures()
        emblemIcon:AddTexture(data.iconPath)
        emblemIcon:SetVisible(true)
        victoryMark:SetVisible(data.victoryState == VS_WIN)
      else
        emblemIcon:SetVisible(false)
        victoryMark:SetVisible(false)
      end
      if data.bgColorKey ~= nil and data.bgColorKey ~= "" then
        bg:SetTextureColor(data.bgColorKey)
        bg:SetVisible(true)
      else
        bg:SetVisible(false)
      end
      local colorKey = (data.fontColorKey == nil or data.fontColorKey == "") and "white" or data.fontColorKey
      name.style:SetColorByKey(colorKey)
      score.style:SetColorByKey(colorKey)
    end
    return emblemFrame
  end
  local resultTextureKeys = {
    [VS_WIN] = "victory",
    [VS_LOSE] = "defeat",
    [VS_DRAW] = "draw"
  }
  local resultSoundKeys = {
    [VS_WIN] = "battlefield_win",
    [VS_LOSE] = "battlefield_defeat",
    [VS_DRAW] = "battlefield_draw"
  }
  local function SetResult(state, playSound)
    if state == nil then
      stateTexture:SetVisible(false)
      resultBg:SetVisible(false)
      return
    end
    local textureKey = resultTextureKeys[state]
    if textureKey == nil then
      return
    end
    stateTexture:SetTextureInfo(textureKey)
    stateTexture:SetVisible(true)
    local width = stateTexture:GetWidth() + 100
    resultBg:SetWidth(width)
    resultBg:SetVisible(true)
    if not playSound then
      return
    end
    local soundKey = resultTextureKeys[state]
    if soundKey == nil then
      return
    end
    F_SOUND.PlayUISound(soundKey, false)
  end
  local function SetReason(state, reason, victoryFactionInfo)
    local text = ""
    if state == "RETIRED" then
      text = GetUIText(GRAVE_YARD_TEXT, "dead")
    elseif reason == BFER_ACHIEVEMENT_ALL_KILL_CORPS then
      text = GetCommonText("achieve_all_kill_corps")
    elseif reason == BFER_ACHIEVEMENT_KILL_COUNT then
      text = locale.battlefield.scoreboardEndReason[2](victoryFactionInfo.name, victoryFactionInfo.score)
    elseif reason == BFER_ACHIEVEMENT_KILL_CORPS_HEAD then
      text = locale.battlefield.scoreboardEndReason[3](victoryFactionInfo.name)
    else
      text = locale.battlefield.scoreboardEndReason[1]
    end
    reasonText:SetText(text)
    reasonText:Show(true)
  end
  function frame:Fill(data, playSound)
    local victoryFactionInfo = {name = "", score = 0}
    local myVictoryState = VS_DRAW
    local maxFaction = data.factions == nil and 0 or #data.factions
    local target = reasonText
    local emblemInset = 12
    if data.factions ~= nil then
      for i, v in ipairs(data.factions) do
        if v.victoryState == VS_WIN then
          victoryFactionInfo.name = v.name
          victoryFactionInfo.score = v.score
        end
        if v.myCorps then
          myVictoryState = v.victoryState
        end
        local emblem
        if self.emblemFrame == nil or self.emblemFrame[i] == nil then
          emblem = CreateEmblem(i, v)
          if i == 1 then
            emblem:AddAnchor("TOP", target, "BOTTOM", -((emblemWidth + emblemInset) * (maxFaction - 1)) / 2, 25)
          else
            emblem:AddAnchor("LEFT", target, "RIGHT", emblemInset, 0)
          end
        else
          emblem = self.emblemFrame[i]
        end
        emblem:SetData(v)
        target = emblem
      end
    else
      myVictoryState = data.victoryState or VS_DRAW
    end
    SetResult(myVictoryState, playSound)
    SetReason(data.state, data.endReason, victoryFactionInfo)
    local height = resultBg:GetHeight() + detailBgOffset + detailInset * 2
    local additionalHeight = 0
    if maxFaction == 0 then
      additionalHeight = reasonText:GetHeight()
    else
      _, got = F_LAYOUT.GetExtentWidgets(reasonText, target)
      additionalHeight = got
    end
    self:SetHeight(height + additionalHeight)
  end
  return frame
end
local function CreateDetailSection(id, parent)
  local frame = parent:CreateChildWidget("emptywidget", id, 0, false)
  frame:Show(true)
  frame:SetHeight(525)
  local tab = W_TAB.CreateTab("tab", frame, "instance_scoreboard")
  tab:RemoveAllAnchors()
  tab:AddAnchor("TOPLEFT", frame, 0, 0)
  tab:AddAnchor("BOTTOMRIGHT", frame, 0, 0)
  tab:SetOffset(25)
  local tabButtonHeight = 35
  local columnHeight = 36
  local rowHeight = 27
  local maxRowCount = 10
  local leftOffset = 16
  local frameBg = tab:CreateDrawable(texturePath, "bg_main", "background")
  frameBg:AddAnchor("TOPLEFT", tab, 0, tabButtonHeight)
  frameBg:AddAnchor("BOTTOMRIGHT", tab, 0, 0)
  local scrollListCtrl = W_CTRL.CreateScrollListCtrl("scrollListCtrl", frame)
  scrollListCtrl:AddAnchor("TOPLEFT", tab, leftOffset, tabButtonHeight)
  scrollListCtrl:SetHeight(maxRowCount * rowHeight + columnHeight)
  scrollListCtrl:SetWidth(300)
  local topBg = scrollListCtrl:CreateDrawable(texturePath, "bg_top", "background")
  topBg:AddAnchor("TOPLEFT", scrollListCtrl, 0, 0)
  topBg:AddAnchor("TOPRIGHT", scrollListCtrl, 0, 0)
  local bottomBg = scrollListCtrl:CreateDrawable(texturePath, "bg_bottom", "background")
  bottomBg:AddAnchor("BOTTOMLEFT", scrollListCtrl.listCtrl, 0, 0)
  bottomBg:AddAnchor("BOTTOMRIGHT", scrollListCtrl.listCtrl, 0, 0)
  local TYPE_SCORE = "myScore"
  local TYPE_REWARD = "myReward"
  local function CreateTitle(id, type)
    local KEY_TEXTURE = "textureKey"
    local KEY_FONT_COLOR = "fontColor"
    local KEY_STRING = "string"
    local typeInfo = {
      [TYPE_SCORE] = {
        [KEY_TEXTURE] = "title_my_score",
        [KEY_FONT_COLOR] = "soft_yellow",
        [KEY_STRING] = GetUIText(COMMON_TEXT, "my_record")
      },
      myReward = {
        [KEY_TEXTURE] = "title_reward",
        [KEY_FONT_COLOR] = "soda_blue",
        [KEY_STRING] = GetUIText(COMMON_TEXT, "instance_reward")
      }
    }
    local info = typeInfo[type]
    if info == nil then
      return
    end
    local titleHeight = 30
    local titleInset = 36
    local title = tab:CreateChildWidget("label", id, 0, false)
    title:SetHeight(titleHeight)
    title:SetAutoResize(true)
    title:SetText(info[KEY_STRING])
    title.style:SetFontSize(FONT_SIZE.LARGE)
    title.style:SetColorByKey(info[KEY_FONT_COLOR])
    local bg = title:CreateDrawable(texturePath, info[KEY_TEXTURE], "background")
    bg:AddAnchor("LEFT", title, -titleInset, 0)
    bg:AddAnchor("RIGHT", title, titleInset, 0)
    return title
  end
  local myScoreTitle = CreateTitle("myScoreTitle", TYPE_SCORE)
  myScoreTitle:AddAnchor("TOP", scrollListCtrl, "BOTTOM", 0, 0)
  local myRewardtitle = CreateTitle("myRewardtitle", TYPE_REWARD)
  myRewardtitle:AddAnchor("TOP", myScoreTitle, "BOTTOM", 0, rowHeight)
  local function CreateRewardSection()
    local rewardSection = frame:CreateChildWidget("emptywidget", "rewardSection", 0, false)
    rewardSection:Show(true)
    rewardSection:SetHeight(50)
    local bg = rewardSection:CreateDrawable(texturePath, "bg_reward", "background")
    bg:AddAnchor("TOPLEFT", rewardSection, 0, 0)
    bg:AddAnchor("BOTTOMRIGHT", rewardSection, 0, 0)
    local REWARD_TYPE_ITEM = 1
    local REWARD_TYEP_HONOR_POINT = 2
    local function CreateRewardItem(index, type)
      local rewardItem
      local key = "item"
      if type == REWARD_TYPE_ITEM then
        rewardItem = rewardSection:CreateChildWidget("emptywidget", key, index, true)
        rewardItem:SetWidth(150)
        do
          local itemIcon = CreateIconButton("iconButton", rewardItem)
          itemIcon:AddAnchor("LEFT", rewardItem, 0, 0)
          local count = rewardItem:CreateChildWidget("label", "count", 0, false)
          count:SetHeight(FONT_SIZE.MIDDLE)
          count:AddAnchor("LEFT", itemIcon, "RIGHT", 6, 0)
          count:AddAnchor("RIGHT", rewardItem, 0, 0)
          count.style:SetAlign(ALIGN_LEFT)
          rewardItem:SetHeight(itemIcon:GetHeight())
          function rewardItem:Fill(data)
            local itemInfo = X2Item:GetItemInfoByType(data.itemType)
            if itemInfo == nil then
              rewardItem:Show(false)
              return
            end
            rewardItem:Show(true)
            itemIcon:SetInfo(itemInfo)
            count:SetText(string.format("X %d", data.count or 0))
          end
        end
      elseif type == REWARD_TYEP_HONOR_POINT then
        rewardItem = rewardSection:CreateChildWidget("textbox", key, index, true)
        rewardItem:SetHeight(FONT_SIZE.MIDDLE)
        rewardItem:SetAutoWordwrap(false)
        rewardItem:SetAutoResize(true)
        function rewardItem:Fill(data)
          rewardItem:SetText(F_MONEY:GetCostStringByCurrency(data.currencyType, data.count))
        end
      else
        return
      end
      return rewardItem
    end
    function rewardSection:Fill(datas)
      local width = 0
      local count = 1
      local target = self
      local firstItem
      local inset = 15
      local maxCount = #datas
      for i, v in ipairs(datas) do
        local type
        if v.currencyType ~= nil then
          type = REWARD_TYEP_HONOR_POINT
        else
          type = REWARD_TYPE_ITEM
        end
        local item
        if self.item == nil or self.item[i] == nil then
          item = CreateRewardItem(i, type)
        else
          item = self.item[i]
        end
        item:Fill(v)
        if item:IsVisible() then
          if count ~= 1 then
            item:AddAnchor("LEFT", target, "RIGHT", inset, 0)
          else
            firstItem = item
          end
          count = count + 1
          target = item
          if i ~= maxCount then
            width = width + item:GetWidth() + inset
          end
        end
      end
      if firstItem ~= nil then
        firstItem:AddAnchor("CENTER", self, -(width / 2), 0)
      end
    end
    return rewardSection
  end
  local rewardSection = CreateRewardSection()
  rewardSection:AddAnchor("TOP", myRewardtitle, "BOTTOM", 0, 0)
  local askLeaveBtn = frame:CreateChildWidget("button", "askLeaveBtn", 0, true)
  askLeaveBtn:SetText(locale.battlefield.immediatelyExit)
  askLeaveBtn:SetStyle("text_default")
  local timeFrame = CreateTimeFrame(frame, "scoreboard")
  timeFrame:AddAnchor("BOTTOM", tab, -(askLeaveBtn:GetWidth() / 2), -10)
  timeFrame.time = 0
  askLeaveBtn:AddAnchor("LEFT", timeFrame.nowTime, "RIGHT", 10, 0)
  local askLeaveBtnLeftClickFunc = function()
    X2BattleField:AskLeaveInstantGame()
  end
  ButtonOnClickHandler(askLeaveBtn, askLeaveBtnLeftClickFunc)
  local corps = {0}
  local scrollWidth = 20
  local inited = false
  local scoreColumnKeys = {}
  local myRecordScoreItems = {}
  local function Init(factionInfo)
    if inited then
      return
    end
    local tablInfo = {
      GetCommonText("all")
    }
    if factionInfo ~= nil then
      for i, v in ipairs(factionInfo) do
        table.insert(tablInfo, v.name)
        table.insert(corps, v.corpsNo)
      end
    end
    tab:AddTabs(tablInfo)
    scrollListCtrl:Raise()
    local myInfoColor = "battlefield_yellow"
    local whiteColor = "white"
    local function RankDataSetFunc(subItem, data, setValue)
      subItem.style:SetColorByKey(whiteColor)
      local bg = subItem.bg
      bg:SetVisible(false)
      if setValue then
        if data.myInfo then
          subItem.style:SetColorByKey(myInfoColor)
          bg:SetTextureInfo("list_mine")
          bg:SetVisible(true)
        elseif data.myTeam then
          bg:SetTextureInfo("list_team")
          bg:SetVisible(true)
        end
        subItem:SetText(tostring(data.rank))
      else
        subItem:SetText("")
      end
    end
    local TimeConverter = function(timeValue)
      local minute, second = GetMinuteSecondeFromSec(timeValue)
      return string.format("%02d:%02d", minute, second)
    end
    local function RetireTimeSetFunc(subItem, data, setValue)
      subItem.style:SetColorByKey(whiteColor)
      if setValue then
        if data.myInfo then
          subItem.style:SetColorByKey(myInfoColor)
        end
        subItem:SetText(TimeConverter(data.value))
      else
        subItem:SetText("-")
      end
    end
    local function DataSetFunc(subItem, data, setValue)
      if setValue then
        if subItem.defaultColor ~= nil then
          subItem.style:SetColorByKey(subItem.defaultColor)
        elseif data.myInfo then
          subItem.style:SetColorByKey(myInfoColor)
        else
          subItem.style:SetColorByKey(whiteColor)
        end
        subItem:SetText(tostring(data.value))
      else
        subItem:SetText("")
      end
    end
    local GetRatingString = function(data)
      if data == nil or type(data) ~= "table" then
        return ""
      end
      local str = ""
      if data.deltaRating < 0 then
        str = string.format("%d %s(%d)|r", data.totalRating, F_COLOR.GetColor("pure_red", true), data.deltaRating)
      else
        str = string.format("%d %s(+%d)|r", data.totalRating, F_COLOR.GetColor("green", true), data.deltaRating)
      end
      return str
    end
    local function RatingDataSetFunc(subItem, data, setValue)
      subItem.style:SetColorByKey(whiteColor)
      if setValue then
        if data.myInfo then
          subItem.style:SetColorByKey(myInfoColor)
        end
        subItem:SetText(GetRatingString(data.value))
      else
        subItem:SetText("")
      end
    end
    local function RankLayoutSetFunc(widget, rowIndex, colIndex, subItem)
      subItem.style:SetShadow(true)
      local row = widget:GetListCtrlItem(rowIndex)
      local bg = row:CreateDrawable(texturePath, "list_team", "background")
      bg:SetVisible(false)
      bg:AddAnchor("TOPLEFT", row, 0, 0)
      bg:AddAnchor("BOTTOMRIGHT", row, 0, 0)
      subItem.bg = bg
    end
    local NameLayoutSetFunc = function(widget, rowIndex, colIndex, subItem)
      subItem.style:SetAlign(ALIGN_LEFT)
      subItem.style:SetShadow(true)
      subItem.style:SetEllipsis(true)
      F_TEXT.ApplyAutoEllipsisTooltipText(subItem)
    end
    local RedLayoutSetFunc = function(widget, rowIndex, colIndex, subItem)
      subItem.style:SetColorByKey("pure_red")
      subItem.style:SetShadow(true)
      subItem.defaultColor = "pure_red"
    end
    local DefaultLayoutSetFunc = function(widget, rowIndex, colIndex, subItem)
      subItem.style:SetShadow(true)
    end
    local scoreColumnInfo = X2BattleField:GetScoreColumnInfo(false)
    local rankWidth = 70
    local listCtrlWidth = rankWidth
    scrollListCtrl:InsertColumn(GetUIText(RANKING_TEXT, "placing"), rankWidth, LCCIT_STRING, RankDataSetFunc, nil, nil, RankLayoutSetFunc)
    local function CreateMyRecordDefaultType(id)
      local label = frame:CreateChildWidget("label", id, 0, true)
      label:SetHeight(rowHeight)
      label.style:SetShadow(true)
      label.style:SetColorByKey("battlefield_yellow")
      function label:Fill(data)
        self:SetText(tostring(data))
      end
      return label
    end
    local function CreateMyRecordRedType(id)
      local label = CreateMyRecordDefaultType(id)
      label.style:SetColorByKey("pure_red")
      return label
    end
    local function CreateMyRecordName(id)
      local label = CreateMyRecordDefaultType(id)
      label.style:SetEllipsis(true)
      label.style:SetShadow(true)
      label.style:SetAlign(ALIGN_LEFT)
      return label
    end
    local function CreateMyRecordRatingType(id)
      local label = frame:CreateChildWidget("textbox", id, 0, false)
      label:SetHeight(rowHeight)
      label.style:SetShadow(true)
      label.style:SetColorByKey("battlefield_yellow")
      function label:Fill(data)
        self:SetText(GetRatingString(data))
      end
      return label
    end
    local function CreateMyRecordRetireTime(id)
      local label = frame:CreateChildWidget("label", id, 0, true)
      label:SetHeight(rowHeight)
      label.style:SetShadow(true)
      label.style:SetColorByKey("battlefield_yellow")
      function label:Fill(data)
        self:SetText(TimeConverter(data))
      end
      return label
    end
    local rankInMyRecord = CreateMyRecordDefaultType("rankInMyRecord")
    rankInMyRecord:AddAnchor("TOP", myScoreTitle, "BOTTOM", 0, 0)
    rankInMyRecord:AddAnchor("LEFT", scrollListCtrl, 0, 0)
    rankInMyRecord:SetWidth(rankWidth)
    frame.rankInMyRecord = rankInMyRecord
    local myRecordBg = rankInMyRecord:CreateDrawable(texturePath, "list_mine", "background")
    myRecordBg:AddAnchor("LEFT", rankInMyRecord, 0, 0)
    local nameWidth = 330
    scrollListCtrl:InsertColumn(locale.faction.name, nameWidth, LCCIT_STRING, DataSetFunc, nil, nil, NameLayoutSetFunc)
    listCtrlWidth = listCtrlWidth + nameWidth
    local nameInMyRecord = CreateMyRecordName("nameInMyRecord")
    nameInMyRecord:AddAnchor("LEFT", rankInMyRecord, "RIGHT", 0, 0)
    nameInMyRecord:SetWidth(nameWidth)
    local serverTarget = nameInMyRecord
    local scoreColumnSettings = {
      score = {
        dataFunc = DataSetFunc,
        layoutFunc = DefaultLayoutSetFunc,
        width = 130,
        columnType = LCCIT_STRING,
        myRecordCreateFunc = CreateMyRecordDefaultType
      },
      characterKill = {
        dataFunc = DataSetFunc,
        layoutFunc = RedLayoutSetFunc,
        width = 130,
        columnType = LCCIT_STRING,
        myRecordCreateFunc = CreateMyRecordRedType
      },
      npcKill = {
        dataFunc = DataSetFunc,
        layoutFunc = RedLayoutSetFunc,
        width = 130,
        columnType = LCCIT_STRING,
        myRecordCreateFunc = CreateMyRecordRedType
      },
      slaveKill = {
        dataFunc = DataSetFunc,
        layoutFunc = RedLayoutSetFunc,
        width = 130,
        columnType = LCCIT_STRING,
        myRecordCreateFunc = CreateMyRecordRedType
      },
      housingKill = {
        dataFunc = DataSetFunc,
        layoutFunc = RedLayoutSetFunc,
        width = 130,
        columnType = LCCIT_STRING,
        myRecordCreateFunc = CreateMyRecordRedType
      },
      transferKill = {
        dataFunc = DataSetFunc,
        layoutFunc = RedLayoutSetFunc,
        width = 130,
        columnType = LCCIT_STRING,
        myRecordCreateFunc = CreateMyRecordRedType
      },
      mateKill = {
        dataFunc = DataSetFunc,
        layoutFunc = RedLayoutSetFunc,
        width = 130,
        columnType = LCCIT_STRING,
        myRecordCreateFunc = CreateMyRecordRedTyfpe
      },
      shipyardKill = {
        dataFunc = DataSetFunc,
        layoutFunc = RedLayoutSetFunc,
        width = 130,
        columnType = LCCIT_STRING,
        myRecordCreateFunc = CreateMyRecordRedType
      },
      death = {
        dataFunc = DataSetFunc,
        layoutFunc = RedLayoutSetFunc,
        width = 130,
        columnType = LCCIT_STRING,
        myRecordCreateFunc = CreateMyRecordRedType
      },
      retireTime = {
        dataFunc = RetireTimeSetFunc,
        layoutFunc = DefaultLayoutSetFunc,
        width = 130,
        columnType = LCCIT_STRING,
        myRecordCreateFunc = CreateMyRecordRetireTime
      },
      rating = {
        dataFunc = RatingDataSetFunc,
        layoutFunc = DefaultLayoutSetFunc,
        width = 130,
        columnType = LCCIT_TEXTBOX,
        myRecordCreateFunc = CreateMyRecordRatingType
      },
      characterAssist = {
        dataFunc = DataSetFunc,
        layoutFunc = DefaultLayoutSetFunc,
        width = 130,
        columnType = LCCIT_STRING,
        myRecordCreateFunc = CreateMyRecordDefaultType
      }
    }
    if scoreColumnInfo ~= nil and scoreColumnInfo.columns ~= nil and 0 < #scoreColumnInfo.columns then
      for idx = 1, #scoreColumnInfo.columns do
        local key = scoreColumnInfo.columns[idx]
        local settingData = scoreColumnSettings[key]
        scrollListCtrl:InsertColumn(GetInstanceRankRuleName(key), settingData.width, settingData.columnType, settingData.dataFunc, nil, nil, settingData.layoutFunc)
        scoreColumnKeys[idx] = key
        listCtrlWidth = listCtrlWidth + settingData.width
        local item = settingData.myRecordCreateFunc(string.format("%sInMyRecord", key))
        item:AddAnchor("LEFT", serverTarget, "RIGHT", 0, 0)
        item:SetWidth(settingData.width)
        table.insert(myRecordScoreItems, item)
        serverTarget = item
      end
    end
    local serverNameWidth = 177
    scrollListCtrl:InsertColumn(GetCommonText("squad_info_list_server_name"), serverNameWidth, LCCIT_STRING, DataSetFunc, nil, nil, DefaultLayoutSetFunc)
    listCtrlWidth = listCtrlWidth + serverNameWidth
    local worldNameInMyRecord = CreateMyRecordDefaultType("worldNameInMyRecord")
    worldNameInMyRecord:AddAnchor("LEFT", serverTarget, "RIGHT", 0, 0)
    worldNameInMyRecord:SetWidth(serverNameWidth)
    for i = 1, #scrollListCtrl.listCtrl.column do
      SetButtonFontColor(scrollListCtrl.listCtrl.column[i], {
        normal = F_COLOR.GetColor("white"),
        highlight = F_COLOR.GetColor("white"),
        pushed = F_COLOR.GetColor("white"),
        disabled = F_COLOR.GetColor("white")
      })
      scrollListCtrl.listCtrl.column[i]:Enable(false)
      scrollListCtrl.listCtrl.column[i].style:SetFontSize(battlefieldLayoutLocale.scoreboardColumnFontSize)
    end
    myRecordBg:SetWidth(listCtrlWidth)
    rewardSection:SetWidth(listCtrlWidth)
    scrollListCtrl:SetWidth(listCtrlWidth + scrollWidth)
    scrollListCtrl:InsertRows(maxRowCount, false)
    scrollListCtrl.listCtrl:SetHeaderColumnHeight(columnHeight)
    frame:SetWidth(scrollListCtrl:GetWidth() + leftOffset + scrollWidth)
    inited = true
  end
  local function GetFactionIndex()
    local selected = tab:GetSelectedTab()
    return corps[selected] == nil and -1 or corps[selected]
  end
  local function FillMember()
    if not inited then
      return
    end
    scrollListCtrl:DeleteAllDatas()
    local datas = X2BattleField:GetMemberInfo(GetFactionIndex())
    if datas == nil then
      return
    end
    local dataCount = #datas
    for index = 1, dataCount do
      local data = datas[index]
      local rank = data.rank
      local name = data.name
      local worldName = data.worldName
      local myInfo = data.myInfo
      if myInfo then
        frame.rankInMyRecord:Fill(rank)
        frame.nameInMyRecord:Fill(name)
        frame.worldNameInMyRecord:Fill(worldName)
      end
      local rankColumnData = {
        myInfo = myInfo,
        myTeam = data.myTeam or false,
        rank = rank
      }
      local columnIndex = 1
      scrollListCtrl:InsertData(index, columnIndex, rankColumnData)
      columnIndex = columnIndex + 1
      local nameData = {myInfo = myInfo, value = name}
      scrollListCtrl:InsertData(index, columnIndex, nameData)
      columnIndex = columnIndex + 1
      for idx = 1, #scoreColumnKeys do
        local datas = {
          myInfo = myInfo,
          value = data[scoreColumnKeys[idx]]
        }
        scrollListCtrl:InsertData(index, columnIndex, datas)
        columnIndex = columnIndex + 1
        if myInfo then
          local myRecordWidget = myRecordScoreItems[idx]
          myRecordWidget:Fill(datas.value)
        end
      end
      local worldNameData = {myInfo = myInfo, value = worldName}
      scrollListCtrl:InsertData(index, columnIndex, worldNameData)
    end
    scrollListCtrl.scroll:Show(dataCount > maxRowCount)
  end
  local function FillReward()
    local info = X2BattleField:GetRewardInfo()
    if info == nil then
      myRewardtitle:Show(false)
      rewardSection:Show(false)
      return
    end
    myRewardtitle:Show(true)
    rewardSection:Fill(info)
    rewardSection:Show(true)
  end
  function tab:OnTabChangedProc(index)
    FillMember()
  end
  local remainTime = 0
  local oldTime = 0
  local function FillTime()
    local timeInfo = X2BattleField:GetProgressTimeInfo()
    if timeInfo == nil or timeInfo.state ~= "ENDED" and timeInfo.state ~= "RETIRED" then
      return false
    end
    remainTime = tonumber(timeInfo.remainTime)
    if timeFrame:HasHandler("OnUpdate") == false then
      local function OnUpdateTime(self, dt)
        if remainTime <= 0 then
          return
        end
        if oldTime ~= remainTime then
          oldTime = remainTime
          timeFrame:UpdateTime(oldTime)
        end
      end
      timeFrame:SetHandler("OnUpdate", OnUpdateTime)
    end
    return true
  end
  function frame:Fill(factionInfo)
    Init(factionInfo)
    FillMember()
    FillTime()
    FillReward()
    local target = rewardSection:IsVisible() and rewardSection or self.rankInMyRecord
    local _, height = F_LAYOUT.GetExtentWidgets(scrollListCtrl, target)
    self:SetHeight(height + tabButtonHeight + timeFrame:GetHeight() + 20)
  end
  local events = {
    LEAVED_INSTANT_GAME_ZONE = function()
      frame:Show(false)
    end,
    UPDATE_INSTANT_GAME_TIME = function()
      FillTime()
    end
  }
  frame:SetHandler("OnEvent", function(this, event, ...)
    events[event](...)
  end)
  RegistUIEvent(frame, events)
  return frame
end
local function CreateScoreboard(id, parent)
  local scoreboard = UIParent:CreateWidget("window", id, parent)
  scoreboard:EnableHidingIsRemove(true)
  scoreboard:AddAnchor("CENTER", "UIParent", 0, 0)
  local resultSection = CreateResultSection("resultSection", scoreboard)
  resultSection:AddAnchor("TOPLEFT", scoreboard, 0, 0)
  resultSection:AddAnchor("TOPRIGHT", scoreboard, 0, 0)
  local offset = 10
  local detailSection = CreateDetailSection("detailSection", scoreboard)
  detailSection:AddAnchor("TOP", resultSection, "BOTTOM", 0, offset)
  function scoreboard:Fill(playSound)
    local factionInfo = X2BattleField:GetFactionInfo()
    if factionInfo == nil then
      return
    end
    resultSection:Fill(factionInfo, playSound)
    detailSection:Fill(factionInfo.factions)
    scoreboard:SetExtent(detailSection:GetWidth(), resultSection:GetHeight() + detailSection:GetHeight() + offset)
  end
  local function OnHide()
    instanceScoreboard = nil
  end
  scoreboard:SetHandler("OnHide", OnHide)
  return scoreboard
end
function ShowInstanceScoreboard(show, playSound)
  local timeInfo = X2BattleField:GetProgressTimeInfo()
  if timeInfo == nil or timeInfo.state ~= "ENDED" and timeInfo.state ~= "RETIRED" then
    show = false
  end
  if show == false then
    if instanceScoreboard == nil then
      return
    end
    instanceScoreboard:Show(false)
  else
    if instanceScoreboard == nil then
      instanceScoreboard = CreateScoreboard("instanceScoreboard", "UIParent")
    end
    instanceScoreboard:Show(true)
    instanceScoreboard:Fill(playSound)
  end
end
local EnteredWorld = function()
  ShowInstanceScoreboard(true, false)
end
UIParent:SetEventHandler("ENTERED_WORLD", EnteredWorld)
local LeftLoading = function()
  ShowInstanceScoreboard(false, false)
end
UIParent:SetEventHandler("LEFT_LOADING", LeftLoading)
