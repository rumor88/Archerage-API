## author : yoshimom
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## battlefield

locale/ko.lua
locale/ja.lua
locale/ru.lua
locale/zh_cn.lua
locale/zh_tw.lua
locale/en_us.lua
locale/de.lua
locale/fr.lua
locale/th.lua
locale/layout_set.lua

common.lua
dialog_handler.lua
actionbar.lua
event_alarm.lua

squad_view.lua
squad.lua

scoreboard_new.lua

pick_buff_list.lua

# new
entrance_squad_list.lua
entrance_new.lua

banner_view.lua
banner.lua