battlefield = {}
BFER_DISABLE = 0
BFER_TIMEOVER_COMPARE_KILL_COUNT = 1
BFER_TIMEOVER_COMPARE_ROUND_WIN_COUNT = 2
BFER_TIMEOVER_COMPARE_ALIVE = 3
BFER_TIMEOVER_DRAW = 4
BFER_ACHIEVEMENT_KILL_COUNT = 5
BFER_ACHIEVEMENT_ROUND_WIN_COUNT = 6
BFER_ACHIEVEMENT_KILL_CORPS_HEAD = 7
BFER_ACHIEVEMENT_SCORE = 8
BFER_ACHIEVEMENT_ALL_KILL_CORPS = 9
BFER_UNEARNED_WIN = 10
BFER_TIMEOVER_COMPARE_SCORE = 11
battlefield.actionbar = nil
battlefield.pickBuffList = nil
battlefield.eventAlarm = nil
function CreateTimeFrame(parent, styleType)
  local timeFrame = parent:CreateChildWidget("emptywidget", "timeFrame", 0, true)
  timeFrame:SetHeight(27)
  local leaveTitle = timeFrame:CreateChildWidget("label", "leaveTitle", 0, true)
  leaveTitle:SetAutoResize(true)
  leaveTitle.style:SetFontSize(FONT_SIZE.XLARGE)
  leaveTitle:SetHeight(FONT_SIZE.XLARGE)
  leaveTitle:AddAnchor("LEFT", timeFrame, 0, 0)
  leaveTitle.style:SetColorByKey("orange")
  if styleType == "scoreboard" then
    leaveTitle:SetText(X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "leave_time"))
  elseif styleType == "expedition_war_scoreboard" then
    leaveTitle:SetText(X2Locale:LocalizeUiText(TOOLTIP_TEXT, "left_time"))
  end
  local nowTime = timeFrame:CreateChildWidget("label", "nowTime", 0, true)
  nowTime:SetAutoResize(true)
  nowTime:SetHeight(FONT_SIZE.XXLARGE)
  nowTime:AddAnchor("RIGHT", timeFrame, 0, 0)
  nowTime.style:SetAlign(ALIGN_LEFT)
  nowTime.style:SetFontSize(FONT_SIZE.XLARGE)
  nowTime.style:SetColorByKey("orange")
  function timeFrame:UpdateTime(nowTime)
    if nowTime <= 0 then
      nowTime = 0
    end
    if styleType == "expedition_war_scoreboard" and nowTime == 0 then
      self.nowTime:SetText("")
    else
      local hour, minute, second = GetHourMinuteSecondeFromSec(nowTime)
      local timeStr = string.format("%02d:%02d:%02d", hour, minute, second)
      self.nowTime:SetText(timeStr)
    end
    if self.leaveTitle ~= nil then
      self:SetWidth(self.nowTime:GetWidth() + self.leaveTitle:GetWidth() + 10)
    elseif self.icon ~= nil then
      self:SetWidth(self.nowTime:GetWidth() + self.icon:GetWidth())
    end
  end
  timeFrame:UpdateTime(0)
  return timeFrame
end
local WEEK_OF_DAY_UITEXT = {
  [0] = "sunday_abbr",
  [1] = "monday_abbr",
  [2] = "tuesday_abbr",
  [3] = "wednesday_abbr",
  [4] = "thursday_abbr",
  [5] = "friday_abbr",
  [6] = "saterday_abbr"
}
function GetEntranceTime(availableTimeInfo)
  local GetEntranceTime = function(timeInfo)
    local fromHH = timeInfo.fromHH
    local fromMM = timeInfo.fromMM
    local toHH = timeInfo.toHH
    local toMM = timeInfo.toMM
    local anyTime = timeInfo.anyTime
    if toHH > 24 then
      toHH = toHH - 24
    end
    return fromHH, fromMM, toHH, toMM, anyTime
  end
  local strEnterTimeInfo = ""
  local timeGroupInfo = availableTimeInfo.timeGroupInfo
  for i = 1, #timeGroupInfo do
    local strTimeInfo = ""
    local timeInfo = timeGroupInfo[i]
    local weekInfo = timeInfo.weekInfoList
    local fromHH, fromMM, toHH, toMM, anyTime = GetEntranceTime(timeInfo)
    local strWeek = ""
    if #weekInfo == 7 then
      strWeek = X2Locale:LocalizeUiText(DATE_TIME_TEXT, "every_day")
    else
      for j = 1, #weekInfo do
        strWeek = string.format("%s%s", strWeek, X2Locale:LocalizeUiText(DATE_TIME_TEXT, WEEK_OF_DAY_UITEXT[weekInfo[j]]))
        if j ~= #weekInfo then
          strWeek = string.format("%s ", strWeek)
        end
      end
    end
    if anyTime then
      strTimeInfo = string.format("%s %s", strWeek, X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "unlimited"))
    else
      strTimeInfo = string.format("%s %d:%02d~%d:%02d", strWeek, fromHH, fromMM, toHH, toMM)
    end
    strEnterTimeInfo = F_TEXT.SetEnterString(strEnterTimeInfo, strTimeInfo)
  end
  local weekGroupInfo = availableTimeInfo.weekGroupInfo
  for i = 1, #weekGroupInfo do
    local strTimeInfo = ""
    local weekInfo = weekGroupInfo[i]
    local timeInfo = weekInfo.timeInfoList
    local strWeek = X2Locale:LocalizeUiText(DATE_TIME_TEXT, WEEK_OF_DAY_UITEXT[weekInfo.week])
    for j = 1, #timeInfo do
      local fromHH, fromMM, toHH, toMM, anyTime = GetEntranceTime(timeInfo[j])
      if anyTime then
        strTimeInfo = string.format("%s%s", strTimeInfo, X2Locale:LocalizeUiText(BATTLE_FIELD_TEXT, "unlimited"))
      else
        strTimeInfo = string.format("%s%d:%02d~%d:%02d", strTimeInfo, fromHH, fromMM, toHH, toMM)
      end
      if j ~= #timeInfo then
        strTimeInfo = string.format("%s, ", strTimeInfo)
      end
    end
    strTimeInfo = string.format("%s %s", strWeek, strTimeInfo)
    strEnterTimeInfo = F_TEXT.SetEnterString(strEnterTimeInfo, strTimeInfo)
  end
  return strEnterTimeInfo
end
SQUAD_EVENT_BUTTON_TYPE = {
  APPLY = 1,
  READY = 2,
  READY_CANCEL = 3,
  ENTER = 4
}
