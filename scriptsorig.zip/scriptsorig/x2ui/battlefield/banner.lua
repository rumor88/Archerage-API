local banner
local CreateBanner = function(id, parent)
  local frame = SetViewBanner(id, parent)
  local exitBtn = frame.exitBtn
  local function OnClick()
    frame:ShowBannerClosedWarringDlg()
  end
  ButtonOnClickHandler(exitBtn, OnClick)
  if X2Player:GetFeatureSet().show_instance_in_hud then
    local function OnClick(self)
      local data = {
        requestByInteraction = false,
        uiKind = frame.selectedInstanceUiKindType,
        instanceType = frame.selectedInstance
      }
      ADDON:ShowContent(UIC_REQUEST_BATTLEFIELD, true, data)
    end
    frame.dragWindow:SetHandler("OnClick", OnClick)
  end
  local function OnDragStart(self)
    frame:StartMoving()
    self.moving = true
  end
  frame.dragWindow:SetHandler("OnDragStart", OnDragStart)
  local function OnDragStop(self)
    if self.moving == true then
      frame:StopMovingOrSizing()
      self.moving = false
    end
  end
  frame.dragWindow:SetHandler("OnDragStop", OnDragStop)
  return frame
end
local function ShowBanner(show, instanceType)
  if show then
    if banner == nil then
      banner = CreateBanner("Banner", "UIParent")
    end
    if not banner:SetData(instanceType) then
      return
    end
    banner:Show(true)
  elseif banner ~= nil then
    banner:Show(false)
  end
end
UIParent:SetEventHandler("SHOW_BANNER", ShowBanner)
local function UpdatePermission()
  if not UIParent:GetPermission(UIC_REQUEST_BATTLEFIELD) then
    ShowBanner(false, nil)
  end
end
UIParent:SetEventHandler("UI_PERMISSION_UPDATE", UpdatePermission)
