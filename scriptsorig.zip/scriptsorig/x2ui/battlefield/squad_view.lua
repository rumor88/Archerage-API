SQUAD_PER_COUNT = 10
function SetViewOfSquad(id, parent)
  local wnd = CreateWindow(id, parent)
  wnd:SetExtent(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_680), 474)
  wnd:AddAnchor("CENTER", "UIParent", 0, 0)
  wnd:SetTitle(GetCommonText("squad_info_title"))
  local contentWidth = wnd:GetWidth() - MARGIN.WINDOW_SIDE * 2
  local subTitleBox = wnd:CreateChildWidget("emptywidget", "subTitleBox", 0, true)
  subTitleBox:SetExtent(contentWidth, 40)
  wnd:RegisterStack(subTitleBox)
  local subTitleBg = subTitleBox:CreateDrawable(TEXTURE_PATH.DEFAULT, "common_bg", "background")
  subTitleBg:SetTextureColor("bg_01")
  subTitleBg:AddAnchor("TOPLEFT", subTitleBox, 0, 0)
  subTitleBg:AddAnchor("BOTTOMRIGHT", subTitleBox, 0, 0)
  local subTitle = subTitleBox:CreateChildWidget("label", "subTitle", 0, true)
  subTitle:SetExtent(contentWidth, FONT_SIZE.XXLARGE)
  subTitle.style:SetFont(FONT_PATH.SUB, FONT_SIZE.XXLARGE)
  subTitle.style:SetColorByKey("middle_title")
  subTitle:AddAnchor("CENTER", subTitleBox, 0, 0)
  local infoSection = wnd:CreateChildWidget("emptywidget", "infoSection", 0, true)
  local openTypeBg = CreateContentBackground(infoSection, "TYPE2", "brown")
  local openTypeLabel = infoSection:CreateChildWidget("label", "openTypeLabel", 0, false)
  openTypeLabel:AddAnchor("LEFT", infoSection, 10, 0)
  openTypeLabel:SetAutoResize(true)
  openTypeLabel:SetHeight(FONT_SIZE.LARGE)
  openTypeLabel.style:SetFontSize(FONT_SIZE.LARGE)
  openTypeLabel.style:SetColorByKey("default")
  openTypeLabel:SetText(GetCommonText("squad_open_type"))
  local radioData = {
    {
      text = GetCommonText("squad_open_type_public"),
      value = SOT_PUBLIC
    },
    {
      text = GetCommonText("squad_open_type_private"),
      value = SOT_PRIVATE
    }
  }
  local openTypeRadioBoxes = CreateRadioGroup("openTypeRadioBoxes", infoSection, "horizen")
  openTypeRadioBoxes:AddAnchor("LEFT", openTypeLabel, "RIGHT", 8, 0)
  openTypeRadioBoxes:SetData(radioData)
  openTypeRadioBoxes:Check(1)
  local directMatchingLabel = infoSection:CreateChildWidget("label", "directMatchingLabel", 0, true)
  directMatchingLabel:AddAnchor("LEFT", openTypeLabel, "RIGHT", 8, 1)
  directMatchingLabel:SetAutoResize(true)
  directMatchingLabel:SetHeight(FONT_SIZE.MIDDLE)
  directMatchingLabel.style:SetFontSize(FONT_SIZE.MIDDLE)
  directMatchingLabel.style:SetColorByKey("default")
  directMatchingLabel:SetText(GetCommonText("squad_open_type_direct_matching"))
  local directMatchingLabelGuide = W_ICON.CreateGuideIconWidget(infoSection)
  directMatchingLabelGuide:AddAnchor("LEFT", directMatchingLabel, "RIGHT", 5, 0)
  local OnEnterDirectMatchingLabelGuide = function(self)
    SetTooltip(GetUIText(TOOLTIP_TEXT, "squad_open_type_direct_matching_tooltip"), self)
  end
  directMatchingLabelGuide:SetHandler("OnEnter", OnEnterDirectMatchingLabelGuide)
  local OnRadioChanged = function(self, index, dataValue)
    X2Squad:ChangeOpenType(dataValue)
  end
  openTypeRadioBoxes:SetHandler("OnRadioChanged", OnRadioChanged)
  local refreshButton = infoSection:CreateChildWidget("button", "refreshButton", 0, true)
  ApplyButtonSkin(refreshButton, BUTTON_BASIC.RESET)
  refreshButton:AddAnchor("RIGHT", infoSection, -7, 0)
  local squadCount = wnd:CreateChildWidget("textbox", "squadCount", 0, true)
  squadCount.style:SetFontSize(FONT_SIZE.LARGE)
  squadCount:SetAutoWordwrap(false)
  squadCount:SetAutoResize(true)
  squadCount:SetHeight(FONT_SIZE.LARGE)
  squadCount.style:SetColorByKey("default")
  squadCount:AddAnchor("RIGHT", refreshButton, "LEFT", -4, 0)
  local squadCountBg = CreateContentBackground(infoSection, "TYPE2", "brown")
  squadCountBg:AddAnchor("TOPLEFT", squadCount, -10, -10)
  squadCountBg:AddAnchor("BOTTOMRIGHT", refreshButton, 7, 5)
  infoSection:SetExtent(contentWidth, refreshButton:GetHeight())
  wnd:RegisterStack(infoSection, 10)
  function infoSection:FillInfo(isLeader, openType, curCount, maxCount)
    squadCount:SetText(F_TEXT.SetColonFormat(GetCommonText("squad_info_count"), string.format("%s%s", F_COLOR.GetColor("blue", true), F_TEXT.SetSlashFormat(curCount, maxCount))))
    local bgTarget
    if openType ~= SOT_MUST_PUBLIC then
      if openType ~= SOT_DIRECT_MATCHING then
        openTypeRadioBoxes:Show(true)
        openTypeRadioBoxes:Enable(isLeader)
        openTypeRadioBoxes:Check(openTypeRadioBoxes:GetIndexByValue(openType), false)
        directMatchingLabel:Show(false)
        directMatchingLabelGuide:Show(false)
        bgTarget = openTypeRadioBoxes
      else
        openTypeRadioBoxes:Show(false)
        directMatchingLabel:Show(true)
        directMatchingLabelGuide:Show(true)
        bgTarget = directMatchingLabelGuide
      end
      openTypeLabel:Show(true)
      openTypeBg:AddAnchor("TOPLEFT", openTypeLabel, -10, -10)
      openTypeBg:AddAnchor("BOTTOMRIGHT", bgTarget, 10, 10)
    else
      openTypeLabel:Show(false)
      openTypeRadioBoxes:Show(false)
      directMatchingLabel:Show(false)
      directMatchingLabelGuide:Show(false)
      openTypeBg:Show(false)
    end
  end
  local offset = 3
  local list = W_MODULE:Create("listCtrl", wnd, W_MODULE.TYPES.LISTCTRL, nil, {
    [W_MODULE.ATTRIBUTE.HAS_SCROLL] = false,
    [W_MODULE.ATTRIBUTE.COLUMN_HEIGHT_TYPE] = "large",
    [W_MODULE.ATTRIBUTE.ROW_COUNT] = 10,
    [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = true,
    [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = "text_small",
    [W_MODULE.ATTRIBUTE.ROW_CLICK_FUNC] = function(listCtrl, row, clickButton, data)
      if clickButton ~= "RightButton" then
        return
      end
      ActivateSquadMemberPopupMenu(listCtrl, row, data.isMe, data.worldId, data.charId, data.name)
    end,
    [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = 225,
        [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("name"),
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
          local leaderMark = W_ICON.CreateLeaderMark("leaderMark", subItem)
          leaderMark:AddAnchor("LEFT", subItem, "RIGHT", 0, 0)
          leaderMark:SetMarkTexture("leader")
          subItem.leaderMark = leaderMark
          local name = CreateCacheCharacterNameLabel("name", subItem)
          name:AddAnchor("LEFT", leaderMark, "RIGHT", 0, 0)
          local stausImg = subItem:CreateDrawable(TEXTURE_PATH.ICON_WAITING, "icon_waiting", "background")
          stausImg:AddAnchor("LEFT", subItem, 0, 0)
          subItem.stausImg = stausImg
          leaderMark:AddAnchor("LEFT", subItem.stausImg, "RIGHT", offset, 0)
          name:SetExtent(subItem:GetWidth() - leaderMark:GetWidth() - stausImg:GetWidth() - offset - 10, FONT_SIZE.MIDDLE)
        end,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data == nil then
            subItem.name:ClearValue()
            subItem.stausImg:SetVisible(false)
            subItem.leaderMark:Show(false)
            return
          end
          if data.leader then
            subItem.leaderMark:Show(true)
            subItem.name:RemoveAllAnchors()
            subItem.name:AddAnchor("LEFT", subItem.leaderMark, "RIGHT", offset, 0)
          else
            subItem.leaderMark:Show(false)
            subItem.name:RemoveAllAnchors()
            subItem.name:AddAnchor("LEFT", subItem.stausImg, "RIGHT", offset, 0)
          end
          subItem.name:SetValue(data.nameCacheQueryId, data.name)
          subItem.stausImg:SetVisible(true)
          if data.ready then
            subItem.stausImg:SetTexture(TEXTURE_PATH.DEFAULT)
            subItem.stausImg:SetTextureInfo("common_v")
            subItem.stausImg:SetTextureColor("green")
          else
            subItem.stausImg:SetTexture(TEXTURE_PATH.ICON_WAITING)
            subItem.stausImg:SetTextureInfo("icon_waiting")
          end
          subItem.charId = data.charId
          if data.offline then
            subItem.name.style:SetColorByKey("gray")
          else
            local info = W_MODULE:GetRoleInfoByRole(data.role)
            subItem.name.style:SetColorByKey(info.fontColor)
          end
        end
      },
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = 60,
        [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("level"),
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_TEXTBOX,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data == nil then
            subItem:SetText("")
            return
          end
          if data.offline then
            subItem:SetText(GetLevelToString(data.level, F_COLOR.GetColor("default_gray", true)))
          else
            subItem:SetText(GetLevelToString(data.level))
          end
        end
      },
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = 95,
        [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMUNITY_TEXT, "job"),
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_STRING,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data == nil then
            subItem:SetText("")
            return
          end
          if data.offline then
            subItem.style:SetColorByKey("gray")
          else
            subItem.style:SetColorByKey("default")
          end
          subItem:SetText(string.format("%s", F_UNIT.GetCombinedAbilityName(data.abilities[1], data.abilities[2], data.abilities[3])))
        end
      },
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = 150,
        [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("squad_info_list_server_name"),
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_STRING,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data == nil then
            subItem:SetText("")
            return
          end
          if data.offline then
            subItem.style:SetColorByKey("gray")
          else
            subItem.style:SetColorByKey("default")
          end
          subItem:SetText(data.serverName)
        end
      },
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = 110,
        [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "role"),
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
          local roleLabel = CreateRoleLabel("roleLabel", subItem)
          roleLabel:AddAnchor("CENTER", subItem, -5, 0)
          local roleSelectButton = subItem:CreateChildWidget("button", "roleSelectButton", 0, true)
          roleSelectButton:SetStyle("right_arrow")
          roleSelectButton:AddAnchor("RIGHT", subItem, 0, 0)
          local squadRoleFrame = CreateRoleFrame("squadRoleFrame", roleSelectButton)
          squadRoleFrame:AddAnchor("TOPLEFT", roleSelectButton, "TOPRIGHT", 0, 0)
          subItem.squadRoleFrame = squadRoleFrame
          function squadRoleFrame:GetMyRole()
            local data = X2Squad:GetMyRoleInfo()
            return data.role
          end
          function squadRoleFrame:SetMyRole(role)
            X2Squad:SetMyRole(role)
          end
          function roleSelectButton:OnClick()
            squadRoleFrame:Show(not squadRoleFrame:IsVisible())
          end
          roleSelectButton:SetHandler("OnClick", roleSelectButton.OnClick)
        end,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          if data == nil then
            subItem.roleLabel:Show(false)
            return
          end
          subItem.roleLabel:Show(true)
          subItem.roleLabel:SetRole(data.role)
          subItem.roleSelectButton:Show(data.isMe)
          subItem.isMe = data.isMe
          subItem.charId = data.charId
          subItem.worldId = data.worldId
        end
      }
    }
  })
  wnd:RegisterStack(list, 5)
  wnd.list = list
  local buttonSet = W_MODULE:Create("buttonSet", wnd, W_MODULE.TYPES.BUTTON_SET)
  wnd:RegisterStack(buttonSet)
  buttonSet:AddButton("leaveSquadButton", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "squad_info_leave_squad"),
    enable = false,
    clickFunc = function()
      X2Squad:LeaveSquad()
    end,
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.LEFT
  })
  buttonSet:AddButton("disbandSquadButton", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "squad_info_disband_squad"),
    clickFunc = function()
      X2Squad:DisbandSquad()
    end,
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.LEFT
  })
  buttonSet:AddButton("eventButton", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("squad_info_ready"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.RIGHT
  })
  wnd:ApplyAutoHeightByStack()
  return wnd
end
