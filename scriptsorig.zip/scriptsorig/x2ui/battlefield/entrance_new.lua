local featureSet = X2Player:GetFeatureSet()
local selectedInstance
local function SetViewOfEntranceWindow(id, parent)
  local window = CreateWindow(id, parent)
  window:SetExtent(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_680), 711)
  window:SetTitle(GetCommonText("instance_entrance_title"))
  local kindList = X2BattleField:GetInstanceUiKindList()
  local tabNames = {}
  local kindInfo = {}
  for i, v in ipairs(kindList) do
    tabNames[i] = v.name
    kindInfo[i] = {
      path = v.listButtonPath,
      type = v.type,
      showHonorStore = v.showHonorStore
    }
  end
  function window:GetKindInfo(index)
    return kindInfo[index]
  end
  function window:GetTabIndexByKindType(kindType)
    if kindType == nil then
      return 0
    end
    for i, v in ipairs(kindInfo) do
      if v.type == kindType then
        return i
      end
    end
    return 0
  end
  local tab = W_TAB.CreateTab("tab", window)
  tab:AddTabs(tabNames)
  tab:AddAnchor("TOPLEFT", window, 20, 50)
  window.tabs = tab
  local contentHeight = 515
  local rightWidth = 510
  local titleHeight = 39
  local function CreateLeftList(id, parent)
    local leftList = W_MODULE:Create("listCtrl", window, W_MODULE.TYPES.LISTCTRL, nil, {
      [W_MODULE.ATTRIBUTE.HAS_SCROLL] = true,
      [W_MODULE.ATTRIBUTE.ROW_COUNT] = 6,
      [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = 85,
      [W_MODULE.ATTRIBUTE.OVER_SELECT_IMAGE_TYPE] = "type_3",
      [W_MODULE.ATTRIBUTE.ONSELCHANGED_PROC] = function(index, doubleClick, moduleFrame)
        local data = moduleFrame:GetDataPartially(W_MODULE.ATTRIBUTE.SELECTED_DATA)
        if data == nil then
          return
        end
        local instanceType = data.type
        window:FillDetail(instanceType)
        selectedInstance = instanceType
      end,
      [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
        {
          [W_MODULE.ATTRIBUTE.WIDTH] = 100,
          [W_MODULE.ATTRIBUTE.TEXT] = "",
          [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
          [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
            local bg = subItem:CreateDrawable(TEXTURE_PATH.BATTLEFIELD_LIST_BUTTON, "instance_training_camp", "background")
            bg:AddAnchor("CENTER", subItem, 0, 0)
            subItem.bg = bg
            local memberCount = subItem:CreateChildWidget("label", "memberCount", 0, true)
            memberCount:AddAnchor("BOTTOM", bg, 0, -4)
            memberCount:SetExtent(10, FONT_SIZE.SMALL)
            memberCount.style:SetFontSize(FONT_SIZE.SMALL)
            memberCount:SetAutoResize(true)
            local festivalIcon = subItem:CreateChildWidget("emptywidget", "festivalIcon", 0, true)
            festivalIcon.icon = festivalIcon:CreateDrawable(TEXTURE_PATH.BATTLEFIELD_COMMON_LIST_BUTTON, "icon_festival", "overlay")
            festivalIcon:SetExtent(festivalIcon.icon:GetWidth(), festivalIcon.icon:GetHeight())
            festivalIcon.icon:AddAnchor("CENTER", festivalIcon, 0, 0)
            local function OnfestivalIconEnter(self)
              SetTooltip(GetUIText(COMMON_TEXT, "festival"), festivalIcon)
            end
            festivalIcon:SetHandler("OnEnter", OnfestivalIconEnter)
            local globalIcon = subItem:CreateChildWidget("emptywidget", "globalIcon", 0, true)
            globalIcon.icon = globalIcon:CreateDrawable(TEXTURE_PATH.BATTLEFIELD_COMMON_LIST_BUTTON, "icon_combine", "overlay")
            globalIcon:SetExtent(globalIcon.icon:GetWidth(), globalIcon.icon:GetHeight())
            globalIcon.icon:AddAnchor("CENTER", globalIcon, 0, 0)
            local function OnglobalIconEnter(self)
              SetTooltip(GetUIText(COMMON_TEXT, "integration"), globalIcon)
            end
            globalIcon:SetHandler("OnEnter", OnglobalIconEnter)
            local globalArenaIcon = subItem:CreateChildWidget("emptywidget", "globalArenaIcon", 0, true)
            globalArenaIcon.icon = globalArenaIcon:CreateDrawable(TEXTURE_PATH.BATTLEFIELD_COMMON_LIST_BUTTON, "icon_global", "overlay")
            globalArenaIcon:SetExtent(globalArenaIcon.icon:GetWidth(), globalArenaIcon.icon:GetHeight())
            globalArenaIcon.icon:AddAnchor("CENTER", globalArenaIcon, 0, 0)
            local function OnglobalArenaIconEnter(self)
              SetTooltip(GetUIText(COMMON_TEXT, "global_arena"), globalArenaIcon)
            end
            globalArenaIcon:SetHandler("OnEnter", OnglobalArenaIconEnter)
          end,
          [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
            local row = subItem:GetParent()
            if data then
              subItem.bg:SetVisible(true)
              subItem.bg:SetTexture(data.path)
              subItem.bg:SetTextureInfo(string.lower(data.uiKey))
              local showGlobaArenalIcon = false
              subItem.globalArenaIcon:Show(showGlobaArenalIcon)
              local x = -2
              local y = 2
              local taget = subItem.bg
              if showGlobaArenalIcon then
                subItem.globalArenaIcon:AddAnchor("TOPRIGHT", taget, "TOPRIGHT", x, y)
                taget = subItem.globalArenaIcon
                x = x + -subItem.globalArenaIcon:GetWidth()
                y = 0
              end
              local showGlobalIcon = false
              subItem.globalIcon:Show(showGlobalIcon)
              if showGlobalIcon then
                subItem.globalIcon:AddAnchor("TOPRIGHT", taget, x, y)
                taget = subItem.globalIcon
                x = x + -subItem.globalIcon:GetWidth()
                y = 0
              end
              local showFetivallIcon = false
              subItem.festivalIcon:Show(showFetivallIcon)
              if showFetivallIcon then
                subItem.festivalIcon:AddAnchor("TOPRIGHT", taget, x, y)
              end
              if data.memberCount ~= nil then
                local str = ""
                local count = #data.memberCount
                for i = 1, count do
                  if str == "" then
                    str = tostring(data.memberCount[i])
                  end
                  if i > 1 then
                    str = F_TEXT.SetColonFormat(str, data.memberCount[i])
                  end
                end
                subItem.memberCount:Show(true)
                subItem.memberCount:SetText(str)
              end
              subItem:Show(true)
            else
              subItem:Show(false)
            end
          end
        }
      }
    })
    return leftList
  end
  local function CreateDeatilTitle(id, parent)
    local frame = parent:CreateChildWidget("emptywidget", id, 0, true)
    frame:SetExtent(rightWidth, titleHeight)
    local bg = frame:CreateDrawable(TEXTURE_PATH.DEFAULT, "common_bg", "background")
    bg:SetTextureColor("bg_01")
    bg:AddAnchor("TOPLEFT", frame, 0, 0)
    bg:AddAnchor("BOTTOMRIGHT", frame, 0, 0)
    local titleWidget = frame:CreateChildWidget("label", "titleWidget", 0, false)
    titleWidget:SetExtent(frame:GetWidth() - 40, frame:GetHeight())
    titleWidget:AddAnchor("TOPLEFT", frame, 20, 0)
    titleWidget.style:SetAlign(ALIGN_LEFT)
    titleWidget.style:SetFont(FONT_PATH.SUB, FONT_SIZE.XXLARGE)
    titleWidget.style:SetEllipsis(true)
    titleWidget.style:SetColorByKey("middle_title")
    function frame:SetTitle(text)
      titleWidget:SetText(text)
    end
    return frame
  end
  local function CreateDetailInfo(id, parent)
    local frame = parent:CreateChildWidget("emptywidget", id, 0, true)
    frame:SetExtent(rightWidth, contentHeight - titleHeight)
    local bgImg = frame:CreateDrawable(TEXTURE_PATH.DEFAULT, "common_bg", "background")
    bgImg:SetTextureColor("bg_01")
    bgImg:AddAnchor("TOPLEFT", frame, 0, -titleHeight)
    bgImg:AddAnchor("BOTTOMRIGHT", frame, 0, 0)
    local defaultPreview = string.format("%s/%s.dds", TEXTURE_PATH.BATTLEFIELD_PREVIEW_PREFIX, "instance_training_camp_1on1")
    frame.defaultUiKey = "instance_training_camp_1on1"
    local preview = frame:CreateDrawable(defaultPreview, "image", "background")
    preview:AddAnchor("TOP", frame, 0, 5)
    local bgZoneName = frame:CreateDrawable(TEXTURE_PATH.DEFAULT, "battlefield_preview", "background")
    bgZoneName:SetTextureColor("default_30")
    bgZoneName:SetExtent(484, 24)
    bgZoneName:AddAnchor("TOP", preview, 8, 0)
    local zoneName = frame:CreateChildWidget("label", "zoneName", 0, false)
    zoneName:SetExtent(484, FONT_SIZE.LARGE)
    zoneName:AddAnchor("LEFT", bgZoneName, 10, 0)
    zoneName.style:SetAlign(ALIGN_LEFT)
    zoneName.style:SetFontSize(FONT_SIZE.LARGE)
    zoneName.style:SetColorByKey("default")
    local pageControl = W_CTRL.CreatePageControl("pageControl", frame)
    pageControl:AddAnchor("TOP", preview, "BOTTOM", 0, 0)
    frame.pageControl = pageControl
    local scrollWnd = CreateScrollWindow(frame, "scroll", 0)
    scrollWnd:SetExtent(484, 253)
    scrollWnd:AddAnchor("TOP", pageControl, "BOTTOM", 0, 8)
    scrollWnd:AddAnchor("LEFT", frame, 20, 0)
    local targetParent = scrollWnd.content
    local contentWidth = targetParent:GetWidth()
    local balanceLevel = targetParent:CreateChildWidget("label", "balanceLevel", 0, false)
    balanceLevel:SetExtent(contentWidth, FONT_SIZE.LARGE)
    balanceLevel:AddAnchor("TOPLEFT", targetParent, 0, 0)
    balanceLevel:SetText(GetUIText(COMMON_TEXT, "on_balance_level_battlefield"))
    balanceLevel.style:SetFont(FONT_PATH.SUB, FONT_SIZE.LARGE)
    balanceLevel.style:SetAlign(ALIGN_LEFT)
    balanceLevel.style:SetColorByKey("blue")
    local description = targetParent:CreateChildWidget("textbox", "description", 0, false)
    description:SetExtent(contentWidth, 30)
    description:SetAutoResize(true)
    description.style:SetAlign(ALIGN_LEFT)
    description.style:SetColorByKey("default")
    local additionalInfo = targetParent:CreateChildWidget("textbox", "additionalInfo", 0, true)
    additionalInfo:SetExtent(contentWidth, 30)
    additionalInfo:AddAnchor("TOPLEFT", description, "BOTTOMLEFT", 0, 15)
    additionalInfo:SetAutoResize(true)
    additionalInfo.style:SetAlign(ALIGN_LEFT)
    additionalInfo.style:SetFontSize(FONT_SIZE.LARGE)
    additionalInfo.style:SetColorByKey("red")
    local victoryFrame = targetParent:CreateChildWidget("emptywidget", "victoryFrame", 0, false)
    victoryFrame:SetExtent(contentWidth, 30)
    victoryFrame:AddAnchor("TOPLEFT", additionalInfo, "BOTTOMLEFT", -3, 8)
    local bg = CreateContentBackground(victoryFrame, "TYPE2", "brown")
    bg:AddAnchor("TOPLEFT", victoryFrame, 0, 0)
    bg:AddAnchor("BOTTOMRIGHT", victoryFrame, 0, 0)
    local calcWidth = contentWidth - 40
    local victoryTitle = victoryFrame:CreateChildWidget("label", "victoryTitle", 0, false)
    victoryTitle:SetExtent(calcWidth, FONT_SIZE.LARGE)
    victoryTitle:SetText(locale.battlefield.winCondition.title)
    victoryTitle:AddAnchor("TOPLEFT", victoryFrame, 20, 15)
    victoryTitle.style:SetFontSize(FONT_SIZE.LARGE)
    victoryTitle.style:SetAlign(ALIGN_LEFT)
    victoryTitle.style:SetColorByKey("middle_title")
    local victoryTitleGuide = W_ICON.CreateGuideIconWidget(victoryTitle)
    victoryTitleGuide:AddAnchor("TOPRIGHT", victoryTitle, 0, -2)
    local OnEnter = function(self)
      SetTooltip(locale.battlefield.winCondition.tip, self)
    end
    victoryTitleGuide:SetHandler("OnEnter", OnEnter)
    local line = CreateLine(victoryFrame, "TYPE1", "background")
    line:SetWidth(victoryFrame:GetWidth() - 35)
    line:AddAnchor("TOP", victoryTitle, "BOTTOM", 0, 7)
    local goal = victoryFrame:CreateChildWidget("textbox", "goal", 0, true)
    goal:AddAnchor("TOPLEFT", victoryTitle, "BOTTOMLEFT", 0, 20)
    goal:SetExtent(calcWidth, FONT_SIZE.MIDDLE)
    goal.style:SetFontSize(FONT_SIZE.LARGE)
    goal.style:SetAlign(ALIGN_LEFT)
    goal:SetAutoResize(true)
    goal.style:SetColorByKey("blue")
    local honorStore = frame:CreateChildWidget("button", "honorStore", 0, false)
    honorStore:SetText(locale.battlefield.shop)
    honorStore:SetStyle("text_default")
    honorStore:AddAnchor("BOTTOMLEFT", tab, 0, 0)
    local OnClick = function(self)
      DirectOpenStore(SHOP_OPEN_BATTLEFIELD)
    end
    honorStore:SetHandler("OnClick", OnClick)
    function frame:ShowHonorStore(show)
      honorStore:Show(show)
    end
    local entranceButton = frame:CreateChildWidget("button", "entranceButton", 0, true)
    entranceButton:SetText(GetUIText(BATTLE_FIELD_TEXT, "random_entrance"))
    entranceButton:SetStyle("text_default")
    ButtonOnClickHandler(entranceButton, OnClick_EntranceButton)
    entranceButton:AddAnchor("BOTTOMRIGHT", tab, 0, 0)
    local cancelButton = frame:CreateChildWidget("button", "cancelButton", 0, true)
    cancelButton:Show(false)
    cancelButton:SetText(locale.battlefield.cancelEntrance)
    cancelButton:SetStyle("text_default")
    cancelButton:AddAnchor("BOTTOMRIGHT", tab, 0, 0)
    local switchSquadListBtn = frame:CreateChildWidget("button", "switchSquadListBtn", 0, true)
    switchSquadListBtn:SetText(GetCommonText("squad_recruit_and_search"))
    switchSquadListBtn:SetStyle("text_default")
    switchSquadListBtn:AddAnchor("RIGHT", entranceButton, "LEFT", 0, 0)
    local buttonTable = {
      entranceButton,
      cancelButton,
      switchSquadListBtn
    }
    AdjustBtnLongestTextWidth(buttonTable)
    local enterCount = frame:CreateChildWidget("textbox", "enterCount", 0, true)
    enterCount:SetAutoWordwrap(false)
    enterCount:SetAutoResize(true)
    enterCount:AddAnchor("TOPRIGHT", frame, "BOTTOMRIGHT", -5, 11)
    enterCount.style:SetColorByKey("default")
    local enterCountGuide = W_ICON.CreateGuideIconWidget(enterCount)
    enterCountGuide:AddAnchor("RIGHT", enterCount, "LEFT", -3, 0)
    local OnEnter = function(self)
      SetTooltip(GetUIText(COMMON_TEXT, "Battlefield_entrance_count_info"), self)
    end
    enterCountGuide:SetHandler("OnEnter", OnEnter)
    local resetCount = frame:CreateChildWidget("textbox", "resetCount", 0, true)
    resetCount:SetAutoWordwrap(false)
    resetCount:SetAutoResize(true)
    resetCount:AddAnchor("TOPRIGHT", enterCount, "BOTTOMRIGHT", 0, 5)
    resetCount.style:SetColorByKey("default")
    function frame:SetPreview(key)
      preview:SetTexture(string.format("%s/%s.dds", TEXTURE_PATH.BATTLEFIELD_PREVIEW_PREFIX, key))
      preview:SetTextureInfo("image")
    end
    function frame:SetBalanceLevel(level)
      description:RemoveAllAnchors()
      if level == nil or level == 0 then
        balanceLevel:Show(false)
        description:AddAnchor("TOPLEFT", targetParent, 0, 0)
      else
        balanceLevel:Show(true)
        description:AddAnchor("TOPLEFT", balanceLevel, "BOTTOMLEFT", 0, 8)
      end
    end
    function frame:SetDescription(desc)
      description:SetText(desc)
    end
    function frame:SetAdditionalInfo(info)
      local str = ""
      local totalPlayTime = locale.time.GetRemainDate(0, 0, 0, 0, info.playingTime, 0)
      local valueTime = ""
      if info.playRoundCount ~= nil and 0 < info.playRoundCount then
        valueTime = string.format("%s %s", totalPlayTime, locale.battlefield.playTimeDetail(info.playRoundCount, info.roundTime))
      else
        valueTime = totalPlayTime
      end
      str = F_TEXT.SetColonFormat(locale.battlefield.playTime, valueTime)
      local strMinLevel = GetLevelToString(info.levelMin)
      local strMaxLevel = GetLevelToString(info.levelMax)
      local levelStr = F_TEXT.SetColonFormat(GetCommonText("raid_level_limit"), string.format("%s - %s", strMinLevel, strMaxLevel))
      str = F_TEXT.SetEnterString(str, levelStr)
      local gearStr = ""
      if 0 < info.gearScore then
        gearStr = F_TEXT.SetColonFormat(GetCommonText("gear_score_limit"), info.gearScore)
      else
        gearStr = GetCommonText("gear_score_no_limit")
      end
      str = F_TEXT.SetEnterString(str, gearStr)
      local expeditionStr = ""
      if info.showExpeditionLevel == true then
        if 0 < info.expeditionLevel then
          expeditionStr = F_TEXT.SetColonFormat(GetCommonText("expedition_level_limit"), info.expeditionLevel)
        else
          expeditionStr = GetCommonText("expedition_level_no_limit")
        end
        str = F_TEXT.SetEnterString(str, expeditionStr)
      end
      local timeStr = F_TEXT.SetColonFormat(GetCommonText("battle_field_available_time"), GetCommonText("real_time"))
      str = F_TEXT.SetEnterString(str, timeStr)
      local timeDeatilStr = GetEntranceTime(info.entranceTime)
      str = F_TEXT.SetEnterString(str, timeDeatilStr)
      if info.maxPlayerCount ~= nil then
        local maxStr = F_TEXT.SetColonFormat(GetCommonText("instance_max_enter_player"), tostring(info.maxPlayerCount))
        str = F_TEXT.SetEnterString(str, maxStr)
      end
      additionalInfo:SetText(str)
    end
    function frame:SetVictoryInfo(info)
      if info == nil then
        victoryFrame:Show(false)
        victoryFrame:SetHeight(0)
      else
        victoryFrame:Show(true)
        local str = ""
        local lastTarget = victoryTitle
        local function PushVictoryGoal(widget, text, anchorTarget)
          widget:Show(true)
          widget:AddAnchor("TOPLEFT", anchorTarget, "BOTTOMLEFT", 0, anchorTarget == victoryTitle and 20 or 7)
          if text ~= nil then
            widget:SetText(text)
          end
        end
        local score = info.victoryScore
        if score ~= nil and score > 0 then
          str = F_TEXT.SetEnterString(str, locale.battlefield.winCondition.scoreAttainment(score))
        end
        local killCount = info.victoryKillCount
        if killCount ~= nil and killCount > 0 then
          str = F_TEXT.SetEnterString(str, locale.battlefield.winCondition.killCountAttainment(killCount))
        end
        local winCount = info.victoryRoundWinCount
        if winCount ~= nil and winCount > 0 then
          str = F_TEXT.SetEnterString(str, locale.battlefield.winCondition.roundWinCountAttainment(winCount))
        end
        local targetDestroy = info.victoryTarget ~= 0
        if targetDestroy then
          str = F_TEXT.SetEnterString(str, locale.battlefield.winCondition.targetDestruction)
        end
        local timeOut = info.victoryDefault
        local rankScope = info.victoryRankScope
        if timeOut == BFER_TIMEOVER_COMPARE_SCORE and rankScope > 0 then
          str = F_TEXT.SetEnterString(str, locale.battlefield.winCondition.timeoverScopeRank(rankScope))
        else
          str = F_TEXT.SetEnterString(str, locale.battlefield.winCondition.scoreSuperiority)
        end
        goal:SetText(str)
        local _, height = F_LAYOUT.GetExtentWidgets(victoryTitle, goal)
        victoryFrame:SetHeight(height + 30)
      end
    end
    function frame:SetEnterCount(cur, max)
      local str = ""
      local colorKey = "default"
      if max == 1000 then
        str = GetUIText(COMMON_TEXT, "Battlefield_entrance_unlimited")
      elseif cur < max then
        str = F_TEXT.SetColonFormat(GetUIText(COMMON_TEXT, "Battlefield_entrance_condition"), F_TEXT.SetSlashFormat(tostring(cur), tostring(max)))
      else
        str = F_TEXT.SetColonFormat(GetUIText(COMMON_TEXT, "Battlefield_entrance_condition"), F_TEXT.SetSlashFormat(tostring(cur), tostring(max)))
        str = string.format("%s %s", str, GetUIText(COMMON_TEXT, "Battlefield_entrance_reset_time"))
        color = "red"
      end
      enterCount.style:SetColorByKey(colorKey)
      enterCount:SetText(str)
    end
    function frame:SetResetCount(hasResetItem, cur, max)
      local resetAvailable = hasResetItem and max > 0
      local maxReset = max <= cur
      if not resetAvailable then
        resetCount:Show(false)
        return
      end
      local color = max <= cur and "red" or "default"
      resetCount:Show(true)
      resetCount.style:SetColorByKey(color)
      resetCount:SetText(F_TEXT.SetColonFormat(GetUIText(COMMON_TEXT, "Battlefield_reset_visit_count_title"), F_TEXT.SetSlashFormat(tostring(cur), tostring(max))))
    end
    function frame:UpdateButtonWhenFillDetail(available, singleApplyAvailable, squadCreatable, hasSquad)
      entranceButton:Enable(available and not hasSquad and singleApplyAvailable)
      switchSquadListBtn:Enable(available and squadCreatable)
    end
    function frame:UpdateButtonWithApplyInfo(apply)
      entranceButton:Show(not apply)
      cancelButton:Show(apply)
    end
    function frame:SetScrollValue(value)
      scrollWnd:SetValue(value)
    end
    function frame:SetDefaultUiKey(value)
      frame.defaultUiKey = value
    end
    frame.zoneList = {}
    function frame:OnPageChangedProc(pageIndex)
      if frame.zoneList ~= nil and #frame.zoneList > 1 then
        zoneName:SetText(frame.zoneList[pageIndex].zoneName)
        frame:SetPreview(frame.zoneList[pageIndex].uiKey)
      else
        zoneName:SetText("")
        frame:SetPreview(frame.defaultUiKey)
      end
    end
    function pageControl:OnPageChanged(pageIndex, countPerPage)
      if frame.OnPageChangedProc ~= nil then
        frame:OnPageChangedProc(pageIndex)
      end
    end
    function frame:SetZoneList(value)
      if value == nil or #value < 2 then
        frame.zoneList = {}
        pageControl:SetPageByItemCount(0, 1)
        pageControl:SetCurrentPage(1, true)
        pageControl:Show(false)
        bgZoneName:Show(false)
        scrollWnd:RemoveAllAnchors()
        scrollWnd:SetExtent(484, 283)
        scrollWnd:AddAnchor("TOP", preview, "BOTTOM", 0, 8)
        scrollWnd:AddAnchor("LEFT", frame, 20, 0)
      else
        frame.zoneList = value
        zoneName:SetText(frame.zoneList[1].zoneName)
        pageControl:SetPageByItemCount(#value, 1)
        pageControl:SetCurrentPage(1, true)
        pageControl:Show(true)
        bgZoneName:Show(true)
        scrollWnd:RemoveAllAnchors()
        scrollWnd:SetExtent(484, 253)
        scrollWnd:AddAnchor("TOP", pageControl, "BOTTOM", 0, 8)
        scrollWnd:AddAnchor("LEFT", frame, 20, 0)
      end
    end
    function frame:ResetScroll()
      local startTarget = balanceLevel:IsVisible() and balanceLevel or description
      local endTarget = victoryFrame:IsVisible() and victoryFrame or additionalInfo
      local _, startPos = startTarget:GetOffset()
      local _, endPos = endTarget:GetOffset()
      local scrollHeight = endPos + endTarget:GetHeight() - startPos + 15
      scrollWnd:ResetScroll(scrollHeight)
    end
    return frame
  end
  local leftList = CreateLeftList("leftList", window)
  leftList:AddAnchor("TOPLEFT", tab, 0, 40)
  window.leftList = leftList
  local rightDetail = CreateDetailInfo("rightDetail", window)
  local rightTitle = CreateDeatilTitle("rightTitle", window)
  rightTitle:AddAnchor("TOPLEFT", leftList, "TOPRIGHT", 10, 0)
  rightDetail:AddAnchor("TOPLEFT", rightTitle, "BOTTOMLEFT", 0, 0)
  local squadList = CreateSquadList("squadList", window, rightWidth, contentHeight, titleHeight)
  squadList:AddAnchor("TOPLEFT", rightTitle, "BOTTOMLEFT", 0, 0)
  squadList:Show(false)
  return window
end
local function CreateEntranceWindow(id, parent)
  local window = SetViewOfEntranceWindow(id, parent)
  local tab = window.tab
  local leftList = window.leftList
  local rightTitle = window.rightTitle
  local rightDetail = window.rightDetail
  local squadList = window.squadList
  local activatedInstances = {}
  function window:GetSelectedInstance()
    return selectedInstance
  end
  local function OnClickEntranceBtn()
    if X2Squad:HasMySquad() or X2Team:IsSiegeRaidTeam() then
      return
    end
    if selectedInstance == nil then
      return
    end
    X2BattleField:RequestInstanceGame(selectedInstance)
  end
  rightDetail.entranceButton:SetHandler("OnClick", OnClickEntranceBtn)
  local OnClickCancelBtn = function()
    if X2Squad:HasMySquad() then
      return
    end
    X2BattleField:CancelInstanceGame()
  end
  rightDetail.cancelButton:SetHandler("OnClick", OnClickCancelBtn)
  local function SwitchPage(showSquadList)
    if showSquadList then
      if not featureSet.squad and UIParent:GetPermission(UIC_SQUAD) then
        return
      end
      if selectedInstance == nil then
        return
      end
      squadList:SetCurrentInstance(selectedInstance)
      rightDetail:Show(false)
      squadList:Show(true)
      X2Squad:GetSquadList(selectedInstance, 0)
    else
      squadList:SetCurrentInstance(nil)
      rightDetail:Show(true)
      squadList:Show(false)
    end
  end
  local function OnClickSwitchSqustListBtn()
    SwitchPage(true)
  end
  ButtonOnClickHandler(rightDetail.switchSquadListBtn, OnClickSwitchSqustListBtn)
  local function OnClickBackButton()
    SwitchPage(false)
  end
  ButtonOnClickHandler(squadList.backButton, OnClickBackButton)
  local function SetEnableTabButtonsByApplyStatus(apply)
    if apply then
      local selectTab = tab:GetSelectedTab()
      for i = 1, #tab.window do
        if selectTab ~= i then
          tab:EnableTab(i, not apply)
        end
      end
    else
      window:ChangeEnablementTabButtons()
    end
  end
  local function SetEnableLeftList(enable)
    leftList:Enable(enable, true)
  end
  function window:UpdateApplyInfo(tabChanged)
    local apply = X2BattleField:IsApplyInstance()
    if not apply then
      rightDetail:UpdateButtonWithApplyInfo(false)
      if tabChanged ~= true then
        SetEnableTabButtonsByApplyStatus(false)
        SetEnableLeftList(true)
      end
      return
    end
    SetEnableTabButtonsByApplyStatus(true)
    SetEnableLeftList(false)
    local addCondition = X2Squad:HasMySquad() or X2Team:IsSiegeRaidTeam()
    if addCondition then
      rightDetail:UpdateButtonWithApplyInfo(false)
    else
      rightDetail:UpdateButtonWithApplyInfo(true)
    end
  end
  function window:FillList(info)
    local returnValue = true
    local list = activatedInstances[info.type]
    if list == nil then
      returnValue = false
    else
      for i = 1, #list do
        list[i].path = info.path
      end
    end
    leftList:SetData({
      [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
      [W_MODULE.ATTRIBUTE.DATA] = list
    })
    return returnValue
  end
  function window:SelectByInstanceType(instanceType)
    leftList:SetDataPartially(W_MODULE.ATTRIBUTE.SELECTED_DATA, {
      checkFunc = function(rowData)
        return rowData.type == instanceType
      end
    })
  end
  function window:SetTabVisible(showUiKindTab, tabIndex)
    local allShow = true
    if showUiKindTab and tabIndex ~= 0 then
      allShow = false
    end
    if allShow then
      for i = 1, #window.tab.window do
        window.tab:ShowTab(i)
      end
    else
      for i = 1, #window.tab.window do
        if tabIndex == i then
          window.tab:ShowTab(i)
        else
          window.tab:HideTab(i)
        end
      end
    end
  end
  function window:FillDetail(instanceType)
    if instanceType == nil then
      X2Util:RaiseLuaCallStack("[FillDetail] instanceType is nil")
      return
    end
    local info = X2BattleField:GetDetailInstanceInfo(instanceType)
    if info == nil then
      return
    end
    local zoneList = info.zoneList
    SwitchPage(false)
    rightDetail:SetScrollValue(0)
    rightTitle:SetTitle(info.name)
    rightDetail:SetZoneList(zoneList)
    rightDetail:SetDefaultUiKey(info.uiKey)
    rightDetail:SetPreview(info.uiKey)
    rightDetail:SetBalanceLevel(info.balanceLevel)
    rightDetail:SetDescription(info.desc)
    rightDetail:SetAdditionalInfo(info)
    rightDetail:SetVictoryInfo(X2BattleField:GetVictoryInfo(instanceType))
    rightDetail:ResetScroll()
    rightDetail:SetEnterCount(info.enterCount, info.maxEnterCount)
    rightDetail:SetResetCount(info.resetItem, info.resetCount, info.resetLimit)
    rightDetail:UpdateButtonWhenFillDetail(info.available, info.singleApplyAvailable, info.squadCreatable, info.hasSquad)
  end
  function window:ChangeEnablementTabButtons()
    local activatedCount = 0
    local activatedFirstTab = 0
    for i = 1, #tab.window do
      local info = window:GetKindInfo(i)
      local list = X2BattleField:GetInstanceListByKind(info.type)
      if list == nil or #list == 0 then
        tab:EnableTab(i, false)
      else
        tab:EnableTab(i, true)
        activatedInstances[info.type] = list
        activatedCount = activatedCount + 1
        if activatedFirstTab == 0 then
          activatedFirstTab = i
        end
      end
    end
    return activatedCount, activatedFirstTab
  end
  function window.tab:OnTabChangedProc(selected)
    local info = window:GetKindInfo(selected)
    SwitchPage(false)
    rightDetail:ShowHonorStore(info.showHonorStore)
    local result = window:FillList(info)
    if result then
      leftList:SetDataPartially(W_MODULE.ATTRIBUTE.SELECT_BY_INDEX, {index = 0, trigger = true})
    end
  end
  window:ChangeEnablementTabButtons()
  window.tab:OnTabChangedProc(1)
  local events = {
    LEVEL_CHANGED = function(_, stringId)
      if not W_UNIT.IsMyUnitId(stringId) then
        return
      end
      window:ChangeEnablementTabButtons()
    end,
    LEFT_LOADING = function()
      window:Show(false)
    end,
    ENTERED_INSTANT_GAME_ZONE = function()
      window:Show(false)
    end,
    NPC_INTERACTION_END = function()
      if not X2Player:GetFeatureSet().show_instance_in_hud then
        window:Show(false)
      end
    end,
    UPDATE_INSTANT_GAME_STATE = function()
      window:UpdateApplyInfo(false)
      ShowBattleFieldEntranceAlarm(true)
    end,
    INSTANT_GAME_JOIN_APPLY = function()
      window:UpdateApplyInfo(false)
      ShowBattleFieldEntranceAlarm(true)
    end,
    INSTANT_GAME_JOIN_CANCEL = function()
      window:FillDetail(selectedInstance)
      window:UpdateApplyInfo(false)
      ShowBattleFieldEntranceAlarm(false)
    end,
    INSTANT_GAME_VISIT_COUNT_RESET = function(state)
      window:FillDetail(selectedInstance)
    end
  }
  window:SetHandler("OnEvent", function(this, event, ...)
    events[event](...)
  end)
  RegistUIEvent(window, events)
  return window
end
instanceEntrance = CreateEntranceWindow("entrance", "UIParent")
instanceEntrance:AddAnchor("LEFT", "UIParent", 0, 0)
local function ToggleInstanceEntrance(show, data)
  local requestByInteraction, instanceUiKindType, instanceType
  local showUiKindTab = false
  if data ~= nil then
    if data.requestByInteraction ~= nil and type(data.requestByInteraction) == "boolean" then
      requestByInteraction = data.requestByInteraction
    end
    if not featureSet.show_instance_in_hud and requestByInteraction == nil then
      return
    end
    if data.uiKind ~= nil and type(data.uiKind) == "number" then
      instanceUiKindType = data.uiKind
    end
    if data.instanceType ~= nil and type(data.instanceType) == "number" then
      instanceType = data.instanceType
    end
    if data.showUiKindTab ~= nil and type(data.showUiKindTab) == "boolean" then
      showUiKindTab = data.showUiKindTab
    end
  elseif not featureSet.show_instance_in_hud then
    showUiKindTab = true
  end
  if show == nil then
    show = not instanceEntrance:IsVisible()
  end
  if show and not X2Player:IsInSeamlessZone() then
    AddMessageToSysMsgWindow(GetUIText(COMMON_TEXT, "instant_game_hud_button_disable_tooltip"))
    return false
  end
  if show and X2Team:IsSiegeRaidTeam() then
    AddMessageToSysMsgWindow(X2Locale:LocalizeUiText(ERROR_MSG, "DO_NOT_USABLE_INDUN_IN_SIEGE_RAID_TEAM"))
    return false
  end
  local activatedCount, activatedFirstTab = 0, 0
  if show then
    activatedCount, activatedFirstTab = instanceEntrance:ChangeEnablementTabButtons()
    if activatedCount == 0 then
      AddMessageToSysMsgWindow(GetUIText(COMMON_TEXT, "battle_field_list_none"))
      return false
    end
    if instanceUiKindType == nil or instanceType == nil then
      local info = X2BattleField:GetApplyInstanceInfo()
      if info ~= nil then
        instanceUiKindType = info.instanceUiKindType
        instanceType = info.instanceType
      end
    end
    local selectableTab = instanceEntrance:GetTabIndexByKindType(instanceUiKindType)
    instanceEntrance:SetTabVisible(showUiKindTab, selectableTab)
    if selectableTab == 0 then
      selectableTab = activatedFirstTab or 1
    end
    instanceEntrance.tabs:SelectTab(selectableTab)
    local selectableInstance = instanceType
    if selectableInstance == nil then
      selectableInstance = instanceEntrance:GetSelectedInstance()
    end
    instanceEntrance:SelectByInstanceType(selectableInstance)
    instanceEntrance:UpdateApplyInfo()
  end
  instanceEntrance:Show(show)
  return true
end
ADDON:RegisterContentTriggerFunc(UIC_REQUEST_BATTLEFIELD, ToggleInstanceEntrance)
