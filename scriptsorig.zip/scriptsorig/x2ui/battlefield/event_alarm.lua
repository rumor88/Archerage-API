local EVENT_ALARM = {
  JOINED = 1,
  READY = 2,
  COUNTDOWN = 3,
  ROUND_RESULT = 4,
  ENDED = 5,
  RETIRED = 6
}
local GetRemainTime = function()
  return battlefield.eventAlarm.remainTime
end
local OnAlphaAnimeEnd = function(self)
  if self.animState == nil then
    return
  end
  if self.animState == "start" then
    do
      local visibleTime = 0
      local function ShowResultAlarm(self, dt)
        visibleTime = visibleTime + dt
        if visibleTime < 4000 then
          return
        end
        self:ReleaseHandler("OnUpdate")
        self:SetAlphaAnimation(1, 0, 4602678819172646912, 4602678819172646912)
        self:SetStartAnimation(true, false)
        self.animState = "end"
      end
      if self:HasHandler("OnUpdate") == false then
        self:SetHandler("OnUpdate", ShowResultAlarm)
      end
    end
  elseif self.animState == "end" then
    self.animState = nil
    self:Show(false)
    if self.animStateEndedFunc ~= nil then
      self.animStateEndedFunc()
      self.animStateEndedFunc = nil
    end
  end
end
local function CreatePeopleWaiting()
  local widget = UIParent:CreateWidget("window", "peopleWaiting", "UIParent")
  widget:SetExtent(756, 145)
  widget:AddAnchor("TOP", "UIParent", 0, 50)
  widget:SetUILayer("system")
  widget:EnablePick(false)
  local bottomBg = widget:CreateEffectDrawableByKey(TEXTURE_PATH.ALARM_DECO, "bg", "background")
  bottomBg:AddAnchor("BOTTOM", widget, 0, 0)
  bottomBg:SetRepeatCount(1)
  local decoBg = widget:CreateEffectDrawableByKey(TEXTURE_PATH.ALARM_DECO, "icon_bg", "background")
  decoBg:AddAnchor("CENTER", bottomBg, "TOP", 0, 0)
  decoBg:SetRepeatCount(1)
  local decoIcon = widget:CreateEffectDrawableByKey(TEXTURE_PATH.BATTLEFIELD_ALARM_READY, "icon", "artwork")
  decoIcon:AddAnchor("CENTER", decoBg, -2, -3)
  decoIcon:SetRepeatCount(1)
  local effectDrawable = widget:CreateEffectDrawableByKey(TEXTURE_PATH.BATTLEFIELD_ALARM_READY, "standby", "artwork")
  effectDrawable:AddAnchor("CENTER", bottomBg, -3, -15)
  effectDrawable:SetRepeatCount(1)
  function widget:ShowWidget()
    widget:Show(true)
    bottomBg:SetEffectPriority(1, "alpha", 4591870180066957722, 4591870180066957722)
    bottomBg:SetEffectInitialColor(1, 1, 1, 1, 1)
    bottomBg:SetEffectFinalColor(1, 1, 1, 1, 1)
    decoBg:SetEffectPriority(1, "alpha", 4591870180066957722, 4591870180066957722)
    decoBg:SetEffectInitialColor(1, 1, 1, 1, 1)
    decoBg:SetEffectFinalColor(1, 1, 1, 1, 1)
    decoIcon:SetEffectPriority(1, "alpha", 4591870180066957722, 4591870180066957722)
    decoIcon:SetEffectInitialColor(1, 1, 1, 1, 1)
    decoIcon:SetEffectFinalColor(1, 1, 1, 1, 1)
    effectDrawable:SetEffectPriority(1, "alpha", 4599075939470750515, 4599075939470750515)
    effectDrawable:SetEffectInitialColor(1, 1, 1, 1, 1)
    effectDrawable:SetEffectFinalColor(1, 1, 1, 1, 1)
    effectDrawable:SetStartEffect(true)
    widget:SetAlphaAnimation(0, 1, 4602678819172646912, 4602678819172646912)
    widget:SetStartAnimation(true, false)
  end
  widget:SetHandler("OnAlphaAnimeEnd", OnAlphaAnimeEnd)
  widget:Show(false)
  widget:Raise()
  return widget
end
local function CreateReadyTime()
  local widget = UIParent:CreateWidget("window", "readyTime", "UIParent")
  widget:AddAnchor("TOP", "UIParent", 0, 185)
  widget:SetUILayer("system")
  widget:EnablePick(false)
  local readyTimeBg = widget:CreateDrawable(TEXTURE_PATH.BATTLEFIELD_TIME, "time", "background")
  readyTimeBg:AddAnchor("TOPLEFT", widget, "TOPLEFT", 0, 0)
  readyTimeBg:AddAnchor("BOTTOMRIGHT", widget, "BOTTOMRIGHT", 0, 0)
  local baseWidth = 180
  local readyTimeText = widget:CreateChildWidget("textbox", "readyTimeText", 0, true)
  readyTimeText.style:SetFontSize(FONT_SIZE.XXLARGE)
  readyTimeText.style:SetAlign(ALIGN_LEFT)
  local timeStr = locale.battlefield.readyTime(0, 0)
  local readyTimeWidth = readyTimeText.style:GetTextWidth(timeStr) or baseWidth
  readyTimeText:SetExtent(readyTimeWidth + FONT_SIZE.XXLARGE, FONT_SIZE.XXLARGE)
  readyTimeText:SetAutoResize(true)
  readyTimeText.style:SetColorByKey("medium_yellow")
  readyTimeText:AddAnchor("LEFT", widget, "LEFT", 90, 12)
  if baseWidth < readyTimeWidth then
    widget:SetExtent(90 + readyTimeWidth + 40, 64)
  else
    widget:SetExtent(310, 64)
  end
  readyTimeText:SetText(timeStr)
  local function OnUpdateTime(self, dt)
    if battlefield.eventAlarm.state ~= "READY" then
      widget:ReleaseHandler("OnUpdate")
      widget:Show(false)
      return
    end
    if widget.oldTime ~= GetRemainTime() then
      widget.oldTime = GetRemainTime()
      local minute, second = GetMinuteSecondeFromSec(GetRemainTime())
      readyTimeText:SetText(locale.battlefield.readyTime(minute, second))
    end
  end
  function widget:ShowWidget()
    battlefield.eventAlarm[EVENT_ALARM.JOINED]:SetAlphaAnimation(1, 0, 4602678819172646912, 4602678819172646912)
    battlefield.eventAlarm[EVENT_ALARM.JOINED]:SetStartAnimation(true, false)
    battlefield.eventAlarm[EVENT_ALARM.JOINED].animState = "end"
    widget.oldTime = 0
    widget:Show(true)
    if widget:HasHandler("OnUpdate") == false then
      widget:SetHandler("OnUpdate", OnUpdateTime)
    end
  end
  widget:Show(false)
  widget:Raise()
  return widget
end
local function CreateCountDown()
  local widget = UIParent:CreateWidget("window", "countDown", "UIParent")
  widget:SetExtent(113, 103)
  widget:AddAnchor("TOP", "UIParent", 0, 182)
  widget:SetUILayer("system")
  widget:EnablePick(false)
  local countDownBg = widget:CreateDrawable("ui/battlefield/bg_circle.dds", "count_bg", "background")
  countDownBg:AddAnchor("TOPLEFT", widget, "TOPLEFT", 0, 0)
  countDownBg:AddAnchor("BOTTOMRIGHT", widget, "BOTTOMRIGHT", 0, 0)
  countDownBg:Show(false)
  local countDown = {}
  for i = 0, 5 do
    local texturePath = ""
    local textureInfo = ""
    if i > 0 then
      texturePath = string.format("ui/battlefield/cont_%d.dds", i)
      textureInfo = string.format("count_%d", i)
    else
      texturePath = "ui/battlefield/war_start_image.dds"
      textureInfo = "war_start_image"
    end
    countDown[i] = widget:CreateEffectDrawableByKey(texturePath, textureInfo, "overlay")
    countDown[i]:SetRepeatCount(1)
    if i > 0 then
      countDown[i]:AddAnchor("TOPLEFT", widget, "TOPLEFT", 20, 0)
    else
      countDown[i]:AddAnchor("TOP", widget, "TOP", 0, 0)
    end
    countDown[i]:Show(i == 0)
  end
  local warStartImage = widget:CreateDrawable("ui/battlefield/war_start.dds", "war_start", "background")
  warStartImage:AddAnchor("TOP", widget, "TOP", 0, 56)
  warStartImage:Show(false)
  local CountDownPhaseAnim = function(self)
    self:SetEffectPriority(1, "alpha", 4599075939470750515, 4599075939470750515)
    self:SetEffectInitialColor(1, 1, 1, 1, 0)
    self:SetEffectFinalColor(1, 1, 1, 1, 1)
    self:SetEffectScale(1, 4609434218613702656, 1, 4609434218613702656, 1)
    self:SetEffectInterval(1, 4591870180066957722)
    self:SetStartEffect(true)
    self:SetVisible(true)
  end
  local HidePhaseAnim = function(self)
    self:SetEffectPriority(1, "alpha", 4599075939470750515, 4599075939470750515)
    self:SetEffectInitialColor(1, 1, 1, 1, 0)
    self:SetEffectFinalColor(1, 1, 1, 1, 1)
    self:SetEffectScale(1, 0, 1, 0, 1)
    self:SetEffectInterval(1, 4603579539098121011)
    self:SetEffectPriority(2, "alpha", 4599075939470750515, 4599075939470750515)
    self:SetEffectInitialColor(2, 1, 1, 1, 1)
    self:SetEffectFinalColor(2, 1, 1, 1, 0)
    self:SetStartEffect(true)
    self:SetVisible(true)
  end
  local function OnUpdateTime(self, dt)
    widget.remainTime = widget.remainTime - dt
    local remainTime = math.floor(widget.remainTime / 1000)
    if remainTime < 0 then
      widget:ReleaseHandler("OnUpdate")
      widget:SetAlphaAnimation(1, 0, 4599075939470750515, 4599075939470750515)
      widget:SetStartAnimation(true, false)
      widget:Show(false)
      return
    end
    if widget.oldTime ~= remainTime then
      if widget.oldShowWidget ~= nil then
        widget.oldShowWidget:Show(false)
        widget.oldShowWidget = nil
      end
      if countDown[remainTime] ~= nil then
        countDown[remainTime]:Show(true)
        widget.oldShowWidget = countDown[remainTime]
        local isCountDownPhase = remainTime > 0
        if isCountDownPhase then
          CountDownPhaseAnim(countDown[remainTime])
          F_SOUND.PlayUISound(string.format("battlefield_%d_secound", remainTime), true)
        else
          HidePhaseAnim(countDown[remainTime])
          F_SOUND.PlayUISound("battlefield_start", true)
        end
        countDownBg:Show(isCountDownPhase)
        warStartImage:Show(not isCountDownPhase)
      end
      widget.oldTime = remainTime
    end
  end
  function widget:ShowWidget()
    widget:Show(true)
    widget.oldTime = 0
    widget.remainTime = GetRemainTime() * 1000
    widget.oldShowWidget = nil
    widget:SetAlphaAnimation(0, 1, 4599075939470750515, 4599075939470750515)
    widget:SetStartAnimation(true, false)
    if widget:HasHandler("OnUpdate") == false then
      widget:SetHandler("OnUpdate", OnUpdateTime)
    end
  end
  widget:Show(false)
  widget:Raise()
  return widget
end
local function CreateRoundResult()
  local widget = UIParent:CreateWidget("window", "roundResult", "UIParent")
  widget:SetExtent(756, 145)
  widget:AddAnchor("TOP", "UIParent", 0, 50)
  widget:SetUILayer("system")
  widget:EnablePick(false)
  local bottomBg = widget:CreateEffectDrawableByKey(TEXTURE_PATH.ALARM_DECO, "bg", "background")
  bottomBg:AddAnchor("BOTTOM", widget, 0, 0)
  bottomBg:SetRepeatCount(1)
  local decoBg = widget:CreateEffectDrawableByKey(TEXTURE_PATH.ALARM_DECO, "icon_bg", "background")
  decoBg:AddAnchor("CENTER", bottomBg, "TOP", 0, 0)
  decoBg:SetRepeatCount(1)
  local decoIcon = widget:CreateEffectDrawableByKey(TEXTURE_PATH.BATTLEFIELD_ALARM_IN_PROGRESS, "icon", "artwork")
  decoIcon:AddAnchor("CENTER", decoBg, -2, -3)
  decoIcon:SetRepeatCount(1)
  local effectDrawable = widget:CreateEffectDrawable("ui/font/image_text.dds", "artwork")
  function effectDrawable:SetRound(round)
    local color = F_COLOR.GetColor("round_message_in_instance")
    local coords = X2:GetImageTextCoords("img_font_combat", 60, tostring(round))
    self:SetCoords(coords[1], coords[2], coords[3], coords[4])
    self:SetExtent(coords[3], coords[4])
    self:SetEffectPriority(1, "alpha", 4599075939470750515, 4599075939470750515)
    self:SetEffectInitialColor(1, color[1], color[2], color[3], color[4])
    self:SetEffectFinalColor(1, color[1], color[2], color[3], color[4])
  end
  effectDrawable:SetRound(1)
  effectDrawable:SetRepeatCount(1)
  local effectRound = widget:CreateEffectDrawableByKey(TEXTURE_PATH.BATTLEFIELD_ROUND, "round", "artwork")
  effectRound:SetRepeatCount(1)
  local effectRoundResult = widget:CreateEffectDrawableByKey(TEXTURE_PATH.BATTLEFIELD_ROUND_DRAW, "draw", "artwork")
  function effectRoundResult:SetRoundResult(result)
    if result == VS_LOSE then
      self:SetTexture(TEXTURE_PATH.BATTLEFIELD_ROUND_LOSE)
      self:SetTextureInfo("lose")
    elseif result == VS_DRAW then
      self:SetTexture(TEXTURE_PATH.BATTLEFIELD_ROUND_DRAW)
      self:SetTextureInfo("draw")
    else
      self:SetTexture(TEXTURE_PATH.BATTLEFIELD_ROUND_WIN)
      self:SetTextureInfo("win")
    end
    self:SetEffectPriority(1, "alpha", 4599075939470750515, 4599075939470750515)
    self:SetEffectInitialColor(1, 1, 1, 1, 1)
    self:SetEffectFinalColor(1, 1, 1, 1, 1)
  end
  effectRoundResult:SetRepeatCount(1)
  effectRoundResult:SetRoundResult(1)
  widget.animState = nil
  widget.animStateEndedFunc = nil
  function widget:ShowWidget()
    widget:Show(true)
    bottomBg:SetEffectPriority(1, "alpha", 4591870180066957722, 4591870180066957722)
    bottomBg:SetEffectInitialColor(1, 1, 1, 1, 1)
    bottomBg:SetEffectFinalColor(1, 1, 1, 1, 1)
    decoBg:SetEffectPriority(1, "alpha", 4591870180066957722, 4591870180066957722)
    decoBg:SetEffectInitialColor(1, 1, 1, 1, 1)
    decoBg:SetEffectFinalColor(1, 1, 1, 1, 1)
    decoIcon:SetEffectPriority(1, "alpha", 4591870180066957722, 4591870180066957722)
    decoIcon:SetEffectInitialColor(1, 1, 1, 1, 1)
    decoIcon:SetEffectFinalColor(1, 1, 1, 1, 1)
    effectRound:SetEffectPriority(1, "alpha", 4599075939470750515, 4599075939470750515)
    effectRound:SetEffectInitialColor(1, 1, 1, 1, 1)
    effectRound:SetEffectFinalColor(1, 1, 1, 1, 1)
    effectDrawable:SetRound(battlefield.eventAlarm.resultRound)
    effectRoundResult:SetRoundResult(battlefield.eventAlarm.resultState)
    local startPos = bottomBg:GetWidth() / 2 - (effectDrawable:GetWidth() + effectRound:GetWidth() + effectRoundResult:GetWidth()) / 2
    local countPos = 0
    local rountPos = 0
    if ROUND_RESULT_STRING_ORDER.COUNT == 1 then
      countPos = startPos
      rountPos = countPos + effectDrawable:GetWidth()
    else
      rountPos = startPos
      countPos = rountPos + effectRound:GetWidth()
    end
    effectDrawable:RemoveAllAnchors()
    effectDrawable:AddAnchor("LEFT", bottomBg, countPos, -2)
    effectDrawable:SetVisible(true)
    effectDrawable:SetStartEffect(true)
    effectRound:RemoveAllAnchors()
    effectRound:AddAnchor("LEFT", bottomBg, rountPos, 0)
    effectRound:SetVisible(true)
    effectRound:SetStartEffect(true)
    effectRoundResult:RemoveAllAnchors()
    effectRoundResult:AddAnchor("RIGHT", bottomBg, "RIGHT", -startPos, 0)
    effectRoundResult:SetVisible(true)
    effectRoundResult:SetStartEffect(true)
    widget:SetAlphaAnimation(0, 1, 4602678819172646912, 4602678819172646912)
    widget:SetStartAnimation(true, false)
    widget.animState = "start"
  end
  widget:SetHandler("OnAlphaAnimeEnd", OnAlphaAnimeEnd)
  widget:Show(false)
  widget:Raise()
  return widget
end
local function CreateGameEnded()
  local widget = UIParent:CreateWidget("window", "gameEnded", "UIParent")
  widget:SetExtent(756, 145)
  widget:AddAnchor("TOP", "UIParent", 0, 50)
  widget:SetUILayer("system")
  local bottomBg = widget:CreateEffectDrawableByKey(TEXTURE_PATH.ALARM_DECO, "bg", "background")
  bottomBg:AddAnchor("BOTTOM", widget, 0, 0)
  bottomBg:SetRepeatCount(1)
  local decoBg = widget:CreateEffectDrawableByKey(TEXTURE_PATH.ALARM_DECO, "icon_bg", "background")
  decoBg:AddAnchor("CENTER", bottomBg, "TOP", 0, 0)
  decoBg:SetRepeatCount(1)
  local decoIcon = widget:CreateEffectDrawableByKey(TEXTURE_PATH.BATTLEFIELD_ALARM_READY, "icon", "artwork")
  decoIcon:AddAnchor("CENTER", decoBg, -2, -3)
  decoIcon:SetRepeatCount(1)
  local effectDrawable = widget:CreateEffectDrawableByKey(TEXTURE_PATH.BATTLEFIELD_ALARM_READY, "ended", "artwork")
  effectDrawable:AddAnchor("CENTER", bottomBg, -3, -15)
  effectDrawable:SetRepeatCount(1)
  local endReasonText = widget:CreateChildWidget("label", "endReasonText", 0, true)
  endReasonText:Show(false)
  endReasonText:SetAutoResize(true)
  endReasonText:SetHeight(FONT_SIZE.LARGE)
  endReasonText:AddAnchor("TOP", effectDrawable, "BOTTOM", 0, -5)
  endReasonText.style:SetFontSize(FONT_SIZE.LARGE)
  endReasonText.style:SetShadow(true)
  endReasonText.style:SetColorByKey("gray")
  widget.animState = nil
  function widget.animStateEndedFunc()
    ShowInstanceScoreboard(true, true)
  end
  local GetWinnerInfo = function(info)
    local winnerInfo = info.winnerInfo
    local reason = info.endReason
    local name = winnerInfo.name
    local count
    if reason == BFER_ACHIEVEMENT_KILL_COUNT then
      count = winnerInfo.killCount
    elseif reason == BFER_ACHIEVEMENT_ROUND_WIN_COUNT then
      count = winnerInfo.roundWinCount
    end
    return name, count
  end
  function endReasonText:SetEndReason()
    local info = X2BattleField:GetEndReasonInfo()
    if info == nil or info.myResult == VS_DRAW then
      return
    end
    local reason = info.endReason
    if reason == nil then
      return
    end
    local winnerInfo = info.winnerInfo
    if winnerInfo == nil then
      return
    end
    local str = ""
    if reason == BFER_TIMEOVER_COMPARE_KILL_COUNT or reason == BFER_TIMEOVER_COMPARE_ROUND_WIN_COUNT or reason == BFER_TIMEOVER_COMPARE_ALIVE or reason == BFER_TIMEOVER_DRAW or reason == BFER_UNEARNED_WIN or reason == BFER_TIMEOVER_COMPARE_SCORE then
      str = locale.battlefield.alarmEndReason.timeover
    elseif reason == BFER_ACHIEVEMENT_KILL_COUNT then
      local winTeamName, count = GetWinnerInfo(info)
      str = locale.battlefield.alarmEndReason.killCount(winTeamName, count)
      endReasonText:SetText(str)
    elseif reason == BFER_ACHIEVEMENT_ROUND_WIN_COUNT then
      local winTeamName, count = GetWinnerInfo(info)
      str = locale.battlefield.alarmEndReason.roundWinCount(winTeamName, count)
    elseif reason == BFER_ACHIEVEMENT_KILL_CORPS_HEAD then
      local winTeamName, _ = GetWinnerInfo(info)
      str = locale.battlefield.alarmEndReason.killCorpsHead(winTeamName)
    else
      endReasonText:SetText("")
    end
    endReasonText:SetText(str)
    X2Chat:DispatchChatMessage(CMF_SYSTEM, str)
    endReasonText:Show(true)
  end
  function widget:ShowWidget()
    local info = X2BattleField:GetProgressEntireInfo(false)
    if info == nil then
      return
    end
    widget:Show(true)
    endReasonText:SetEndReason()
    bottomBg:SetEffectPriority(1, "alpha", 4591870180066957722, 4591870180066957722)
    bottomBg:SetEffectInitialColor(1, 1, 1, 1, 1)
    bottomBg:SetEffectFinalColor(1, 1, 1, 1, 1)
    decoBg:SetEffectPriority(1, "alpha", 4591870180066957722, 4591870180066957722)
    decoBg:SetEffectInitialColor(1, 1, 1, 1, 1)
    decoBg:SetEffectFinalColor(1, 1, 1, 1, 1)
    decoIcon:SetEffectPriority(1, "alpha", 4591870180066957722, 4591870180066957722)
    decoIcon:SetEffectInitialColor(1, 1, 1, 1, 1)
    decoIcon:SetEffectFinalColor(1, 1, 1, 1, 1)
    effectDrawable:SetEffectPriority(1, "alpha", 4599075939470750515, 4599075939470750515)
    effectDrawable:SetEffectInitialColor(1, 1, 1, 1, 1)
    effectDrawable:SetEffectFinalColor(1, 1, 1, 1, 1)
    widget:SetAlphaAnimation(0, 1, 4602678819172646912, 4602678819172646912)
    widget:SetStartAnimation(true, false)
    widget.animState = "start"
    F_SOUND.PlayUISound("battlefield_end", true)
  end
  widget:SetHandler("OnAlphaAnimeEnd", OnAlphaAnimeEnd)
  widget:Show(false)
  widget:Raise()
  return widget
end
local function CreateGameRetired()
  local widget = UIParent:CreateWidget("window", "gameRetired", "UIParent")
  widget:SetExtent(756, 145)
  widget:AddAnchor("TOP", "UIParent", 0, 50)
  widget:SetUILayer("system")
  local bottomBg = widget:CreateEffectDrawableByKey(TEXTURE_PATH.ALARM_DECO, "bg", "background")
  bottomBg:AddAnchor("BOTTOM", widget, 0, 0)
  bottomBg:SetRepeatCount(1)
  local decoBg = widget:CreateEffectDrawableByKey(TEXTURE_PATH.ALARM_DECO, "icon_bg", "background")
  decoBg:AddAnchor("CENTER", bottomBg, "TOP", 0, 0)
  decoBg:SetRepeatCount(1)
  local decoIcon = widget:CreateEffectDrawableByKey(TEXTURE_PATH.BATTLEFIELD_ALARM_READY, "icon", "artwork")
  decoIcon:AddAnchor("CENTER", decoBg, -2, -3)
  decoIcon:SetRepeatCount(1)
  local effectDrawable = widget:CreateEffectDrawableByKey(TEXTURE_PATH.BATTLEFIELD_ALARM_READY, "ended", "artwork")
  effectDrawable:AddAnchor("CENTER", bottomBg, -3, -15)
  effectDrawable:SetRepeatCount(1)
  local alarmText = widget:CreateChildWidget("label", "alarmText", 0, true)
  alarmText:Show(false)
  alarmText:SetAutoResize(true)
  alarmText:SetHeight(FONT_SIZE.LARGE)
  alarmText:AddAnchor("TOP", effectDrawable, "BOTTOM", 0, -5)
  alarmText.style:SetFontSize(FONT_SIZE.LARGE)
  alarmText.style:SetShadow(true)
  alarmText.style:SetColorByKey("gray")
  widget.animState = nil
  function widget.animStateEndedFunc()
    ShowInstanceScoreboard(true, true)
  end
  function alarmText:SetAlarmText()
    self:SetText(GetUIText(GRAVE_YARD_TEXT, "dead"))
    self:Show(true)
  end
  function widget:ShowWidget()
    widget:Show(true)
    alarmText:SetAlarmText()
    bottomBg:SetEffectPriority(1, "alpha", 4591870180066957722, 4591870180066957722)
    bottomBg:SetEffectInitialColor(1, 1, 1, 1, 1)
    bottomBg:SetEffectFinalColor(1, 1, 1, 1, 1)
    decoBg:SetEffectPriority(1, "alpha", 4591870180066957722, 4591870180066957722)
    decoBg:SetEffectInitialColor(1, 1, 1, 1, 1)
    decoBg:SetEffectFinalColor(1, 1, 1, 1, 1)
    decoIcon:SetEffectPriority(1, "alpha", 4591870180066957722, 4591870180066957722)
    decoIcon:SetEffectInitialColor(1, 1, 1, 1, 1)
    decoIcon:SetEffectFinalColor(1, 1, 1, 1, 1)
    effectDrawable:SetEffectPriority(1, "alpha", 4599075939470750515, 4599075939470750515)
    effectDrawable:SetEffectInitialColor(1, 1, 1, 1, 1)
    effectDrawable:SetEffectFinalColor(1, 1, 1, 1, 1)
    widget:SetAlphaAnimation(0, 1, 4602678819172646912, 4602678819172646912)
    widget:SetStartAnimation(true, false)
    widget.animState = "start"
    F_SOUND.PlayUISound("battlefield_end", true)
  end
  widget:SetHandler("OnAlphaAnimeEnd", OnAlphaAnimeEnd)
  widget:Show(false)
  widget:Raise()
  return widget
end
local TestTimeInfo = function()
  timeInfo = {
    state = "RETIRED",
    remainTime = 60000,
    curPlayRoundCount = 1,
    playRoundCount = 1
  }
  return timeInfo
end
local function CreateEventAlarm()
  local timeInfo = X2BattleField:GetProgressTimeInfo()
  if timeInfo == nil then
    return
  end
  if battlefield.eventAlarm ~= nil then
    return
  end
  battlefield.eventAlarm = {}
  battlefield.eventAlarm[EVENT_ALARM.JOINED] = CreatePeopleWaiting()
  battlefield.eventAlarm[EVENT_ALARM.READY] = CreateReadyTime()
  battlefield.eventAlarm[EVENT_ALARM.COUNTDOWN] = CreateCountDown()
  battlefield.eventAlarm[EVENT_ALARM.ROUND_RESULT] = CreateRoundResult()
  battlefield.eventAlarm[EVENT_ALARM.ENDED] = CreateGameEnded()
  battlefield.eventAlarm[EVENT_ALARM.RETIRED] = CreateGameRetired()
end
local function ShowEventAlarm(eventAlram)
  local timeInfo = X2BattleField:GetProgressTimeInfo()
  if timeInfo == nil then
    return
  end
  CreateEventAlarm()
  if battlefield.eventAlarm[eventAlram] == nil then
    return
  end
  battlefield.eventAlarm.state = timeInfo.state
  battlefield.eventAlarm.remainTime = tonumber(timeInfo.remainTime)
  battlefield.eventAlarm[eventAlram]:ShowWidget()
end
local function HideEventMsg()
  if battlefield.eventAlarm == nil then
    return
  end
  local DestroyEventAlarm = function(widget)
    if widget == nil then
      return
    end
    widget:ReleaseHandler("OnUpdate")
    widget:EnableHidingIsRemove(true)
    widget:Show(false)
  end
  DestroyEventAlarm(battlefield.eventAlarm[EVENT_ALARM.JOINED])
  DestroyEventAlarm(battlefield.eventAlarm[EVENT_ALARM.READY])
  DestroyEventAlarm(battlefield.eventAlarm[EVENT_ALARM.COUNTDOWN])
  DestroyEventAlarm(battlefield.eventAlarm[EVENT_ALARM.ROUND_RESULT])
  DestroyEventAlarm(battlefield.eventAlarm[EVENT_ALARM.ENDED])
  DestroyEventAlarm(battlefield.eventAlarm[EVENT_ALARM.RETIRED])
  battlefield.eventAlarm = nil
end
local FillInstantTimeInfo = function()
  if battlefield.eventAlarm == nil then
    return
  end
  local timeInfo = X2BattleField:GetProgressTimeInfo()
  if timeInfo == nil then
    return
  end
  battlefield.eventAlarm.state = timeInfo.state
  battlefield.eventAlarm.remainTime = tonumber(timeInfo.remainTime)
end
UIParent:SetEventHandler("UPDATE_INSTANT_GAME_TIME", FillInstantTimeInfo)
local function EnteredInstantGameZone(type)
  if type ~= nil and type == 0 then
    ShowEventAlarm(EVENT_ALARM.JOINED)
  end
end
UIParent:SetEventHandler("ENTERED_INSTANT_GAME_ZONE", EnteredInstantGameZone)
local function InstantGameStateReady()
  ShowEventAlarm(EVENT_ALARM.READY)
end
UIParent:SetEventHandler("INSTANT_GAME_READY", InstantGameStateReady)
local function InstantGameStateCountDown()
  ShowEventAlarm(EVENT_ALARM.COUNTDOWN)
end
UIParent:SetEventHandler("INSTANT_GAME_WAIT", InstantGameStateCountDown)
local function InstantGameStateRoundResult(resultState, resultRound)
  battlefield.eventAlarm.resultRound = resultRound
  battlefield.eventAlarm.resultState = resultState
  ShowEventAlarm(EVENT_ALARM.ROUND_RESULT)
end
UIParent:SetEventHandler("INSTANT_GAME_ROUND_RESULT", InstantGameStateRoundResult)
local function InstantGameStateEnded()
  ShowEventAlarm(EVENT_ALARM.ENDED)
end
UIParent:SetEventHandler("INSTANT_GAME_END", InstantGameStateEnded)
local function InstantGameStateRetired()
  ShowEventAlarm(EVENT_ALARM.RETIRED)
end
UIParent:SetEventHandler("INSTANT_GAME_RETIRE", InstantGameStateRetired)
local function EnteredLoading()
  HideEventMsg()
end
UIParent:SetEventHandler("ENTERED_LOADING", EnteredLoading)
local function LeftLoading()
  local timeInfo = X2BattleField:GetProgressTimeInfo()
  if timeInfo == nil then
    return
  end
  CreateEventAlarm()
  local eventAlarm
  battlefield.eventAlarm.state = timeInfo.state
  battlefield.eventAlarm.remainTime = tonumber(timeInfo.remainTime)
  if battlefield.eventAlarm.state == "JOINED" then
    eventAlarm = EVENT_ALARM.JOINED
  elseif battlefield.eventAlarm.state == "READY" then
    eventAlarm = EVENT_ALARM.READY
  elseif battlefield.eventAlarm.state == "COUNTDOWN" then
    eventAlarm = EVENT_ALARM.COUNTDOWN
  elseif battlefield.eventAlarm.state == "ROUND_RESULT" then
    eventAlarm = EVENT_ALARM.ROUND_RESULT
  elseif battlefield.eventAlarm.state == "ENDED" then
    eventAlarm = EVENT_ALARM.ENDED
  elseif battlefield.eventAlarm.state == "RETIRED" then
    eventAlarm = EVENT_ALARM.RETIRED
  end
  ShowEventAlarm(eventAlarm)
end
UIParent:SetEventHandler("LEFT_LOADING", LeftLoading)
UIParent:SetEventHandler("ENTERED_WORLD", LeftLoading)
