if battleFieldLocale == nil then
  battleFieldLocale = {}
end
ROUND_RESULT_STRING_ORDER = {
  COUNT = 2,
  ROUND = 1,
  RESULT = 3
}
