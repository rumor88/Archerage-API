local layoutSet = {
  default = {
    squadOpenTypeLeftWidthPreset = "small",
    scoreboardColumnFontSize = FONT_SIZE.MIDDLE,
    textBadgeFontSize = FONT_SIZE.MIDDLE
  },
  [KAKAONA] = {
    squadOpenTypeLeftWidthPreset = "middle",
    textBadgeFontSize = FONT_SIZE.SMALL
  },
  [MAILRU] = {
    squadOpenTypeLeftWidthPreset = "middle",
    scoreboardColumnFontSize = FONT_SIZE.LARGE,
    textBadgeFontSize = FONT_SIZE.SMALL
  },
  [XLGAMES_TH] = {squadOpenTypeLeftWidthPreset = "middle"}
}
function GetLayoutSetBattleField()
  return L_HELPER.Get(layoutSet)
end
