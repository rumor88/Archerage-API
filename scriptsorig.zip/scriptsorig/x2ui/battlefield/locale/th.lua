if X2Util:GetGameProvider() == XLGAMES_TH then
  ROUND_RESULT_STRING_ORDER = {
    COUNT = 2,
    ROUND = 1,
    RESULT = 3
  }
end
