if X2Util:GetGameProvider() == KAKAONA and X2Locale:GetLocale() == "fr" then
  ROUND_RESULT_STRING_ORDER = {
    COUNT = 2,
    ROUND = 1,
    RESULT = 3
  }
end
