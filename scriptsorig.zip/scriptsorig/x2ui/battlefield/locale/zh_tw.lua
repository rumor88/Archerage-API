if X2Util:GetGameProvider() == PLAYWITH then
  ROUND_RESULT_STRING_ORDER = {
    COUNT = 1,
    ROUND = 2,
    RESULT = 3
  }
end
