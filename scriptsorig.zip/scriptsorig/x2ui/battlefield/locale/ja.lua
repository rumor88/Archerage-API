if X2Util:GetGameProvider() == GAMEON then
  ROUND_RESULT_STRING_ORDER = {
    COUNT = 2,
    ROUND = 1,
    RESULT = 3
  }
end
