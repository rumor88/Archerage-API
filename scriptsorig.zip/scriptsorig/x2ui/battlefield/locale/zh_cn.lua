if X2Util:GetGameProvider() == KAKAONA and X2Locale:GetLocale() == "zh_cn" then
  ROUND_RESULT_STRING_ORDER = {
    COUNT = 1,
    ROUND = 2,
    RESULT = 3
  }
end
