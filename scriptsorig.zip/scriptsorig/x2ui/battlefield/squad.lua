function ShowSquadWindow(parent)
  local wnd = SetViewOfSquad("squadWnd", parent)
  local disbandSquadButton = wnd.buttonSet:GetButton("disbandSquadButton")
  local buttonType
  local function Update()
    local data = X2Squad:GetMySquadInfo()
    if data == nil then
      wnd:DisableLeaveButton()
      X2Squad:EnableLeaveSquad(false)
      return
    end
    wnd.list:SetData({
      [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
      [W_MODULE.ATTRIBUTE.DATA] = data.memberInfo
    })
    wnd.infoSection:FillInfo(data.isLeader, data.openType, data.curMemberCount, data.maxMemberCount)
    local buttonString = ""
    local enable = true
    if data.isJoining then
      buttonType = SQUAD_EVENT_BUTTON_TYPE.ENTER
      buttonString = GetCommonText("indun_entrance")
    elseif data.isReady then
      buttonType = SQUAD_EVENT_BUTTON_TYPE.READY_CANCEL
      buttonString = X2Locale:LocalizeUiText(COMMON_TEXT, "cancel")
    elseif data.isLeader then
      buttonType = SQUAD_EVENT_BUTTON_TYPE.APPLY
      buttonString = GetCommonText("squad_info_apply_matching")
      enable = data.isAllReady and data.applyAvailble
    else
      buttonType = SQUAD_EVENT_BUTTON_TYPE.READY
      buttonString = GetCommonText("squad_info_ready")
    end
    wnd.buttonSet:UpdateButton("eventButton", {
      [W_MODULE.ATTRIBUTE.TEXT] = buttonString,
      enable = enable
    })
    disbandSquadButton:Show(data.isLeader)
    wnd.subTitleBox.subTitle:SetText(data.fieldName)
  end
  function wnd:ToggleSquadWindow()
    if not (X2Player:GetFeatureSet().squad and UIParent:GetPermission(UIC_SQUAD)) or not X2Squad:HasMySquad() then
      return
    end
    local isVisible = self:IsVisible()
    isVisible = not isVisible
    self:Show(isVisible)
  end
  local events = {
    UPDATE_SQUAD = function()
      Update()
    end
  }
  wnd:SetHandler("OnEvent", function(this, event, ...)
    events[event](...)
  end)
  RegistUIEvent(wnd, events)
  local function RefreshSquad()
    Update()
  end
  ButtonOnClickHandler(wnd.infoSection.refreshButton, RefreshSquad)
  function wnd:DisableLeaveButton()
    wnd.buttonSet:UpdateButton("leaveSquadButton", {enable = false})
    wnd.showTime = 0
    wnd:SetHandler("OnUpdate", wnd.OnUpdate)
  end
  wnd.buttonSet:UpdateButton("eventButton", {
    clickFunc = function(self)
      if buttonType == SQUAD_EVENT_BUTTON_TYPE.APPLY then
        X2Squad:ApplySquadMatching()
      elseif buttonType == SQUAD_EVENT_BUTTON_TYPE.READY then
        X2Squad:ReadySquad()
      elseif buttonType == SQUAD_EVENT_BUTTON_TYPE.READY_CANCEL then
        X2Squad:ReadySquad()
      elseif buttonType == SQUAD_EVENT_BUTTON_TYPE.ENTER then
        X2Squad:EnterSquadMatching()
      end
    end
  })
  wnd.showTime = 0
  function wnd:OnUpdate(dt)
    wnd.showTime = wnd.showTime + dt
    local enable = wnd.showTime > 5000
    if enable == false then
      return
    end
    wnd.buttonSet:UpdateButton("leaveSquadButton", {enable = true})
    X2Squad:EnableLeaveSquad(true)
    wnd:ReleaseHandler("OnUpdate")
    return
  end
  wnd:SetHandler("OnUpdate", wnd.OnUpdate)
  function wnd:ShowProc()
    Update()
  end
  return wnd
end
local squadWnd = ShowSquadWindow("UIParent")
squadWnd:SetSounds("battlefield_entrance")
ADDON:RegisterContentWidget(UIC_SQUAD, squadWnd)
