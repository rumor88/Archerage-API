local CreatePickBuffList = function(id, parent)
  local window = CreateWindow(id, parent)
  window:SetExtent(F_PREFIX_SIZE:GetWindowWidth(WINDOW_WIDTH_350), 430)
  window:SetTitle(GetUIText(COMMON_TEXT, "battlefield_pick_buff_title"))
  window:SetCloseOnEscape(false)
  window.titleBar:HideCloseButton()
  window:AddAnchor("CENTER", "UIParent", 0, 0)
  local selectedBuffType = 0
  local buttonSet = W_MODULE:Create("buttonSet", window, W_MODULE.TYPES.BUTTON_SET)
  buttonSet:AddButton("ok", {
    [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "ok"),
    [W_MODULE.ATTRIBUTE.ANCHOR_ALIGN] = W_MODULE.ANCHOR_ALIGN_TYPE.CENTER,
    enable = false,
    clickFunc = function()
      if window.scrollList == nil then
        return
      end
      local data = window.scrollList:GetDataPartially(W_MODULE.ATTRIBUTE.SELECTED_DATA)
      if data == nil then
        return
      end
      X2BattleField:PickBuff(data.buff_id)
      window:Show(false)
    end
  })
  function window:OnDeleted()
    battlefield.pickBuffList = nil
  end
  window:SetDeletedHandler(window.OnDeleted)
  local contentWidth = window:GetWidth() - MARGIN.WINDOW_SIDE * 2
  local textData = {
    [W_MODULE.ATTRIBUTE.TEXT] = GetCommonText("battlefield_pick_buff_desc")
  }
  local description = W_MODULE:Create("textbox", window, W_MODULE.TYPES.TEXTBOX, textData)
  window:RegisterStack(description)
  local scrollList = W_MODULE:Create("listCtrl", window, W_MODULE.TYPES.LISTCTRL, nil, {
    [W_MODULE.ATTRIBUTE.HAS_SCROLL] = true,
    [W_MODULE.ATTRIBUTE.COLUMN_HEIGHT_TYPE] = nil,
    [W_MODULE.ATTRIBUTE.ROW_COUNT] = 4,
    [W_MODULE.ATTRIBUTE.HAS_ROW_LINE] = false,
    [W_MODULE.ATTRIBUTE.ROW_BACKGROUND_TYPE] = "type_3",
    [W_MODULE.ATTRIBUTE.ROW_HEIGHT_TYPE] = "icon_buff",
    [W_MODULE.ATTRIBUTE.ROW_INSET_TYPE] = "icon_large",
    [W_MODULE.ATTRIBUTE.OVER_SELECT_IMAGE_TYPE] = "type_4",
    [W_MODULE.ATTRIBUTE.ONSELCHANGED_PROC] = function(index, doubleClick, moduleFrame)
      buttonSet:UpdateButton("ok", {enable = true})
    end,
    [W_MODULE.ATTRIBUTE.COLUMN_INFO] = {
      {
        [W_MODULE.ATTRIBUTE.WIDTH] = contentWidth - 15,
        [W_MODULE.ATTRIBUTE.TEXT] = "",
        [W_MODULE.ATTRIBUTE.LCCIT] = LCCIT_WINDOW,
        [W_MODULE.ATTRIBUTE.COLUMN_LAYOUT_FUNC] = function(subItem, row, listCtrl)
          local buffOffset = 10
          local buff = CreateIconButton("buff", subItem, "buff")
          buff:AddAnchor("LEFT", subItem, buffOffset, 0)
          subItem.buff = buff
          local buffNameOffset = 5
          local buffName = subItem:CreateChildWidget("label", "buffName", 0, true)
          buffName:SetExtent(subItem:GetWidth() - buffNameOffset - 2 * buffOffset - buff:GetWidth(), FONT_SIZE.MIDDLE)
          buffName:AddAnchor("LEFT", buff, "RIGHT", buffNameOffset, 0)
          buffName.style:SetAlign(ALIGN_LEFT)
          buffName.style:SetColorByKey("default")
          buffName.style:SetEllipsis(true)
          subItem.buffName = buffName
        end,
        [W_MODULE.ATTRIBUTE.COLUMN_DATA_SET_FUNC] = function(subItem, data)
          local row = subItem:GetParent()
          if data == nil then
            subItem.buffName:Show(false)
            subItem.buff:Show(false)
            row:ShowRowBackground(false)
            return
          end
          subItem.buffName:SetText(data.name)
          subItem.buffName:Show(true)
          subItem.buff:Show(true)
          subItem.buff:SetInfo(data)
          row:ShowRowBackground(true)
        end
      }
    }
  })
  window.scrollList = scrollList
  window:RegisterStack(scrollList)
  window:RegisterStack(buttonSet)
  window:ApplyAutoHeightByStack()
  return window
end
local function PickBuffListFunc()
  if X2BattleField:IsPossiblePickBuff() == true then
    if battlefield.pickBuffList == nil then
      battlefield.pickBuffList = CreatePickBuffList("pickBuffListWnd", "UIParent")
      battlefield.pickBuffList:EnableHidingIsRemove(true)
    end
    local buffInfos = X2BattleField:GetMyPickBuffInfos()
    battlefield.pickBuffList.scrollList:SetData({
      [W_MODULE.ATTRIBUTE.DELETE_ALL_DATAS] = true,
      [W_MODULE.ATTRIBUTE.DATA] = buffInfos
    })
    battlefield.pickBuffList:Show(true)
  elseif battlefield.pickBuffList ~= nil then
    battlefield.pickBuffList:Show(false)
  end
end
UIParent:SetEventHandler("INSTANT_GAME_PICK_BUFFS", PickBuffListFunc)
UIParent:SetEventHandler("ENTERED_WORLD", PickBuffListFunc)
UIParent:SetEventHandler("LEFT_LOADING", PickBuffListFunc)
local EnteredLoading = function()
  if battlefield.pickBuffList ~= nil then
    battlefield.pickBuffList:Show(false)
  end
end
UIParent:SetEventHandler("ENTERED_LOADING", EnteredLoading)
