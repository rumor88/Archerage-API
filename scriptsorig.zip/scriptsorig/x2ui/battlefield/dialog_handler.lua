local battlefieldLayoutLocale = GetLayoutSetBattleField()
local levelList = X2Team:GetRaidRecruitLimitLevelList()
local gearPointList = X2Team:GetRaidRecruitLimitGearPointList()
function ShowSquadRecruitDialog(parent, instanceType)
  local function DialogHandler(wnd)
    wnd:UseExpandWidth()
    wnd:SetTitle(GetCommonText("squad_recruit_title"))
    local dataManager = {}
    local openTypeRowKey = "openTypeRowKey"
    local limitLevelRowKey = "limitLevelRowKey"
    local limitGearPointRowKey = "limitGearPointRowKey"
    local isMustPublic = X2Squad:IsExpeditionContents(instanceType)
    if isMustPublic == false then
      local gettedHeaderTable = W_MODULE:Create("condition", wnd, W_MODULE.TYPES.HEADER_TABLE_A, {
        [W_MODULE.ATTRIBUTE.LEFT_WIDTH_PRESET] = battlefieldLayoutLocale.squadOpenTypeLeftWidthPreset
      })
      wnd:RegisterStack(gettedHeaderTable)
      gettedHeaderTable:AddRow(openTypeRowKey, {
        title = {
          string = GetUIText(COMMON_TEXT, "squad_open_type")
        },
        value = {
          [W_MODULE.ATTRIBUTE.CREATE_ROW_FUNC] = function(valueWidgetName, valueMaxWidth, rowFrame)
            local radioData = {
              {
                text = GetCommonText("squad_open_type_public"),
                value = SOT_PUBLIC
              },
              {
                text = GetCommonText("squad_open_type_private"),
                value = SOT_PRIVATE
              }
            }
            if X2Squad:IsAvailableDirectMatching(instanceType) == true then
              table.insert(radioData, {
                text = GetCommonText("squad_open_type_direct_matching"),
                value = SOT_DIRECT_MATCHING
              })
            end
            local openTypeRadioBoxes = CreateRadioGroup(valueWidgetName, rowFrame, "grid", true)
            openTypeRadioBoxes:SetWidth(valueMaxWidth)
            openTypeRadioBoxes:SetData(radioData)
            openTypeRadioBoxes:Check(1, false)
            wnd.openTypeRadioBoxes = openTypeRadioBoxes
            dataManager[openTypeRowKey] = 1
            local function OnRadioChanged(self, index, dataValue)
              dataManager[openTypeRowKey] = index
            end
            openTypeRadioBoxes:SetHandler("OnRadioChanged", OnRadioChanged)
            return openTypeRadioBoxes
          end
        }
      })
    end
    local gettedHeaderTable = W_MODULE:Create("condition", wnd, W_MODULE.TYPES.HEADER_TABLE_B, {
      title = GetCommonText("set_detail"),
      [W_MODULE.ATTRIBUTE.LEFT_WIDTH_PRESET] = battlefieldLayoutLocale.squadOpenTypeLeftWidthPreset
    })
    wnd:RegisterStack(gettedHeaderTable)
    gettedHeaderTable:AddRow(limitLevelRowKey, {
      title = {
        string = GetUIText(COMMON_TEXT, "raid_level_limit")
      },
      value = {
        [W_MODULE.ATTRIBUTE.CREATE_ROW_FUNC] = function(valueWidgetName, valueMaxWidth, rowFrame)
          local info = X2BattleField:GetInstanceAvailableLevel(instanceType)
          local inputName = W_MODULE:Create("inputName", wnd, W_MODULE.TYPES.EDITBOX, {action = "input"}, {
            width = 180,
            [W_MODULE.ATTRIBUTE.EDIT_DIGIT_ONLY] = true,
            [W_MODULE.ATTRIBUTE.SHOW_EDITBOX_RULE] = false,
            [W_MODULE.ATTRIBUTE.EDIT_TEXT_CHANGED_PROC] = function(text)
              wnd:ApplyOkButtonEnablement()
            end
          })
          local heirButton = inputName:CreateChildWidget("button", "heirButton", 0, true)
          heirButton:AddAnchor("LEFT", inputName, "RIGHT", 3, 0)
          heirButton:SetStyle("auction_successor_grey")
          inputName:SetDataPartially(W_MODULE.ATTRIBUTE.TEXT, tostring(info.levelMin))
          wnd.heirButton = heirButton
          heirButton.active = false
          local function GetMinMaxLevel()
            local levelMin = info.levelMin
            local levelMax = X2Player:GetFeatureSet().levelLimit
            if heirButton.active then
              if IsHeirLevel(levelMin) then
                levelMin = current - X2Player:GetMinHeirLevel()
              else
                levelMin = 1
              end
              levelMax = X2Player:GetMaxHeirLevel()
            end
            return levelMin, levelMax
          end
          local function HeirButtonLeftClickFunc()
            if heirButton.active == false then
              heirButton.active = true
            else
              heirButton.active = false
            end
            local levelMin = GetMinMaxLevel()
            heirButton:SetStyle(heirButton.active == true and "auction_successor" or "auction_successor_grey")
            inputName:SetDataPartially(W_MODULE.ATTRIBUTE.TEXT, tostring(levelMin))
          end
          ButtonOnClickHandler(heirButton, HeirButtonLeftClickFunc)
          local function InputNameOnEnter(self)
            local minLevelStr = GetLevelToString(info.levelMin)
            local maxLevelStr = GetLevelToString(info.levelMax)
            local levelStr = X2Locale:LocalizeUiText(COMMON_TEXT, "squad_level_limit_tooltip", minLevelStr, maxLevelStr)
            SetTooltip(levelStr, self)
          end
          inputName:SetHandler("OnEnter", InputNameOnEnter)
          local HeirButtonOnEnter = function(self)
            if self.active == true then
              return
            end
            SetTooltip(locale.auction.heirLevelSearchTooltip, self)
          end
          heirButton:SetHandler("OnEnter", HeirButtonOnEnter)
          wnd.levelTextInput = inputName
          function inputName:Satisfy()
            local levelMin, levelMax = GetMinMaxLevel()
            local level = tonumber(wnd.levelTextInput:GetDataPartially(W_MODULE.ATTRIBUTE.TEXT))
            return level ~= nil and levelMax >= level and levelMin <= level
          end
          return inputName
        end
      }
    })
    gettedHeaderTable:AddRow(limitGearPointRowKey, {
      title = {
        string = GetUIText(COMMON_TEXT, "gear_score_limit")
      },
      value = {
        [W_MODULE.ATTRIBUTE.CREATE_ROW_FUNC] = function(valueWidgetName, valueMaxWidth, rowFrame)
          local info = X2BattleField:GetDetailInstanceInfo(instanceType)
          local inputName = W_MODULE:Create("inputName", wnd, W_MODULE.TYPES.EDITBOX, {action = "input"}, {
            width = 180,
            [W_MODULE.ATTRIBUTE.EDIT_DIGIT_ONLY] = true,
            [W_MODULE.ATTRIBUTE.SHOW_EDITBOX_RULE] = false,
            [W_MODULE.ATTRIBUTE.EDIT_TEXT_CHANGED_PROC] = function(text)
              wnd:ApplyOkButtonEnablement()
            end
          })
          local maxGearScore = info.gearScoreLimitMax
          inputName:SetDataPartially(W_MODULE.ATTRIBUTE.TEXT, tostring(info.gearScore))
          wnd.gearScoreTextInput = inputName
          function inputName:Satisfy()
            local gearScore = tonumber(wnd.gearScoreTextInput:GetDataPartially(W_MODULE.ATTRIBUTE.TEXT))
            return gearScore ~= nil and gearScore <= maxGearScore and gearScore >= info.gearScore
          end
          local function InputNameOnEnter(self)
            local gearScoreStr = X2Locale:LocalizeUiText(COMMON_TEXT, "squad_gear_score_limit_tooltip", tostring(info.gearScore), tostring(maxGearScore))
            SetTooltip(gearScoreStr, self)
          end
          inputName:SetHandler("OnEnter", InputNameOnEnter)
          return inputName
        end
      }
    })
    local explanationEdit = W_MODULE:Create("explanationEdit", wnd, W_MODULE.TYPES.EDITBOX_MULTILINE_TITLE_BOX, {
      titleInfo = {
        title = GetUIText(COMMON_TEXT, "guide_explanation")
      }
    }, {
      [W_MODULE.ATTRIBUTE.MAX_LETTER] = 50,
      [W_MODULE.ATTRIBUTE.WINDOW_WIDTH_PRESET] = WINDOW_WIDTH_450
    })
    wnd:RegisterStack(explanationEdit)
    local partyInvitationCheckBoxData = {
      text = GetUIText(COMMON_TEXT, "squad_recruit_create_and_party_invitation")
    }
    local partyInvitationCheckBox = W_MODULE:Create("partyInvitationCheckBox", wnd, W_MODULE.TYPES.CHECKBOX, partyInvitationCheckBoxData)
    wnd:RegisterStack(partyInvitationCheckBox)
    function wnd:OkProc()
      local level = tonumber(wnd.levelTextInput:GetDataPartially(W_MODULE.ATTRIBUTE.TEXT))
      local gearScore = tonumber(wnd.gearScoreTextInput:GetDataPartially(W_MODULE.ATTRIBUTE.TEXT))
      local curLevel = wnd.heirButton.active and level + X2Player:GetMinHeirLevel() or level
      X2Squad:CreateSquad(instanceType, isMustPublic and SOT_MUST_PUBLIC or wnd.openTypeRadioBoxes:GetCheckedData(), explanationEdit:GetDataPartially(W_MODULE.ATTRIBUTE.TEXT), wnd.partyInvitationCheckBox:GetData(), curLevel, gearScore)
    end
  end
  X2DialogManager:RequestDialog(DialogHandler, parent:GetId())
end
local ShowBestRatingRewardMessage = function()
  if X2BattleField:IsInInstantGame() then
    return
  end
  local rewardInfo = X2BattleField:GetBestRatingReward()
  if rewardInfo.hasReward ~= true then
    return
  end
  local function DialogHandler(wnd)
    wnd:SetTitle(GetUIText(COMMON_TEXT, "best_rating"))
    local textData = {
      [W_MODULE.ATTRIBUTE.TEXT] = GetUIText(COMMON_TEXT, "best_rating_reward_ui_inform", rewardInfo.fieldName)
    }
    local textbox = W_MODULE:Create("textbox", wnd, W_MODULE.TYPES.TEXTBOX, textData)
    wnd:RegisterStack(textbox)
    local changeData = {
      titleInfo = {
        title = GetUIText(COMMON_TEXT, "best_rating_change")
      },
      left = {
        UpdateValueFunc = function(leftValueWidget)
          leftValueWidget:SetText(tostring(rewardInfo.oldRating))
        end
      },
      right = {
        UpdateValueFunc = function(rightValueWidget)
          rightValueWidget:SetText(tostring(rewardInfo.newRating))
        end
      }
    }
    local ratingDiff = W_MODULE:Create("ratingDiff", wnd, W_MODULE.TYPES.CHANGE_BOX_A, changeData)
    wnd:RegisterStack(ratingDiff)
    local bestReward = W_MODULE:Create("bestReward", wnd, W_MODULE.TYPES.ICON_VERTICAL_TITLE_BOX, {
      itemIconInfo = {
        itemInfo = X2Item:GetItemInfoByType(rewardInfo.rewardType),
        stack = rewardInfo.rewardAmount,
        enable = true
      },
      titleInfo = {
        title = GetCommonText("best_rating_reward")
      }
    })
    wnd:RegisterStack(bestReward)
    X2BattleField:ClearBestRatingReward()
  end
  X2DialogManager:RequestDialog(DialogHandler, UIParent:GetId(), {buttonType = DBT_OK})
end
UIParent:SetEventHandler("LEFT_LOADING", ShowBestRatingRewardMessage)
UIParent:SetEventHandler("ENTERED_WORLD", ShowBestRatingRewardMessage)
