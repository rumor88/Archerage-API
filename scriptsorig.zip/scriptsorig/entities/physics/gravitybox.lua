GravityBox = {
  Properties = {
    bActive = 1,
    BoxMin = {
      x = -10,
      y = -10,
      z = -10
    },
    BoxMax = {
      x = 10,
      y = 10,
      z = 10
    },
    bUniform = 1,
    Gravity = {
      x = 0,
      y = 0,
      z = 0
    },
    Falloff = {
      x = 0,
      y = 0,
      z = 0
    }
  },
  _PhysTable = {
    Area = {}
  }
}
function GravityBox:OnLoad(table)
  self.bActive = table.bActive
  if self.bActive == 1 then
    self:PhysicalizeThis()
  else
    self:DestroyPhysics()
  end
end
function GravityBox:OnSave(table)
  table.bActive = self.bActive
end
function GravityBox:OnInit()
  self.bActive = self.Properties.bActive
  if self.bActive == 1 then
    self:PhysicalizeThis()
  end
end
function GravityBox:OnPropertyChange()
  if self.bActive ~= self.Properties.bActive then
    self.bActive = self.Properties.bActive
    if self.bActive == 1 then
      self:PhysicalizeThis()
    else
      self:DestroyPhysics()
    end
  end
end
function GravityBox:OnReset()
end
function GravityBox:PhysicalizeThis()
  if self.bActive == 1 then
    local Properties = self.Properties
    local Area = self._PhysTable.Area
    Area.type = AREA_BOX
    Area.box_min = Properties.BoxMin
    Area.box_max = Properties.BoxMax
    Area.uniform = Properties.bUniform
    Area.falloff = Properties.Falloff
    Area.gravity = Properties.Gravity
    self:Physicalize(0, PE_AREA, self._PhysTable)
  end
end
function GravityBox:Event_Activate()
  if self.bActive ~= 1 then
    self.bActive = 1
    self:PhysicalizeThis()
  end
end
function GravityBox:Event_Deactivate()
  if self.bActive ~= 0 then
    self.bActive = 0
    self:PhysicalizeThis()
  end
end
GravityBox.FlowEvents = {
  Inputs = {
    Deactivate = {
      GravityBox.Event_Deactivate,
      "bool"
    },
    Activate = {
      GravityBox.Event_Activate,
      "bool"
    }
  },
  Outputs = {Deactivate = "bool", Activate = "bool"}
}
