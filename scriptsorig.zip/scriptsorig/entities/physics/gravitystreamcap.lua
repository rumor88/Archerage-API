GravityStreamCap = {}
