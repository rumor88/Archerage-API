Script.ReloadScript("SCRIPTS/Entities/actor/BasicActor.lua")
Player = {
  AnimationGraph = "monster_full_body.xml",
  UpperBodyGraph = "monster_full_body.xml",
  type = "Player",
  foreignCollisionDamageMult = 4591870180066957722,
  vehicleCollisionDamageMult = 4620130267728707584,
  Properties = {
    soclasses_SmartObjectClass = "Player",
    groupid = 0,
    species = 0,
    commrange = 40,
    aicharacter_character = "Player",
    Perception = {sightrange = 10},
    fileModel = "objects/Characters/hariharan/male/nude/ha_m.cdf",
    clientFileModel = "objects/Characters/hariharan/male/nude/ha_m.cdf"
  },
  PropertiesInstance = {
    aibehavior_behaviour = "player_idle"
  },
  AIMovementAbility = {
    passRadius = -1,
    pathRadius = -1,
    avoidanceRadius = 5
  },
  gameParams = {
    stance = {
      {
        stanceId = STANCE_STAND,
        normalSpeed = 4610785298501913805,
        maxSpeed = 4617090337980232499
      },
      {
        stanceId = STANCE_RELAXED,
        normalSpeed = 4610785298501913805,
        maxSpeed = 4617090337980232499
      },
      {
        stanceId = STANCE_SWIM,
        normalSpeed = 1,
        maxSpeed = 4615739258092021350
      },
      {
        stanceId = STANCE_ZEROG,
        normalSpeed = 4610785298501913805,
        maxSpeed = 4615739258092021350
      }
    },
    nanoSuitActive = 1
  },
  modelSetup = {
    deadAttachments = {"head", "helmet"}
  },
  Server = {},
  Client = {},
  squadFollowMode = 0,
  squadTarget = {
    x = 0,
    y = 0,
    z = 0
  },
  SignalData = {},
  AI = {
    commandSet = {}
  },
  OnUseEntityId = NULL_ENTITY,
  OnUseSlot = 0
}
function Player.Server:OnInit()
  self.thrusterAISoundRadius = 38
  self:OnInit()
end
function Player:PhysicalizeActor()
end
function Player:SetModel(model, fp3p)
  if model then
    if fp3p then
      self.Properties.clientFileModel = fp3p
    end
    self.Properties.fileModel = model
  end
end
function Player.Server:OnInitClient(channelId)
end
function Player.Server:OnPostInitClient(channelId)
end
function Player.Client:Revive()
  self:ResetDofFx()
  self:ResetMotionFx()
  self.actor:Revive()
end
function Player.Client:MoveTo(pos)
  self:SetWorldPos(pos)
end
function Player.Client:AlignTo(ang)
  self.actor:SetAngles(ang)
end
function Player.Client:ClearInventory()
  self.inventory:Clear()
end
function Player.Client:OnSetPlayerId()
end
function Player.Client:OnInit()
  self:OnInit()
end
function Player.Client:OnUpdate(frameTime)
  self:UpdateScreenEffects(frameTime)
end
function Player.Server:OnUpdate(frameTime)
  BasicActor.Server.OnUpdate(self, frameTime)
  if self.stopEPATime and self.stopEPATime < 0 then
    self.actor:SetMovementTarget(g_Vectors.v000, g_Vectors.v000, g_Vectors.v000, 1)
    self.stopEPATime = nil
    self.hostageID = nil
    self:HolsterItem(false)
  elseif self.stopEPATime then
    self.stopEPATime = self.stopEPATime - frameTime
  end
end
function Player:OnInit()
end
function Player:OnReset()
  g_aimode = nil
  BasicActor.Reset(self)
  self.thrusterAIVolume = 1
  self.thrusterVolume = nil
  if self == g_localActor then
    self:ResetDofFx()
    self:ResetMotionFx()
  end
  mergef(Player.SignalData, g_SignalData, 1)
end
function Player:StopThrusterSounds()
  if self.thrusterSound then
    self:StopSound(self.thrusterSound)
  end
  self.thrusterSound = nil
end
function Player:StartThrusterSounds(afterburn)
  if not self.thrusterSound or not Sound.IsPlaying(self.thrusterSound) then
    Sound.SetSoundLoop(self.thrusterSound, 1)
  end
  self.thrusterVolume = 1 + afterburn * 4594572339843380019
  self.thrusterAIVolume = 1 + afterburn * 3
end
function Player:UpdateThrusterSounds(frameTime)
  if self.thrusterVolume and self.thrusterVolume < 0 then
    self:StopThrusterSounds()
    self.thrusterVolume = nil
    self.thrusterAIVolume = 0
  elseif self.thrusterVolume then
    self.thrusterVolume = self.thrusterVolume - frameTime
    self.thrusterAIVolume = self.thrusterAIVolume - frameTime
    local volume = self.zeroGTable.thrusterVolume
    volume = volume or 150
    Sound.SetSoundVolume(self.thrusterSound, __min(255, __max(0, volume * self.thrusterVolume)) / 255)
  end
end
function Player:SetOnUseData(entityId, slot)
  self.OnUseEntityId = entityId
  self.OnUseSlot = slot
end
function Player:OnAction(action, activation, value)
  if action == "use" or action == "xi_use" then
    self:UseEntity(self.OnUseEntityId, self.OnUseSlot, activation == "press")
  end
end
function Player:OnActionUse(press)
  self:UseEntity(self.OnUseEntityId, self.OnUseSlot, press)
end
function Player:OnUpdateView(frameTime)
end
function Player:ScriptEvent(event, value, str)
  local message, sound
  if event == "gyroscope" then
    message = "gyroscope"
    sound = "gyro"
  elseif event == "gravityboots" then
    message = "gravity_boots"
    sound = "gboots"
  end
  if message then
    if value == 1 then
      message = message .. "_on"
    else
      message = message .. "_off"
    end
  end
  if sound then
    if value == 1 then
      sound = sound .. "_on"
    else
      sound = sound .. "_off"
    end
    PlayRandomSound(self, self.zeroGTable[sound])
  end
  if event == "thrusters" then
    self:StartThrusterSounds(value)
  elseif event == "unfreeze_shake" then
    self:OnUnfreezeShake(value)
  end
  BasicActor.ScriptEvent(self, event, value, str)
end
function Player:GrabObject(object, query)
  BasicActor.GrabObject(self, object, query)
end
function Player.Client:OnTimer(timerId, mSec)
  if timerId == SWITCH_WEAPON_TIMER then
    if AI then
      AI.Signal(SIGNALFILTER_GROUPONLY_EXCEPT, 1, "CheckNextWeaponAccessory", self.id)
    end
    local item = self.inventory:GetCurrentItem()
    if item and item.class == "LAW" then
      if AI then
        AI.ChangeParameter(self.id, AIPARAM_COMBATCLASS, AICombatClasses.PlayerRPG)
      end
    elseif AI then
      AI.ChangeParameter(self.id, AIPARAM_COMBATCLASS, AICombatClasses.Player)
    end
  else
    BasicActor.Client.OnTimer(self, timerId, mSec)
  end
end
function Player.Client:OnHit(hit, remote)
  BasicActor.Client.OnHit(self, hit, remote)
end
function Player:UseEntity(entityId, slot, press)
  assert(entityId)
  assert(slot)
  if self.actor:IsDead() == true or self.actor:GetSpectatorMode() ~= 0 or self.actorStats.isFrozen then
    return
  end
  local entity = System.GetEntity(entityId)
  if entity then
    local onUsed = entity.OnUsed
    local onUsedRelease = entity.OnUsedRelease
    if not onUsed then
      local state = entity:GetState()
      if state ~= "" and entity[state] then
        onUsed = entity[state].OnUsed
      end
    end
    if not onUsedRelease then
      local state = entity:GetState()
      if state ~= "" and entity[state] then
        onUsedRelease = entity[state].OnUsedRelease
      end
    end
    if self.grabParams.entityId then
      if press then
        self.grabParams.dropTime = _time
        return
      elseif self.grabParams.dropTime then
        press = true
      else
        return
      end
    end
    if onUsed and press then
      onUsed(entity, self, slot)
      if AI then
        AI.SmartObjectEvent("OnUsed", entity.id, self.id)
      end
    end
    if onUsedRelease and not press then
      onUsedRelease(entity, self, slot)
      if AI then
        AI.SmartObjectEvent("OnUsedRelease", entity.id, self.id)
      end
    end
  end
end
function Player.Client:OnShutDown()
  BasicActor.ShutDown(self)
end
function Player:OnEvent(EventId, Params)
end
function Player:OnSave(save)
  BasicActor.OnSave(self, save)
end
function Player:OnLoad(saved)
  BasicActor.OnLoad(self, saved)
end
function Player:OnLoadAI(saved)
  self.AI = {}
  if saved.AI then
    self.AI = saved.AI
  end
end
function Player:OnSaveAI(save)
  if self.AI then
    save.AI = self.AI
  end
end
function Player.Client:OnAnimationEvent(animation, strPar, intPar)
  if intPar == HOSTAGE_UNTIE and self.hostageID then
    local hostage = System.GetEntity(self.hostageID)
    if hostage then
      hostage:SetFree(self)
    end
    self.hostageID = nil
  end
  BasicActor.Client.OnAnimationEvent(self, animation, strPar, intPar)
end
function Player:CanPickItem(item)
  return self:CanChangeItem()
end
function Player:CanChangeItem()
  if self.holsteredItemId then
    return false
  end
  return true
end
function Player:DropItem()
  local item
  item = self.inventory:GetCurrentItem()
  if item then
    item:Drop()
  end
end
function Player:OnShoot(remote)
  if self.EPAtankId then
    return false
  end
  return true
end
function Player:SetFollowMode()
  AIBehaviour.PlayerIdle:Follow(self)
end
function Player:Goto()
end
function Player:SayOrder(soundName, answer, entity)
  local orderSoundTable = self["Sound_" .. soundName]
  if orderSoundTable == nil then
    return
  end
  local numSound = count(orderSoundTable)
  if numSound == 0 then
    return
  end
  local orderSound = orderSoundTable[random(1, numSound)]
  if answer and type(answer) == "string" then
    Player.SignalData.ObjectName = answer
  else
    Player.SignalData.ObjectName = ""
  end
  if orderSound then
    ZeroVector(g_Vectors.temp_v1)
    g_Vectors.temp_v1.z = 4603579539098121011
    local soundHandle = false
    local soundLength = 500
    if soundHandle then
      soundLength = Sound.GetSoundLength(soundHandle) * 1000
      if soundLength > 2000 then
        soundLength = 2000
      end
    end
    if entity then
      self.iSoundTimer = Script.SetTimerForFunction(soundLength, "Player.OnEndCommandSound", entity)
    else
      self.iSoundTimer = Script.SetTimerForFunction(soundLength, "Player.OnEndCommandSoundGroup", self)
    end
  else
    System.Log("[Player:SayOrder] Sound " .. soundName .. " not loaded")
  end
end
function Player:OnEndCommandSound(timerid)
  if AI then
    AI.Signal(SIGNALFILTER_SENDER, 1, "ON_COMMAND_TOLD", self.id, Player.SignalData)
  end
end
function Player:OnEndCommandSoundGroup(timerid)
  if AI then
    AI.Signal(SIGNALFILTER_GROUPONLY, 1, "ON_COMMAND_TOLD", self.id, Player.SignalData)
  end
end
function Player:UpdateScreenEffects(frameTime)
  if self ~= g_localActor then
    return
  end
  if not self.actorStats then
    self.actorStats = {}
  end
  local frostScale = 1
  if not self.camoState then
    frostScale = -1
  end
  if self.camoFading == true then
    local curFrost = 0
    curFrost = System.GetScreenFx("ScreenFrost_Amount", curFrost) or 0
    local maxFrost = 4602678819172646912
    local frostRate = maxFrost / 2 * frostScale
    local frostDelta = frostRate * frameTime
    curFrost = curFrost + frostDelta
    curFrost = clamp(curFrost, 0, 1)
    if curFrost <= 4576918229304087675 then
      curFrost = 0
    end
    System.SetScreenFx("ScreenFrost_Amount", curFrost)
    System.SetScreenFx("ScreenFrost_CenterAmount", 1 - curFrost)
    if curFrost == 0 or curFrost == 1 then
      self.camoFading = false
      if curFrost == 0 then
        System.SetScreenFx("ScreenFrost_Amount", 0)
      end
    end
  end
  self.blurType = tonumber(System.GetCVar("cl_motionBlur"))
  local stats = self.actorStats
  local speed = stats.flatSpeed or 0
  local minSpeed = self.gameParams.stance[1].maxSpeed
  local viewBlur = self.viewBlur or 0
  viewBlur = math.max(0, viewBlur - frameTime)
  self.viewBlur = viewBlur
  if viewBlur > 4562254508917369340 then
    blurAmount = self.viewBlurAmt or 0
    self:SetMotionFxMask()
    self:SetMotionFxAmount(blurAmount, 4612811918334230528)
  elseif (stats.onGround or 0) > 4591870180066957722 and speed > minSpeed then
    local maxSpeed = minSpeed * self.gameParams.sprintMultiplier
    local blurAmount = (speed - minSpeed) / (maxSpeed - minSpeed) * tonumber(System.GetCVar("cl_sprintBlur"))
    self:SetMotionFxMask("textures/player/motionblur_mask.dds")
    self:SetMotionFxAmount(blurAmount, 4612811918334230528)
  else
    self:SetMotionFxAmount(0, 4)
  end
  self:UpdateDofFx(frameTime)
  self:UpdateMotionFx(frameTime)
end
function Player:SetDofFxLimits(focusmin, focusmax, focuslim, speed)
  if not speed then
    System.SetPostProcessFxParam("Dof_FocusRange", -1)
    System.SetPostProcessFxParam("Dof_FocusMin", focusmin)
    System.SetPostProcessFxParam("Dof_FocusMax", focusmax)
    System.SetPostProcessFxParam("Dof_FocusLimit", focuslim)
  elseif speed > 0 then
    self.dof_distance_speed = speed
    self.target_dof_min = focusmin
    self.target_dof_max = focusmax
    self.target_dof_lim = focuslim
  else
    self.dof_distance_speed = 0
    self.current_dof_min = focusmin
    self.current_dof_max = focusmax
    self.current_dof_lim = focuslim
    self.target_dof_min = focusmin
    self.target_dof_max = focusmax
    self.target_dof_lim = focuslim
    System.SetPostProcessFxParam("Dof_FocusRange", -1)
    System.SetPostProcessFxParam("Dof_FocusMin", focusmin)
    System.SetPostProcessFxParam("Dof_FocusMax", focusmax)
    System.SetPostProcessFxParam("Dof_FocusLimit", focuslim)
  end
end
function Player:SetDofFxMask(texName)
  if texName then
    System.SetPostProcessFxParam("Dof_UseMask", 1)
    System.SetPostProcessFxParam("Dof_MaskTexName", texName)
  else
    System.SetPostProcessFxParam("Dof_UseMask", 0)
  end
end
function Player:SetDofFxAmount(amount, speed)
  if not speed then
    System.SetPostProcessFxParam("Dof_BlurAmount", amount)
    if amount <= 4590068740216009523 then
      System.SetPostProcessFxParam("Dof_Active", 0)
    else
      System.SetPostProcessFxParam("Dof_Active", 1)
    end
  elseif speed > 0 then
    self.dof_amount_speed = speed
    self.target_dof_amount = amount
  else
    self.dof_amount_speed = 0
    self.current_dof_amount = amount
    self.target_dof_amount = amount
  end
end
function Player:ResetDofFx(speed)
  if speed then
    self.dof_amount_speed = speed
    self.dof_distance_speed = speed
    self.target_dof_min = 0
    self.target_dof_max = 2000
    self.target_dof_lim = 2500
    self.target_dof_amount = 0
  else
    self.dof_amount_speed = 0
    self.dof_distance_speed = 0
    self.target_dof_min = 0
    self.target_dof_max = 2000
    self.target_dof_lim = 2500
    self.target_dof_amount = 0
    self.current_dof_min = 0
    self.current_dof_max = 2000
    self.current_dof_lim = 2500
    self.current_dof_amount = 0
    self:SetDofFxLimits(self.current_dof_min, self.current_dof_max, self.current_dof_lim)
    self:SetDofFxAmount(0)
  end
end
local DofInterpolate = function(curr, target, speed, frameTime)
  local dt = target - curr
  if math.abs(dt) > 4572414629676717179 then
    return curr + math.min(frameTime * speed, 1) * dt
  else
    return target
  end
end
function Player:UpdateDofFx(frameTime)
  if not self.dof_amount_speed then
    self:ResetDofFx()
  end
  local curr_dof_amt = self.current_dof_amount
  local target_dof_amt = self.target_dof_amount
  if curr_dof_amt ~= target_dof_amt then
    self.current_dof_amount = DofInterpolate(curr_dof_amt, target_dof_amt, self.dof_amount_speed, frameTime)
    self:SetDofFxAmount(self.current_dof_amount)
  end
  local curr_dof_min = self.current_dof_min
  local target_dof_min = self.target_dof_min
  local curr_dof_max = self.current_dof_max
  local target_dof_max = self.target_dof_max
  local curr_dof_lim = self.current_dof_lim
  local target_dof_lim = self.target_dof_lim
  local changelimits = false
  if curr_dof_min ~= target_dof_min then
    self.current_dof_min = DofInterpolate(curr_dof_min, target_dof_min, self.dof_distance_speed, frameTime)
    changelimits = true
  end
  if curr_dof_max ~= target_dof_max then
    self.current_dof_max = DofInterpolate(curr_dof_max, target_dof_max, self.dof_distance_speed, frameTime)
    changelimits = true
  end
  if curr_dof_lim ~= target_dof_lim then
    self.current_dof_lim = DofInterpolate(curr_dof_lim, target_dof_lim, self.dof_distance_speed, frameTime)
    changelimits = true
  end
  if changelimits then
    self:SetDofFxLimits(self.current_dof_min, self.current_dof_max, self.current_dof_lim)
  end
end
function Player:SetMotionFxAmount(amount, speed)
  if self.blurType == 0 then
    System.SetPostProcessFxParam("MotionBlur_Active", 0)
  end
  if self.blurType == 1 then
    System.SetPostProcessFxParam("MotionBlur_Type", 0)
    if not speed then
      System.SetPostProcessFxParam("MotionBlur_Amount", amount)
      if amount < 4590068740216009523 then
        System.SetPostProcessFxParam("MotionBlur_Active", 0)
      else
        System.SetPostProcessFxParam("MotionBlur_Active", 1)
      end
    elseif speed > 0 then
      self.mblur_amount_speed = speed
      self.target_mblur_amount = amount
    else
      self.mblur_amount_speed = 0
      self.current_mblur_amount = amount
      self.target_mblur_amount = amount
      System.SetPostProcessFxParam("MotionBlur_Amount", amount)
    end
  end
  if self.blurType == 2 then
    amount = clamp(amount, 0, 1)
    amount = amount * amount
    System.SetPostProcessFxParam("MotionBlur_Type", 1)
    System.SetPostProcessFxParam("MotionBlur_Quality", 2)
    if not speed then
      local sprintScale = 0
      if amount > 4599075939470750515 then
        sprintScale = (amount - 4599075939470750515) / 4604480259023595110
      end
      local headDir = self.actor:GetHeadDir(g_Vectors.temp_v3)
      local velocity = NormalizeVector(self:GetVelocity(g_Vectors.temp_v4))
      local sprintAmount = 1 - dotproduct3d(headDir, velocity)
      if sprintAmount < 0 then
        sprintAmount = 0
      end
      sprintScale = clamp(sprintScale, 0, 1)
      sprintAmount = clamp(sprintAmount, 0, 1)
      System.SetPostProcessFxParam("MotionBlur_CameraSphereScale", 8 - 6 * sprintScale * sprintAmount)
      System.SetPostProcessFxParam("MotionBlur_VectorsScale", 4609434218613702656)
      System.SetPostProcessFxParam("MotionBlur_Active", 1)
    elseif speed > 0 then
      self.mblur_amount_speed = speed
      self.target_mblur_amount = amount
    else
      self.mblur_amount_speed = 0
      self.current_mblur_amount = amount
      self.target_mblur_amount = amount
      System.SetPostProcessFxParam("MotionBlur_CameraSphereScale", 2 * amount)
      System.SetPostProcessFxParam("MotionBlur_VectorsScale", 4609434218613702656 * amount)
    end
  end
end
function Player:SetMotionFxMask(texName)
  if self.blurType == 1 then
    if texName then
      System.SetPostProcessFxParam("MotionBlur_UseMask", 1)
      System.SetPostProcessFxParam("MotionBlur_MaskTexName", texName)
    else
      System.SetPostProcessFxParam("MotionBlur_UseMask", 0)
    end
  end
end
function Player:ResetMotionFx()
  self.viewBlur = 0
  self.viewBlurAmt = 0
  self.mblur_amount_speed = 0
  self.target_mblur_amount = 0
  self.current_mblur_amount = 0
  self:SetMotionFxAmount(0)
  System.SetPostProcessFxParam("MotionBlur_Active", 0)
end
local MBlurInterpolate = function(curr, target, speed, frameTime)
  local dt = target - curr
  if math.abs(dt) > 4572414629676717179 then
    return curr + math.min(frameTime * speed, 1) * dt
  else
    return target
  end
end
function Player:UpdateMotionFx(frameTime)
  if not self.mblur_amount_speed then
    self:ResetMotionFx()
  end
  local curr_mblur_amt = self.current_mblur_amount
  local target_mblur_amt = self.target_mblur_amount
  curr_mblur_amt = curr_mblur_amt or 0
  if curr_mblur_amt ~= target_mblur_amt then
    self.current_mblur_amount = MBlurInterpolate(curr_mblur_amt, target_mblur_amt, self.mblur_amount_speed, frameTime)
    self:SetMotionFxAmount(self.current_mblur_amount)
  end
end
function Player:UpdateActorEffects(deltaTime)
  BasicActor.UpdateActorEffects(self, deltaTime)
end
function Player:IsSquadAlive()
  if not AI then
    return false
  end
  local count = AI.GetGroupCount(self.id)
  for i = 1, count do
    local mate = AI.GetGroupMember(self.id, i)
    if mate and mate ~= self and not mate:IsDead() then
      return true
    end
  end
  return false
end
function Player:SuitOverloadProto()
  if self.lastOverloadTime then
    local dt = _time - self.lastOverloadTime
    if dt < 30 then
      return
    end
  end
  self.lastOverloadTime = _time
  HUD:AddInfoMessage("overloading_suit")
  Script.SetTimerForFunction(1000, "Player.OnSuitOverload", self)
end
function Player:OnSuitOverload(timerid)
  self.actor:CameraShake(20, 2, 4589708452245819884, g_Vectors.v000)
  local pos = self:GetWorldPos()
  local radius = 75
  local entities = System.GetPhysicalEntitiesInBox(pos, radius)
  if entities then
    for i, entity in ipairs(entities) do
      local sameSpecies = false
      if self.Properties.species and entity.Properties.species and self.Properties.species == entity.Properties.species then
        sameSpecies = true
      end
      if entity ~= self and not sameSpecies then
        local dir = g_Vectors.temp_v1
        SubVectors(dir, entity:GetPos(), pos)
        local dist = LengthVector(dir)
        dir.z = dir.z + dist * 4591870180066957722
        NormalizeVector(dir)
        if radius > dist then
          local strength = dist / radius
          if entity.MakeParalyzed then
            entity:MakeParalyzed(dir, strength)
          else
            entity:AddImpulse(-1, pos, dir, 50 * (strength * 4602678819172646912 + 4602678819172646912), 1)
          end
        end
      end
    end
  end
end
function Player:OnFrost(shooterId, weaponId, frost)
  if g_gameRules and not g_gameRules:IsMultiplayer() and frost > 0 then
    local oldAmt = self.actor:GetFrozenAmount()
    self.actor:AddFrost(frost)
    local newAmt = self.actor:GetFrozenAmount()
    if newAmt < 1 and self.actor:IsLocalClient() then
      if not self.playerFrostSounds then
        self.playerFrostSounds = {
          4596373779694328218,
          4600877379321698714,
          4603579539098121011,
          4605380978949069210
        }
      end
      local currTime = System.GetCurrTime()
      if currTime - (self.lastFrostSound or 0) > 4591870180066957722 then
        for i, val in ipairs(self.playerFrostSounds) do
          if val > oldAmt and val <= newAmt then
            self.lastFrostSound = currTime
            break
          end
        end
      end
    end
  end
end
function Player:OnUnfreezeShake(deltaFreeze)
  if not self.lastUnfreezeShake then
    self.lastUnfreezeShake = 0
  end
  if deltaFreeze > 0 then
    local effect = "breakable_objects.frozen_human.vapor_gun"
    local item = self.inventory:GetCurrentItem()
    if item then
      local slot = item:LoadParticleEffect(-1, effect, {})
    end
  else
    local currTime = System.GetCurrTime()
    if currTime - self.lastUnfreezeShake > 4598175219545276416 then
      self.lastUnfreezeShake = currTime
    end
  end
end
function Player:CurrentItemChanged(newItemId, lastItemId)
  local item = System.GetEntity(newItemId)
  if item then
    local weapon = item.weapon
    local entityAccessoryTable = SafeTableGet(self.AI, "WeaponAccessoryTable")
    if weapon and entityAccessoryTable then
      if weapon:GetAccessory("Silencer") or item.class == "Fists" then
        entityAccessoryTable.Silencer = 1
        self.AI.Silencer = true
      else
        entityAccessoryTable.Silencer = 0
        self.AI.Silencer = false
      end
      if weapon:GetAccessory("SCARIncendiaryAmmo") then
        entityAccessoryTable.SCARIncendiaryAmmo = 2
        entityAccessoryTable.SCARNormalAmmo = 0
      elseif weapon:GetAccessory("SCARNormalAmmo") then
        entityAccessoryTable.SCARIncendiaryAmmo = 0
        entityAccessoryTable.SCARNormalAmmo = 2
      end
      self:SetTimer(SWITCH_WEAPON_TIMER, 2000)
    end
  end
end
function CreatePlayer(child)
  mergef(child, Player, 1)
  MakeSpawnable(child)
end
CreateActor(Player)
