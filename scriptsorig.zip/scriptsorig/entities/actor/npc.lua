Script.ReloadScript("SCRIPTS/Entities/actor/BasicActor.lua")
Script.ReloadScript("SCRIPTS/Entities/AI/Shared/BasicAI.lua")
npc = {
  Server = {},
  Client = {},
  PropertiesInstance = {},
  Properties = {},
  AnimationGraph = "monster_full_body.xml",
  UpperBodyGraph = "monster_upper_body.xml",
  ActorTemplate = {
    modelType = "actor",
    colliderEnergyScale = 10,
    colliderRagdollScale = 150,
    Properties = {aicharacter_character = "unknown", preferredCombatDistance = 20},
    PropertiesInstance = {aibehavior_behaviour = "unknown"},
    gameParams = {
      inertia = 30,
      inertiaAccel = 0,
      stance = {
        {stanceId = STANCE_STAND, maxSpeed = 12},
        {stanceId = STANCE_RELAXED, maxSpeed = 12}
      }
    },
    AIMovementAbility = {
      pathFindPrediction = 4602678819172646912,
      allowEntityClampingByAnimation = 1,
      usePredictiveFollowing = 1,
      pathSpeedLookAheadPerSpeed = -4613937818241073152,
      cornerSlowDown = 4604930618986332160,
      velDecay = 4602678819172646912,
      faceTargetInstantlyOnStrafing = false,
      lookIdleTurnSpeed = -1,
      lookCombatTurnSpeed = -1,
      aimTurnSpeed = -1,
      fireTurnSpeed = -1,
      directionalScaleRefSpeedMin = 1,
      directionalScaleRefSpeedMax = 8,
      AIMovementSpeeds = {
        Relaxed = {
          Slow = {
            4610785298501913805,
            4610785298501913805,
            4610785298501913805
          },
          Walk = {
            4610785298501913805,
            4610785298501913805,
            4610785298501913805
          },
          Run = {
            4617765877924338074,
            4617765877924338074,
            4617765877924338074
          },
          Sprint = {
            4617765877924338074,
            4617765877924338074,
            4617765877924338074
          }
        },
        Combat = {
          Slow = {
            4610785298501913805,
            4610785298501913805,
            4610785298501913805
          },
          Walk = {
            4610785298501913805,
            4610785298501913805,
            4610785298501913805
          },
          Run = {
            4617765877924338074,
            4617765877924338074,
            4617765877924338074
          },
          Sprint = {
            4617765877924338074,
            4617765877924338074,
            4617765877924338074
          }
        },
        Crouch = {
          Slow = {
            4610785298501913805,
            4610785298501913805,
            4610785298501913805
          },
          Walk = {
            4610785298501913805,
            4610785298501913805,
            4610785298501913805
          },
          Run = {
            4617765877924338074,
            4617765877924338074,
            4617765877924338074
          },
          Sprint = {
            4617765877924338074,
            4617765877924338074,
            4617765877924338074
          }
        },
        Stealth = {
          Slow = {
            4610785298501913805,
            4610785298501913805,
            4610785298501913805
          },
          Walk = {
            4610785298501913805,
            4610785298501913805,
            4610785298501913805
          },
          Run = {
            4617765877924338074,
            4617765877924338074,
            4617765877924338074
          },
          Sprint = {
            4617765877924338074,
            4617765877924338074,
            4617765877924338074
          }
        },
        Prone = {
          Slow = {
            4610785298501913805,
            4610785298501913805,
            4610785298501913805
          },
          Walk = {
            4610785298501913805,
            4610785298501913805,
            4610785298501913805
          },
          Run = {
            4617765877924338074,
            4617765877924338074,
            4617765877924338074
          },
          Sprint = {
            4617765877924338074,
            4617765877924338074,
            4617765877924338074
          }
        },
        Swim = {
          Slow = {
            4610785298501913805,
            4610785298501913805,
            4610785298501913805
          },
          Walk = {
            4610785298501913805,
            4610785298501913805,
            4610785298501913805
          },
          Run = {
            4617765877924338074,
            4617765877924338074,
            4617765877924338074
          },
          Sprint = {
            4617765877924338074,
            4617765877924338074,
            4617765877924338074
          }
        }
      }
    }
  }
}
function npc.ActorTemplate:Kill(ragdoll, shooterId, weaponId, freeze)
  BasicActor.Kill(self, false, shooterId, weaponId, freeze)
  return true
end
function npc.ActorTemplate:HealthChanged()
  BasicActor.HealthChanged(self)
  if self.actor:IsDead() == true then
    return
  end
  self.actor:SetAnimationInput("Signal", "wound", true)
end
CreateActor(npc.ActorTemplate)
CreateAILite(npc.ActorTemplate)
function npc:Create(name, srcActor)
  local instance = {
    AIMovementAbility = {},
    gameParams = {}
  }
  if srcActor.AIMovementAbility then
    mergef(instance.AIMovementAbility, srcActor.AIMovementAbility, 1)
  end
  if srcActor.gameParams then
    mergef(instance.gameParams, srcActor.gameParams, 1)
  end
  mergef(instance, npc.ActorTemplate, 1)
  instance.Properties.fileModel = srcActor.Properties.fileModel
  instance.Properties.clientFileModel = srcActor.Properties.clientFileModel
  if srcActor.AnimationGraph then
    instance.AnimationGraph = srcActor.AnimationGraph
  end
  if srcActor.UpperBodyGraph then
    instance.UpperBodyGraph = srcActor.UpperBodyGraph
  end
  _G[name] = instance
end
