Script.ReloadScript("SCRIPTS/Entities/actor/BasicActor.lua")
Script.ReloadScript("SCRIPTS/Entities/AI/Shared/BasicAI.lua")
WanderingPieceColossus_x = {
  colliderEnergyScale = 10,
  colliderRagdollScale = 150,
  AnimationGraph = "monster_full_body.xml",
  UpperBodyGraph = "",
  Properties = {
    voiceType = "enemy",
    fileModel = "Objects/Characters/monster/wandering_piece_colossus/wandering_piece_colossus.chr",
    aicharacter_character = "Orc",
    Damage = {
      bNoGrab = 0,
      bNoDeath = 0,
      FallPercentage = 0,
      FallSleepTime = 2
    },
    distanceToHideFrom = 3,
    preferredCombatDistance = 20
  },
  PropertiesInstance = {aibehavior_behaviour = "OrcIdle"},
  gameParams = {
    inertia = 0,
    inertiaAccel = 0,
    backwardMultiplier = 4602678819172646912
  },
  AIMovementAbility = {
    pathFindPrediction = 4602678819172646912,
    allowEntityClampingByAnimation = 1,
    usePredictiveFollowing = 1,
    walkSpeed = 2,
    runSpeed = 4,
    sprintSpeed = 4618891777831180698,
    b3DMove = 0,
    pathLookAhead = 1,
    pathRadius = 4600877379321698714,
    pathSpeedLookAheadPerSpeed = -4613937818241073152,
    cornerSlowDown = 4604930618986332160,
    maxAccel = 3,
    maxDecel = 8,
    maneuverSpeed = 4609434218613702656,
    velDecay = 4602678819172646912,
    minTurnRadius = 0,
    maxTurnRadius = 3,
    maneuverTrh = 2,
    resolveStickingInTrace = 1,
    pathRegenIntervalDuringTrace = 4,
    lightAffectsSpeed = 1,
    lookIdleTurnSpeed = 30,
    lookCombatTurnSpeed = 50,
    aimTurnSpeed = -1,
    fireTurnSpeed = -1,
    directionalScaleRefSpeedMin = 1,
    directionalScaleRefSpeedMax = 8,
    AIMovementSpeeds = {
      Relaxed = {
        Slow = {
          1,
          1,
          4611235658464650854
        },
        Walk = {
          4608533498688228557,
          1,
          4611235658464650854
        },
        Run = {
          4616752568008179712,
          2,
          4619792497756654797
        }
      },
      Combat = {
        Slow = {
          4605380978949069210,
          4605380978949069210,
          4608533498688228557
        },
        Walk = {
          4608533498688228557,
          4605380978949069210,
          4608533498688228557
        },
        Run = {
          4616752568008179712,
          4612361558371493478,
          6
        },
        Sprint = {
          4619004367821864960,
          4612361558371493478,
          4619004367821864960
        }
      },
      Crouch = {
        Slow = {
          4602678819172646912,
          4599075939470750515,
          4608533498688228557
        },
        Walk = {
          4606281698874543309,
          4599075939470750515,
          4608533498688228557
        },
        Run = {
          4615063718147915776,
          4613262278296967578,
          4617878467915022336
        }
      },
      Stealth = {
        Slow = {
          4605380978949069210,
          4604480259023595110,
          1
        },
        Walk = {
          4606281698874543309,
          4604480259023595110,
          1
        },
        Run = {
          4615063718147915776,
          4613262278296967578,
          4617878467915022336
        }
      },
      Prone = {
        Slow = {
          4600877379321698714,
          4600877379321698714,
          4602678819172646912
        },
        Walk = {
          4602678819172646912,
          4600877379321698714,
          4602678819172646912
        },
        Run = {
          4602678819172646912,
          4600877379321698714,
          4602678819172646912
        }
      },
      Swim = {
        Slow = {
          4602678819172646912,
          4603579539098121011,
          4604480259023595110
        },
        Walk = {
          4603579539098121011,
          4603579539098121011,
          4604480259023595110
        },
        Run = {
          3,
          4613712638259704627,
          4616527388026811187
        }
      }
    }
  },
  AI_changeCoverLastTime = 0,
  AI_changeCoverInterval = 7
}
function WanderingPieceColossus_x:Kill(ragdoll, shooterId, weaponId, freeze)
  BasicActor.Kill(self, false, shooterId, weaponId, freeze)
  return true
end
function WanderingPieceColossus_x:HealthChanged()
  BasicActor.HealthChanged(self)
  if self.actor:IsDead() == true then
    return
  end
  self.actor:SetAnimationInput("Signal", "wound", true)
end
CreateActor(WanderingPieceColossus_x)
WanderingPieceColossus = CreateAI(WanderingPieceColossus_x)
