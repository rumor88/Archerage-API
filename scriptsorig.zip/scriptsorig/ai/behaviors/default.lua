AIBehaviour.DEFAULT = {
  Name = "DEFAULT",
  OnUseSmartObject = function(self, entity, sender, extraData)
    AI.ExecuteAction(extraData.ObjectName, entity.id, sender.id, extraData.iValue)
  end,
  ABORT_ALL_ACTIONS = function(self, entity)
    AI.AbortAction(entity.id)
  end,
  OnReinforcementRequested = function(self, entity, sender, extraData)
    local pos = {}
    AI.GetBeaconPosition(extraData.id, pos)
    AI.SetBeaconPosition(entity.id, pos)
    AI.Signal(SIGNALFILTER_SENDER, 1, "GO_TO_SEEK", entity.id, sender.id)
  end,
  SignalToNearestDirectional = function(self, entity, signal)
    local nearest = entity:GetNearestInGroup()
    if nearest then
      local dir = {}
      FastDifferenceVectors(dir, nearest:GetWorldPos(), entity:GetWorldPos())
      local x = dotproduct3d(entity:GetDirectionVector(0), dir)
      local y = dotproduct3d(entity:GetDirectionVector(1), dir)
      if x <= y and y >= -x then
        AI.Signal(SIGNALID_READIBILITY, 1, signal .. "_FRONT", entity.id)
      elseif x > y and x > -y then
        AI.Signal(SIGNALID_READIBILITY, 1, signal .. "_LEFT", entity.id)
      elseif x < y and x < -y then
        AI.Signal(SIGNALID_READIBILITY, 1, signal .. "_RIGHT", entity.id)
      else
        AI.Signal(SIGNALID_READIBILITY, 1, signal .. "_BACK", entity.id)
      end
    end
  end,
  SignalToNearest_InPosition = function(self, entity, sender)
    self:SignalToNearestDirectional(entity, "IN_POSITION")
  end,
  OnQueryUseObject = function(self, entity, sender, extraData)
  end,
  OnExplosionDanger = function(self, entity, sender, data)
    if data and data.id ~= NULL_ENTITY then
      entity:InsertSubpipe(0, "backoff_from_explosion", data.id)
    end
  end,
  SHARED_USE_THIS_MOUNTED_WEAPON = function(self, entity)
    local weapon = entity.AI.current_mounted_weapon
    if entity:GetDistance(weapon.id) < 3 then
      entity:HolsterItem(true)
      local mwitem = entity.AI.current_mounted_weapon.item
      if mwitem and not mwitem:IsUsed() then
        mwitem:StartUse(entity.id)
      end
      weapon.listPotentialUsers = nil
    else
      AI.Signal(SIGNALFILTER_SENDER, 1, "TOO_FAR_FROM_WEAPON", entity.id)
      entity:DrawWeaponNow()
    end
    entity.AI.approachingMountedWeapon = false
    local targettype = AI.GetTargetType(entity.id)
    if targettype == AITARGET_ENEMY then
      entity:SelectPipe(0, "fire_mounted_weapon")
    else
      entity:SelectPipe(0, "mounted_weapon_look_around")
    end
  end,
  LOOK_AT_MOUNTED_WEAPON_DIR = function(self, entity, sender)
    local pos = g_Vectors.temp
    local weapon = entity.AI.current_mounted_weapon
    if weapon == nil then
      AI.LogEvent("WARNING: weapon is nil in LOOK_AT_MOUNTED_WEAPON_DIR for " .. entity:GetName())
    else
      FastSumVectors(pos, weapon:GetPos(), weapon.item:GetMountedDir())
      FastSumVectors(pos, pos, weapon.item:GetMountedDir())
      AI.SetRefPointPosition(entity.id, pos)
      AI.SetRefPointDirection(entity.id, weapon.item:GetMountedDir())
      local targetType = AI.GetTargetType(entity.id)
      AI.Signal(SIGNALFILTER_SENDER, 1, "SHARED_USE_THIS_MOUNTED_WEAPON", entity.id)
    end
  end,
  SET_MOUNTED_WEAPON_PERCEPTION = function(self, entity, sender)
    local perceptionTable = entity.Properties.Perception
    local newSightRange = perceptionTable.sightrange * 2
    AI.ChangeParameter(entity.id, AIPARAM_ACCURACY, 1)
    AI.ChangeParameter(entity.id, AIPARAM_SIGHTRANGE, newSightRange)
    AI.ChangeParameter(entity.id, AIPARAM_ATTACKRANGE, newSightRange)
    AI.ChangeParameter(entity.id, AIPARAM_FOVSECONDARY, perceptionTable.FOVPrimary)
  end,
  MOUNTED_WEAPON_USABLE = function(self, entity, sender, data)
    local weapon = System.GetEntity(data.id)
    local curWeapon = entity.inventory:GetCurrentItem()
    if curWeapon and curWeapon.class == "LAW" then
      weapon = nil
    end
    if weapon and weapon.item == nil then
      AI.LogEvent("trying to use " .. weapon:GetName() .. " as weapon. Please check SO class")
      weapon = nil
    end
    if weapon and AI.IsMountedWeaponUsableWithTarget(entity.id, weapon.id, 7, entity.AI.SkipTargetCheck) then
      weapon.reserved = entity
      entity.AI.current_mounted_weapon = weapon
      local parent = weapon:GetParent()
      if parent and parent.vehicle then
        g_SignalData.fValue = mySeat
        g_SignalData.id = parent.id
        g_SignalData.iValue2 = 0
        g_SignalData.iValue = -148
        AI.Signal(SIGNALFILTER_SENDER, 1, "ACT_ENTERVEHICLE", entity.id, g_SignalData)
      else
        AI.Signal(SIGNALFILTER_SENDER, 0, "USE_MOUNTED_WEAPON", entity.id)
      end
      AI.ModifySmartObjectStates(entity.id, "Busy")
    else
      if weapon then
        AI.ModifySmartObjectStates(weapon.id, "Idle,-Busy")
      end
      AI.ModifySmartObjectStates(entity.id, "-Busy")
    end
  end,
  ORDER_HIDE = function(self, entity, sender, data)
    AI.SetRefPointPosition(entity.id, data.point)
  end,
  ORDER_SEARCH = function(self, entity, sender, data)
    AI.SetRefPointPosition(entity.id, data.point)
  end,
  HIDE_FROM_BEACON = function(self, entity, sender)
    entity:InsertSubpipe(0, "hide_from_beacon")
  end,
  DESTROY_THE_BEACON = function(self, entity, sender)
    if entity.cnt.numofgrenades > 0 then
      local rnd = random(1, 4)
      if rnd > 2 then
        entity:InsertSubpipe(0, "shoot_the_beacon")
      else
        entity:InsertSubpipe(0, "bomb_the_beacon")
      end
    else
      entity:InsertSubpipe(0, "shoot_the_beacon")
    end
  end,
  OnFriendInWay = function(self, entity, sender)
  end,
  OnReceivingDamage = function(self, entity, sender)
  end,
  MAKE_ME_IGNORANT = function(self, entity, sender)
    AI.SetIgnorant(entity.id, 1)
  end,
  MAKE_ME_UNIGNORANT = function(self, entity, sender)
    AI.SetIgnorant(entity.id, 0)
  end,
  RETREAT_NOW = function(self, entity, sender)
    local retreat_spot = AI.FindObjectOfType(entity.id, 100, AIAnchorTable.COMBAT_RETREAT_HERE)
    if retreat_spot then
      entity:SelectPipe(0, "retreat_to_spot", retreat_spot)
    else
      entity:SelectPipe(0, "retreat_back")
    end
    entity:Readibility("RETREATING_NOW", 1)
  end,
  RETREAT_NOW_PHASE2 = function(self, entity, sender)
    local retreat_spot = AI.FindObjectOfType(entity.id, 100, AIAnchorTable.COMBAT_RETREAT_HERE)
    if retreat_spot then
      entity:SelectPipe(0, "retreat_to_spot_phase2", retreat_spot)
    else
      entity:SelectPipe(0, "retreat_back_phase2")
    end
    entity:Readibility("RETREATING_NOW", 1)
  end,
  PROVIDE_COVERING_FIRE = function(self, entity, sender)
    entity:SelectPipe(0, "dumb_shoot")
    entity:Readibility("PROVIDING_COVER", 1)
  end,
  RUSH_TARGET = function(self, entity, sender)
    entity:SelectPipe(0, "rush_player")
    entity:Readibility("AI_AGGRESSIVE", 1)
  end,
  STOP_RUSH = function(self, entity, sender)
    entity:TriggerEvent(AIEVENT_CLEAR)
  end,
  START_SWIMMING = function(self, entity, sender)
    AI.SetIgnorant(entity.id, 1)
    entity:SelectPipe(0, "swim_inplace")
    if entity.MUTANT then
      entity:InsertAnimationPipe("drown00", 2, "NOW_DIE", 4594572339843380019, 4605380978949069210)
    else
      local dh = AI.FindObjectOfType(entity:GetPos(), 30, AIAnchorTable.SWIM_HERE)
      if dh then
        entity:InsertSubpipe(0, "swim_to", dh)
      end
    end
  end,
  GO_INTO_WAIT_STATE = function(self, entity, sender)
    entity:SelectPipe(0, "wait_state")
  end,
  SPECIAL_FOLLOW = function(self, entity, sender)
    entity.AI.SpecialBehaviour = "SPECIAL_FOLLOW"
    entity:SelectPipe(0, "val_follow")
    entity:Readibility("FOLLOWING_PLAYER", 1)
    AI.SetIgnorant(entity.id, 0)
  end,
  SPECIAL_GODUMB = function(self, entity, sender)
    entity.AI.SpecialBehaviour = "SPECIAL_GODUMB"
    AI.SetIgnorant(entity.id, 1)
  end,
  SPECIAL_STOPALL = function(self, entity, sender)
    entity.AI.SpecialBehaviour = nil
    entity:SelectPipe(0, "standingthere")
    AI.SetIgnorant(entity.id, 0)
  end,
  SPECIAL_LEAD = function(self, entity, sender)
    entity.AI.SpecialBehaviour = "SPECIAL_LEAD"
    entity:SelectPipe(0, "standingthere")
    entity.LEADING = nil
    entity.EventToCall = "OnCloseContact"
    entity:Readibility("LETS_CONTINUE", 1)
    AI.SetIgnorant(entity.id, 0)
  end,
  SPECIAL_HOLD = function(self, entity, sender)
    entity.AI.SpecialBehaviour = "SPECIAL_HOLD"
    local spot = AI.FindObjectOfType(entity:GetPos(), 50, AIAnchorTable.SPECIAL_HOLD_SPOT)
    if spot == nil then
      Hud:AddMessage("========================== UNACCEPTABLE ERROR ====================")
      Hud:AddMessage("No SPECIAL_HOLD_SPOT anchor for entity " .. entity:GetName())
      Hud:AddMessage("========================== UNACCEPTABLE ERROR ====================")
    end
    entity:SelectPipe(0, "hold_spot", spot)
    AI.SetIgnorant(entity.id, 0)
  end,
  CANNOT_RESUME_SPECIAL_BEHAVIOUR = function(self, entity, sender)
    if entity.AI.SpecialBehaviour then
      entity:Readibility("THERE_IS_STILL_SOMEONE", 1)
    end
  end,
  RESUME_SPECIAL_BEHAVIOUR = function(self, entity, sender)
    if entity.AI.SpecialBehaviour then
      entity:TriggerEvent(AIEVENT_CLEARSOUNDEVENTS)
      AI.Signal(0, 1, entity.AI.SpecialBehaviour, entity.id)
    end
  end,
  AISF_CallForHelp = function(self, entity, sender)
    local guy_should_reinforce = AI.FindObjectOfType(entity.id, 5, AIAnchorTable.COMBAT_RESPOND_TO_REINFORCEMENT)
    if guy_should_reinforce then
      entity:MakeAlerted()
      entity:SelectPipe(0, "cover_beacon_pindown")
      entity:InsertSubpipe(0, "offer_join_team_to", sender.id)
      if not entity.inventory:GetCurrentItemId() then
        entity:DrawWeaponNow()
      end
    end
  end,
  APPLY_IMPULSE_TO_ENVIRONMENT = function(self, entity, sender)
    entity:InsertAnimationPipe("kick_barrel")
    entity.ImpulseParameters.pos = entity:GetPos()
    entity.ImpulseParameters.pos.z = entity.ImpulseParameters.pos.z - 1
    entity:ApplyImpulseToEnvironment(entity.ImpulseParameters)
  end,
  OnRestoreVehicleDanger = function(self, entity)
    entity.AI.avoidingVehicleTime = nil
  end,
  HIDE_END_EFFECT = function(self, entity, sender)
    entity.actor:QueueAnimationState("rollfwd")
  end,
  Smoking = function(self, entity, sender)
    entity.EventToCall = "OnSpawn"
  end,
  YOU_ARE_BEING_WATCHED = function(self, entity, sender)
  end,
  LEFT_LEAN_ENTER = function(self, entity, sender)
    entity:SelectPipe(0, "lean_left_attack")
  end,
  RIGHT_LEAN_ENTER = function(self, entity, sender)
    entity:SelectPipe(0, "lean_right_attack")
  end,
  SWITCH_TO_MORTARGUY = function(self, entity, sender)
  end,
  RETURN_TO_FIRST = function(self, entity, sender)
  end,
  OnDeath = function(self, entity, sender)
  end,
  OnCloseContact = function(self, entity, sender, data)
  end,
  JoinGroup = function(self, entity, sender)
    AI.ChangeParameter(entity.id, AIPARAM_GROUPID, AI.GetGroupOf(sender.id))
    entity:SelectPipe(0, "AIS_LookForThreat")
  end,
  UNCONDITIONAL_JOIN = function(self, entity, sender)
    AI.ChangeParameter(entity.id, AIPARAM_GROUPID, AI.GetGroupOf(sender.id))
  end,
  CONVERSATION_REQUEST = function(self, entity, sender, data)
    AI.LogEvent(entity:GetName() .. " requesting conversation ")
    if sender ~= nil then
      local distance = entity:GetDistance(sender.id)
      if (distance < 8 or distance < 20 and data.fValue == 0) and entity.AI.CurrentConversation == nil then
        sender.ConvPartecipants = sender.ConvPartecipants + 1
        sender.ConvActors[sender.ConvPartecipants] = entity
        if entity == sender then
          entity.AI.ConvInPlace = data.fValue
          entity.AI.ConvType = data.iValue
          entity:InsertSubpipe(0, "gather_conversation_partecipants")
        end
      end
    end
  end,
  START_CONVERSATION = function(self, entity, sender)
    AI.LogEvent(entity:GetName() .. " starting conversation")
    local convType = entity.AI.ConvType
    local conv = AI_ConvManager:GetRandomConversation(entity.ConversationName, entity.AI.ConvType, entity.AI.ConvInPlace, entity.AI.ConvPartecipants)
    if conv ~= nil then
      entity.AI.ConvPartecipants = conv.Participants
      for i = 1, conv.Participants do
        conv:Join(entity.ConvActors[i])
      end
      conv:Start()
      entity.AI.CurrentConversation = conv
    else
      AI.LogEvent(entity:GetName() .. " couldn't start the conversation")
    end
  end,
  OFFER_JOIN_TEAM = function(self, entity, sender)
    if entity ~= sender and AI.GetGroupOf(entity.id) ~= AI.GetGroupOf(sender.id) then
      AI.ChangeParameter(entity.id, AIPARAM_GROUPID, AI.GetGroupOf(sender.id))
    end
  end,
  OnOutOfAmmo = function(self, entity, sender)
    if entity.Reload == nil then
      return
    end
    entity:Reload()
  end,
  SHARED_RELOAD = function(self, entity, sender)
    do return end
    if entity.cnt and entity.cnt.ammo_in_clip and entity.cnt.ammo_in_clip > 5 then
      return
    end
    AI.CreateGoalPipe("reload_timeout")
    AI.PushGoal("reload_timeout", "timeout", 1, entity:GetAnimationLength(0, "reload"))
    entity:InsertSubpipe(0, "reload_timeout")
    entity.actor:QueueAnimationState("reload")
    BasicPlayer.Reload(entity)
  end,
  WPN_SHOOT = function(self, entity, sender)
  end,
  THROW_GRENADE_DONE = function(self, entity, sender)
  end,
  SMART_THROW_GRENADE = function(self, entity, sender)
    if AI_Utils:CanThrowGrenade(entity) == 1 then
      entity:Readibility("throwing_grenade", 1)
      entity:InsertSubpipe(AIGOALPIPE_NOTDUPLICATE, "throw_grenade_execute")
    end
  end,
  SHARED_PLAYLEFTROLL = function(self, entity, sender)
    entity.actor:QueueAnimationState("rollleft")
  end,
  SHARED_PLAYRIGHTROLL = function(self, entity, sender)
    entity.actor:QueueAnimationState("rollright")
  end,
  SHARED_TAKEOUTPIN = function(self, entity, sender)
    entity.actor:QueueAnimationState("signal_inposition")
  end,
  death_recognition = function(self, entity, sender)
    local XRandom = random(1, 3)
    if XRandom == 1 then
      entity.actor:QueueAnimationState("death_recognition1")
    elseif XRandom == 2 then
      entity.actor:QueueAnimationState("death_recognition2")
    elseif XRandom == 3 then
      entity.actor:QueueAnimationState("death_recognition3")
    end
  end,
  PlayRollLeftAnim = function(self, entity, sender)
    entity.actor:QueueAnimationState("rollleft")
  end,
  PlayRollRightAnim = function(self, entity, sender)
    entity.actor:QueueAnimationState("rollright")
  end,
  OnNoAmmo = function(self, entity, sender)
  end,
  OnDamage = function(self, entity, sender, data)
  end,
  DEFAULT_CURRENT_TO_CROUCH = function(self, entity, sender)
  end,
  DEFAULT_CURRENT_TO_PRONE = function(self, entity, sender)
    if entity.cnt.crouching == nil and entity.cnt.proning == nil then
      entity.actor:QueueAnimationState("pgetdown")
    end
  end,
  DEFAULT_CURRENT_TO_STAND = function(self, entity, sender)
    if entity.cnt.proning then
      entity.actor:QueueAnimationState("pgetup")
    end
  end,
  LIGHTS_OFF = function(self, entity, sender)
    AI.ChangeParameter(entity.id, AIPARAM_SIGHTRANGE, 4591870180066957722)
  end,
  LIGHTS_ON = function(self, entity, sender)
    AI.ChangeParameter(entity.id, AIPARAM_SIGHTRANGE, entity.Properties.Perception.sightrange)
  end,
  HIDE_GUN = function(self, entity)
    entity.cnt:DrawThirdPersonWeapon(0)
  end,
  UNHIDE_GUN = function(self, entity)
    entity.cnt:DrawThirdPersonWeapon(1)
  end,
  DO_THREATENED_ANIMATION = function(self, entity, sender)
    do return end
    local rnd = random(1, 3)
    entity:InsertAnimationPipe("_surprise0" .. rnd, 3)
    local anim_dur = entity:GetAnimationLength(0, "_surprise0" .. rnd)
    entity:TriggerEvent(AIEVENT_ONBODYSENSOR, anim_dur)
  end,
  SHARED_PLAY_CURIOUS_ANIMATION = function(self, entity, sender)
    local rnd = random(1, 2)
    entity:InsertAnimationPipe("_curious" .. rnd)
  end,
  DO_SOMETHING_IDLE = function(self, entity, sender)
    if entity:MakeMissionConversation() then
      entity:CheckFlashLight()
      return
    end
    if entity:MakeRandomConversation() then
      entity:CheckFlashLight()
      return
    end
    entity:CheckFlashLight()
  end,
  GOING_TO_TRIGGER = function(self, entity, sender)
    entity.RunToTrigger = 1
    if sender.id == entity.id then
      AI.SetIgnorant(entity.id, 1)
      entity:InsertSubpipe(0, "run_to_trigger", entity.AI.ALARMNAME)
    end
  end,
  THROW_FLARE = function(self, entity, sender)
    if sender.id == entity.id then
      entity:InsertSubpipe(0, "throw_flare")
    end
  end,
  MAKE_STUNNED_ANIMATION = function(self, entity, sender)
    if entity.BLINDED_ANIM_COUNT then
      local rnd = random(0, entity.BLINDED_ANIM_COUNT)
      local anim_name = format("blind%02d", rnd)
      entity:InsertAnimationPipe(anim_name, 4)
      local dur = entity:GetAnimationLength(0, anim_name)
      AI.EnablePuppetMovement(entity.id, 0, dur + 3)
      entity:TriggerEvent(AIEVENT_ONBODYSENSOR, dur + 3)
    else
      Hud:AddMessage("==================UNACCEPTABLE ERROR====================")
      Hud:AddMessage("Entity " .. entity:GetName() .. " tried to make blinded anim, but no blindXX anims for his character.")
      Hud:AddMessage("==================UNACCEPTABLE ERROR====================")
    end
  end,
  FLASHBANG_GRENADE_EFFECT = function(self, entity, sender)
    if entity.ai then
      entity:InsertSubpipe(0, "stunned")
      entity:Readibility("FLASHBANG_GRENADE_EFFECT", 1)
    end
  end,
  SHARED_BLINDED = function(self, entity, sender)
  end,
  SHARED_UNBLINDED = function(self, entity, sender)
    entity.actor:QueueAnimationState("NULL")
  end,
  SHARED_PLAY_GETDOWN_ANIM = function(self, entity, sender)
    local rnd = random(1, 2)
    entity:InsertAnimationPipe("duck" .. rnd .. "_down", 3)
  end,
  SHARED_PLAY_GETUP_ANIM = function(self, entity, sender)
    local rnd = random(1, 2)
    entity:InsertAnimationPipe("duck" .. rnd .. "_up", 3)
  end,
  SHARED_PLAY_DAMAGEAREA_ANIM = function(self, entity, sender)
    local rnd = random(1, 2)
    entity:InsertAnimationPipe("duck" .. rnd .. "_up", 3)
  end,
  exited_vehicle = function(self, entity, sender)
    AI.Signal(0, 1, "OnSpawn", entity.id)
  end,
  select_gunner_pipe = function(self, entity, sender)
    entity:SelectPipe(0, "h_gunner_fire")
  end,
  JOIN_TEAM = function(self, entity, sender)
    AI.LogEvent(entity:GetName() .. " JOINING TEAM")
    entity.AI.InSquad = 1
  end,
  BREAK_TEAM = function(self, entity, sender)
    entity.AI.InSquad = 0
  end,
  SET_REFPOINT_BEHIND_ME = function(self, entity, sender)
    local refPos = g_Vectors.temp
    FastDifferenceVectors(refPos, entity:GetWorldPos(), entity:GetDirectionVector())
    AI.SetRefPointPosition(entity.id, refPos)
  end,
  CHECK_CONVOY = function(self, entity, sender)
    entity:Event_Convoy()
  end,
  PLAY_TALK_ANIMATION = function(self, entity, sender)
    local rnd = math.random(1, 6)
    entity.actor:QueueAnimationState("relaxed_idle_talk_nw_0" .. rnd)
  end,
  PLAY_LISTEN_ANIMATION = function(self, entity, sender)
    local rnd = math.random(1, 3)
    entity.actor:QueueAnimationState("relaxed_idle_listening_0" .. rnd)
  end,
  FOLLOW_LEADER = function(self, entity, sender, data)
    entity.AI.InSquad = 1
    if AI.GetGroupOf(entity.id) == 0 then
      entity.Properties.bSquadMate = 1
    end
    AI.Signal(SIGNALFILTER_LEADER, 10, "OnJoinTeam", entity.id)
  end,
  SHARED_STOP_ANIMATION = function(self, entity, sender)
    entity:StopAnimation(0, 4)
  end,
  SHARED_PICK_UP = function(self, entity, sender, data)
    local entityName = System.GetEntity(data.id):GetName()
    System.Log("Picking up entity '" .. entityName .. "'")
    entity:CreateBoneAttachment(0, "item_hand_right", "equip_hand_right")
    entity:CreateBoneAttachment(0, "weapon_bone", "equip_hand_right")
    entity:SetAttachmentObject(0, "equip_hand_right", data.id, -1, 0)
  end,
  SHARED_DROP = function(self, entity, sender, data)
    entity:ResetAttachment(0, "equip_hand_right")
  end,
  HOLSTERITEM_TRUE = function(self, entity, sender)
    entity:HolsterItem(true)
  end,
  HOLSTERITEM_FALSE = function(self, entity, sender)
    entity:DrawWeaponNow()
  end,
  ORDER_TIMEOUT = function(self, entity, sender, data)
    if data.fValue and data.fValue > 0 then
      g_StringTemp1 = "order_timeout" .. math.floor(data.fValue * 10) / 10
      AI.CreateGoalPipe(g_StringTemp1)
      AI.PushGoal(g_StringTemp1, "timeout", 1, data.fValue)
      AI.PushGoal(g_StringTemp1, "signal", 0, 10, "ORD_DONE", SIGNALFILTER_LEADER)
      entity:InsertSubpipe(0, g_StringTemp1)
    else
      entity:InsertSubpipe(0, "order_timeout")
    end
  end,
  ORDER_ACQUIRE_TARGET = function(self, entity, sender, data)
    if data.id ~= NULL_ENTITY then
      entity:InsertSubpipe(0, "acquire_target", data.id)
    else
      entity:InsertSubpipe(0, "acquire_target", data.ObjectName)
    end
    AI.Signal(SIGNALFILTER_LEADER, 10, "ORD_DONE", entity.id)
  end,
  ORDER_COVER_SEARCH = function(self, entity, sender)
    AI.Signal(SIGNALFILTER_LEADER, 10, "ORD_DONE", entity.id)
  end,
  CORNER = function(self, entity, sender)
    AI.SmartObjectEvent("CORNER", entity.id, sender.id)
  end,
  SetTargetDistance = function(self, entity, dist)
    if dist == nil or dist == 0 then
      AI.SetPFBlockerRadius(entity.id, PFB_ATT_TARGET, 0)
      AI.SetPFBlockerRadius(entity.id, PFB_BEACON, 0)
    else
      local targetDist = AI.GetAttentionTargetDistance(entity.id)
      if targetDist then
        local attDist = math.min(math.max(targetDist - 4591870180066957722, 2), dist)
        AI.SetPFBlockerRadius(entity.id, PFB_ATT_TARGET, attDist)
      else
        AI.SetPFBlockerRadius(entity.id, PFB_BEACON, dist)
      end
    end
  end,
  OnUpdateItems = function(self, entity, sender)
    if entity.inventory:GetItemByClass("LAW") then
      AI.ChangeParameter(entity.id, AIPARAM_COMBATCLASS, AICombatClasses.InfantryRPG)
      AI.LogEvent(entity:GetName() .. " changes his combat class to InfantryRPG on signal OnUpdateItems")
    end
  end,
  UNHIDE = function(self, entity, sender)
    if AI.SmartObjectEvent("Unhide", entity.id) <= 0 then
      entity:InsertSubpipe(0, "shared_unhide")
    end
  end,
  ACT_DUMMY = function(self, entity, sender, data)
    entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_dummy", nil, data.iValue)
  end,
  ACT_EXECUTE = function(self, entity, sender, data)
    if data then
      AI.ExecuteAction(data.ObjectName, entity.id, sender.id, data.fValue, data.iValue)
    else
      AI.ExecuteAction(data.ObjectName, entity.id, entity.id, sender.fValue, sender.iValue)
    end
  end,
  ACT_FOLLOWPATH = function(self, entity, sender, data)
    local pathfind = data.point.x
    local reverse = data.point.y
    local startNearest = data.point.z
    local loops = data.fValue
    g_StringTemp1 = "follow_path"
    if pathfind > 0 then
      g_StringTemp1 = g_StringTemp1 .. "_pathfind"
    end
    if reverse > 0 then
      g_StringTemp1 = g_StringTemp1 .. "_reverse"
    end
    if startNearest > 0 then
      g_StringTemp1 = g_StringTemp1 .. "_nearest"
    end
    AI.CreateGoalPipe(g_StringTemp1)
    AI.PushGoal(g_StringTemp1, "followpath", 1, pathfind, reverse, startNearest, loops)
    AI.PushGoal(g_StringTemp1, "signal", 1, 1, "END_ACT_FOLLOWPATH", 0)
    entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, g_StringTemp1, nil, data.iValue)
  end,
  ACT_GOTO = function(self, entity, sender, data)
    if data and data.point then
      AI.SetRefPointPosition(entity.id, data.point)
      g_StringTemp1 = "action_goto" .. data.fValue
      AI.CreateGoalPipe(g_StringTemp1)
      AI.PushGoal(g_StringTemp1, "locate", 0, "refpoint")
      AI.PushGoal(g_StringTemp1, "+stick", 1, data.point2.x, AILASTOPRES_USE, 1, data.fValue)
      AI.PushGoal(g_StringTemp1, "+branch", 0, "NO_PATH", IF_LASTOP_FAILED)
      AI.PushGoal(g_StringTemp1, "branch", 0, "END", BRANCH_ALWAYS)
      AI.PushLabel(g_StringTemp1, "NO_PATH")
      AI.PushGoal(g_StringTemp1, "signal", 1, 1, "CANCEL_CURRENT", 0)
      AI.PushLabel(g_StringTemp1, "END")
      AI.PushGoal(g_StringTemp1, "signal", 1, 1, "END_ACT_GOTO", 0)
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, g_StringTemp1, nil, data.iValue)
    end
  end,
  CANCEL_CURRENT = function(self, entity)
    entity:CancelSubpipe()
  end,
  ACT_LOOKAT = function(self, entity, sender, data)
    if data and data.point.x ~= 0 and data.point.y ~= 0 and data.point.z ~= 0 then
      AI.SetRefPointPosition(entity.id, data.point)
      g_StringTemp1 = "action_lookat"
      AI.CreateGoalPipe(g_StringTemp1)
      AI.PushGoal(g_StringTemp1, "lookat", 1, 0, 0, false, AI_LOOKAT_USE_BODYDIR)
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, g_StringTemp1, nil, data.iValue)
    end
  end,
  ACT_LOOKATPOINT = function(self, entity, sender, data)
    if data and data.point and (data.point.x ~= 0 or data.point.y ~= 0 or data.point.z ~= 0) then
      AI.SetRefPointPosition(entity.id, data.point)
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_lookatpoint", nil, data.iValue)
    else
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_resetlookat", nil, data.iValue)
    end
  end,
  ACT_SHOOTAT = function(self, entity, sender, data)
    AI.CreateGoalPipe("action_shoot_at")
    AI.PushGoal("action_shoot_at", "locate", 0, "refpoint")
    AI.PushGoal("action_shoot_at", "+firecmd", 0, FIREMODE_FORCED, AILASTOPRES_USE)
    AI.PushGoal("action_shoot_at", "+timeout", 1, data.fValue)
    AI.PushGoal("action_shoot_at", "firecmd", 0, 0)
    AI.SetRefPointPosition(entity.id, data.point)
    entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_shoot_at", nil, data.iValue)
    entity:DrawWeaponNow()
  end,
  ACT_AIMAT = function(self, entity, sender, data)
    AI.CreateGoalPipe("action_aim_at")
    AI.PushGoal("action_aim_at", "locate", 0, "refpoint")
    AI.PushGoal("action_aim_at", "+firecmd", 0, FIREMODE_AIM, AILASTOPRES_USE)
    AI.PushGoal("action_aim_at", "+timeout", 1, data.fValue)
    AI.PushGoal("action_aim_at", "firecmd", 0, 0)
    AI.SetRefPointPosition(entity.id, data.point)
    entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_aim_at", nil, data.iValue)
    if entity.DrawWeaponNow then
      entity:DrawWeaponNow()
    end
  end,
  ACT_SPEED = function(self, entity, sender, data)
    if data and data.iValue == 2 then
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "do_it_running")
    elseif data and data.iValue == 3 then
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "do_it_sprinting")
    elseif data and data.iValue == 0 then
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "do_it_very_slow")
    elseif data and data.iValue == -1 then
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "do_it_super_slow")
    else
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "do_it_walking")
    end
  end,
  ACT_STANCE = function(self, entity, sender, data)
    if data and data.iValue == 0 then
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "do_it_prone")
    elseif data and data.iValue == 1 then
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "do_it_crouched")
    else
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "do_it_standing")
    end
  end,
  ACT_ANIM = function(self, entity, sender, data)
    AI.CreateGoalPipe("act_animation")
    AI.PushGoal("act_animation", "timeout", 1, 4591870180066957722)
    AI.PushGoal("act_animation", "branch", 1, -1, BRANCH_ALWAYS)
    entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "act_animation", nil, data.iValue)
  end,
  ACT_DIALOG = function(self, entity, sender, data)
    AI.CreateGoalPipe("act_animation")
    AI.PushGoal("act_animation", "timeout", 1, 4591870180066957722)
    AI.PushGoal("act_animation", "branch", 1, -1, BRANCH_ALWAYS)
    entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "act_animation", nil, data.iValue)
  end,
  ACT_FOLLOW = function(self, entity, sender, data)
    if data == nil then
      AI.Warning("ACT_FOLLOW " .. entity:GetName() .. ": nil data!")
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_dummy", nil, sender.iValue)
      entity:CancelSubpipe(sender.iValue)
      return
    end
    self:ACT_JOINFORMATION(entity, sender, data)
  end,
  END_ACT_FORM = function(self, entity, sender)
  end,
  ACT_JOINFORMATION = function(self, entity, sender, data)
    if data == nil then
      AI.Warning("ACT_JOINFORMATION " .. entity:GetName() .. ": nil data!")
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_dummy", nil, sender.iValue)
      entity:CancelSubpipe(sender.iValue)
      return
    end
    if sender == nil then
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_dummy", nil, data.iValue)
      entity:CancelSubpipe(data.iValue)
      return
    elseif sender == entity then
      if entity.AI.followGoalPipeId and entity.AI.followGoalPipeId ~= 0 then
        entity:CancelSubpipe(entity.AI.followGoalPipeId)
      end
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_dummy", nil, data.iValue)
      entity.AI.followGoalPipeId = data.iValue
      return
    end
    entity.AI.followGoalPipeId = data.iValue
    local stance = AI.GetStance(sender.id)
    entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "stay_in_formation_moving", nil, data.iValue)
    if stance == BODYPOS_CROUCH or stance == BODYPOS_PRONE then
      AI.SetStance(entity.id, stance)
    end
    if stance == BODYPOS_RELAX then
      AI.SetStance(entity.id, stance)
    else
      AI.SetStance(entity.id, BODYPOS_STAND)
    end
  end,
  ACT_GRAB_OBJECT = function(self, entity, sender, data)
    if data == nil then
      AI.Warning("ACT_GRAB_OBJECT " .. entity:GetName() .. ": nil data!")
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_dummy", nil, sender.iValue)
      entity:CancelSubpipe(sender.iValue)
      return
    end
    entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_dummy", nil, data.iValue)
    AI.Signal(SIGNALFILTER_SENDER, 0, "GO_TO_GRABBED", sender.id)
    if entity:GrabObject(sender) ~= 1 then
      entity:CancelSubpipe(data.iValue)
    end
  end,
  ACT_DROP_OBJECT = function(self, entity, sender, data)
    if entity.grabParams and entity.grabParams.entityId then
      local grab = System.GetEntity(entity.grabParams.entityId)
      AI.Signal(SIGNALFILTER_SENDER, 0, "OnDropped", entity.grabParams.entityId)
      entity:DropObject(true, data.point, 0)
    end
    entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_dummy", nil, data.iValue)
  end,
  ACT_WEAPONDRAW = function(self, entity, sender, data)
    entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_weapondraw", nil, data.iValue)
  end,
  ACT_WEAPONHOLSTER = function(self, entity, sender, data)
    entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_weaponholster", nil, data.iValue)
  end,
  ACT_USEOBJECT = function(self, entity, sender, data)
    if data == nil then
      AI.Warning("ACT_USEOBJECT " .. entity:GetName() .. ": nil data!")
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_dummy", nil, sender.iValue)
      entity:CancelSubpipe(sender.iValue)
      return
    end
    if sender then
      sender:OnUsed(entity, 2)
      AI.SmartObjectEvent("OnUsed", sender.id, entity.id)
    end
    entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_dummy", nil, data.iValue)
  end,
  ACT_WEAPONSELECT = function(self, entity, sender, data)
    ItemSystem.SetActorItemByName(entity.id, data.ObjectName, false)
    entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_dummy", nil, data.iValue)
  end,
  ACT_ALERTED = function(self, entity, sender, data)
    entity:MakeAlerted()
  end,
  SETUP_ENTERING = function(self, entity)
    if entity.AI.theVehicle then
      if entity.AI.theVehicle:EnterVehicle(entity.id, entity.AI.mySeat, true) ~= true then
        entity:CancelSubpipe()
      end
    else
      entity:CancelSubpipe()
    end
  end,
  SETUP_ENTERING_FAST = function(self, entity)
    if entity.AI.theVehicle then
      if entity.AI.theVehicle:EnterVehicle(entity.id, entity.AI.mySeat, false) ~= true then
        entity:CancelSubpipe()
      end
    else
      entity:CancelSubpipe()
    end
  end,
  ACT_ENTERVEHICLE = function(self, entity, sender, data)
    if entity.AI.theVehicle then
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_dummy", nil, data.iValue)
      entity:CancelSubpipe(data.iValue)
      return
    end
    entity.AI.theVehicle = System.GetEntity(data.id)
    if entity.AI.theVehicle == nil then
      AI.LogEvent(entity:GetName() .. " couldn't find the vehicle to enter")
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_enter", nil, data.iValue)
      entity:CancelSubpipe(data.iValue)
      return
    end
    local numSeats = count(entity.AI.theVehicle.Seats)
    if data.fValue < 1 or numSeats < data.fValue then
      entity.AI.mySeat = entity.AI.theVehicle:RequestClosestSeat(entity.id)
    else
      entity.AI.mySeat = data.fValue
    end
    if entity.AI.mySeat == nil then
      AI.LogEvent(entity:GetName() .. " aborting enter vehicle " .. entity.AI.theVehicle:GetName())
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_enter", nil, data.iValue)
      entity:CancelSubpipe(data.iValue)
      return
    end
    entity.AI.theVehicle:ReserveSeat(entity.id, entity.AI.mySeat)
    if entity.AI.theVehicle:IsDriver(entity.id) then
    end
    if data.iValue2 == 1 then
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_enter_fast", nil, data.iValue)
    else
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_enter", nil, data.iValue)
    end
    entity.AI.theVehicle.AI.goalType = AIGOALTYPE_UNDEFINED
    AI.Signal(SIGNALFILTER_SENDER, 0, "ENTERING_VEHICLE", entity.id)
  end,
  ACT_EXITVEHICLE = function(self, entity, sender, data)
    if entity.AI.theVehicle == nil then
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_dummy", nil, data.iValue)
      entity:CancelSubpipe(data.iValue)
      return
    end
    if entity.AI.theVehicle:IsDriver(entity.id) then
    end
    entity.AI.theVehicle:LeaveVehicle(entity.id)
    entity.AI.theVehicle = nil
    entity:InsertSubpipe(AIGOALPIPE_HIGHPRIORITY, "action_exit", nil, data.iValue)
  end,
  ACT_ANIMEX = function(self, entity, sender, data)
    if data then
      AI.CreateGoalPipe("action_animEx")
      AI.PushGoal("action_animEx", "locate", 0, "refpoint")
      AI.PushGoal("action_animEx", "+animtarget", 0, data.iValue2, data.ObjectName, data.point.x, data.fValue, data.point2.x)
      AI.PushGoal("action_animEx", "+locate", 0, "animtarget")
      AI.PushGoal("action_animEx", "+approach", 1, 0, AILASTOPRES_USE)
      entity:InsertSubpipe(AIGOALPIPE_SAMEPRIORITY, "action_animEx", nil, data.iValue)
    end
  end,
  SPOTTED_BY_SHARK = function(self, entity, sender, data)
    local shark = System.GetEntity(data.id)
    if shark then
      shark:Chase(entity)
    end
  end,
  NANOSUIT_ARMOR = function(self, entity, sender)
    entity.AI.suitMode = 1
  end,
  NANOSUIT_CLOAK = function(self, entity, sender)
    entity:SetCloakType(0)
    entity.AI.suitMode = 2
  end,
  DO_NOTHING = function(self, entity, sender)
    entity:SelectPipe(0, "standingthere")
    entity:SelectPipe(0, "do_nothing")
  end,
  TARGETLASER_ON = function(self, entity, sender)
    AI.EnableWeaponAccessory(entity.id, AIWEPA_LASER, true)
  end,
  TARGETLASER_OFF = function(self, entity, sender)
    AI.EnableWeaponAccessory(entity.id, AIWEPA_LASER, false)
  end,
  SYS_FLASHLIGHT_ON = function(self, entity, sender)
    AI.EnableWeaponAccessory(entity.id, AIWEPA_COMBAT_LIGHT, true)
  end,
  SYS_FLASHLIGHT_OFF = function(self, entity, sender)
    AI.EnableWeaponAccessory(entity.id, AIWEPA_COMBAT_LIGHT, false)
  end,
  PATROL_FLASHLIGHT_ON = function(self, entity, sender)
    AI.EnableWeaponAccessory(entity.id, AIWEPA_PATROL_LIGHT, true)
  end,
  PATROL_FLASHLIGHT_OFF = function(self, entity, sender)
    AI.EnableWeaponAccessory(entity.id, AIWEPA_PATROL_LIGHT, false)
  end,
  NEW_SPAWN = function(self, entity, sender)
    if entity.AI.reinfPoint then
      entity:SelectPipe(0, "goto_point", entity.AI.reinfPoint)
    else
      entity:SelectPipe(0, "goto_point", g_SignalData.ObjectName)
    end
  end,
  TEST_SEARCH = function(self, entity, sender, data)
    entity.AI.lookDir = {}
    CopyVector(entity.AI.lookDir, System.GetEntityByName("P1"):GetDirectionVector(1))
    AI.BeginGoalPipe("tr_order_search1")
    AI.PushGoal("bodypos", 1, BODYPOS_STAND)
    AI.PushGoal("firecmd", 0, 0)
    AI.PushGoal("pathfind", 1, "P1")
    AI.PushGoal("branch", 1, "PATH_FOUND", NOT + IF_NO_PATH)
    AI.PushGoal("signal", 0, 1, "OnUnitStop", SIGNALFILTER_LEADER)
    AI.PushGoal("branch", 1, "DONE", BRANCH_ALWAYS)
    AI.PushLabel("PATH_FOUND")
    AI.PushGoal("signal", 0, 1, "OnUnitMoving", SIGNALFILTER_LEADER)
    AI.PushGoal("locate", 1, "P1")
    AI.PushGoal("stick", 1, 0, AILASTOPRES_USE, 1, STICK_BREAK)
    AI.PushGoal("signal", 1, 1, "TEST_SEARCH_REACHED", SIGNALFILTER_SENDER)
    AI.PushGoal("bodypos", 1, BODYPOS_STEALTH)
    AI.PushGoal("locate", 0, "refpoint")
    AI.PushGoal("+lookat", 1, 0, 0, 1, AI_LOOKAT_CONTINUOUS + AI_LOOKAT_USE_BODYDIR)
    AI.PushGoal("lookaround", 1, 20, 3, 3, 5, AI_BREAK_ON_LIVE_TARGET)
    AI.PushGoal("lookat", 1, -500)
    AI.PushLabel("DONE")
    AI.PushGoal("bodypos", 1, BODYPOS_STAND)
    AI.PushGoal("locate", 1, "P")
    AI.PushGoal("stick", 1, 0, AILASTOPRES_USE, 1, STICK_BREAK)
    AI.EndGoalPipe()
    entity:SelectPipe(0, "do_nothing")
    entity:SelectPipe(0, "tr_order_search1")
  end,
  OnAlertTargetChanged = function(self, entity, sender, data)
    if entity.unit:IsDead() then
      return
    end
    local alertness = AI.GetAlertness(entity.id)
    if alertness ~= nil and alertness >= AIALERTNESS_ALERT then
      return
    end
    if entity.Behaviour.alertness == nil then
      System.LogAlways("[Error] No Alertness! CodeAlert: " .. tostring(alertness))
      dumpAlways(entity.Behaviour)
    end
    if entity.AI.param.alertDuration == nil or entity.AI.param.alertDuration ~= nil and entity.AI.param.alertDuration < 4591870180066957722 then
      if entity.Properties.bSpeciesHostility ~= 0 then
        local targetEntity = System.GetEntity(data.id)
        entity.unit:NpcAddAggro(targetEntity.unit, 1)
        return
      end
      return
    end
    AI.SetAttentionTargetOf(entity.id, data.id, AITARGETREASON_ALERT)
    AI.Signal(SIGNALFILTER_SENDER, AISIGNAL_INCLUDE_DISABLED, "GO_TO_ALERT", entity.id)
  end,
  OnGroupLeaderDied = function(self, entity)
    if entity.unit:IsDead() then
      return
    end
    if entity.AI.param.onGroupLeaderDied then
      X2AI:UseSkill(entity, USF_AUTO_STICK, "OnGroupLeaderDied")
    end
  end,
  OnRequestSkillInfo_OnGroupLeaderDied = function(self, entity)
    local skillList = entity.AI.param.onGroupLeaderDied or {}
    entity.unit:NpcSetSkillList(skillList)
  end,
  OnGroupMemberDied = function(self, entity)
    if entity.unit:IsDead() then
      return
    end
    if entity.AI.param.onGroupMemberDied then
      X2AI:UseSkill(entity, USF_AUTO_STICK, "OnGroupMemberDied")
    end
  end,
  OnRequestSkillInfo_OnGroupMemberDied = function(self, entity)
    local skillList = entity.AI.param.onGroupMemberDied or {}
    entity.unit:NpcSetSkillList(skillList)
  end,
  OnRequestSkillInfo_pet_manual = function(self, entity)
    entity.unit:NpcSetSkillList(entity.AI.skills.pet_manual)
  end
}
