AIBehaviour.roaming = {
  Name = "roaming",
  alertness = AIALERTNESS_IDLE,
  Constructor = function(self, entity)
    entity:ClearAICombat()
    X2AI:AttackReservedTarget(entity)
    AI.SetRefPointPosition(entity.id, entity.AI.idlePos)
    AI.BeginGoalPipe("roaming_Base")
    AI.PushGoal("bodypos", 1, BODYPOS_RELAX)
    AI.PushGoal("run", 1, 0)
    AI.PushGoal("useskill", 1, USF_AUTO_STICK)
    AI.PushGoal("signal", 1, AISIGNAL_INCLUDE_DISABLED, "UpdateRoaming", SIGNALFILTER_SENDER)
    AI.EndGoalPipe()
    entity:SelectPipe(AIGOALPIPE_DONT_RESET_AG, "roaming_Base")
    entity.unit:NpcSetCheckPosContext(AICPC_ROAMING)
    X2AI:InitRoamingDistance(entity)
  end,
  Destructor = function(self, entity)
    entity.unit:NpcSetCheckPosContext(AICPC_NONE)
  end,
  UpdateRoaming = function(self, entity, sender, data)
    entity:SelectPipe(AIGOALPIPE_DONT_RESET_AG, "_first_")
    if X2AI:IsGroupMember(entity) then
      if leaderEntity ~= nil and leaderEntity ~= entity then
        AI.SetAttentionTargetOf(entity.id, leaderEntity.id, AITARGETREASON_ALERT)
      end
      PipeManager:Create_formation_GoToOnPoint(entity)
      entity:SelectPipe(AIGOALPIPE_DONT_RESET_AG, "formation_GoToOnPoint")
      return
    end
    X2AI:CalcNextRoamingPosition(entity)
    PipeManager:Create_roaming(entity)
    entity:SelectPipe(AIGOALPIPE_DONT_RESET_AG, "roaming")
  end,
  UpdateIdleEnd = function(self, entity, sender, data)
    entity:SelectPipe(AIGOALPIPE_DONT_RESET_AG, "roaming_Base")
  end,
  OnPathStuck = function(self, entity, sender, data)
    self:UpdateIdleEnd(entity, sender, data)
  end,
  OnRequestSkillInfo = function(self, entity)
    entity.unit:NpcSetSkillList(entity.AI.skills.idle)
  end,
  OnArrivedOnFormationPoint = function(self, entity, sender, data)
    self:UpdateIdleEnd(entity, sender, data)
  end,
  OnAlertTargetChanged = function(self, entity, sender, data)
    local isGroupMember, leaderEntity = X2AI:IsGroupMember(entity)
    if isGroupMember then
      entity.AI.idlePos = leaderEntity:GetPos()
      entity.AI.idlePos.z = entity.AI.idlePos.z + 4602678819172646912
    end
    AIBehaviour.DEFAULT:OnAlertTargetChanged(entity, sender, data)
  end,
  OnAggroTargetChanged = function(self, entity, sender, data)
    local pos = entity:GetPos()
    AI.SetRefPointPosition(entity.id, pos)
    AI.SetAttentionTargetOf(entity.id, data.id, AITARGETREASON_ATTACK)
  end
}
