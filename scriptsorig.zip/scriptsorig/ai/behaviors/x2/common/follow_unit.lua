AIBehaviour.follow_unit = {
  Name = "follow_unit",
  alertness = AIALERTNESS_IDLE,
  Constructor = function(self, entity)
    entity:ClearAICombat()
    X2AI:AttackReservedTarget(entity)
    AI.SetAttentionTargetOf(entity.id, entity.AI.followUnit, AITARGETREASON_FRIENDLY)
    local stickOption = AILASTOPRES_LOOKAT + AI_DONT_STEER_AROUND_TARGET + AI_ADJUST_SPEED_BY_DISTANCE + AI_REQUEST_PARTIAL_PATH + AI_FOLLOW_SIDE_ON
    if entity.AI.param.followUnitDist == nil then
      entity.AI.param.followUnitDist = 0
    end
    if entity.AI.param.followUnitRandom ~= nil and entity.AI.param.followUnitRandom == true then
      stickOption = stickOption + AI_FOLLOW_RANDOM_SIDE_ON
    end
    AI.BeginGoalPipe("followUnit")
    AI.PushGoal("bodypos", 1, BODYPOS_RELAX)
    AI.PushGoal("branch", 1, "DO_STICK", IF_TARGET_ZALIGN_NEED)
    AI.PushGoal("branch", 1, "SKIP_STICK", IF_TARGET_DIST_LESS, 4616752568008179712 + entity.AI.param.followUnitDist)
    AI.PushLabel("DO_STICK")
    AI.PushGoal("run", 1, 1)
    AI.PushGoal("stick", 1, 0, stickOption, STICK_BREAK + STICK_SHORTCUTNAV, 0, entity.AI.param.followUnitDist)
    AI.PushLabel("SKIP_STICK")
    AI.EndGoalPipe()
    entity:SelectPipe(AIGOALPIPE_DONT_RESET_AG, "followUnit")
  end,
  Destructor = function(self, entity)
  end,
  OnAlertTargetChanged = function(self, entity, sender, data)
    local followTarget = System.GetEntity(entity.AI.followUnit)
    if followTarget ~= nil then
      entity.AI.idlePos = followTarget:GetPos()
      entity.AI.idlePos.z = entity.AI.idlePos.z + 4602678819172646912
    end
    AIBehaviour.DEFAULT:OnAlertTargetChanged(entity, sender, data)
  end,
  OnAggroTargetChanged = function(self, entity, sender, data)
    local pos = entity:GetPos()
    AI.SetRefPointPosition(entity.id, pos)
    AI.SetAttentionTargetOf(entity.id, data.id, AITARGETREASON_ATTACK)
  end,
  OnLostFollowUnit = function(self, entity, sender, data)
    local cmdSet = entity.AI.commandSet
    local needRemove = false
    if cmdSet:GetCurrentCommand() == AICC_FOLLOW_UNIT then
      cmdSet:OnCommandCompleted(entity, AICC_FOLLOW_UNIT)
      if cmdSet:CanRunCommandSet() == false then
        cmdSet:EndCommandSet(entity)
        if cmdSet:CanRunCommandSet() == false then
          needRemove = true
        end
      end
    else
      needRemove = true
    end
    if needRemove then
      entity.unit:NpcRemoveAfter(5)
      entity:SelectPipe(AIGOALPIPE_DONT_RESET_AG, "common_DoNothing")
    end
  end
}
