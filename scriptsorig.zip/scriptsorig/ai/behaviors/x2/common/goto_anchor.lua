AIBehaviour.goto_anchor = {
  Name = "goto_anchor",
  alertness = AIALERTNESS_IDLE,
  Constructor = function(self, entity)
    entity:ClearAICombat()
    X2AI:AttackReservedTarget(entity)
    AI.SetAttentionAnchorOf(entity.id, entity.AI.anchorType, AITARGETREASON_ANCHOR)
    if entity.AI.param.aiPathSkillLists ~= nil and table.getn(entity.AI.param.aiPathSkillLists) > 0 then
      entity.unit:StartAiSkillLists(PHASE_TYPE_FOLLOW_PATH, entity.AI.param.aiPathSkillLists)
    end
    local stickOption = AILASTOPRES_LOOKAT + AI_DONT_STEER_AROUND_TARGET + AI_ADJUST_SPEED_BY_DISTANCE + AI_REQUEST_PARTIAL_PATH + AI_FOLLOW_SIDE_ON
    if entity.AI.param.followUnitDist == nil then
      entity.AI.param.followUnitDist = 2
    end
    if entity.AI.param.followUnitRandom ~= nil and entity.AI.param.followUnitRandom == true then
      stickOption = stickOption + AI_FOLLOW_RANDOM_SIDE_ON
    end
    AI.BeginGoalPipe("gotoAnchor")
    AI.PushGoal("bodypos", 1, BODYPOS_RELAX)
    AI.PushGoal("run", 1, 1)
    AI.PushGoal("stick", 1, 0, stickOption, STICK_BREAK + STICK_SHORTCUTNAV, 0, entity.AI.param.followUnitDist)
    AI.PushGoal("signal", 1, AISIGNAL_INCLUDE_DISABLED, "OnAnchorArrived")
    AI.PushGoal("useskill", 1, 0)
    AI.PushGoal("timeout", 1, entity.AI.param.anchorEndTime)
    AI.PushGoal("signal", 1, AISIGNAL_INCLUDE_DISABLED, "OnGotoAnchorEnded")
    AI.EndGoalPipe()
    entity:SelectPipe(AIGOALPIPE_DONT_RESET_AG, "gotoAnchor")
  end,
  Destructor = function(self, entity)
    entity.unit:EndAiSkillLists()
  end,
  OnAlertTargetChanged = function(self, entity, sender, data)
    local pos = entity:GetPos()
    AI.SetRefPointPosition(entity.id, pos)
    local laPos = AI.GetPathFollowLAPos(entity.id)
    if IsNotNullVector(laPos) then
      entity.AI.idlePos = laPos
    end
    AIBehaviour.DEFAULT:OnAlertTargetChanged(entity, sender, data)
  end,
  OnAggroTargetChanged = function(self, entity, sender, data)
    if entity.AI.param.aiPathDamageSkillLists ~= nil and table.getn(entity.AI.param.aiPathDamageSkillLists) > 0 then
      if entity.AI.damaged == false then
        entity.unit:StartAiSkillLists(PHASE_TYPE_FOLLOW_PATH, entity.AI.param.aiPathDamageSkillLists)
        entity.AI.damaged = true
      end
    else
      entity.unit:EndAiSkillLists()
      entity.AI.damaged = false
      local pos = entity:GetPos()
      AI.SetRefPointPosition(entity.id, pos)
      AI.SetAttentionTargetOf(entity.id, data.id, AITARGETREASON_ATTACK)
      AI.Signal(SIGNALFILTER_SENDER, AISIGNAL_INCLUDE_DISABLED, "GO_TO_COMBAT", entity.id)
    end
  end,
  OnNoAggroTarget = function(self, entity, sender, data)
    if entity.AI.param.aiPathSkillLists ~= nil and table.getn(entity.AI.param.aiPathSkillLists) > 0 then
      entity.unit:StartAiSkillLists(PHASE_TYPE_FOLLOW_PATH, entity.AI.param.aiPathSkillLists)
      entity.AI.damaged = false
    end
  end,
  OnPathStuck = function(self, entity, sender, data)
    if entity.AI.commandSet.canInteract then
      entity:SelectPipe(AIGOALPIPE_DONT_RESET_AG, "common_WaitFiveSec")
    end
  end,
  OnFiveSecPassed = function(self, entity, sender, data)
    entity:SelectPipe(AIGOALPIPE_DONT_RESET_AG, "gotoAnchor")
  end,
  OnAnchorArrived = function(self, entity, sender, data)
    local pos = entity:GetPos()
    AI.SetRefPointPosition(entity.id, pos)
  end,
  OnGotoAnchorEnded = function(self, entity, sender, data)
    local anchorEndType = entity.AI.param.anchorEndType
    entity.AI.idlePos = entity:GetPos()
    entity.AI.idleDir = entity:GetDirectionVector()
    if anchorEndType == PT_REMOVE then
      local npcRemoveTime = 9
      entity.unit:NpcRemoveAfter(npcRemoveTime)
      entity:SelectPipe(AIGOALPIPE_DONT_RESET_AG, "common_DoNothing")
    elseif followPathType == PT_IDLE then
      if entity.AI.commandSet:GetCurrentProcessingCommand() == AICC_GOTO_ANCHOR then
        entity.AI.commandSet:OnCommandCompleted(entity, AICC_GOTO_ANCHOR)
      else
        AI.Signal(SIGNALFILTER_SENDER, AISIGNAL_INCLUDE_DISABLED, "GO_TO_IDLE", entity.id)
      end
    elseif anchorEndType == PT_LOOP then
      return
    end
    if entity.unit:NpcOnEndedGotoAnchor() and AI.SetAttentionAnchorOf(entity.id, entity.AI.anchorType, AITARGETREASON_ANCHOR) then
      entity:SelectPipe(AIGOALPIPE_DONT_RESET_AG, "gotoAnchor")
    end
  end
}
