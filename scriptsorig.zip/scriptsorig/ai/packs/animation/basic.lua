ANIMATIONPACK.Basic = {
  IN_POSITION_FRONT = {
    {
      PROBABILITY = 1000,
      animationName = "combat_signalInposition_rifle_front_01",
      duration = 0,
      layer = 6,
      blend_time = 4599075939470750515
    }
  },
  IN_POSITION_LEFT = {
    {
      PROBABILITY = 1000,
      animationName = "combat_signalInposition_rifle_left_01",
      duration = 0,
      layer = 6,
      blend_time = 4599075939470750515
    }
  },
  IN_POSITION_RIGHT = {
    {
      PROBABILITY = 1000,
      animationName = "combat_signalInposition_rifle_right_01",
      duration = 0,
      layer = 6,
      blend_time = 4599075939470750515
    }
  },
  IN_POSITION_BACK = {
    {
      PROBABILITY = 1000,
      animationName = "combat_signalInposition_rifle_right_01",
      duration = 0,
      layer = 6,
      blend_time = 4599075939470750515
    }
  },
  FOLLOW_ME = {
    {
      PROBABILITY = 1000,
      animationName = "combat_signalFollow_rifle_01",
      duration = 0,
      layer = 6,
      blend_time = 4599075939470750515
    }
  },
  HIDE_END_EFFECT = {
    {
      PROBABILITY = 1000,
      animationName = "rollfwd",
      duration = 4609434218613702656,
      layer = 4,
      blend_time = 4593851763903000740
    }
  },
  I_SEE_YOU = {
    {
      PROBABILITY = 1000,
      animationName = "first_contact",
      duration = 4609434218613702656,
      layer = 0,
      blend_time = 4593851763903000740
    }
  },
  IDLE_TO_INTERESTED = {
    {
      PROBABILITY = 1000,
      animationName = "first_contact",
      duration = 4609434218613702656,
      layer = 0,
      blend_time = 4593851763903000740
    }
  },
  IDLE_TO_THREATENED = {
    {
      PROBABILITY = 1000,
      animationName = "first_contact",
      duration = 4609434218613702656,
      layer = 0,
      blend_time = 4593851763903000740
    }
  },
  I_NO_SEE_YOU = {
    {
      PROBABILITY = 1000,
      animationName = "enemy_target_lost",
      duration = 4609434218613702656,
      layer = 0,
      blend_time = 4593851763903000740
    }
  },
  I_HEAR_YOU = {
    {
      PROBABILITY = 1000,
      animationName = "sSoundheard",
      duration = 4609434218613702656,
      layer = 0,
      blend_time = 4593851763903000740
    }
  },
  THREATEN = {
    {
      PROBABILITY = 1000,
      animationName = "first_contact",
      duration = 4609434218613702656,
      layer = 0,
      blend_time = 4593851763903000740
    }
  },
  ACT_SURPRISED = {
    {
      PROBABILITY = 100,
      animationName = "suprise01",
      duration = 0,
      layer = 1,
      blend_time = 4599075939470750515
    },
    {
      PROBABILITY = 100,
      animationName = "suprise02",
      duration = 0,
      layer = 1,
      blend_time = 4599075939470750515
    },
    {
      PROBABILITY = 100,
      animationName = "suprise03",
      duration = 0,
      layer = 1,
      blend_time = 4599075939470750515
    }
  },
  RESPOND_DOWN = {
    {
      PROBABILITY = 100,
      animationName = "suprise01",
      duration = 0,
      layer = 1,
      blend_time = 4599075939470750515
    }
  },
  FIRST_CONTACT = {
    {
      PROBABILITY = 100,
      animationName = "first_contact",
      duration = 0,
      layer = 1,
      blend_time = 4599075939470750515
    }
  },
  FIRST_HOSTILE_CONTACT = {
    {
      PROBABILITY = 100,
      animationName = "first_contact",
      duration = 0,
      layer = 1,
      blend_time = 4599075939470750515
    }
  },
  ENEMY_TARGET_LOST = {
    {
      PROBABILITY = 100,
      animationName = "enemy_target_lost",
      duration = 0,
      layer = 1,
      blend_time = 4599075939470750515
    }
  },
  CALL_REINFORCEMENTS = {
    {
      PROBABILITY = 500,
      animationName = "reinforcements_wave1",
      duration = 0,
      layer = 4,
      blend_time = 4599075939470750515
    },
    {
      PROBABILITY = 500,
      animationName = "reinforcements_wave2",
      duration = 0,
      layer = 4,
      blend_time = 4599075939470750515
    }
  },
  STOP_MOVING = {
    {
      PROBABILITY = 1000,
      animationName = "stand_signal_rifle_wait",
      duration = 0,
      layer = 6,
      blend_time = 4599075939470750515
    }
  },
  CONVOY_SPOTTED = {
    {
      PROBABILITY = 1000,
      animationName = "stand_rifle_talk_pointing",
      Volume = 255,
      duration = 0,
      layer = 6,
      blend_time = 4599075939470750515
    }
  },
  OUTPOST_SIGHTED = {
    {
      PROBABILITY = 1000,
      animationName = "stand_rifle_talk_pointing",
      Volume = 255,
      duration = 0,
      layer = 6,
      blend_time = 4599075939470750515
    }
  },
  HAWKER_INTRO = {
    {
      PROBABILITY = 1000,
      animationName = "special_hawker_intro_m01",
      Volume = 255,
      duration = 0,
      layer = 6,
      blend_time = 4599075939470750515
    }
  },
  SYKES_INTRO = {
    {
      PROBABILITY = 1000,
      animationName = "special_sykes_intro_m01",
      Volume = 255,
      duration = 0,
      layer = 6,
      blend_time = 4599075939470750515
    }
  },
  bulletrain = {
    {PROBABILITY = 250, animationName = "flinch"}
  },
  melee_weapon_punch = {
    {
      PROBABILITY = 1000,
      animationName = "weaponPunch"
    }
  },
  signalAdvance = {
    {
      PROBABILITY = 1000,
      animationName = "signalAdvance"
    }
  },
  signalMove = {
    {PROBABILITY = 1000, animationName = "signalMove"}
  }
}
