ANIMATIONPACK.Trooper = {
  FOLLOW_ME = {
    {
      PROBABILITY = 1000,
      animationName = "combat_signalFollow_rifle_01",
      duration = 0,
      layer = 6,
      blend_time = 4599075939470750515
    }
  },
  I_SEE_YOU = {
    {
      PROBABILITY = 1000,
      animationName = "first_contact",
      duration = 4609434218613702656,
      layer = 0,
      blend_time = 4593851763903000740
    }
  },
  IDLE_TO_INTERESTED = {
    {
      PROBABILITY = 1000,
      animationName = "first_contact",
      duration = 4609434218613702656,
      layer = 0,
      blend_time = 4593851763903000740
    }
  },
  REBOOT = {
    {
      PROBABILITY = 1000,
      animationName = "reboot",
      Persistent = 1
    }
  },
  END_REBOOT = {
    {
      PROBABILITY = 1000,
      animationName = "none",
      Persistent = 1
    }
  },
  I_HEAR_YOU = {
    {
      PROBABILITY = 1000,
      animationName = "sSoundheard",
      duration = 4609434218613702656,
      layer = 0,
      blend_time = 4593851763903000740
    }
  },
  FIRST_CONTACT = {
    {
      PROBABILITY = 100,
      animationName = "first_contact",
      duration = 0,
      layer = 1,
      blend_time = 4599075939470750515
    }
  },
  FIRST_HOSTILE_CONTACT = {
    {
      PROBABILITY = 100,
      animationName = "first_contact",
      duration = 0,
      layer = 1,
      blend_time = 4599075939470750515
    }
  },
  ENEMY_TARGET_LOST = {
    {
      PROBABILITY = 100,
      animationName = "enemy_target_lost",
      duration = 0,
      layer = 1,
      blend_time = 4599075939470750515
    }
  },
  CALL_REINFORCEMENTS = {
    {
      PROBABILITY = 500,
      animationName = "reinforcements_wave1",
      duration = 0,
      layer = 4,
      blend_time = 4599075939470750515
    },
    {
      PROBABILITY = 500,
      animationName = "reinforcements_wave2",
      duration = 0,
      layer = 4,
      blend_time = 4599075939470750515
    }
  },
  STOP_MOVING = {
    {
      PROBABILITY = 1000,
      animationName = "stand_signal_rifle_wait",
      duration = 0,
      layer = 6,
      blend_time = 4599075939470750515
    }
  },
  MELEE = {
    {
      PROBABILITY = 1000,
      animationName = "meleeAttack",
      duration = 0,
      layer = 6,
      blend_time = 4599075939470750515
    }
  },
  FIREMODE0 = {
    {PROBABILITY = 1000, animationName = "fireMode01"}
  },
  FIREMODE1 = {
    {
      PROBABILITY = 1000,
      animationName = "fireMode02",
      duration = 0,
      layer = 6,
      blend_time = 4599075939470750515
    }
  },
  clear = {
    {
      PROBABILITY = 1000,
      animationName = "none",
      Persistent = 1
    }
  }
}
