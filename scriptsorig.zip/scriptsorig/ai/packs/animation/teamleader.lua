ANIMATIONPACK.TeamLeader = {
  LOOK_FOR_COVER = {
    {
      PROBABILITY = 1000,
      animationName = "slookingfortarget",
      duration = 4609434218613702656,
      layer = 4,
      blend_time = 4593851763903000740
    }
  },
  LO_SPLIT_LEFT = {
    {
      PROBABILITY = 1000,
      animationName = "signal_teamleftsplit",
      duration = 2,
      layer = 4,
      blend_time = 4593851763903000740
    }
  },
  LO_SPLIT_RIGHT = {
    {
      PROBABILITY = 1000,
      animationName = "signal_teamrightsplit",
      duration = 2,
      layer = 4,
      blend_time = 4593851763903000740
    }
  },
  LO_LEFT_ADVANCE = {
    {
      PROBABILITY = 1000,
      animationName = "signal_teamleftadvance",
      duration = 4612136378390124954,
      layer = 4,
      blend_time = 4593851763903000740
    }
  },
  LO_RIGHT_ADVANCE = {
    {
      PROBABILITY = 1000,
      animationName = "signal_teamrightadvance",
      duration = 4612136378390124954,
      layer = 4,
      blend_time = 4593851763903000740
    }
  }
}
