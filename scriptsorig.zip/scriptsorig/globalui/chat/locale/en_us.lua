if X2Util:GetGameProvider() == KAKAONA then
  baselibLocale.MarkedCiphersValue = 0
end
