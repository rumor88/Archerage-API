if X2Util:GetGameProvider() == MAILRU then
  baselibLocale.MarkedCiphersValue = 0
end
