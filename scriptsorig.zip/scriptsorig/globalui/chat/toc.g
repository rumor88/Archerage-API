﻿locale/ko.lua
locale/ru.lua
locale/en_us.lua

chat_msg_event.lua
