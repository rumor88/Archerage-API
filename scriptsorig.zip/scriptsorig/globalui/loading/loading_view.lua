function CreateEmptyWindow(id, parent, useTitleBar)
  parent = parent or "UIParent"
  local window = UIParent:CreateWidget("window", id, parent)
  return window
end
loading = {}
local BG_WIDTH = 1920
local BG_HEIGHT = 1200
local PATH = "ui/gauge.dds"
loading.mainWindow = CreateEmptyWindow("loading.mainWindow", "UIParent")
loading.mainWindow:Show(false)
loading.mainWindow:AddAnchor("TOPLEFT", "UIParent", 0, 0)
loading.mainWindow:AddAnchor("BOTTOMRIGHT", "UIParent", 0, 0)
loading.mainWindow:SetUILayer("system")
function CalcDontApplyUIScale(value)
  return value / UIParent:GetUIScale()
end
function ResizeLoadingBg(bg)
  local SCREEN_WIDTH = UIParent:GetScreenWidth()
  local SCREEN_HEIGHT = UIParent:GetScreenHeight()
  if BG_WIDTH / BG_HEIGHT < SCREEN_WIDTH / SCREEN_HEIGHT then
    local new_height = math.floor(BG_HEIGHT * SCREEN_WIDTH / BG_WIDTH)
    if SCREEN_HEIGHT > new_height then
      new_height = SCREEN_HEIGHT
    end
    bg:SetExtent(CalcDontApplyUIScale(SCREEN_WIDTH), CalcDontApplyUIScale(new_height))
  else
    local new_width = math.floor(BG_WIDTH * SCREEN_HEIGHT / BG_HEIGHT)
    if SCREEN_WIDTH > new_width then
      new_width = SCREEN_WIDTH
    end
    bg:SetExtent(CalcDontApplyUIScale(new_width), CalcDontApplyUIScale(SCREEN_HEIGHT))
  end
  bg:AddAnchor("CENTER", "UIParent", 0, 0)
end
function SetViewOfLoadingBg(worldImagePath)
  if loading.bg == nil then
    loading.bg = loading.mainWindow:CreateImageDrawable(worldImagePath, "background")
    loading.bg:SetCoords(0, 0, BG_WIDTH, BG_HEIGHT)
    ResizeLoadingBg(loading.bg)
  else
    loading.bg:SetTexture(worldImagePath)
    ResizeLoadingBg(loading.bg)
  end
end
local bg = loading.mainWindow:CreateDrawable(PATH, "black_bg", "artwork")
bg:AddAnchor("TOPLEFT", loading.mainWindow, "BOTTOMLEFT", 0, -157)
bg:AddAnchor("BOTTOMRIGHT", loading.mainWindow, 0, 0)
local gaugeWindow = loading.mainWindow:CreateChildWidget("emptywidget", "gaugeWindow", 0, true)
gaugeWindow:Show(true)
gaugeWindow:SetExtent(798, 22)
gaugeWindow:AddAnchor("BOTTOM", loading.mainWindow, 0, -61)
local bg = gaugeWindow:CreateDrawable(PATH, "gauge_bg", "artwork")
bg:AddAnchor("TOPLEFT", gaugeWindow, 0, 0)
bg:AddAnchor("BOTTOMRIGHT", gaugeWindow, 0, 0)
local loadingGauge = UIParent:CreateWidget("statusbar", "loadingGauge", gaugeWindow)
loadingGauge:SetHeight(6)
loadingGauge:AddAnchor("LEFT", gaugeWindow, 6, 0)
loadingGauge:AddAnchor("RIGHT", gaugeWindow, -6, 0)
gaugeWindow.loadingGauge = loadingGauge
local gageDeco = loadingGauge:CreateDrawable(PATH, "gauge_top", "overlay")
gageDeco:AddAnchor("CENTER", gaugeWindow, 0, 0)
local info = UIParent:GetTextureData(PATH, "gauge_orange")
loadingGauge:SetBarTexture(PATH, "overlay")
loadingGauge:SetBarTextureCoords(info.coords[1], info.coords[2], info.coords[3], info.coords[4])
loadingGauge:SetOrientation("HORIZONTAL")
loadingGauge:SetBarColor(1, 1, 1, 1)
loadingGauge:SetMinMaxValues(0, 100)
loadingGauge:SetValue(0)
local title = loading.mainWindow:CreateChildWidget("label", "title", 0, true)
title:SetAutoResize(true)
title:SetHeight(FONT_SIZE.LARGE)
title:SetText(locale.loading.notice)
title:AddAnchor("TOP", gaugeWindow, "BOTTOM", 0, 4)
title.style:SetFontSize(FONT_SIZE.LARGE)
title.style:SetColorByKey("loading_content")
local percent = loading.mainWindow:CreateChildWidget("label", "percent", 0, true)
percent:SetExtent(0, FONT_SIZE.XLARGE)
percent:SetAutoResize(true)
percent:AddAnchor("LEFT", gaugeWindow, "RIGHT", 3, -1)
percent.style:SetFontSize(FONT_SIZE.XLARGE)
percent.style:SetAlign(ALIGN_LEFT)
percent.style:SetColorByKey("loading_percent")
if X2Player:GetFeatureSet().loadingTipOfDay then
  local tip = loading.mainWindow:CreateChildWidget("textbox", "tip", 0, true)
  tip:AddAnchor("BOTTOM", gaugeWindow, "TOP", 0, -6)
  tip:AddAnchor("LEFT", loading.mainWindow, 0, 0)
  tip:AddAnchor("RIGHT", loading.mainWindow, 0, 0)
  tip:SetAutoResize(true)
  tip:SetHeight(FONT_SIZE.XLARGE)
  tip.style:SetSnap(true)
  tip.style:SetFontSize(FONT_SIZE.XLARGE)
  tip.style:SetColorByKey("loading_tip")
end
