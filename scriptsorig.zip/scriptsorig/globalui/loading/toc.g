﻿## author : dolsoe3
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## loading ui

loading_view.lua
loading.lua
