locale = {}
locale.loading = {
  notice = X2Locale:LocalizeUiText(LOADING_TEXT, "notice")
}
