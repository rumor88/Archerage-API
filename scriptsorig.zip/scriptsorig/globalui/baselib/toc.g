﻿locale_helper.lua
