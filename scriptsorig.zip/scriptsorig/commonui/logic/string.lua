local IsDigit = function(byte)
  if byte < 48 or byte > 57 then
    return false
  end
  return true
end
F_TEXT = {}
function F_TEXT.GetCommonText(key, a, b, c)
  if a and b and c then
    return X2Locale:LocalizeUiText(COMMON_TEXT, key, tostring(a), tostring(b), tostring(c))
  end
  if a and b then
    return X2Locale:LocalizeUiText(COMMON_TEXT, key, tostring(a), tostring(b))
  end
  if a then
    return X2Locale:LocalizeUiText(COMMON_TEXT, key, tostring(a))
  end
  return X2Locale:LocalizeUiText(COMMON_TEXT, key)
end
function F_TEXT.HasLocalizeUiText(category, key)
  return X2Locale:HasLocalizeUiText(category, key)
end
function F_TEXT.GetUIText(category, key, ...)
  return X2Locale:LocalizeUiText(category, key, ...)
end
function F_TEXT.SetEnterString(str, addStr, enterCount)
  if enterCount == nil then
    enterCount = 1
  end
  local enterStr = ""
  for i = 1, enterCount do
    enterStr = string.format("%s\n", enterStr)
  end
  if str ~= "" then
    str = string.format("%s%s%s", str, enterStr, addStr)
  else
    str = addStr
  end
  return str
end
function F_TEXT.IStr(arg)
  return string.format("%i", arg)
end
local format = function(value)
  if type(value) == "number" then
    return string.format("%d", value)
  elseif type(value) == "string" then
    return value
  end
end
function F_TEXT.SetColonFormat(key, value)
  if key == nil or value == nil then
    X2Util:RaiseLuaCallStack(string.format("[F_TEXT.SetColonFormat] key: %s, value: %s", tostring(key), tostring(value)))
    return
  end
  return string.format("%s: %s", key, format(value))
end
function F_TEXT.SetSlashFormat(...)
  local str = ""
  for i, v in ipairs(arg) do
    if str == "" then
      str = format(v)
    else
      str = string.format("%s/%s", str, format(v))
    end
  end
  return str
end
function F_TEXT.SetCommaFormat(value, useLabelWidget)
  if useLabelWidget == true then
    return X2Util:InsertComma(string.format("%i", value))
  elseif type(value) == "number" then
    return string.format("|,%i;", value)
  elseif type(value) == "string" then
    return string.format("|,%s;", value)
  end
  return value
end
function F_TEXT.GetEquipReinforceLevelString(level, small)
  if small then
    return string.format("|v%s;", tostring(level))
  else
    return string.format("|V%s;", tostring(level))
  end
end
function F_TEXT.Replace(target, from, to)
  local newTarget = target
  local strFindStart, strFindEnd = string.find(newTarget, from)
  while strFindStart ~= nil do
    local strCnt = string.len(newTarget)
    newTarget = string.format("%s%s%s", string.sub(newTarget, 1, strFindStart - 1), to, string.sub(newTarget, strFindEnd + 1, strCnt))
    strFindStart, strFindEnd = string.find(newTarget, from)
  end
  return newTarget
end
function F_TEXT.CreateCountingText(id, parent, title)
  local text = parent:CreateChildWidget("textbox", id, 0, true)
  text:SetHeight(FONT_SIZE.MIDDLE)
  text:SetAutoWordwrap(false)
  text:SetAutoResize(true)
  text.style:SetColorByKey("default")
  function text:UpdateCount(cur, max)
    text:SetText(string.format("%s %s%s", title, F_COLOR.GetColor("blue", true), F_TEXT.SetSlashFormat(cur, max)))
  end
  return text
end
function F_TEXT.RemoveNonDigit(num)
  local limit = string.len(num)
  local byte, char
  local strNum = ""
  for i = 1, limit do
    byte = string.byte(num, i)
    if IsDigit(byte) then
      strNum = string.format("%s%s", strNum, string.char(byte))
    end
  end
  if limit == 0 then
    strNum = "0"
  end
  return strNum
end
function F_TEXT.GetEllipsisStr()
  return ".."
end
function F_TEXT.SetSignFormat(isPositive, value)
  if type(value) == "number" then
    value = tostring(value)
  end
  local sign = isPositive and "+" or "-"
  return string.format("%s%s", sign, value)
end
