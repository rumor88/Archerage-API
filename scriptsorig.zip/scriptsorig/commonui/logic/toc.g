﻿## author : zergra
## Copyright (c) 2012 XLGames, Inc. All rights reserved.
## raidframe

string.lua
money.lua
chat.lua