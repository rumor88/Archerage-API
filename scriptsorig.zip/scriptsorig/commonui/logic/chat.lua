function ParseCombatMessage(combatEvent, ...)
  local pos = combatEvent:find("_")
  local prefix = combatEvent:sub(1, pos - 1)
  local suffix = combatEvent:sub(pos + 1)
  local result = {}
  local index = 0
  local function GetNextIndex()
    index = index + 1
    return index
  end
  if prefix == "MELEE" then
  elseif prefix == "SPELL" then
    result.spellId = arg[GetNextIndex()]
    result.spellName = arg[GetNextIndex()]
    result.spellSchool = arg[GetNextIndex()]
  elseif prefix == "ENVIRONMENTAL" then
    result.source = arg[GetNextIndex()]
    result.subType = arg[GetNextIndex()]
    if result.subType ~= nil and result.subType ~= -1 then
      result.mySlave = arg[GetNextIndex()]
    end
  end
  if suffix == "DAMAGE" or suffix == "DOT_DAMAGE" then
    result.damage = arg[GetNextIndex()]
    result.powerType = arg[GetNextIndex()]
    result.hitType = arg[GetNextIndex()]
    result.reduced = arg[GetNextIndex()]
    result.elementDamage = arg[GetNextIndex()]
    result.showElementEffect = arg[GetNextIndex()]
    result.elementType = arg[GetNextIndex()]
    result.synergy = arg[GetNextIndex()]
  elseif suffix == "MISSED" then
    result.missType = arg[GetNextIndex()]
    result.damage = arg[GetNextIndex()]
    result.reduced = arg[GetNextIndex()]
    result.elementDamage = arg[GetNextIndex()]
    result.showElementEffect = arg[GetNextIndex()]
    result.elementType = arg[GetNextIndex()]
  elseif suffix == "HEALED" then
    result.heal = arg[GetNextIndex()]
    result.hitType = arg[GetNextIndex()]
    result.showElementEffect = arg[GetNextIndex()]
    result.elementType = arg[GetNextIndex()]
  elseif suffix == "ENERGIZE" then
    result.amount = arg[GetNextIndex()]
    result.powerType = arg[GetNextIndex()]
  elseif suffix == "DRAIN" then
    result.amount = arg[GetNextIndex()]
    result.powerType = arg[GetNextIndex()]
  elseif suffix == "LEECH" then
    result.amount = arg[GetNextIndex()]
    result.powerType = arg[GetNextIndex()]
  elseif suffix == "CAST_FAILED" then
    result.failType = arg[GetNextIndex()]
  elseif suffix == "AURA_APPLIED" or suffix == "AURA_REMOVED" then
    result.auraType = arg[GetNextIndex()]
    result.combatText = arg[GetNextIndex()]
  end
  return result
end
function AlertMsgToSecondPasswordUnlockRemainTime()
  local remainDate = X2Security:GetSecondPasswordUnlockRemainTime()
  if remainDate ~= nil then
    local msg = GetRemainDate(remainDate.year, remainDate.month, remainDate.day, remainDate.hour, remainDate.minute, remainDate.second)
    X2Chat:DispatchChatMessage(CMF_SYSTEM, X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "lock_state_played", tostring(msg)))
    AddMessageToSysMsgWindow(X2Locale:LocalizeUiText(SECOND_PASSWORD_TEXT, "lock_state_played", tostring(msg)))
  end
end
function envSourceToStr(envSource, subType)
  if envSource == "DROWNING" then
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "drowning")
  elseif envSource == "FALLING" then
    return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "falling")
  elseif envSource == "COLLISION" then
    if subType == COLLISION_PART_FRONT then
      return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "collision_front")
    elseif subType == COLLISION_PART_SIDE then
      return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "collision_side")
    elseif subType == COLLISION_PART_REAR then
      return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "collision_rear")
    elseif subType == COLLISION_PART_BOTTOM then
      return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "collision_bottom")
    else
      return X2Locale:LocalizeUiText(CHAT_COMBAT_LOG_TEXT, "collision")
    end
  end
end
function ShowSextantPos(long, deg_long, min_long, sec_long, lat, deg_lat, min_lat, sec_lat)
  return string.format("%s%s %s\194\176|r%s' %s\", %s%s %s\194\176|r%s' %s\"", F_COLOR.GetColor("original_dark_orange", true), tostring(long), tostring(deg_long), tostring(min_long), tostring(sec_long), F_COLOR.GetColor("original_dark_orange", true), tostring(lat), tostring(deg_lat), tostring(min_lat), tostring(sec_lat))
end
function ReplaceWorldMsgLikeMacro(msg, info)
  if info == nil then
    return msg
  end
  keyWord = "@coordinates"
  found = string.find(msg, keyWord)
  if found ~= nil then
    local sextants = info.sextant
    if sextants ~= nil then
      local long = sextants.longitude
      local deg_long = sextants.deg_long
      local min_long = sextants.min_long
      local sec_long = sextants.sec_long
      local lat = sextants.latitude
      local deg_lat = sextants.deg_lat
      local min_lat = sextants.min_lat
      local sec_lat = sextants.sec_lat
      sextStr = ShowSextantPos(long, deg_long, min_long, sec_long, lat, deg_lat, min_lat, sec_lat)
      msg = string.gsub(msg, keyWord, sextStr)
    end
  end
  keyWord = "@faction"
  found = string.find(msg, keyWord)
  if found ~= nil and info.factionName ~= nil then
    msg = string.gsub(msg, keyWord, info.factionName)
  end
  keyWord = "@motherfaction"
  found = string.find(msg, keyWord)
  if found ~= nil and info.motherFactionName ~= nil then
    msg = string.gsub(msg, keyWord, info.motherFactionName)
  end
  keyWord = "@name"
  found = string.find(msg, keyWord)
  if found ~= nil and info.name ~= nil then
    msg = string.gsub(msg, keyWord, info.name)
  end
  keyWord = "@trgfaction"
  found = string.find(msg, keyWord)
  if found ~= nil and info.trgFactionName ~= nil then
    msg = string.gsub(msg, keyWord, info.trgFactionName)
  end
  keyWord = "@trgmotherfaction"
  found = string.find(msg, keyWord)
  if found ~= nil and info.trgMotherFactionName ~= nil then
    msg = string.gsub(msg, keyWord, info.trgMotherFactionName)
  end
  keyWord = "@trgname"
  found = string.find(msg, keyWord)
  if found ~= nil and info.trgName ~= nil then
    msg = string.gsub(msg, keyWord, info.trgName)
  end
  keyWord = "@zonegroupname"
  found = string.find(msg, keyWord)
  if found ~= nil and info.zoneGroupName ~= nil then
    msg = string.gsub(msg, keyWord, info.zoneGroupName)
  end
  return msg
end
