local callstackAble = X2Debug ~= nil and X2Debug:GetDevMode()
local prefix = "|c"
function ConvertColor(value)
  if value == nil or type(value) ~= "number" then
    if callstackAble then
      X2Util:RaiseLuaCallStack(string.format("[ConvertColor] invalid arg, %s", tostring(value)))
    end
    return 0
  end
  return value / 255
end
local Dec2Hex = function(colors)
  return string.format("%02x%02x%02x%02x", colors[4] * 255, colors[1] * 255, colors[2] * 255, colors[3] * 255)
end
F_COLOR = {}
local fontColor = {}
local function CheckValidColorString(value)
  if type(value) ~= "string" then
    if callstackAble then
      X2Util:RaiseLuaCallStack(string.format("[CheckValidColorString] invalid arg, %s", tostring(value)))
    end
    return false
  end
  local firstIndex, lastIndex, matchedStr = string.find(value, "^(%x%x%x%x%x%x%x%x)$")
  if firstIndex == nil or lastIndex == nil or matchedStr == nil then
    if callstackAble then
      X2Util:RaiseLuaCallStack(string.format("[CheckValidColorString] invalid string format, %s", tostring(value)))
    end
    return false
  end
  return true
end
function F_COLOR.GetHexColorForString(stringValue)
  local valid = CheckValidColorString(stringValue)
  if not valid then
    return F_COLOR.GetColor("red", true)
  end
  local color = ""
  color = string.format("%s%s", prefix, stringValue)
  return color
end
function F_COLOR.Hex2Dec(stringValue)
  local valid = CheckValidColorString(stringValue)
  if not valid then
    return {
      1,
      0,
      0,
      1
    }
  end
  local colors = {}
  local _, closeIdx = string.find(stringValue, prefix)
  if closeIdx ~= nil then
    stringValue = string.sub(stringValue, closeIdx + 1)
  end
  colors[1] = string.sub(stringValue, 3, 4)
  colors[2] = string.sub(stringValue, 5, 6)
  colors[3] = string.sub(stringValue, 7, 8)
  colors[4] = string.sub(stringValue, 1, 2)
  for i = 1, #colors do
    colors[i] = tonumber(string.format("0x" .. colors[i]))
    colors[i] = ConvertColor(colors[i])
  end
  return colors
end
function F_COLOR.GetColor(key, isHex)
  if fontColor[key] == nil then
    local info = UIParent:GetFontColor(key)
    if info == nil then
      return {
        1,
        0,
        0,
        1
      }
    end
    fontColor[key] = {
      info[1],
      info[2],
      info[3],
      info[4]
    }
  end
  if isHex then
    return F_COLOR.GetHexColorForString(Dec2Hex(fontColor[key]))
  else
    return fontColor[key]
  end
end
function F_COLOR.ApplyTextColor(widget, color)
  if type(color) ~= "table" then
    if callstackAble then
      X2Util:RaiseLuaCallStack(string.format("[F_COLOR.ApplyTextColor] invalid arg, %s", tostring(color)))
    end
    return
  end
  widget.style:SetColor(color[1], color[2], color[3], color[4])
end
function F_COLOR.GetHudZoneStateFontColorKey(zoneInfo)
  if zoneInfo == nil then
    return nil
  end
  if zoneInfo.isFestivalZone then
    return "zone_festival_green"
  elseif zoneInfo.isConflictZone then
    if zoneInfo.conflictState == HPWS_BATTLE then
      return "tooltip_zone_color_state_high"
    elseif zoneInfo.conflictState == HPWS_WAR then
      return "scarlet_red"
    elseif zoneInfo.conflictState == HPWS_PEACE then
      return "faction_party"
    else
      return "tooltip_zone_color_state_default"
    end
  elseif zoneInfo.isSiegeZone then
    return "zone_dispute_ogange"
  else
    return "white"
  end
end
function F_COLOR.GetMsgZoneStateFontColor(zoneInfo, isHex)
  if zoneInfo == nil then
    return nil
  end
  local key = "msg_zone_color_state_default"
  if zoneInfo.isFestivalZone then
    key = "msg_zone_color_state_festival"
  elseif zoneInfo.isConflictZone then
    if zoneInfo.conflictState == HPWS_WAR then
      key = "msg_zone_color_state_high"
    elseif zoneInfo.conflictState == HPWS_PEACE then
      key = "msg_zone_color_state_peace"
    end
  elseif zoneInfo.isNuiaProtectedZone or zoneInfo.isHariharaProtectedZone or zoneInfo.isPeaceZone then
    key = "msg_zone_color_state_peace"
  end
  if not isHex then
    return key
  end
  return F_COLOR.GetColor(key, true)
end
function F_COLOR.GetMapZoneStateFontColorKey(zoneInfo)
  if zoneInfo == nil then
    return
  end
  if zoneInfo.isFestivalZone then
    return "map_zone_color_state_festival"
  elseif zoneInfo.isConflictZone then
    if zoneInfo.conflictState == HPWS_BATTLE then
      return "map_zone_color_state_default"
    elseif zoneInfo.conflictState == HPWS_WAR then
      return "map_zone_color_state_high"
    elseif zoneInfo.conflictState == HPWS_PEACE then
      return "map_zone_color_state_peace"
    else
      return "map_zone_color_state_default"
    end
  elseif zoneInfo.isSiegeZone then
    return "map_zone_color_state_default"
  elseif zoneInfo.isNuiaProtectedZone or zoneInfo.isHariharaProtectedZone or zoneInfo.isPeaceZone then
    return "map_zone_color_state_peace"
  else
    return "map_zone_color_state_default"
  end
end
function F_COLOR.GetTooltipZoneStateFontColorHexFormat(zoneInfo)
  if zoneInfo == nil then
    return
  end
  local key = "tooltip_zone_color_state_default"
  if zoneInfo.isFestivalZone then
    key = "bright_green"
  elseif zoneInfo.isConflictZone then
    if zoneInfo.conflictState == HPWS_WAR then
      key = "tooltip_zone_color_state_high"
    elseif zoneInfo.conflictState == HPWS_PEACE then
      key = "tooltip_zone_color_state_peace"
    end
  elseif zoneInfo.isNuiaProtectedZone or zoneInfo.isHariharaProtectedZone or zoneInfo.isPeaceZone then
    key = "tooltip_zone_color_state_peace"
  end
  return F_COLOR.GetColor(key, true)
end
function F_COLOR.GetMapZoneStateTextureColorKey(zoneInfo)
  if zoneInfo == nil then
    return "default_gray_65"
  elseif zoneInfo.isFestivalZone then
    return "festival_green_65"
  elseif zoneInfo.isConflictZone then
    if zoneInfo.conflictState == HPWS_BATTLE then
      return "danger_red_65"
    elseif zoneInfo.conflictState == HPWS_WAR then
      return "war_red_65"
    elseif zoneInfo.conflictState == HPWS_PEACE then
      return "peace_blue_65"
    else
      return "dispute_orange_65"
    end
  elseif zoneInfo.isSiegeZone then
    return "danger_red_65"
  elseif zoneInfo.isNuiaProtectedZone or zoneInfo.isHariharaProtectedZone or zoneInfo.isPeaceZone then
    return "peace_blue_65"
  else
    return "danger_red_65"
  end
end
function F_COLOR.GetUnitGradeColorHexFormat(grade)
  if grade == nil then
    return F_COLOR.GetColor("white", true)
  end
  local colorTable = {
    weak = F_COLOR.GetColor("unit_grade_weak", true),
    normal = F_COLOR.GetColor("middle_brown", true),
    strong = F_COLOR.GetColor("unit_grade_strong", true),
    elite = F_COLOR.GetColor("bright_blue", true),
    boss_c = F_COLOR.GetColor("unit_grade_boss_c", true),
    boss_b = F_COLOR.GetColor("unit_grade_boss_b", true),
    boss_a = F_COLOR.GetColor("unit_grade_boss_a", true),
    boss_s = F_COLOR.GetColor("unit_grade_boss_s", true)
  }
  local color = colorTable[grade]
  if color == nil then
    return F_COLOR.GetColor("white", true)
  end
  return color
end
function F_COLOR.GetPriceColorKey(priceType)
  local layoutSet = GetLayoutSetComponents()
  if priceType == PRICE_TYPE_AA_CASH then
    return layoutSet.aaCashColor
  elseif priceType == PRICE_TYPE_AA_POINT then
    return "default"
  elseif priceType == PRICE_TYPE_BM_MILEAGE then
    return "deep_orange"
  elseif priceType == PRICE_TYPE_AA_BONUS_CASH then
    return "rose_pink"
  elseif priceType == PRICE_TYPE_AA_CASH_AND_BONUS_CASH then
    return layoutSet.aaCashColor
  else
    return "blue"
  end
end
function F_COLOR.ApplyTextureColor(texture, color)
  texture:SetColor(color[1], color[2], color[3], color[4])
end
function F_COLOR.SetHexFormatToGradeColor(gradeColor)
  return string.format("|c%s", gradeColor)
end
